package com.fenglin.springboottest.dto;

import jakarta.validation.constraints.NotBlank;

/**
 * 后台管理员登录请求。
 * 后台管理系统<b>只有登录功能，没有注册功能</b>，账号由数据库/初始化器预置。
 */
public class AdminLoginRequest {

    @NotBlank(message = "请输入管理员账号")
    private String account;

    @NotBlank(message = "请输入密码")
    private String password;

    /** 是否记住登录状态（影响令牌有效期） */
    private Boolean remember;

    public String getAccount() {
        return account;
    }

    public void setAccount(String account) {
        this.account = account;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public Boolean getRemember() {
        return remember;
    }

    public void setRemember(Boolean remember) {
        this.remember = remember;
    }
}
