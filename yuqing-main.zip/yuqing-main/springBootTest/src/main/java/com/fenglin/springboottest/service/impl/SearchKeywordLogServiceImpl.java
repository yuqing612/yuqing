package com.fenglin.springboottest.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.fenglin.springboottest.entity.SearchKeywordLog;
import com.fenglin.springboottest.mapper.SearchKeywordLogMapper;
import com.fenglin.springboottest.service.SearchKeywordLogService;
import com.fenglin.springboottest.vo.HotKeywordVO;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import java.time.LocalDateTime;
import java.util.List;

@Service
public class SearchKeywordLogServiceImpl
        extends ServiceImpl<SearchKeywordLogMapper, SearchKeywordLog>
        implements SearchKeywordLogService {

    /** 关键词长度上限，超长截断，避免污染统计表 */
    private static final int MAX_KEYWORD_LENGTH = 32;

    @Override
    public void record(String keyword, int resultCount) {
        if (!StringUtils.hasText(keyword)) {
            return;
        }
        String trimmed = keyword.trim();
        if (trimmed.length() > MAX_KEYWORD_LENGTH) {
            trimmed = trimmed.substring(0, MAX_KEYWORD_LENGTH);
        }
        String normalized = normalize(trimmed);
        if (normalized.isEmpty()) {
            return;
        }

        SearchKeywordLog existing = this.getOne(new LambdaQueryWrapper<SearchKeywordLog>()
                .eq(SearchKeywordLog::getNormalizedKey, normalized)
                .last("LIMIT 1"));
        LocalDateTime now = LocalDateTime.now();
        if (existing == null) {
            SearchKeywordLog row = new SearchKeywordLog();
            row.setKeyword(trimmed);
            row.setNormalizedKey(normalized);
            row.setSearchCount(1);
            row.setResultCount(resultCount);
            row.setLastSearchTime(now);
            this.save(row);
        } else {
            SearchKeywordLog update = new SearchKeywordLog();
            update.setId(existing.getId());
            update.setKeyword(trimmed);
            update.setSearchCount((existing.getSearchCount() == null ? 0 : existing.getSearchCount()) + 1);
            update.setResultCount(resultCount);
            update.setLastSearchTime(now);
            this.updateById(update);
        }
    }

    @Override
    public List<HotKeywordVO> hot(int limit) {
        int size = limit <= 0 ? 10 : Math.min(limit, 50);
        List<SearchKeywordLog> rows = this.list(new LambdaQueryWrapper<SearchKeywordLog>()
                .orderByDesc(SearchKeywordLog::getSearchCount)
                .orderByDesc(SearchKeywordLog::getLastSearchTime)
                .last("LIMIT " + size));
        return rows.stream().map(r -> {
            HotKeywordVO vo = new HotKeywordVO();
            vo.setKeyword(r.getKeyword());
            vo.setCount(r.getSearchCount());
            vo.setResultCount(r.getResultCount());
            return vo;
        }).collect(java.util.stream.Collectors.toList());
    }

    @Override
    public List<String> suggest(String keyword, int limit) {
        if (!StringUtils.hasText(keyword)) {
            return List.of();
        }
        int size = limit <= 0 ? 8 : Math.min(limit, 20);
        String normalized = normalize(keyword.trim());
        if (normalized.isEmpty()) {
            return List.of();
        }
        List<SearchKeywordLog> rows = this.list(new LambdaQueryWrapper<SearchKeywordLog>()
                .likeRight(SearchKeywordLog::getNormalizedKey, normalized)
                .orderByDesc(SearchKeywordLog::getSearchCount)
                .last("LIMIT " + size));
        return rows.stream().map(SearchKeywordLog::getKeyword).distinct().collect(java.util.stream.Collectors.toList());
    }

    /** 归一化：小写 + 去空白，用于聚合同一关键词 */
    private static String normalize(String keyword) {
        return keyword.toLowerCase().replaceAll("\\s+", "");
    }
}
