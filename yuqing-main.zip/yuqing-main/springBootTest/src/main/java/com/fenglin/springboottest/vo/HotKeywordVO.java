package com.fenglin.springboottest.vo;

import com.fasterxml.jackson.annotation.JsonInclude;

/**
 * 热门搜索词。
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public class HotKeywordVO {

    /** 关键词 */
    private String keyword;

    /** 搜索次数 */
    private Integer count;

    /** 最近一次命中的结果数 */
    private Integer resultCount;

    public String getKeyword() {
        return keyword;
    }

    public void setKeyword(String keyword) {
        this.keyword = keyword;
    }

    public Integer getCount() {
        return count;
    }

    public void setCount(Integer count) {
        this.count = count;
    }

    public Integer getResultCount() {
        return resultCount;
    }

    public void setResultCount(Integer resultCount) {
        this.resultCount = resultCount;
    }
}
