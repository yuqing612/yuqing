package com.fenglin.springboottest.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

/**
 * 后台新增/编辑番剧放送时间表的请求体。
 */
public class ScheduleForm {

    @NotNull(message = "请选择番剧")
    private Long bangumiId;

    /** 放送星期：1=周一 … 7=周日 */
    @NotNull(message = "请选择放送星期")
    private Integer weekday;

    /** 放送时间 HH:mm */
    @NotBlank(message = "请填写放送时间")
    private String airTime;

    /** 当日更新至第几话 */
    private Integer episode;

    public Long getBangumiId() {
        return bangumiId;
    }

    public void setBangumiId(Long bangumiId) {
        this.bangumiId = bangumiId;
    }

    public Integer getWeekday() {
        return weekday;
    }

    public void setWeekday(Integer weekday) {
        this.weekday = weekday;
    }

    public String getAirTime() {
        return airTime;
    }

    public void setAirTime(String airTime) {
        this.airTime = airTime;
    }

    public Integer getEpisode() {
        return episode;
    }

    public void setEpisode(Integer episode) {
        this.episode = episode;
    }
}
