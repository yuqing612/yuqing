package com.fenglin.springboottest.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.fenglin.springboottest.entity.Bangumi;
import com.fenglin.springboottest.entity.Category;
import com.fenglin.springboottest.entity.Video;
import com.fenglin.springboottest.mapper.BangumiMapper;
import com.fenglin.springboottest.mapper.CategoryMapper;
import com.fenglin.springboottest.mapper.VideoMapper;
import com.fenglin.springboottest.service.CategoryService;
import com.fenglin.springboottest.vo.CategoryVO;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

@Service
public class CategoryServiceImpl extends ServiceImpl<CategoryMapper, Category> implements CategoryService {

    private final VideoMapper videoMapper;
    private final BangumiMapper bangumiMapper;

    public CategoryServiceImpl(VideoMapper videoMapper, BangumiMapper bangumiMapper) {
        this.videoMapper = videoMapper;
        this.bangumiMapper = bangumiMapper;
    }

    @Override
    public List<CategoryVO> tree(String module, boolean countContent) {
        LambdaQueryWrapper<Category> qw = new LambdaQueryWrapper<Category>()
                .eq(Category::getEnabled, 1)
                .orderByAsc(Category::getSortOrder)
                .orderByAsc(Category::getId);
        if (StringUtils.hasText(module) && !"all".equalsIgnoreCase(module.trim())) {
            qw.in(Category::getModule, module.trim(), "all");
        }
        List<Category> all = this.list(qw);
        if (all.isEmpty()) {
            return List.of();
        }

        // 各分类的直接内容数（视频 + 番剧）
        Map<Long, Long> counts = countContent ? loadContentCounts() : Map.of();

        // 先建 id -> VO 映射，便于挂 children
        Map<Long, CategoryVO> voMap = new LinkedHashMap<>();
        for (Category c : all) {
            CategoryVO vo = new CategoryVO();
            vo.setId(c.getId());
            vo.setParentId(c.getParentId());
            vo.setName(c.getName());
            vo.setSlug(c.getSlug());
            vo.setModule(c.getModule());
            vo.setLevel(c.getLevel());
            vo.setIcon(c.getIcon());
            vo.setColor(c.getColor());
            vo.setDescription(c.getDescription());
            vo.setSortOrder(c.getSortOrder());
            voMap.put(c.getId(), vo);
        }

        // 挂子分类
        List<CategoryVO> roots = new ArrayList<>();
        for (Category c : all) {
            CategoryVO vo = voMap.get(c.getId());
            CategoryVO parent = voMap.get(c.getParentId());
            if (parent != null) {
                if (parent.getChildren() == null) {
                    parent.setChildren(new ArrayList<>());
                }
                parent.getChildren().add(vo);
            } else {
                roots.add(vo);
            }
        }

        // 统计直接数量与（含子孙）总数
        if (countContent) {
            for (CategoryVO vo : voMap.values()) {
                long direct = counts.getOrDefault(vo.getId(), 0L);
                vo.setContentCount(direct);
                vo.setTotalCount(direct + sumDescendants(vo, voMap, counts));
            }
        }
        return roots;
    }

    /** 递归累加子孙分类的内容数 */
    private long sumDescendants(CategoryVO node, Map<Long, CategoryVO> voMap, Map<Long, Long> counts) {
        long sum = 0;
        List<CategoryVO> children = node.getChildren();
        if (children == null) {
            return sum;
        }
        for (CategoryVO child : children) {
            sum += counts.getOrDefault(child.getId(), 0L);
            sum += sumDescendants(child, voMap, counts);
        }
        return sum;
    }

    /** 一次性统计所有分类下的内容数量，避免 N+1 查询 */
    private Map<Long, Long> loadContentCounts() {
        Map<Long, Long> counts = new HashMap<>();

        List<Video> videos = videoMapper.selectList(new LambdaQueryWrapper<Video>()
                .select(Video::getCategoryId)
                .isNotNull(Video::getCategoryId));
        for (Video v : videos) {
            counts.merge(v.getCategoryId(), 1L, Long::sum);
        }

        List<Bangumi> bangumis = bangumiMapper.selectList(new LambdaQueryWrapper<Bangumi>()
                .select(Bangumi::getCategoryId)
                .isNotNull(Bangumi::getCategoryId));
        for (Bangumi b : bangumis) {
            counts.merge(b.getCategoryId(), 1L, Long::sum);
        }
        return counts;
    }

    @Override
    public List<Long> expandToDescendants(Long categoryId) {
        if (categoryId == null) {
            return List.of();
        }
        Category target = this.getById(categoryId);
        if (target == null) {
            return List.of();
        }
        // 自身
        List<Long> result = new ArrayList<>();
        result.add(categoryId);

        // 逐层展开子分类（兼容未来多层）
        List<Long> frontier = new ArrayList<>(result);
        while (!frontier.isEmpty()) {
            List<Category> children = this.list(new LambdaQueryWrapper<Category>()
                    .in(Category::getParentId, frontier)
                    .eq(Category::getEnabled, 1));
            if (children.isEmpty()) {
                break;
            }
            List<Long> next = new ArrayList<>();
            for (Category c : children) {
                if (!result.contains(c.getId())) {
                    result.add(c.getId());
                    next.add(c.getId());
                }
            }
            frontier = next;
        }
        return result;
    }

    @Override
    public Map<Long, Category> mapByIds(List<Long> ids) {
        if (ids == null || ids.isEmpty()) {
            return Map.of();
        }
        return this.listByIds(ids).stream()
                .collect(Collectors.toMap(Category::getId, Function.identity(), (a, b) -> a));
    }

    @Override
    public String parentNameOf(Long categoryId) {
        if (categoryId == null) {
            return null;
        }
        Category child = this.getById(categoryId);
        if (child == null || child.getParentId() == null || child.getParentId() == 0) {
            return null;
        }
        Category parent = this.getById(child.getParentId());
        return parent == null ? null : parent.getName();
    }

    /** 分类路径：如 "动画 / 治愈"，用于搜索结果回显 */
    public String pathOf(Long categoryId) {
        if (categoryId == null) {
            return null;
        }
        Category child = this.getById(categoryId);
        if (child == null) {
            return null;
        }
        String parent = parentNameOf(categoryId);
        return parent == null ? child.getName() : parent + " / " + child.getName();
    }

    /** 供首页统计使用的分类数 */
    public long countEnabled(String module) {
        LambdaQueryWrapper<Category> qw = new LambdaQueryWrapper<Category>().eq(Category::getEnabled, 1);
        if (StringUtils.hasText(module) && !"all".equalsIgnoreCase(module.trim())) {
            qw.in(Category::getModule, module.trim(), "all");
        }
        Long c = this.count(qw);
        return c == null ? 0L : c;
    }

    /** 防御性工具：空集合 */
    static List<Long> emptyIds() {
        return Collections.emptyList();
    }
}
