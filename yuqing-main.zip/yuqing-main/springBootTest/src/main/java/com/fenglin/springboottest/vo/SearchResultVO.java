package com.fenglin.springboottest.vo;

import com.fasterxml.jackson.annotation.JsonInclude;

import java.util.List;

/**
 * 搜索结果分页结构。
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public class SearchResultVO {

    /** 命中条目 */
    private List<SearchItemVO> list;

    /** 命中总数 */
    private Long total;

    /** 当前页码，从 1 开始 */
    private Long page;

    /** 每页条数 */
    private Long size;

    /** 总页数 */
    private Long pages;

    /** 本次搜索的关键词（回显用） */
    private String keyword;

    /** 应用的筛选条件回显 */
    private SearchFilterVO filter;

    /** 搜索耗时（毫秒） */
    private Long cost;

    public List<SearchItemVO> getList() {
        return list;
    }

    public void setList(List<SearchItemVO> list) {
        this.list = list;
    }

    public Long getTotal() {
        return total;
    }

    public void setTotal(Long total) {
        this.total = total;
    }

    public Long getPage() {
        return page;
    }

    public void setPage(Long page) {
        this.page = page;
    }

    public Long getSize() {
        return size;
    }

    public void setSize(Long size) {
        this.size = size;
    }

    public Long getPages() {
        return pages;
    }

    public void setPages(Long pages) {
        this.pages = pages;
    }

    public String getKeyword() {
        return keyword;
    }

    public void setKeyword(String keyword) {
        this.keyword = keyword;
    }

    public SearchFilterVO getFilter() {
        return filter;
    }

    public void setFilter(SearchFilterVO filter) {
        this.filter = filter;
    }

    public Long getCost() {
        return cost;
    }

    public void setCost(Long cost) {
        this.cost = cost;
    }
}
