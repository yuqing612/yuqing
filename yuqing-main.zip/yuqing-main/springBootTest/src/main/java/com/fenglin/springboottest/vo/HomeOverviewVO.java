package com.fenglin.springboottest.vo;

import com.fasterxml.jackson.annotation.JsonInclude;

import java.util.List;

/**
 * 首页聚合数据：一次请求返回首页全部板块，
 * 避免前端首屏并发多个接口导致的瀑布请求。
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public class HomeOverviewVO {

    /** Hero 轮播位 */
    private List<BannerVO> banners;

    /** 每日推荐视频 */
    private List<VideoVO> dailyVideos;

    /** 热播排行（带 rank） */
    private List<VideoVO> rankVideos;

    /** 分类导航树（视频分区） */
    private List<CategoryVO> categories;

    /** 番剧新番墙 */
    private List<BangumiVO> bangumis;

    /** 番剧时间表 */
    private ScheduleVO schedule;

    /** 热门搜索词 */
    private List<HotKeywordVO> hotKeywords;

    /** 首页统计：视频数 / 番剧数 / 分类数 */
    private HomeStatVO stat;

    public List<BannerVO> getBanners() {
        return banners;
    }

    public void setBanners(List<BannerVO> banners) {
        this.banners = banners;
    }

    public List<VideoVO> getDailyVideos() {
        return dailyVideos;
    }

    public void setDailyVideos(List<VideoVO> dailyVideos) {
        this.dailyVideos = dailyVideos;
    }

    public List<VideoVO> getRankVideos() {
        return rankVideos;
    }

    public void setRankVideos(List<VideoVO> rankVideos) {
        this.rankVideos = rankVideos;
    }

    public List<CategoryVO> getCategories() {
        return categories;
    }

    public void setCategories(List<CategoryVO> categories) {
        this.categories = categories;
    }

    public List<BangumiVO> getBangumis() {
        return bangumis;
    }

    public void setBangumis(List<BangumiVO> bangumis) {
        this.bangumis = bangumis;
    }

    public ScheduleVO getSchedule() {
        return schedule;
    }

    public void setSchedule(ScheduleVO schedule) {
        this.schedule = schedule;
    }

    public List<HotKeywordVO> getHotKeywords() {
        return hotKeywords;
    }

    public void setHotKeywords(List<HotKeywordVO> hotKeywords) {
        this.hotKeywords = hotKeywords;
    }

    public HomeStatVO getStat() {
        return stat;
    }

    public void setStat(HomeStatVO stat) {
        this.stat = stat;
    }
}
