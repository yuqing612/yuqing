package com.fenglin.springboottest.vo;

import com.fasterxml.jackson.annotation.JsonInclude;

import java.util.List;

/**
 * 视频对外视图对象，字段与前端 anime-login-vue 的每日推荐数据结构一一对应。
 * tags 为字符串数组，fav 为布尔，rank 仅在排行接口返回（其余接口为 null，不序列化）。
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public class VideoVO {

    private Long id;
    private String title;
    private String uploader;
    private String views;
    private Long play;
    private String danmaku;
    private String duration;
    private List<String> tags;
    private String desc;
    private Boolean fav;
    private String grad;
    private String coverUrl;
    private String src;
    private Integer rank;

    /**
     * 播放源类型：native 原生直链视频 / tencent 腾讯视频 / bilibili 哔哩哔哩。
     * 为 null 时前端按 native 处理（兼容历史数据）。
     */
    private String sourceType;

    /** 腾讯视频 VID（sourceType = tencent 时有效） */
    private String vid;

    /** 哔哩哔哩 BV 号（sourceType = bilibili 时有效） */
    private String bvid;

    /** 动漫共和国作品 id（sourceType = omofun 时有效） */
    private String omofunId;

    /**
     * m3u8 直链（sourceType = omofun 时有效）。
     * 前端用 hls.js 直连播放，支持清晰度分级切换。
     */
    private String m3u8Url;

    /**
     * 分集播放源列表（video_episode 表）。
     * 一条视频若对应一部番剧的多个正片分集（如《赛马娘 第二季》13 话），
     * 这里按集下发，前端据此渲染选集面板并逐集切换播放源。
     * 没有配置分集时为空列表，前端隐藏选集面板。
     */
    private List<VideoEpisodeVO> episodeList;

    /**
     * 是否每日推荐：1 推荐，0 否。
     * 仅后台管理接口返回（首页接口不关心该字段，故为 null 时不序列化）。
     */
    private Integer dailyPick;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getUploader() {
        return uploader;
    }

    public void setUploader(String uploader) {
        this.uploader = uploader;
    }

    public String getViews() {
        return views;
    }

    public void setViews(String views) {
        this.views = views;
    }

    public Long getPlay() {
        return play;
    }

    public void setPlay(Long play) {
        this.play = play;
    }

    public String getDanmaku() {
        return danmaku;
    }

    public void setDanmaku(String danmaku) {
        this.danmaku = danmaku;
    }

    public String getDuration() {
        return duration;
    }

    public void setDuration(String duration) {
        this.duration = duration;
    }

    public List<String> getTags() {
        return tags;
    }

    public void setTags(List<String> tags) {
        this.tags = tags;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }

    public Boolean getFav() {
        return fav;
    }

    public void setFav(Boolean fav) {
        this.fav = fav;
    }

    public String getGrad() {
        return grad;
    }

    public void setGrad(String grad) {
        this.grad = grad;
    }

    public String getCoverUrl() {
        return coverUrl;
    }

    public void setCoverUrl(String coverUrl) {
        this.coverUrl = coverUrl;
    }

    public String getSrc() {
        return src;
    }

    public void setSrc(String src) {
        this.src = src;
    }

    public Integer getRank() {
        return rank;
    }

    public void setRank(Integer rank) {
        this.rank = rank;
    }

    public String getSourceType() {
        return sourceType;
    }

    public void setSourceType(String sourceType) {
        this.sourceType = sourceType;
    }

    public String getVid() {
        return vid;
    }

    public void setVid(String vid) {
        this.vid = vid;
    }

    public String getBvid() {
        return bvid;
    }

    public void setBvid(String bvid) {
        this.bvid = bvid;
    }

    public String getOmofunId() {
        return omofunId;
    }

    public void setOmofunId(String omofunId) {
        this.omofunId = omofunId;
    }

    public String getM3u8Url() {
        return m3u8Url;
    }

    public void setM3u8Url(String m3u8Url) {
        this.m3u8Url = m3u8Url;
    }

    public List<VideoEpisodeVO> getEpisodeList() {
        return episodeList;
    }

    public void setEpisodeList(List<VideoEpisodeVO> episodeList) {
        this.episodeList = episodeList;
    }

    public Integer getDailyPick() {
        return dailyPick;
    }

    public void setDailyPick(Integer dailyPick) {
        this.dailyPick = dailyPick;
    }
}
