package com.fenglin.springboottest.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

/**
 * 跨域配置：允许 Vite 开发服务器（5173）直连后端 API。
 * 前端同时配置了 /api 代理，正常开发走代理时不会触发跨域，此配置作为直连兜底。
 */
@Configuration
public class CorsConfig implements WebMvcConfigurer {

    @Override
    public void addCorsMappings(CorsRegistry registry) {
        registry.addMapping("/api/**")
                // 同网段手机 / 模拟器直连后端调试时，Origin 里的主机名是本机的
                // 局域网 IP。这里按模式放行 5173 端口的来源，避免本机 IP 变动
                // （DHCP 续租、换网络、换网卡）后又要改代码重新编译。
                // 只放行本机与私有网段，陌生域名仍然拒绝。
                .allowedOriginPatterns(
                        "http://localhost:[*]",
                        "http://127.0.0.1:[*]",
                        // 本机以太网 IPv4（2026-11-11 核对：192.168.68.15）
                        "http://192.168.68.15:[*]",
                        // 其余同网段私有 IP 兜底，避免 IP 变动又要改代码重新编译
                        "http://192.168.*:[*]",
                        "http://10.*:[*]")
                .allowedMethods("GET", "POST", "PUT", "DELETE", "OPTIONS")
                .allowedHeaders("*")
                .maxAge(3600);
    }
}
