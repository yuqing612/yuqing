package com.fenglin.springboottest.service;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.JwtException;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.security.Keys;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import javax.crypto.SecretKey;
import java.nio.charset.StandardCharsets;
import java.util.Date;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * 后台管理员 JWT 令牌服务（HS256）。
 *
 * <p>与前台用户的 {@link AuthTokenService} 使用<b>不同的签名密钥</b>，
 * 因此管理员令牌无法被前台接口接受，前台令牌也无法访问后台接口，两套会话互不串味。
 * 登出通过 jti 黑名单实现，黑名单条目随令牌过期自动清理。
 */
@Service
public class AdminTokenService {

    private final SecretKey key;
    private final long expireRemember;
    private final long expireSession;

    /** 已登出但未过期的令牌 jti -> 过期时间戳 */
    private final Map<String, Long> blacklist = new ConcurrentHashMap<>();

    /**
     * 管理员 id -> 会话纪元号。
     * 修改密码时递增纪元号，使改密前签发的所有后台令牌立即失效。
     */
    private final Map<Long, Long> epochs = new ConcurrentHashMap<>();

    public AdminTokenService(
            @Value("${app.jwt.secret}") String secret,
            @Value("${app.jwt.expire-remember:604800000}") long expireRemember,
            @Value("${app.jwt.expire-session:43200000}") long expireSession) {
        // 加固定后缀派生后台专用密钥，保证与前台密钥不同
        this.key = Keys.hmacShaKeyFor((secret + ":admin-backend").getBytes(StandardCharsets.UTF_8));
        this.expireRemember = expireRemember;
        this.expireSession = expireSession;
    }

    /** 登录成功后签发后台令牌，subject 为管理员 id */
    public String create(Long adminId, boolean remember) {
        cleanBlacklist();
        long ttl = remember ? expireRemember : expireSession;
        Date now = new Date();
        return Jwts.builder()
                .id(UUID.randomUUID().toString().replace("-", ""))
                .subject(String.valueOf(adminId))
                .claim("role", "admin")
                .claim("ep", currentEpoch(adminId))
                .issuedAt(now)
                .expiration(new Date(now.getTime() + ttl))
                .signWith(key)
                .compact();
    }

    /** 校验后台令牌，返回管理员 id；无效、过期、已登出或改密前签发均返回 null */
    public Long resolve(String token) {
        if (token == null || token.isBlank()) {
            return null;
        }
        try {
            Claims claims = Jwts.parser()
                    .verifyWith(key)
                    .build()
                    .parseSignedClaims(token)
                    .getPayload();
            if (claims.getId() != null && blacklist.containsKey(claims.getId())) {
                return null;
            }
            if (!"admin".equals(claims.get("role", String.class))) {
                return null;
            }
            Long adminId = Long.valueOf(claims.getSubject());
            // 纪元号不一致 = 该令牌是改密之前签发的，立即失效
            Long tokenEpoch = claims.get("ep", Long.class);
            if (tokenEpoch == null || tokenEpoch != currentEpoch(adminId)) {
                return null;
            }
            return adminId;
        } catch (JwtException | IllegalArgumentException e) {
            return null;
        }
    }

    /** 登出：把 jti 加入黑名单直至令牌原本过期 */
    public void revoke(String token) {
        if (token == null || token.isBlank()) {
            return;
        }
        try {
            Claims claims = Jwts.parser()
                    .verifyWith(key)
                    .build()
                    .parseSignedClaims(token)
                    .getPayload();
            if (claims.getId() != null && claims.getExpiration() != null) {
                blacklist.put(claims.getId(), claims.getExpiration().getTime());
            }
        } catch (JwtException | IllegalArgumentException ignored) {
            /* 无效令牌无需处理 */
        }
    }

    private void cleanBlacklist() {
        long now = System.currentTimeMillis();
        blacklist.entrySet().removeIf(e -> e.getValue() < now);
    }

    /** 读取管理员当前会话纪元号，没有记录时视为 0 */
    private long currentEpoch(Long adminId) {
        return epochs.getOrDefault(adminId, 0L);
    }

    /**
     * 修改密码后调用：递增该管理员的会话纪元号，
     * 使其此前签发的所有后台令牌立即失效，需重新登录。
     */
    public void invalidateSessions(Long adminId) {
        if (adminId == null) {
            return;
        }
        epochs.merge(adminId, 1L, Long::sum);
    }
}
