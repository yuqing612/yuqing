package com.fenglin.springboottest.config;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.fenglin.springboottest.entity.SysUser;
import com.fenglin.springboottest.mapper.BangumiMapper;
import com.fenglin.springboottest.mapper.SysUserMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Component;

/**
 * 启动时自动写入一个测试账号（不存在才插入），密码用 BCrypt 加密。
 * 测试账号：sakura / Test@123456（也可用邮箱 sakura@yuqing.dev 登录）
 */
@Component
public class DataInitializer implements CommandLineRunner {

    private static final Logger log = LoggerFactory.getLogger(DataInitializer.class);

    private final SysUserMapper userMapper;
    private final BangumiMapper bangumiMapper;
    private final BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();

    public DataInitializer(SysUserMapper userMapper, BangumiMapper bangumiMapper) {
        this.userMapper = userMapper;
        this.bangumiMapper = bangumiMapper;
    }

    @Override
    public void run(String... args) {
        if (bangumiMapper.selectCount(null) == 0) {
            log.warn("bangumi 表为空，首页番剧板块将没有数据，请执行 yuqing_db.sql 导入种子数据");
        }
        Long count = userMapper.selectCount(new LambdaQueryWrapper<SysUser>()
                .eq(SysUser::getUsername, "sakura"));
        if (count == null || count == 0) {
            SysUser user = new SysUser();
            user.setUsername("sakura");
            user.setEmail("sakura@yuqing.dev");
            user.setPassword(passwordEncoder.encode("Test@123456"));
            user.setNickname("桜守");
            user.setStatus(1);
            user.setRole("ADMIN");
            userMapper.insert(user);
            log.info("已初始化后台管理员账号 sakura / Test@123456（角色 ADMIN）");
        } else {
            // 已存在：确保其为管理员（兼容升级场景，role 列可能刚通过 admin_role.sql 补齐）
            try {
                SysUser admin = new SysUser();
                admin.setRole("ADMIN");
                userMapper.update(admin, new LambdaQueryWrapper<SysUser>()
                        .eq(SysUser::getUsername, "sakura"));
                log.info("已将现有账号 sakura 提升为管理员（角色 ADMIN）");
            } catch (Exception e) {
                log.warn("更新 sakura 角色失败，请确认已执行 admin_role.sql 迁移：{}", e.getMessage());
            }
        }
    }
}
