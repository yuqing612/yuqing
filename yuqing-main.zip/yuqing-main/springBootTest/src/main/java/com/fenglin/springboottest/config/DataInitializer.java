package com.fenglin.springboottest.config;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.fenglin.springboottest.entity.AdminUser;
import com.fenglin.springboottest.entity.SysUser;
import com.fenglin.springboottest.mapper.AdminUserMapper;
import com.fenglin.springboottest.mapper.BangumiMapper;
import com.fenglin.springboottest.mapper.SysUserMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.CommandLineRunner;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Component;

/**
 * 启动时自动完成两件事：
 * 1. 建表：admin_user 不在初始 SQL 脚本里，这里用 JDBC 自动建表，
 *    保证「拉起后端 → 打开后台 → 用默认账号登录」这条链路开箱可用；
 * 2. 预置账号：前台测试账号 sakura / Test@123456，
 *    后台管理员账号见 app.admin.username / app.admin.password
 *    （后台无注册入口，只能靠预置账号登录）。
 *
 * <p>管理员初始凭证放在配置文件而非硬编码，便于部署时按环境覆盖；
 * 生产环境建议用环境变量注入：APP_ADMIN_USERNAME / APP_ADMIN_PASSWORD。
 */
@Component
public class DataInitializer implements CommandLineRunner {

    private static final Logger log = LoggerFactory.getLogger(DataInitializer.class);

    /** 预置的后台管理员账号与初始密码（后台无注册入口，只能靠预置账号登录） */
    private final String adminUsername;
    private final String adminPassword;

    private final SysUserMapper userMapper;
    private final BangumiMapper bangumiMapper;
    private final AdminUserMapper adminUserMapper;
    private final JdbcTemplate jdbcTemplate;
    private final BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();

    public DataInitializer(SysUserMapper userMapper,
                           BangumiMapper bangumiMapper,
                           AdminUserMapper adminUserMapper,
                           JdbcTemplate jdbcTemplate,
                           @Value("${app.admin.username:yuqing}") String adminUsername,
                           @Value("${app.admin.password:11110612Yy@1}") String adminPassword) {
        this.userMapper = userMapper;
        this.bangumiMapper = bangumiMapper;
        this.adminUserMapper = adminUserMapper;
        this.jdbcTemplate = jdbcTemplate;
        this.adminUsername = adminUsername;
        this.adminPassword = adminPassword;
    }

    @Override
    public void run(String... args) {
        createAdminTableIfAbsent();
        initAdminAccount();
        initFrontUser();
    }

    /** 自动建 admin_user 表（幂等，已存在则跳过） */
    private void createAdminTableIfAbsent() {
        try {
            jdbcTemplate.execute("""
                    CREATE TABLE IF NOT EXISTS admin_user (
                        id          BIGINT       NOT NULL AUTO_INCREMENT COMMENT '主键',
                        username    VARCHAR(32)  NOT NULL                COMMENT '登录用户名',
                        password    VARCHAR(100) NOT NULL                COMMENT '密码（BCrypt 加密存储）',
                        nickname    VARCHAR(32)  DEFAULT NULL            COMMENT '展示昵称',
                        status      TINYINT      NOT NULL DEFAULT 1      COMMENT '状态：1 正常，0 禁用',
                        create_time DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
                        update_time DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP
                                                     ON UPDATE CURRENT_TIMESTAMP              COMMENT '更新时间',
                        PRIMARY KEY (id),
                        UNIQUE KEY uk_admin_username (username)
                    ) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COMMENT = '后台管理员表'
                    """);
        } catch (Exception e) {
            log.warn("admin_user 表自动创建失败，请手动执行 sql/yuqing_db.sql 中的建表语句：{}", e.getMessage());
        }
    }

    /** 预置后台管理员（后台无注册入口，必须有初始账号） */
    private void initAdminAccount() {
        try {
            Long count = adminUserMapper.selectCount(new LambdaQueryWrapper<AdminUser>()
                    .eq(AdminUser::getUsername, adminUsername));
            if (count != null && count > 0) {
                return;
            }
            AdminUser admin = new AdminUser();
            admin.setUsername(adminUsername);
            admin.setPassword(passwordEncoder.encode(adminPassword));
            admin.setNickname("站长");
            admin.setStatus(1);
            adminUserMapper.insert(admin);
            log.info("已初始化后台管理员账号 {} / {}", adminUsername, adminPassword);
        } catch (Exception e) {
            log.warn("后台管理员账号初始化失败，请确认 admin_user 表已创建：{}", e.getMessage());
        }
    }

    /** 预置前台测试账号 */
    private void initFrontUser() {
        try {
            if (bangumiMapper.selectCount(null) == 0) {
                log.warn("bangumi 表为空，首页番剧板块将没有数据，请执行 yuqing_db.sql 导入种子数据");
            }
        } catch (Exception e) {
            log.warn("bangumi 表不存在，跳过番剧种子检查（请执行 yuqing_db.sql 导入种子数据）：{}", e.getMessage());
        }
        Long count = userMapper.selectCount(new LambdaQueryWrapper<SysUser>()
                .eq(SysUser::getUsername, "sakura"));
        if (count != null && count > 0) {
            return;
        }
        SysUser user = new SysUser();
        user.setUsername("sakura");
        user.setEmail("sakura@yuqing.dev");
        user.setPassword(passwordEncoder.encode("Test@123456"));
        user.setNickname("桜守");
        user.setStatus(1);
        try {
            userMapper.insert(user);
            log.info("已初始化测试账号 sakura / Test@123456");
        } catch (Exception e) {
            log.warn("测试账号初始化失败：{}", e.getMessage());
        }
    }
}
