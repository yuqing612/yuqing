package com.fenglin.springboottest.config;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.fenglin.springboottest.entity.SysUser;
import com.fenglin.springboottest.mapper.BangumiMapper;
import com.fenglin.springboottest.mapper.SysUserMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.CommandLineRunner;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

/**
 * 启动时自动完成两件事：
 * 1. 补齐 sys_user.permission 字段：老库升级时自动加列并把存量账号设为默认权限；
 * 2. 预置账号：前台测试账号 sakura / Test@123456，
 *    后台管理员账号见 app.admin.username / app.admin.password
 *    （管理员权限 permission=0，可登录后台管理系统）。
 *
 * <p>管理员初始凭证放在配置文件而非硬编码，便于部署时按环境覆盖；
 * 生产环境建议用环境变量注入：APP_ADMIN_USERNAME / APP_ADMIN_PASSWORD。
 */
@Component
public class DataInitializer implements CommandLineRunner {

    private static final Logger log = LoggerFactory.getLogger(DataInitializer.class);

    /** 预置的后台管理员账号与初始密码（后台无注册入口，只能靠预置账号登录） */
    private final String adminUsername;
    private final String adminPassword;

    private final SysUserMapper userMapper;
    private final BangumiMapper bangumiMapper;
    private final JdbcTemplate jdbcTemplate;

    public DataInitializer(SysUserMapper userMapper,
                           BangumiMapper bangumiMapper,
                           JdbcTemplate jdbcTemplate,
                           @Value("${app.admin.username:yuqing}") String adminUsername,
                           @Value("${app.admin.password:11110612Yy@1}") String adminPassword) {
        this.userMapper = userMapper;
        this.bangumiMapper = bangumiMapper;
        this.jdbcTemplate = jdbcTemplate;
        this.adminUsername = adminUsername;
        this.adminPassword = adminPassword;
    }

    @Override
    public void run(String... args) {
        ensurePermissionColumn();
        initAdminAccount();
        initFrontUser();
    }

    /**
     * 老库升级：sys_user 增补 permission 列（幂等，已存在则跳过）。
     * 存量账号一律设为默认权限 1，避免升级后意外获得后台权限。
     */
    private void ensurePermissionColumn() {
        try {
            Integer count = jdbcTemplate.queryForObject(
                    "SELECT COUNT(*) FROM information_schema.COLUMNS "
                            + "WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'sys_user' AND COLUMN_NAME = 'permission'",
                    Integer.class);
            if (count != null && count > 0) {
                return;
            }
            jdbcTemplate.execute("ALTER TABLE sys_user ADD COLUMN permission TINYINT NOT NULL DEFAULT 1 "
                    + "COMMENT '权限：0 管理员（可进后台），1 默认权限' AFTER nickname");
            log.info("已为 sys_user 表新增 permission 字段，存量账号默认为 1（默认权限）");
        } catch (Exception e) {
            log.warn("sys_user.permission 字段补齐失败，请手动执行 ALTER 语句：{}", e.getMessage());
        }
    }

    /** 预置后台管理员：permission=0，可登录后台管理系统（密码明文存储） */
    private void initAdminAccount() {
        try {
            SysUser admin = userMapper.selectOne(new LambdaQueryWrapper<SysUser>()
                    .eq(SysUser::getUsername, adminUsername)
                    .last("limit 1"));
            if (admin == null) {
                admin = new SysUser();
                admin.setUsername(adminUsername);
                admin.setPassword(adminPassword);
                admin.setNickname("站长");
                admin.setStatus(1);
                admin.setPermission(0);
                userMapper.insert(admin);
                log.info("已初始化管理员账号 {} / {}（管理员权限，明文存储）", adminUsername, adminPassword);
                return;
            }
            // 账号已存在：补齐管理员权限，并把旧库遗留的 BCrypt 密码迁移为明文
            boolean changed = false;
            if (admin.getPermission() == null || admin.getPermission() != 0) {
                admin.setPermission(0);
                changed = true;
            }
            if (isLegacyBcrypt(admin.getPassword())) {
                admin.setPassword(adminPassword);
                changed = true;
            }
            if (changed) {
                userMapper.updateById(admin);
                log.info("管理员账号 {} 已更新为管理员权限并迁移密码存储方式", adminUsername);
            }
        } catch (Exception e) {
            log.warn("后台管理员账号初始化失败：{}", e.getMessage());
        }
    }

    /** 预置前台测试账号（默认权限 1，不能进后台） */
    private void initFrontUser() {
        try {
            if (bangumiMapper.selectCount(null) == 0) {
                log.warn("bangumi 表为空，首页番剧板块将没有数据，请执行 yuqing_db.sql 导入种子数据");
            }
        } catch (Exception e) {
            log.warn("bangumi 表不存在，跳过番剧种子检查（请执行 yuqing_db.sql 导入种子数据）：{}", e.getMessage());
        }
        SysUser user = userMapper.selectOne(new LambdaQueryWrapper<SysUser>()
                .eq(SysUser::getUsername, "sakura")
                .last("limit 1"));
        if (user == null) {
            user = new SysUser();
            user.setUsername("sakura");
            user.setEmail("sakura@yuqing.dev");
            user.setPassword("Test@123456");
            user.setNickname("桜守");
            user.setStatus(1);
            user.setPermission(1);
            try {
                userMapper.insert(user);
                log.info("已初始化测试账号 sakura / Test@123456");
            } catch (Exception e) {
                log.warn("测试账号初始化失败：{}", e.getMessage());
            }
            return;
        }
        // 账号已存在：修正权限为默认权限，并把旧库遗留的 BCrypt 密码迁移为明文
        boolean changed = false;
        if (user.getPermission() == null || user.getPermission() != 1) {
            user.setPermission(1);
            changed = true;
        }
        if (isLegacyBcrypt(user.getPassword())) {
            user.setPassword("Test@123456");
            changed = true;
        }
        if (changed) {
            userMapper.updateById(user);
            log.info("测试账号 sakura 已更新权限并迁移密码存储方式");
        }
    }

    /**
     * 判断是否为旧版 BCrypt 哈希（形如 $2a$10$...）。
     * 仅用于把历史数据迁移成明文：已经是明文的密码不动，
     * 以免覆盖用户自己改过的密码。
     */
    private boolean isLegacyBcrypt(String password) {
        return password != null && (password.startsWith("$2a$") || password.startsWith("$2b$") || password.startsWith("$2y$"));
    }
}
