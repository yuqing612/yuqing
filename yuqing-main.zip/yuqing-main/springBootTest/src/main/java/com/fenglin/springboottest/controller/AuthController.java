package com.fenglin.springboottest.controller;

import com.fenglin.springboottest.common.Result;
import com.fenglin.springboottest.dto.LoginRequest;
import com.fenglin.springboottest.dto.RegisterRequest;
import com.fenglin.springboottest.entity.SysUser;
import com.fenglin.springboottest.service.AuthTokenService;
import com.fenglin.springboottest.service.SysUserService;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.HashMap;
import java.util.Map;
import java.util.regex.Pattern;

/**
 * 前后端分离的认证接口，对接 anime-login-vue 前端
 */
@RestController
@RequestMapping("/api/auth")
public class AuthController {

    /** 密码规则：6-15 位，必须包含数字、大小写字母、特殊字符 */
    private static final Pattern PASSWORD_RULE =
            Pattern.compile("^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d)(?=.*[\\W_]).{6,15}$");

    private static final Pattern EMAIL_RULE =
            Pattern.compile("^[^\\s@]+@[^\\s@]+\\.[^\\s@]+$");

    private final SysUserService userService;
    private final AuthTokenService tokenService;

    public AuthController(SysUserService userService, AuthTokenService tokenService) {
        this.userService = userService;
        this.tokenService = tokenService;
    }

    @PostMapping("/login")
    public Result<Map<String, Object>> login(@RequestBody LoginRequest req) {
        if (req == null || !StringUtils.hasText(req.getAccount()) || !StringUtils.hasText(req.getPassword())) {
            return Result.fail("请输入账号和密码");
        }
        SysUser user = userService.login(req.getAccount().trim(), req.getPassword());
        boolean remember = Boolean.TRUE.equals(req.getRemember());
        Map<String, Object> view = buildUserView(user);
        view.put("token", tokenService.create(user.getId(), remember));
        return Result.ok(view);
    }

    /**
     * 恢复会话：前端启动时携带 token 调用，换取最新用户信息
     */
    @GetMapping("/me")
    public Result<Map<String, Object>> me(@RequestHeader(value = "Authorization", required = false) String authorization) {
        Long userId = tokenService.resolve(extractToken(authorization));
        if (userId == null) {
            return Result.unauthorized("登录状态已失效，请重新登录");
        }
        SysUser user = userService.getById(userId);
        if (user == null || (user.getStatus() != null && user.getStatus() == 0)) {
            return Result.unauthorized("账号不可用，请重新登录");
        }
        return Result.ok(buildUserView(user));
    }

    @PostMapping("/logout")
    public Result<Void> logout(@RequestHeader(value = "Authorization", required = false) String authorization) {
        tokenService.revoke(extractToken(authorization));
        return Result.ok();
    }

    private String extractToken(String authorization) {
        if (!StringUtils.hasText(authorization)) {
            return null;
        }
        return authorization.startsWith("Bearer ") ? authorization.substring(7).trim() : authorization.trim();
    }

    @PostMapping("/register")
    public Result<Map<String, Object>> register(@RequestBody RegisterRequest req) {
        if (req == null || !StringUtils.hasText(req.getUsername())) {
            return Result.fail("请输入用户名");
        }
        String username = req.getUsername().trim();
        if (username.length() < 2 || username.length() > 32) {
            return Result.fail("用户名长度需在 2-32 位之间");
        }
        String email = StringUtils.hasText(req.getEmail()) ? req.getEmail().trim() : null;
        if (email != null && !EMAIL_RULE.matcher(email).matches()) {
            return Result.fail("邮箱格式不太对哦～");
        }
        if (!StringUtils.hasText(req.getPassword())
                || !PASSWORD_RULE.matcher(req.getPassword()).matches()) {
            return Result.fail("密码需为 6-15 位，且包含数字、大小写字母和特殊字符");
        }

        SysUser user = userService.register(username, email, req.getPassword(), req.getNickname());
        return Result.ok(buildUserView(user));
    }

    private Map<String, Object> buildUserView(SysUser user) {
        Map<String, Object> view = new HashMap<>();
        view.put("id", user.getId());
        view.put("username", user.getUsername());
        view.put("email", user.getEmail());
        view.put("nickname", StringUtils.hasText(user.getNickname()) ? user.getNickname() : user.getUsername());
        return view;
    }
}
