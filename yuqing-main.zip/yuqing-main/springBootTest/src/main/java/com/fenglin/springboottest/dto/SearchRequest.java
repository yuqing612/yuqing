package com.fenglin.springboottest.dto;

import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;

/**
 * 搜索请求参数。
 * 支持关键词 + 分级分类 + 排序 + 分页的组合过滤。
 */
public class SearchRequest {

    /** 关键词，空表示浏览全部 */
    private String keyword;

    /** 分类 id：传顶级分区时自动包含其全部子孙分类 */
    private Long categoryId;

    /** 搜索范围：all（默认）/ video / bangumi */
    private String scope = "all";

    /** 内容分级：全年龄 / 12+ / 16+ / 18+ */
    private String rating;

    /** 地区：内地 / 港澳台 / 海外 */
    private String region;

    /** 排序：relevance（默认）/ play（播放量）/ latest（最新）/ score（评分） */
    private String sort = "relevance";

    @Min(value = 1, message = "页码最小为 1")
    private long page = 1;

    @Min(value = 1, message = "每页条数最小为 1")
    @Max(value = 100, message = "每页条数最大为 100")
    private long size = 20;

    public String getKeyword() {
        return keyword;
    }

    public void setKeyword(String keyword) {
        this.keyword = keyword;
    }

    public Long getCategoryId() {
        return categoryId;
    }

    public void setCategoryId(Long categoryId) {
        this.categoryId = categoryId;
    }

    public String getScope() {
        return scope;
    }

    public void setScope(String scope) {
        this.scope = scope;
    }

    public String getRating() {
        return rating;
    }

    public void setRating(String rating) {
        this.rating = rating;
    }

    public String getRegion() {
        return region;
    }

    public void setRegion(String region) {
        this.region = region;
    }

    public String getSort() {
        return sort;
    }

    public void setSort(String sort) {
        this.sort = sort;
    }

    public long getPage() {
        return page;
    }

    public void setPage(long page) {
        this.page = page;
    }

    public long getSize() {
        return size;
    }

    public void setSize(long size) {
        this.size = size;
    }
}
