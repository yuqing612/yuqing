package com.fenglin.springboottest.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.fenglin.springboottest.entity.Bangumi;
import com.fenglin.springboottest.entity.Video;
import com.fenglin.springboottest.mapper.BangumiMapper;
import com.fenglin.springboottest.mapper.VideoMapper;
import com.fenglin.springboottest.service.BannerService;
import com.fenglin.springboottest.service.BangumiService;
import com.fenglin.springboottest.service.CategoryService;
import com.fenglin.springboottest.service.HomeService;
import com.fenglin.springboottest.service.SearchKeywordLogService;
import com.fenglin.springboottest.service.VideoService;
import com.fenglin.springboottest.vo.BangumiVO;
import com.fenglin.springboottest.vo.HomeOverviewVO;
import com.fenglin.springboottest.vo.HomeStatVO;
import com.fenglin.springboottest.vo.VideoVO;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class HomeServiceImpl implements HomeService {

    private final BannerService bannerService;
    private final VideoService videoService;
    private final BangumiService bangumiService;
    private final CategoryService categoryService;
    private final SearchKeywordLogService keywordLogService;
    private final VideoMapper videoMapper;
    private final BangumiMapper bangumiMapper;

    public HomeServiceImpl(BannerService bannerService,
                           VideoService videoService,
                           BangumiService bangumiService,
                           CategoryService categoryService,
                           SearchKeywordLogService keywordLogService,
                           VideoMapper videoMapper,
                           BangumiMapper bangumiMapper) {
        this.bannerService = bannerService;
        this.videoService = videoService;
        this.bangumiService = bangumiService;
        this.categoryService = categoryService;
        this.keywordLogService = keywordLogService;
        this.videoMapper = videoMapper;
        this.bangumiMapper = bangumiMapper;
    }

    @Override
    public HomeOverviewVO overview() {
        HomeOverviewVO vo = new HomeOverviewVO();
        vo.setBanners(bannerService.listActive());
        vo.setDailyVideos(videoService.listDailyRecommend());
        vo.setRankVideos(videoService.listRank());
        vo.setCategories(categoryService.tree("video", true));
        vo.setBangumis(bangumiService.list(null));
        vo.setSchedule(bangumiService.schedule());
        vo.setHotKeywords(keywordLogService.hot(10));
        vo.setStat(buildStat());
        return vo;
    }

    /** 首页统计：视频数 / 番剧数 / 分类数 / 总播放量 */
    private HomeStatVO buildStat() {
        HomeStatVO stat = new HomeStatVO();

        Long videoCount = videoMapper.selectCount(null);
        stat.setVideoCount(videoCount == null ? 0L : videoCount);

        Long bangumiCount = bangumiMapper.selectCount(null);
        stat.setBangumiCount(bangumiCount == null ? 0L : bangumiCount);

        Long categoryCount = categoryService.count(new LambdaQueryWrapper<com.fenglin.springboottest.entity.Category>()
                .eq(com.fenglin.springboottest.entity.Category::getEnabled, 1));
        stat.setCategoryCount(categoryCount == null ? 0L : categoryCount);

        List<Video> videos = videoMapper.selectList(new LambdaQueryWrapper<Video>()
                .select(Video::getPlay));
        long totalPlay = videos.stream()
                .mapToLong(v -> v.getPlay() == null ? 0L : v.getPlay())
                .sum();
        stat.setTotalPlay(totalPlay);
        return stat;
    }
}
