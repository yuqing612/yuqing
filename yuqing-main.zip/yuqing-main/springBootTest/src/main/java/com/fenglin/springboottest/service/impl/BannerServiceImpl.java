package com.fenglin.springboottest.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.fenglin.springboottest.entity.Bangumi;
import com.fenglin.springboottest.entity.Banner;
import com.fenglin.springboottest.mapper.BangumiMapper;
import com.fenglin.springboottest.mapper.BannerMapper;
import com.fenglin.springboottest.service.BannerService;
import com.fenglin.springboottest.vo.BannerVO;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

@Service
public class BannerServiceImpl extends ServiceImpl<BannerMapper, Banner> implements BannerService {

    private final BangumiMapper bangumiMapper;

    public BannerServiceImpl(BangumiMapper bangumiMapper) {
        this.bangumiMapper = bangumiMapper;
    }

    @Override
    public List<BannerVO> listActive() {
        LocalDateTime now = LocalDateTime.now();
        List<Banner> banners = this.list(new LambdaQueryWrapper<Banner>()
                .eq(Banner::getEnabled, 1)
                .and(qw -> qw.isNull(Banner::getStartTime).or().le(Banner::getStartTime, now))
                .and(qw -> qw.isNull(Banner::getEndTime).or().ge(Banner::getEndTime, now))
                .orderByAsc(Banner::getSortOrder)
                .orderByAsc(Banner::getId));
        if (banners.isEmpty()) {
            return List.of();
        }

        // 一次性把关联的番剧捞出来，避免逐条查询
        List<Long> bangumiIds = banners.stream()
                .filter(b -> "bangumi".equals(b.getContentType()) && b.getContentId() != null)
                .map(Banner::getContentId)
                .distinct()
                .collect(Collectors.toList());
        Map<Long, Bangumi> bangumiMap = new HashMap<>();
        if (!bangumiIds.isEmpty()) {
            bangumiMap = bangumiMapper.selectBatchIds(bangumiIds).stream()
                    .collect(Collectors.toMap(Bangumi::getId, Function.identity(), (a, b) -> a));
        }

        List<BannerVO> result = new ArrayList<>();
        for (Banner b : banners) {
            BannerVO vo = new BannerVO();
            vo.setId(b.getId());
            vo.setTitle(b.getTitle());
            vo.setSubtitle(b.getSubtitle());
            vo.setContentType(b.getContentType());
            vo.setContentId(b.getContentId());
            vo.setCoverUrl(b.getCoverUrl());
            vo.setCover(b.getCoverGradient());
            vo.setTag(b.getTag());

            Bangumi bg = bangumiMap.get(b.getContentId());
            if (bg != null) {
                vo.setEpisodes(bg.getEpisodes());
                vo.setStatus(bg.getStatus());
                vo.setScore(bg.getScore() == null ? null : bg.getScore().doubleValue());
                vo.setStudio(bg.getStudio());
                // 番剧封面优先级：banner 自带 > 番剧外部图 > 内联 SVG
                if (vo.getCoverUrl() == null || vo.getCoverUrl().isBlank()) {
                    vo.setCoverUrl(bg.getCoverUrl());
                }
                if (vo.getCoverUrl() == null || vo.getCoverUrl().isBlank()) {
                    if (bg.getCoverSvg() != null && !bg.getCoverSvg().isBlank()) {
                        vo.setCoverUrl("/api/bangumi/" + bg.getId() + "/cover");
                    }
                }
                if ((vo.getCover() == null || vo.getCover().isBlank())) {
                    vo.setCover(bg.getCoverGradient());
                }
            }
            result.add(vo);
        }
        return result;
    }
}
