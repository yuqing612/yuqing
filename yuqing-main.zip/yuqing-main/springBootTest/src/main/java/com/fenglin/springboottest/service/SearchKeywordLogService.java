package com.fenglin.springboottest.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.fenglin.springboottest.entity.SearchKeywordLog;
import com.fenglin.springboottest.vo.HotKeywordVO;

import java.util.List;

/**
 * 搜索热词统计服务。
 */
public interface SearchKeywordLogService extends IService<SearchKeywordLog> {

    /** 记录一次搜索（同一归一化关键词累加次数） */
    void record(String keyword, int resultCount);

    /** 热门关键词列表 */
    List<HotKeywordVO> hot(int limit);

    /** 前缀匹配的建议词 */
    List<String> suggest(String keyword, int limit);
}
