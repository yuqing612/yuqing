package com.fenglin.springboottest.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.fenglin.springboottest.entity.Category;
import com.fenglin.springboottest.vo.CategoryVO;

import java.util.List;
import java.util.Map;

/**
 * 分类树服务：负责分类树的组装与"父分类 -> 全部子孙分类"的展开。
 */
public interface CategoryService extends IService<Category> {

    /**
     * 构建分类树。
     *
     * @param module 模块过滤：video / bangumi / all
     * @param countContent 是否统计每个分类下的内容数量
     */
    List<CategoryVO> tree(String module, boolean countContent);

    /** 展开分类 id 及其全部子孙 id；分类不存在时返回空集合 */
    List<Long> expandToDescendants(Long categoryId);

    /** 分类 id -> 分类对象的映射（用于回显分类名） */
    Map<Long, Category> mapByIds(List<Long> ids);

    /** 顶级分区名称（如"动画"） */
    String parentNameOf(Long categoryId);
}
