package com.fenglin.springboottest.vo;

import com.fasterxml.jackson.annotation.JsonInclude;

/**
 * 首页统计信息。
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public class HomeStatVO {

    /** 视频总数 */
    private Long videoCount;

    /** 番剧总数 */
    private Long bangumiCount;

    /** 启用的分类数 */
    private Long categoryCount;

    /** 总播放量 */
    private Long totalPlay;

    public Long getVideoCount() {
        return videoCount;
    }

    public void setVideoCount(Long videoCount) {
        this.videoCount = videoCount;
    }

    public Long getBangumiCount() {
        return bangumiCount;
    }

    public void setBangumiCount(Long bangumiCount) {
        this.bangumiCount = bangumiCount;
    }

    public Long getCategoryCount() {
        return categoryCount;
    }

    public void setCategoryCount(Long categoryCount) {
        this.categoryCount = categoryCount;
    }

    public Long getTotalPlay() {
        return totalPlay;
    }

    public void setTotalPlay(Long totalPlay) {
        this.totalPlay = totalPlay;
    }
}
