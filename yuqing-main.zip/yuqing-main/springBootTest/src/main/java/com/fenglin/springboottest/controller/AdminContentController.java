package com.fenglin.springboottest.controller;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.fenglin.springboottest.common.Result;
import com.fenglin.springboottest.dto.BangumiForm;
import com.fenglin.springboottest.dto.ScheduleForm;
import com.fenglin.springboottest.dto.VideoForm;
import com.fenglin.springboottest.service.AdminContentService;
import com.fenglin.springboottest.vo.AdminScheduleVO;
import com.fenglin.springboottest.vo.BangumiVO;
import com.fenglin.springboottest.vo.VideoVO;
import jakarta.validation.Valid;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.Map;

/**
 * 后台内容管理接口：对首页展示的全部数据做增删改查。
 *
 * <p>板块对应关系：
 * <ul>
 *   <li>/api/admin/videos —— 热门推荐、播放器、热播排行</li>
 *   <li>/api/admin/bangumi —— Hero 轮播、番剧新番、分类 Tab</li>
 *   <li>/api/admin/schedules —— 番剧时间表</li>
 *   <li>/api/admin/users —— 前台注册用户</li>
 *   <li>/api/admin/stats —— 概览统计</li>
 * </ul>
 */
@RestController
@RequestMapping("/api/admin")
public class AdminContentController {

    private final AdminContentService contentService;

    public AdminContentController(AdminContentService contentService) {
        this.contentService = contentService;
    }

    /* ==================== 概览统计 ==================== */

    @GetMapping("/stats")
    public Result<Map<String, Object>> stats() {
        return Result.ok(contentService.stats());
    }

    /* ==================== 视频 ==================== */

    @GetMapping("/videos")
    public Result<IPage<VideoVO>> videos(
            @RequestParam(defaultValue = "1") long page,
            @RequestParam(defaultValue = "10") long size,
            @RequestParam(required = false) String keyword) {
        return Result.ok(contentService.pageVideos(page, size, keyword));
    }

    /** 全部视频（不分页），供下拉选择使用 */
    @GetMapping("/videos/list-all")
    public Result<List<VideoVO>> allVideos() {
        return Result.ok(contentService.listAllVideos());
    }

    @PostMapping("/videos")
    public Result<VideoVO> createVideo(@Valid @RequestBody VideoForm form) {
        return Result.ok(contentService.createVideo(form));
    }

    @PutMapping("/videos/{id}")
    public Result<VideoVO> updateVideo(@PathVariable Long id, @Valid @RequestBody VideoForm form) {
        return Result.ok(contentService.updateVideo(id, form));
    }

    @DeleteMapping("/videos/{id}")
    public Result<Void> deleteVideo(@PathVariable Long id) {
        contentService.deleteVideo(id);
        return Result.ok();
    }

    /** 切换每日推荐标记 */
    @PutMapping("/videos/{id}/daily-pick")
    public Result<VideoVO> toggleDailyPick(@PathVariable Long id) {
        return Result.ok(contentService.toggleDailyPick(id));
    }

    /** 切换收藏标记 —— 直接决定该视频是否出现在前台收藏页 */
    @PutMapping("/videos/{id}/fav")
    public Result<VideoVO> toggleFav(@PathVariable Long id) {
        return Result.ok(contentService.toggleFav(id));
    }

    /* ==================== 番剧 ==================== */

    @GetMapping("/bangumi")
    public Result<IPage<BangumiVO>> bangumi(
            @RequestParam(defaultValue = "1") long page,
            @RequestParam(defaultValue = "10") long size,
            @RequestParam(required = false) String keyword,
            @RequestParam(required = false) String category) {
        return Result.ok(contentService.pageBangumi(page, size, keyword, category));
    }

    @GetMapping("/bangumi/list-all")
    public Result<List<BangumiVO>> allBangumi() {
        return Result.ok(contentService.listAllBangumi());
    }

    @PostMapping("/bangumi")
    public Result<BangumiVO> createBangumi(@Valid @RequestBody BangumiForm form) {
        return Result.ok(contentService.createBangumi(form));
    }

    @PutMapping("/bangumi/{id}")
    public Result<BangumiVO> updateBangumi(@PathVariable Long id, @Valid @RequestBody BangumiForm form) {
        return Result.ok(contentService.updateBangumi(id, form));
    }

    @DeleteMapping("/bangumi/{id}")
    public Result<Void> deleteBangumi(@PathVariable Long id) {
        contentService.deleteBangumi(id);
        return Result.ok();
    }

    /* ==================== 番剧时间表 ==================== */

    @GetMapping("/schedules")
    public Result<List<AdminScheduleVO>> schedules() {
        return Result.ok(contentService.listSchedules());
    }

    @PostMapping("/schedules")
    public Result<AdminScheduleVO> createSchedule(@Valid @RequestBody ScheduleForm form) {
        return Result.ok(contentService.createSchedule(form));
    }

    @PutMapping("/schedules/{id}")
    public Result<AdminScheduleVO> updateSchedule(@PathVariable Long id, @Valid @RequestBody ScheduleForm form) {
        return Result.ok(contentService.updateSchedule(id, form));
    }

    @DeleteMapping("/schedules/{id}")
    public Result<Void> deleteSchedule(@PathVariable Long id) {
        contentService.deleteSchedule(id);
        return Result.ok();
    }

    /* ==================== 用户 ==================== */

    @GetMapping("/users")
    public Result<IPage<Map<String, Object>>> users(
            @RequestParam(defaultValue = "1") long page,
            @RequestParam(defaultValue = "10") long size,
            @RequestParam(required = false) String keyword) {
        return Result.ok(contentService.pageUsers(page, size, keyword));
    }

    /** 启用 / 禁用用户 */
    @PutMapping("/users/{id}/status")
    public Result<Map<String, Object>> toggleUser(@PathVariable Long id) {
        return Result.ok(contentService.toggleUserStatus(id));
    }

    /** 授予 / 回收管理员权限（0 管理员 ↔ 1 默认权限） */
    @PutMapping("/users/{id}/permission")
    public Result<Map<String, Object>> toggleUserPermission(@PathVariable Long id) {
        return Result.ok(contentService.toggleUserPermission(id));
    }
}
