package com.fenglin.springboottest.controller;

import com.fenglin.springboottest.common.Result;
import com.fenglin.springboottest.service.HomeService;
import com.fenglin.springboottest.vo.HomeOverviewVO;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * 首页接口。
 *
 * GET /api/home/overview    首页聚合数据：
 *                            轮播位 / 每日推荐 / 热播排行 / 分类导航 /
 *                            番剧新番 / 番剧时间表 / 热门搜索词 / 站点统计
 *                            一次请求拿全，避免前端首屏瀑布请求。
 */
@RestController
@RequestMapping("/api/home")
public class HomeController {

    private final HomeService homeService;

    public HomeController(HomeService homeService) {
        this.homeService = homeService;
    }

    @GetMapping("/overview")
    public Result<HomeOverviewVO> overview() {
        return Result.ok(homeService.overview());
    }
}
