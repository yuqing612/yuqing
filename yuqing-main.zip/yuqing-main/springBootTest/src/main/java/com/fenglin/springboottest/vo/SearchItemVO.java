package com.fenglin.springboottest.vo;

import com.fasterxml.jackson.annotation.JsonInclude;

import java.util.List;

/**
 * 搜索结果条目：统一描述"视频"与"番剧"两类命中项。
 * type 区分来源（video / bangumi），前端据此决定跳转与卡片样式。
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public class SearchItemVO {

    /** 结果类型：video / bangumi */
    private String type;

    /** 内容 id */
    private Long id;

    /** 标题 */
    private String title;

    /** 副标题：视频为 UP 主，番剧为制作公司 */
    private String subtitle;

    /** 封面（CSS 渐变） */
    private String cover;

    /** 插画地址：番剧为 SVG 接口，视频为封面图 */
    private String illust;

    /** 标签数组 */
    private List<String> tags;

    /** 分类名称（子分类名） */
    private String category;

    /** 顶级分区名 */
    private String categoryPath;

    /** 内容分级 */
    private String rating;

    /** 播放量文案（视频） */
    private String views;

    /** 真实播放量（视频，用于排序） */
    private Long play;

    /** 评分（番剧） */
    private Double score;

    /** 简介 */
    private String desc;

    /** 创建时间（最新排序用） */
    private java.time.LocalDateTime createTime;

    /** 命中原因：title / tag / uploader / description / category */
    private String matchedOn;

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getSubtitle() {
        return subtitle;
    }

    public void setSubtitle(String subtitle) {
        this.subtitle = subtitle;
    }

    public String getCover() {
        return cover;
    }

    public void setCover(String cover) {
        this.cover = cover;
    }

    public String getIllust() {
        return illust;
    }

    public void setIllust(String illust) {
        this.illust = illust;
    }

    public List<String> getTags() {
        return tags;
    }

    public void setTags(List<String> tags) {
        this.tags = tags;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public String getCategoryPath() {
        return categoryPath;
    }

    public void setCategoryPath(String categoryPath) {
        this.categoryPath = categoryPath;
    }

    public String getRating() {
        return rating;
    }

    public void setRating(String rating) {
        this.rating = rating;
    }

    public String getViews() {
        return views;
    }

    public void setViews(String views) {
        this.views = views;
    }

    public Long getPlay() {
        return play;
    }

    public void setPlay(Long play) {
        this.play = play;
    }

    public Double getScore() {
        return score;
    }

    public void setScore(Double score) {
        this.score = score;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }

    public java.time.LocalDateTime getCreateTime() {
        return createTime;
    }

    public void setCreateTime(java.time.LocalDateTime createTime) {
        this.createTime = createTime;
    }

    public String getMatchedOn() {
        return matchedOn;
    }

    public void setMatchedOn(String matchedOn) {
        this.matchedOn = matchedOn;
    }
}
