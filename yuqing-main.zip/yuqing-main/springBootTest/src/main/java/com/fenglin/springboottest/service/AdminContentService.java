package com.fenglin.springboottest.service;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.fenglin.springboottest.dto.BangumiForm;
import com.fenglin.springboottest.dto.ScheduleForm;
import com.fenglin.springboottest.dto.VideoForm;
import com.fenglin.springboottest.entity.Bangumi;
import com.fenglin.springboottest.entity.BangumiSchedule;
import com.fenglin.springboottest.entity.SysUser;
import com.fenglin.springboottest.entity.Video;
import com.fenglin.springboottest.mapper.BangumiMapper;
import com.fenglin.springboottest.mapper.BangumiScheduleMapper;
import com.fenglin.springboottest.mapper.SysUserMapper;
import com.fenglin.springboottest.mapper.VideoMapper;
import com.fenglin.springboottest.service.impl.VideoServiceImpl;
import com.fenglin.springboottest.vo.AdminScheduleVO;
import com.fenglin.springboottest.vo.BangumiVO;
import com.fenglin.springboottest.vo.VideoVO;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * 后台内容管理服务：对首页展示的全部数据提供增删改查。
 *
 * <p>覆盖首页的六大板块：Hero 轮播 / 视频播放器 / 热门推荐 / 番剧新番 / 热播排行 / 番剧时间表，
 * 另含用户列表与概览统计。
 */
@Service
public class AdminContentService {

    private final VideoMapper videoMapper;
    private final BangumiMapper bangumiMapper;
    private final BangumiScheduleMapper scheduleMapper;
    private final SysUserMapper userMapper;

    public AdminContentService(VideoMapper videoMapper,
                               BangumiMapper bangumiMapper,
                               BangumiScheduleMapper scheduleMapper,
                               SysUserMapper userMapper) {
        this.videoMapper = videoMapper;
        this.bangumiMapper = bangumiMapper;
        this.scheduleMapper = scheduleMapper;
        this.userMapper = userMapper;
    }

    /* ==================== 视频（热门推荐 / 播放器 / 热播排行） ==================== */

    public IPage<VideoVO> pageVideos(long page, long size, String keyword) {
        LambdaQueryWrapper<Video> q = new LambdaQueryWrapper<>();
        if (StringUtils.hasText(keyword)) {
            String kw = keyword.trim();
            q.and(w -> w.like(Video::getTitle, kw)
                    .or().like(Video::getUploader, kw)
                    .or().like(Video::getTags, kw));
        }
        q.orderByDesc(Video::getPlay);
        IPage<Video> p = videoMapper.selectPage(new Page<>(page, size), q);
        return p.convert(this::toVideoVO);
    }

    /** 后台视频列表：不分页，供下拉选择与批量操作使用 */
    public List<VideoVO> listAllVideos() {
        return videoMapper.selectList(new LambdaQueryWrapper<Video>().orderByDesc(Video::getPlay))
                .stream().map(this::toVideoVO).collect(Collectors.toList());
    }

    public VideoVO createVideo(VideoForm form) {
        Video v = new Video();
        applyVideoForm(v, form);
        if (v.getPlay() == null) {
            v.setPlay(0L);
        }
        if (v.getFav() == null) {
            v.setFav(0);
        }
        if (v.getDailyPick() == null) {
            v.setDailyPick(0);
        }
        videoMapper.insert(v);
        return toVideoVO(v);
    }

    public VideoVO updateVideo(Long id, VideoForm form) {
        Video v = videoMapper.selectById(id);
        if (v == null) {
            throw new IllegalArgumentException("视频不存在");
        }
        applyVideoForm(v, form);
        videoMapper.updateById(v);
        return toVideoVO(v);
    }

    public void deleteVideo(Long id) {
        if (videoMapper.selectById(id) == null) {
            throw new IllegalArgumentException("视频不存在");
        }
        // 级联清理该视频的放送计划，避免时间表出现空条目
        scheduleMapper.delete(new LambdaQueryWrapper<BangumiSchedule>().eq(BangumiSchedule::getBangumiId, id));
        videoMapper.deleteById(id);
    }

    /** 切换「每日推荐」标记 —— 首页热门推荐板块的入选开关 */
    public VideoVO toggleDailyPick(Long id) {
        Video v = videoMapper.selectById(id);
        if (v == null) {
            throw new IllegalArgumentException("视频不存在");
        }
        v.setDailyPick(v.getDailyPick() != null && v.getDailyPick() == 1 ? 0 : 1);
        videoMapper.updateById(v);
        return toVideoVO(v);
    }

    /** 切换「收藏」标记 —— 前台收藏页（/api/videos/favorites）的入选开关 */
    public VideoVO toggleFav(Long id) {
        Video v = videoMapper.selectById(id);
        if (v == null) {
            throw new IllegalArgumentException("视频不存在");
        }
        v.setFav(v.getFav() != null && v.getFav() == 1 ? 0 : 1);
        videoMapper.updateById(v);
        return toVideoVO(v);
    }

    private void applyVideoForm(Video v, VideoForm form) {
        v.setTitle(form.getTitle());
        v.setUploader(form.getUploader());
        v.setViews(form.getViews());
        v.setPlay(form.getPlay());
        v.setDanmaku(form.getDanmaku());
        v.setDuration(form.getDuration());
        v.setTags(form.getTags());
        v.setDescription(form.getDescription());
        v.setFav(form.getFav());
        v.setGrad(form.getGrad());
        v.setCoverUrl(form.getCoverUrl());
        v.setDailyPick(form.getDailyPick());

        String sourceType = VideoServiceImpl.normalizeSourceType(form.getSourceType());
        v.setSourceType(sourceType);
        if ("tencent".equals(sourceType)) {
            // 腾讯视频：以 vid 生成 iframe 播放器地址，src 由服务端统一拼装
            String vid = form.getVid() == null ? v.getVid() : form.getVid().trim();
            String src = VideoServiceImpl.buildTencentSrc(vid);
            if (src.isEmpty()) {
                throw new IllegalArgumentException("腾讯视频源需要填写 VID（如 v3186hgiqhs）");
            }
            v.setVid(vid);
            v.setSrc(src);
        } else {
            v.setVid(form.getVid());
            v.setSrc(form.getSrc());
        }
    }

    private VideoVO toVideoVO(Video v) {
        VideoVO vo = new VideoVO();
        vo.setId(v.getId());
        vo.setTitle(v.getTitle());
        vo.setUploader(v.getUploader());
        vo.setViews(v.getViews());
        vo.setPlay(v.getPlay());
        vo.setDanmaku(v.getDanmaku());
        vo.setDuration(v.getDuration());
        vo.setDesc(v.getDescription());
        vo.setFav(v.getFav() != null && v.getFav() == 1);
        vo.setGrad(v.getGrad());
        vo.setCoverUrl(v.getCoverUrl());
        vo.setSrc(v.getSrc());
        vo.setSourceType(VideoServiceImpl.normalizeSourceType(v.getSourceType()));
        vo.setVid(v.getVid());
        vo.setDailyPick(v.getDailyPick());
        vo.setTags(splitTags(v.getTags()));
        return vo;
    }

    private List<String> splitTags(String tags) {
        if (!StringUtils.hasText(tags)) {
            return new ArrayList<>();
        }
        return List.of(tags.split(",")).stream()
                .map(String::trim)
                .filter(StringUtils::hasText)
                .collect(Collectors.toList());
    }

    /* ==================== 番剧（Hero 轮播 / 番剧新番 / 分类） ==================== */

    public IPage<BangumiVO> pageBangumi(long page, long size, String keyword, String category) {
        LambdaQueryWrapper<Bangumi> q = new LambdaQueryWrapper<>();
        if (StringUtils.hasText(keyword)) {
            String kw = keyword.trim();
            q.and(w -> w.like(Bangumi::getTitle, kw)
                    .or().like(Bangumi::getStudio, kw)
                    .or().like(Bangumi::getTags, kw));
        }
        if (StringUtils.hasText(category) && !"全部".equals(category.trim())) {
            q.eq(Bangumi::getCategory, category.trim());
        }
        q.orderByDesc(Bangumi::getScore).orderByAsc(Bangumi::getId);
        IPage<Bangumi> p = bangumiMapper.selectPage(new Page<>(page, size), q);
        return p.convert(this::toBangumiVO);
    }

    /** 全部番剧（不分页），供下拉选择使用 */
    public List<BangumiVO> listAllBangumi() {
        return bangumiMapper.selectList(new LambdaQueryWrapper<Bangumi>()
                        .orderByDesc(Bangumi::getScore).orderByAsc(Bangumi::getId))
                .stream().map(this::toBangumiVO).collect(Collectors.toList());
    }

    public BangumiVO createBangumi(BangumiForm form) {
        Bangumi b = new Bangumi();
        applyBangumiForm(b, form);
        if (b.getEpisodes() == null) {
            b.setEpisodes(12);
        }
        if (!StringUtils.hasText(b.getStatus())) {
            b.setStatus("连载中");
        }
        if (!StringUtils.hasText(b.getCoverGradient())) {
            b.setCoverGradient("linear-gradient(135deg,#ff8fb1,#c084fc)");
        }
        bangumiMapper.insert(b);
        return toBangumiVO(b);
    }

    public BangumiVO updateBangumi(Long id, BangumiForm form) {
        Bangumi b = bangumiMapper.selectById(id);
        if (b == null) {
            throw new IllegalArgumentException("番剧不存在");
        }
        applyBangumiForm(b, form);
        bangumiMapper.updateById(b);
        return toBangumiVO(b);
    }

    public void deleteBangumi(Long id) {
        if (bangumiMapper.selectById(id) == null) {
            throw new IllegalArgumentException("番剧不存在");
        }
        scheduleMapper.delete(new LambdaQueryWrapper<BangumiSchedule>().eq(BangumiSchedule::getBangumiId, id));
        bangumiMapper.deleteById(id);
    }

    private void applyBangumiForm(Bangumi b, BangumiForm form) {
        b.setTitle(form.getTitle());
        // 封面 SVG 体积大：仅在明确传值时覆盖，避免编辑其它字段时把插画清空
        if (form.getCoverSvg() != null) {
            b.setCoverSvg(form.getCoverSvg());
        }
        // 封面 URL 同理：未传值时保留原地址，避免编辑其它字段把封面清空
        if (form.getCoverUrl() != null) {
            b.setCoverUrl(form.getCoverUrl());
        }
        b.setCoverGradient(form.getCoverGradient());
        b.setEpisodes(form.getEpisodes());
        b.setStatus(form.getStatus());
        b.setScore(form.getScore());
        b.setStudio(form.getStudio());
        b.setCategory(form.getCategory());
        b.setTags(form.getTags());
        b.setDescription(form.getDescription());
    }

    private BangumiVO toBangumiVO(Bangumi b) {
        BangumiVO vo = new BangumiVO();
        vo.setId(b.getId());
        vo.setTitle(b.getTitle());
        vo.setCover(b.getCoverGradient());
        vo.setIllust(StringUtils.hasText(b.getCoverUrl())
                ? b.getCoverUrl()
                : (StringUtils.hasText(b.getCoverSvg()) ? "/api/bangumi/" + b.getId() + "/cover" : null));
        vo.setCoverUrl(b.getCoverUrl());
        vo.setEpisodes(b.getEpisodes());
        vo.setStatus(b.getStatus());
        vo.setScore(b.getScore() == null ? 0.0 : b.getScore().doubleValue());
        vo.setStudio(b.getStudio());
        vo.setCategory(b.getCategory());
        vo.setDesc(b.getDescription());
        vo.setTags(b.getTags() == null || b.getTags().isBlank()
                ? new ArrayList<>()
                : List.of(b.getTags().split("[/、,]")).stream()
                        .map(String::trim)
                        .filter(StringUtils::hasText)
                        .collect(Collectors.toList()));
        return vo;
    }

    /* ==================== 番剧时间表（首页侧栏） ==================== */

    public List<AdminScheduleVO> listSchedules() {
        List<BangumiSchedule> rows = scheduleMapper.selectList(
                new LambdaQueryWrapper<BangumiSchedule>()
                        .orderByAsc(BangumiSchedule::getWeekday, BangumiSchedule::getAirTime));
        Map<Long, String> titles = bangumiMapper.selectList(
                        new LambdaQueryWrapper<Bangumi>().select(Bangumi::getId, Bangumi::getTitle))
                .stream().collect(Collectors.toMap(Bangumi::getId, Bangumi::getTitle, (a, b) -> a));
        return rows.stream().map(r -> {
            AdminScheduleVO vo = new AdminScheduleVO();
            vo.setId(r.getId());
            vo.setBangumiId(r.getBangumiId());
            vo.setBangumiTitle(titles.get(r.getBangumiId()));
            vo.setWeekday(r.getWeekday());
            vo.setAirTime(r.getAirTime());
            vo.setEpisode(r.getEpisode());
            return vo;
        }).collect(Collectors.toList());
    }

    public AdminScheduleVO createSchedule(ScheduleForm form) {
        if (bangumiMapper.selectById(form.getBangumiId()) == null) {
            throw new IllegalArgumentException("所选番剧不存在");
        }
        validateWeekday(form.getWeekday());
        BangumiSchedule s = new BangumiSchedule();
        s.setBangumiId(form.getBangumiId());
        s.setWeekday(form.getWeekday());
        s.setAirTime(form.getAirTime());
        s.setEpisode(form.getEpisode());
        scheduleMapper.insert(s);
        return listSchedules().stream()
                .filter(v -> v.getId().equals(s.getId()))
                .findFirst()
                .orElseThrow(() -> new IllegalArgumentException("新增放送计划失败"));
    }

    public AdminScheduleVO updateSchedule(Long id, ScheduleForm form) {
        BangumiSchedule s = scheduleMapper.selectById(id);
        if (s == null) {
            throw new IllegalArgumentException("放送计划不存在");
        }
        if (form.getBangumiId() != null && bangumiMapper.selectById(form.getBangumiId()) == null) {
            throw new IllegalArgumentException("所选番剧不存在");
        }
        if (form.getWeekday() != null) {
            validateWeekday(form.getWeekday());
            s.setWeekday(form.getWeekday());
        }
        if (form.getBangumiId() != null) {
            s.setBangumiId(form.getBangumiId());
        }
        if (StringUtils.hasText(form.getAirTime())) {
            s.setAirTime(form.getAirTime());
        }
        s.setEpisode(form.getEpisode());
        scheduleMapper.updateById(s);
        return listSchedules().stream()
                .filter(v -> v.getId().equals(id))
                .findFirst()
                .orElseThrow(() -> new IllegalArgumentException("更新放送计划失败"));
    }

    public void deleteSchedule(Long id) {
        if (scheduleMapper.selectById(id) == null) {
            throw new IllegalArgumentException("放送计划不存在");
        }
        scheduleMapper.deleteById(id);
    }

    private void validateWeekday(Integer weekday) {
        if (weekday == null || weekday < 1 || weekday > 7) {
            throw new IllegalArgumentException("放送星期取值应为 1~7（周一至周日）");
        }
    }

    /* ==================== 用户管理 ==================== */

    public IPage<Map<String, Object>> pageUsers(long page, long size, String keyword) {
        LambdaQueryWrapper<SysUser> q = new LambdaQueryWrapper<>();
        if (StringUtils.hasText(keyword)) {
            String kw = keyword.trim();
            q.and(w -> w.like(SysUser::getUsername, kw)
                    .or().like(SysUser::getNickname, kw)
                    .or().like(SysUser::getEmail, kw));
        }
        q.orderByDesc(SysUser::getId);
        IPage<SysUser> p = userMapper.selectPage(new Page<>(page, size), q);
        return p.convert(this::toUserVO);
    }

    /** 启用 / 禁用前台用户 */
    public Map<String, Object> toggleUserStatus(Long id) {
        SysUser u = userMapper.selectById(id);
        if (u == null) {
            throw new IllegalArgumentException("用户不存在");
        }
        u.setStatus(u.getStatus() != null && u.getStatus() == 1 ? 0 : 1);
        userMapper.updateById(u);
        return toUserVO(u);
    }

    private Map<String, Object> toUserVO(SysUser u) {
        Map<String, Object> vo = new HashMap<>();
        vo.put("id", u.getId());
        vo.put("username", u.getUsername());
        vo.put("email", u.getEmail());
        vo.put("nickname", u.getNickname());
        vo.put("status", u.getStatus());
        vo.put("createTime", u.getCreateTime());
        return vo;
    }

    /* ==================== 概览统计 ==================== */

    public Map<String, Object> stats() {
        Map<String, Object> vo = new HashMap<>();
        vo.put("videoCount", videoMapper.selectCount(null));
        vo.put("bangumiCount", bangumiMapper.selectCount(null));
        vo.put("scheduleCount", scheduleMapper.selectCount(null));
        vo.put("userCount", userMapper.selectCount(null));
        vo.put("dailyPickCount", videoMapper.selectCount(
                new LambdaQueryWrapper<Video>().eq(Video::getDailyPick, 1)));
        vo.put("favCount", videoMapper.selectCount(
                new LambdaQueryWrapper<Video>().eq(Video::getFav, 1)));

        // 总播放量
        Long totalPlay = videoMapper.selectList(new LambdaQueryWrapper<Video>().select(Video::getPlay))
                .stream().map(Video::getPlay).filter(java.util.Objects::nonNull).reduce(0L, Long::sum);
        vo.put("totalPlay", totalPlay);

        // 热门视频 Top5
        List<Map<String, Object>> top = videoMapper.selectList(
                        new LambdaQueryWrapper<Video>().orderByDesc(Video::getPlay).last("limit 5"))
                .stream().map(v -> {
                    Map<String, Object> m = new HashMap<>();
                    m.put("id", v.getId());
                    m.put("title", v.getTitle());
                    m.put("uploader", v.getUploader());
                    m.put("views", v.getViews());
                    m.put("play", v.getPlay());
                    return m;
                }).collect(Collectors.toList());
        vo.put("topVideos", top);

        // 分类分布
        Map<String, Long> categoryStat = new HashMap<>();
        bangumiMapper.selectList(new LambdaQueryWrapper<Bangumi>().select(Bangumi::getCategory))
                .forEach(b -> {
                    if (StringUtils.hasText(b.getCategory())) {
                        categoryStat.merge(b.getCategory(), 1L, Long::sum);
                    }
                });
        vo.put("categoryStat", categoryStat);
        return vo;
    }
}
