package com.fenglin.springboottest.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

/**
 * 注册鉴权拦截器：
 * - 前台用户接口：保护 /api/**，放行登录、注册、番剧封面；
 * - 后台管理接口：保护 /api/admin/**，放行后台登录。
 *
 * 两套拦截器互不重叠：/api/admin/** 从前台拦截器中排除，
 * 改由 AdminAuthInterceptor 用后台专用令牌校验。
 */
@Configuration
public class WebConfig implements WebMvcConfigurer {

    private final AuthInterceptor authInterceptor;
    private final AdminAuthInterceptor adminAuthInterceptor;

    public WebConfig(AuthInterceptor authInterceptor, AdminAuthInterceptor adminAuthInterceptor) {
        this.authInterceptor = authInterceptor;
        this.adminAuthInterceptor = adminAuthInterceptor;
    }

    @Override
    public void addInterceptors(InterceptorRegistry registry) {
        registry.addInterceptor(authInterceptor)
                .addPathPatterns("/api/**")
                .excludePathPatterns(
                        "/api/auth/login",
                        "/api/auth/register",
                        // 番剧封面：<img src> 请求不带 token，必须放行
                        "/api/bangumi/*/cover",
                        // 后台管理接口走后台专用鉴权
                        "/api/admin/**",
                        "/error");

        registry.addInterceptor(adminAuthInterceptor)
                .addPathPatterns("/api/admin/**")
                .excludePathPatterns(
                        "/api/admin/auth/login",
                        "/error");
    }
}
