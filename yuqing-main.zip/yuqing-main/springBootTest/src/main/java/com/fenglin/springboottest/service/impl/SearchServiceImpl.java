package com.fenglin.springboottest.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.fenglin.springboottest.dto.SearchRequest;
import com.fenglin.springboottest.entity.Bangumi;
import com.fenglin.springboottest.entity.Category;
import com.fenglin.springboottest.entity.Video;
import com.fenglin.springboottest.mapper.BangumiMapper;
import com.fenglin.springboottest.mapper.VideoMapper;
import com.fenglin.springboottest.service.CategoryService;
import com.fenglin.springboottest.service.SearchKeywordLogService;
import com.fenglin.springboottest.service.SearchService;
import com.fenglin.springboottest.vo.BangumiVO;
import com.fenglin.springboottest.vo.HotKeywordVO;
import com.fenglin.springboottest.vo.SearchFilterVO;
import com.fenglin.springboottest.vo.SearchItemVO;
import com.fenglin.springboottest.vo.SearchResultVO;
import com.fenglin.springboottest.vo.VideoVO;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

/**
 * 搜索服务实现。
 *
 * 检索策略：
 *   1. 关键词在视频侧匹配 标题 / UP主 / 标签 / 简介，在番剧侧匹配 标题 / 标签 / 简介 / 制作公司；
 *   2. 分级分类：传入 categoryId 时展开为"自身 + 全部子孙"，实现父级筛选覆盖子级；
 *   3. 内容分级（rating）与地区（region）作为附加过滤条件；
 *   4. 排序：relevance（命中位置加权）/ play（播放量）/ latest（发布时间）/ score（评分）；
 *   5. 视频与番剧分别分页查询后按排序规则合并，避免跨表分页语义混乱。
 */
@Service
public class SearchServiceImpl implements SearchService {

    /** 关键词在标题命中的权重 */
    private static final int W_TITLE = 100;
    /** 关键词在标签命中的权重 */
    private static final int W_TAG = 60;
    /** 关键词在 UP主 / 制作公司命中的权重 */
    private static final int W_UPLOADER = 40;
    /** 关键词在简介命中的权重 */
    private static final int W_DESC = 20;

    /** 单次查询的候选集上限，防止全表加载 */
    private static final int MAX_CANDIDATE = 1000;

    private final VideoMapper videoMapper;
    private final BangumiMapper bangumiMapper;
    private final CategoryService categoryService;
    private final SearchKeywordLogService keywordLogService;

    public SearchServiceImpl(VideoMapper videoMapper,
                              BangumiMapper bangumiMapper,
                              CategoryService categoryService,
                              SearchKeywordLogService keywordLogService) {
        this.videoMapper = videoMapper;
        this.bangumiMapper = bangumiMapper;
        this.categoryService = categoryService;
        this.keywordLogService = keywordLogService;
    }

    @Override
    public SearchResultVO search(SearchRequest request) {
        long start = System.currentTimeMillis();

        String keyword = request.getKeyword() == null ? "" : request.getKeyword().trim();
        String scope = normalizeScope(request.getScope());
        String sort = normalizeSort(request.getSort());

        // 分级分类展开：父分类 -> 自身 + 全部子孙
        List<Long> categoryIds = List.of();
        String categoryPath = null;
        if (request.getCategoryId() != null) {
            categoryIds = categoryService.expandToDescendants(request.getCategoryId());
            if (categoryIds.isEmpty()) {
                // 传了不存在的分类，直接返回空结果
                return emptyResult(request, keyword, scope, sort);
            }
            Category child = categoryService.getById(request.getCategoryId());
            String parentName = categoryService.parentNameOf(request.getCategoryId());
            categoryPath = child == null ? null
                    : (parentName == null ? child.getName() : parentName + " / " + child.getName());
        }

        // ---- 视频侧 ----
        List<SearchItemVO> videoHits = new ArrayList<>();
        long videoTotal = 0;
        if (!"bangumi".equals(scope)) {
            LambdaQueryWrapper<Video> vw = buildVideoQuery(keyword, categoryIds, request);
            videoTotal = videoMapper.selectCount(vw);
            // 只取当前页所需的候选集：先按页码窗口拉取，再在内存中做全局排序与切片
            for (Video v : fetchVideos(vw, request, sort, keyword)) {
                videoHits.add(toVideoItem(v, keyword, categoryIds));
            }
        }

        // ---- 番剧侧 ----
        List<SearchItemVO> bangumiHits = new ArrayList<>();
        long bangumiTotal = 0;
        if (!"video".equals(scope)) {
            LambdaQueryWrapper<Bangumi> bw = buildBangumiQuery(keyword, categoryIds, request);
            bangumiTotal = bangumiMapper.selectCount(bw);
            for (Bangumi b : fetchBangumis(bw, request, sort, keyword)) {
                bangumiHits.add(toBangumiItem(b, keyword, categoryIds));
            }
        }

        long total = videoTotal + bangumiTotal;

        // ---- 合并排序 ----
        List<SearchItemVO> merged = new ArrayList<>(videoHits);
        merged.addAll(bangumiHits);
        merged.sort(comparatorFor(sort, keyword));

        // ---- 分页切片 ----
        int from = (int) Math.min((long) (request.getPage() - 1) * request.getSize(), merged.size());
        int to = (int) Math.min((long) from + request.getSize(), merged.size());
        List<SearchItemVO> pageList = merged.subList(from, to);

        SearchResultVO vo = new SearchResultVO();
        vo.setList(new ArrayList<>(pageList));
        vo.setTotal(total);
        vo.setPage(request.getPage());
        vo.setSize(request.getSize());
        vo.setPages((total + request.getSize() - 1) / request.getSize());
        vo.setKeyword(keyword);

        SearchFilterVO filter = new SearchFilterVO();
        filter.setScope(scope);
        filter.setCategoryId(request.getCategoryId());
        filter.setCategoryIds(categoryIds.isEmpty() ? null : categoryIds);
        filter.setCategoryPath(categoryPath);
        filter.setRating(StringUtils.hasText(request.getRating()) ? request.getRating().trim() : null);
        filter.setRegion(StringUtils.hasText(request.getRegion()) ? request.getRegion().trim() : null);
        filter.setSort(sort);
        vo.setFilter(filter);

        vo.setCost(System.currentTimeMillis() - start);

        // 记录热词（仅有关键词时记录）
        if (!keyword.isEmpty()) {
            keywordLogService.record(keyword, (int) Math.min(total, Integer.MAX_VALUE));
        }
        return vo;
    }

    @Override
    public List<com.fenglin.springboottest.vo.HotKeywordVO> hotKeywords(int limit) {
        return keywordLogService.hot(limit);
    }

    @Override
    public List<String> suggest(String keyword, int limit) {
        return keywordLogService.suggest(keyword, limit);
    }

    /* ==================== 取数 ==================== */

    /**
     * 单表候选集取数。
     *
     * 视频与番剧合并后要做全局排序 + 分页，单靠某一页的记录无法保证跨表排序正确，
     * 因此这里取"覆盖全局分页窗口"的候选集：
     *   - 需要跨表合并排序（relevance）时，取前 MAX_CANDIDATE 条；
     *   - 单表内可独立完成排序（play / score / latest）时，取到当前页末尾即可。
     * 排序在数据库层完成，避免全表加载。
     */
    private List<Video> fetchVideos(LambdaQueryWrapper<Video> qw, SearchRequest request, String sort, String keyword) {
        int limit = candidateLimit(request, sort, keyword);
        switch (sort) {
            case "play":
                qw.orderByDesc(Video::getPlay).orderByDesc(Video::getId);
                break;
            case "latest":
                qw.orderByDesc(Video::getCreateTime).orderByDesc(Video::getId);
                break;
            default:
                // relevance 依赖关键词命中位置，只能在内存中打分，先按播放量取候选集
                qw.orderByDesc(Video::getPlay).orderByDesc(Video::getId);
                break;
        }
        return videoMapper.selectList(qw.last("LIMIT " + limit));
    }

    private List<Bangumi> fetchBangumis(LambdaQueryWrapper<Bangumi> qw, SearchRequest request, String sort, String keyword) {
        int limit = candidateLimit(request, sort, keyword);
        switch (sort) {
            case "play":
                qw.orderByDesc(Bangumi::getScore).orderByDesc(Bangumi::getId);
                break;
            case "score":
                qw.orderByDesc(Bangumi::getScore).orderByDesc(Bangumi::getId);
                break;
            case "latest":
                qw.orderByDesc(Bangumi::getCreateTime).orderByDesc(Bangumi::getId);
                break;
            default:
                qw.orderByDesc(Bangumi::getScore).orderByDesc(Bangumi::getId);
                break;
        }
        return bangumiMapper.selectList(qw.last("LIMIT " + limit));
    }

    /** 候选集上限：relevance 需要全量候选，其余按当前页窗口放大 */
    private int candidateLimit(SearchRequest request, String sort, String keyword) {
        if ("relevance".equals(sort) && StringUtils.hasText(keyword)) {
            return MAX_CANDIDATE;
        }
        long window = request.getPage() * request.getSize();
        return (int) Math.min(Math.max(window, request.getSize()), MAX_CANDIDATE);
    }

    /* ==================== 查询构造 ==================== */

    private LambdaQueryWrapper<Video> buildVideoQuery(String keyword,
                                                       List<Long> categoryIds,
                                                       SearchRequest request) {
        LambdaQueryWrapper<Video> qw = new LambdaQueryWrapper<>();
        if (StringUtils.hasText(keyword)) {
            String kw = keyword;
            qw.and(w -> w.like(Video::getTitle, kw)
                    .or().like(Video::getUploader, kw)
                    .or().like(Video::getTags, kw)
                    .or().like(Video::getDescription, kw));
        }
        if (!categoryIds.isEmpty()) {
            qw.in(Video::getCategoryId, categoryIds);
        }
        if (StringUtils.hasText(request.getRating())) {
            qw.eq(Video::getContentRating, request.getRating().trim());
        }
        if (StringUtils.hasText(request.getRegion())) {
            qw.eq(Video::getRegion, request.getRegion().trim());
        }
        return qw;
    }

    private LambdaQueryWrapper<Bangumi> buildBangumiQuery(String keyword,
                                                            List<Long> categoryIds,
                                                            SearchRequest request) {
        LambdaQueryWrapper<Bangumi> qw = new LambdaQueryWrapper<>();
        if (StringUtils.hasText(keyword)) {
            String kw = keyword;
            qw.and(w -> w.like(Bangumi::getTitle, kw)
                    .or().like(Bangumi::getStudio, kw)
                    .or().like(Bangumi::getTags, kw)
                    .or().like(Bangumi::getDescription, kw)
                    .or().like(Bangumi::getCategory, kw));
        }
        if (!categoryIds.isEmpty()) {
            qw.in(Bangumi::getCategoryId, categoryIds);
        }
        if (StringUtils.hasText(request.getRating())) {
            qw.eq(Bangumi::getContentRating, request.getRating().trim());
        }
        return qw;
    }

    /* ==================== 排序 ==================== */

    private Comparator<SearchItemVO> comparatorFor(String sort, String keyword) {
        Comparator<SearchItemVO> base;
        switch (sort) {
            case "play":
                base = Comparator.comparingLong(i -> i.getPlay() == null ? 0L : i.getPlay());
                break;
            case "latest":
                base = Comparator.comparing(i -> i.getCreateTime(),
                        Comparator.nullsLast(Comparator.reverseOrder()));
                break;
            case "score":
                base = Comparator.comparingDouble(i -> i.getScore() == null ? 0D : i.getScore());
                break;
            default:
                base = null;
        }
        if (base == null) {
            // relevance：有关键词时按命中位置加权，无关键词时按播放量
            if (StringUtils.hasText(keyword)) {
                return (a, b) -> {
                    int diff = Integer.compare(relevance(b, keyword), relevance(a, keyword));
                    if (diff != 0) {
                        return diff;
                    }
                    return Long.compare(
                            b.getPlay() == null ? 0L : b.getPlay(),
                            a.getPlay() == null ? 0L : a.getPlay());
                };
            }
            base = Comparator.comparingLong(i -> i.getPlay() == null ? 0L : i.getPlay());
        }
        return base.reversed();
    }

    /** 相关度打分：命中标题权重最高 */
    private int relevance(SearchItemVO item, String keyword) {
        String kw = keyword.toLowerCase();
        int score = 0;
        if (item.getTitle() != null && item.getTitle().toLowerCase().contains(kw)) {
            score += W_TITLE;
        }
        if (item.getTags() != null) {
            for (String t : item.getTags()) {
                if (t != null && t.toLowerCase().contains(kw)) {
                    score += W_TAG;
                    break;
                }
            }
        }
        if (item.getSubtitle() != null && item.getSubtitle().toLowerCase().contains(kw)) {
            score += W_UPLOADER;
        }
        if (item.getDesc() != null && item.getDesc().toLowerCase().contains(kw)) {
            score += W_DESC;
        }
        return score;
    }

    /* ==================== 实体 → 搜索条目 ==================== */

    private SearchItemVO toVideoItem(Video v, String keyword, List<Long> categoryIds) {
        SearchItemVO vo = new SearchItemVO();
        vo.setType("video");
        vo.setId(v.getId());
        vo.setTitle(v.getTitle());
        vo.setSubtitle(v.getUploader());
        vo.setCover(v.getGrad());
        vo.setIllust(v.getCoverUrl());
        vo.setTags(splitTags(v.getTags()));
        vo.setViews(v.getViews());
        vo.setPlay(v.getPlay());
        vo.setRating(v.getContentRating());
        vo.setDesc(v.getDescription());
        vo.setCreateTime(v.getCreateTime());
        vo.setCategory(categoryName(v.getCategoryId()));
        vo.setCategoryPath(categoryPath(v.getCategoryId()));
        vo.setMatchedOn(matchedField(keyword, v.getTitle(), v.getUploader(), v.getTags(), v.getDescription()));
        return vo;
    }

    private SearchItemVO toBangumiItem(Bangumi b, String keyword, List<Long> categoryIds) {
        SearchItemVO vo = new SearchItemVO();
        vo.setType("bangumi");
        vo.setId(b.getId());
        vo.setTitle(b.getTitle());
        vo.setSubtitle(b.getStudio());
        vo.setCover(b.getCoverGradient());
        vo.setIllust(resolveIllust(b));
        vo.setTags(splitTags(b.getTags()));
        vo.setScore(b.getScore() == null ? null : b.getScore().doubleValue());
        vo.setRating(b.getContentRating());
        vo.setDesc(b.getDescription());
        vo.setCreateTime(b.getCreateTime());
        vo.setCategory(categoryName(b.getCategoryId()));
        vo.setCategoryPath(categoryPath(b.getCategoryId()));
        vo.setMatchedOn(matchedField(keyword, b.getTitle(), b.getStudio(), b.getTags(), b.getDescription()));
        return vo;
    }

    /** 命中字段说明，用于前端给结果加"标题命中"之类的角标 */
    private String matchedField(String keyword, String title, String uploader, String tags, String desc) {
        if (!StringUtils.hasText(keyword)) {
            return null;
        }
        String kw = keyword.toLowerCase();
        if (title != null && title.toLowerCase().contains(kw)) {
            return "title";
        }
        if (tags != null) {
            for (String t : splitTags(tags)) {
                if (t.toLowerCase().contains(kw)) {
                    return "tag";
                }
            }
        }
        if (uploader != null && uploader.toLowerCase().contains(kw)) {
            return "uploader";
        }
        if (desc != null && desc.toLowerCase().contains(kw)) {
            return "description";
        }
        return "other";
    }

    private String categoryName(Long categoryId) {
        if (categoryId == null) {
            return null;
        }
        Category c = categoryService.getById(categoryId);
        return c == null ? null : c.getName();
    }

    private String categoryPath(Long categoryId) {
        if (categoryId == null) {
            return null;
        }
        Category c = categoryService.getById(categoryId);
        if (c == null) {
            return null;
        }
        String parent = categoryService.parentNameOf(categoryId);
        return parent == null ? c.getName() : parent + " / " + c.getName();
    }

    private String resolveIllust(Bangumi b) {
        if (StringUtils.hasText(b.getCoverUrl())) {
            return b.getCoverUrl();
        }
        if (StringUtils.hasText(b.getCoverSvg())) {
            return "/api/bangumi/" + b.getId() + "/cover";
        }
        return null;
    }

    private static final List<String> TAG_SPLIT = List.of(",");

    private List<String> splitTags(String raw) {
        if (!StringUtils.hasText(raw)) {
            return List.of();
        }
        return Arrays.stream(raw.split("[/、,]"))
                .map(String::trim)
                .filter(StringUtils::hasText)
                .collect(Collectors.toList());
    }

    private static String normalizeScope(String scope) {
        if (!StringUtils.hasText(scope)) {
            return "all";
        }
        String s = scope.trim().toLowerCase();
        return switch (s) {
            case "video", "bangumi" -> s;
            default -> "all";
        };
    }

    private static String normalizeSort(String sort) {
        if (!StringUtils.hasText(sort)) {
            return "relevance";
        }
        String s = sort.trim().toLowerCase();
        return switch (s) {
            case "play", "latest", "score" -> s;
            default -> "relevance";
        };
    }

    private SearchResultVO emptyResult(SearchRequest request, String keyword, String scope, String sort) {
        SearchResultVO vo = new SearchResultVO();
        vo.setList(new ArrayList<>());
        vo.setTotal(0L);
        vo.setPage(request.getPage());
        vo.setSize(request.getSize());
        vo.setPages(0L);
        vo.setKeyword(keyword);
        SearchFilterVO filter = new SearchFilterVO();
        filter.setScope(scope);
        filter.setCategoryId(request.getCategoryId());
        filter.setSort(sort);
        vo.setFilter(filter);
        return vo;
    }
}
