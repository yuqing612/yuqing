package com.fenglin.springboottest.controller;

import com.fenglin.springboottest.common.AdminContext;
import com.fenglin.springboottest.common.Result;
import com.fenglin.springboottest.dto.AdminLoginRequest;
import com.fenglin.springboottest.dto.ChangePasswordRequest;
import com.fenglin.springboottest.entity.SysUser;
import com.fenglin.springboottest.service.AdminTokenService;
import com.fenglin.springboottest.service.LoginAttemptService;
import com.fenglin.springboottest.service.SysUserService;
import jakarta.validation.Valid;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.HashMap;
import java.util.Map;

/**
 * 后台管理系统认证接口：<b>只有登录，没有注册</b>。
 *
 * <p>账号来源为前台用户表 {@code sys_user}，只有 {@code permission=0}（管理员权限）的账号可以登录，
 * 默认权限（{@code permission=1}）的账号会被拒绝。登录成功后签发后台专用令牌，
 * 后续 /api/admin/** 由 AdminAuthInterceptor 校验。
 */
@RestController
@RequestMapping("/api/admin/auth")
public class AdminAuthController {

    private final SysUserService userService;
    private final AdminTokenService tokenService;
    private final LoginAttemptService loginAttemptService;

    public AdminAuthController(SysUserService userService,
                               AdminTokenService tokenService,
                               LoginAttemptService loginAttemptService) {
        this.userService = userService;
        this.tokenService = tokenService;
        this.loginAttemptService = loginAttemptService;
    }

    /** POST /api/admin/auth/login —— 后台登录（无注册入口，仅管理员权限账号可登录） */
    @PostMapping("/login")
    public Result<Map<String, Object>> login(@Valid @RequestBody AdminLoginRequest req) {
        String account = req.getAccount().trim();
        // 限流 key 加前缀，避免与前台账号的失败次数互相影响
        String throttleKey = "admin:" + account;
        if (loginAttemptService.isLocked(throttleKey)) {
            long minutes = loginAttemptService.remainingSeconds(throttleKey) / 60 + 1;
            return Result.fail("尝试次数过多，请 " + minutes + " 分钟后再试");
        }
        try {
            SysUser admin = userService.loginAdmin(account, req.getPassword());
            loginAttemptService.onSuccess(throttleKey);
            boolean remember = Boolean.TRUE.equals(req.getRemember());
            Map<String, Object> view = buildAdminView(admin);
            view.put("token", tokenService.create(admin.getId(), remember));
            return Result.ok(view);
        } catch (IllegalArgumentException e) {
            loginAttemptService.onFailure(throttleKey);
            return Result.fail(e.getMessage());
        }
    }

    /** GET /api/admin/auth/me —— 恢复会话 */
    @GetMapping("/me")
    public Result<Map<String, Object>> me() {
        SysUser admin = userService.getById(AdminContext.getAdminId());
        if (admin == null || (admin.getStatus() != null && admin.getStatus() == 0)) {
            return Result.unauthorized("账号不可用，请重新登录");
        }
        // 权限被回收后立即失效，不允许继续使用旧会话
        if (admin.getPermission() == null || admin.getPermission() != 0) {
            return Result.unauthorized("该账号没有后台管理权限");
        }
        return Result.ok(buildAdminView(admin));
    }

    /** POST /api/admin/auth/logout */
    @PostMapping("/logout")
    public Result<Void> logout() {
        tokenService.revoke(AdminContext.getToken());
        return Result.ok();
    }

    /** POST /api/admin/auth/password —— 修改自己的密码 */
    @PostMapping("/password")
    public Result<Void> changePassword(@Valid @RequestBody ChangePasswordRequest req) {
        Long adminId = AdminContext.getAdminId();
        userService.changePassword(adminId, req.getOldPassword(), req.getNewPassword());
        // 改密后使该管理员此前签发的所有令牌失效，防止旧会话继续可用
        tokenService.invalidateSessions(adminId);
        return Result.ok();
    }

    private Map<String, Object> buildAdminView(SysUser admin) {
        Map<String, Object> view = new HashMap<>();
        view.put("id", admin.getId());
        view.put("username", admin.getUsername());
        view.put("nickname", StringUtils.hasText(admin.getNickname()) ? admin.getNickname() : admin.getUsername());
        view.put("permission", admin.getPermission());
        return view;
    }
}
