package com.fenglin.springboottest.service;

import com.fenglin.springboottest.dto.SearchRequest;
import com.fenglin.springboottest.vo.HotKeywordVO;
import com.fenglin.springboottest.vo.SearchResultVO;

import java.util.List;

/**
 * 搜索服务：支持关键词 + 分级分类 + 内容分级 + 地区的组合检索，
 * 检索范围可跨视频与番剧。
 */
public interface SearchService {

    /** 执行搜索 */
    SearchResultVO search(SearchRequest request);

    /** 热门搜索词（按搜索次数倒序） */
    List<HotKeywordVO> hotKeywords(int limit);

    /** 搜索建议：基于已记录的关键词前缀匹配 */
    List<String> suggest(String keyword, int limit);
}
