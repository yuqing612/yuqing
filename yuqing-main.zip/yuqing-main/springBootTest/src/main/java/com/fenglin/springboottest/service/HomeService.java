package com.fenglin.springboottest.service;

import com.fenglin.springboottest.vo.HomeOverviewVO;

/**
 * 首页聚合服务：一次请求返回首页全部板块。
 */
public interface HomeService {

    /** 首页概览数据 */
    HomeOverviewVO overview();
}
