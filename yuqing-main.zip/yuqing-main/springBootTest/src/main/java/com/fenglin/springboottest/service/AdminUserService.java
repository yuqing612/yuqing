package com.fenglin.springboottest.service;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.fenglin.springboottest.common.Regexp;
import com.fenglin.springboottest.entity.AdminUser;
import com.fenglin.springboottest.mapper.AdminUserMapper;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

/**
 * 管理员账号服务：仅提供登录校验与资料读取，<b>不提供注册</b>。
 */
@Service
public class AdminUserService extends ServiceImpl<AdminUserMapper, AdminUser> {

    private final BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();

    /**
     * 登录校验：account 为管理员用户名
     *
     * @throws IllegalArgumentException 账号不存在 / 被禁用 / 密码错误
     */
    public AdminUser login(String account, String rawPassword) {
        AdminUser admin = this.getOne(new LambdaQueryWrapper<AdminUser>()
                .eq(AdminUser::getUsername, account)
                .last("limit 1"), false);
        if (admin == null) {
            throw new IllegalArgumentException("管理员账号不存在");
        }
        if (admin.getStatus() != null && admin.getStatus() == 0) {
            throw new IllegalArgumentException("该管理员账号已被禁用");
        }
        if (!passwordEncoder.matches(rawPassword, admin.getPassword())) {
            throw new IllegalArgumentException("密码错误，请重新输入");
        }
        return admin;
    }

    /** 按 id 读取管理员，读取时剔除密码字段 */
    public AdminUser getSafeById(Long id) {
        if (id == null) {
            return null;
        }
        AdminUser admin = this.getById(id);
        if (admin != null) {
            admin.setPassword(null);
        }
        return admin;
    }

    /** 修改管理员密码：校验原密码后设置新密码 */
    public void changePassword(Long adminId, String oldRaw, String newRaw) {
        AdminUser admin = this.getById(adminId);
        if (admin == null) {
            throw new IllegalArgumentException("管理员账号不存在");
        }
        if (!passwordEncoder.matches(oldRaw, admin.getPassword())) {
            throw new IllegalArgumentException("原密码错误");
        }
        // 密码强度校验：与前台用户改密、注册保持同一套规则
        if (!Regexp.isPassword(newRaw)) {
            throw new IllegalArgumentException("新密码需为 6-15 位，且包含数字、大小写字母和特殊字符");
        }
        if (passwordEncoder.matches(newRaw, admin.getPassword())) {
            throw new IllegalArgumentException("新密码不能与旧密码相同");
        }
        admin.setPassword(passwordEncoder.encode(newRaw));
        this.updateById(admin);
    }

    /** 供初始化器使用：判断指定用户名的管理员是否已存在 */
    public boolean existsByUsername(String username) {
        if (!StringUtils.hasText(username)) {
            return false;
        }
        return this.count(new LambdaQueryWrapper<AdminUser>().eq(AdminUser::getUsername, username)) > 0;
    }

    public BCryptPasswordEncoder getPasswordEncoder() {
        return passwordEncoder;
    }
}
