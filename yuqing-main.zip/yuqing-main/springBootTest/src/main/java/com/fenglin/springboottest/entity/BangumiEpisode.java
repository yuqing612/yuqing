package com.fenglin.springboottest.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;

/**
 * 番剧分集播放源实体，对应 bangumi_episode 表。
 *
 * <p>一部番剧的多个正片分集各自对应 B 站上的一个视频，
 * 这里按集记录 bvid / cid，服务端据此拼装官方 iframe 播放器地址。
 */
@TableName("bangumi_episode")
public class BangumiEpisode {

    @TableId(type = IdType.AUTO)
    private Long id;

    /** 所属番剧 id（bangumi.id） */
    private Long bangumiId;

    /** 集号，从 1 开始 */
    private Integer epNo;

    /** 本集标题 */
    private String epTitle;

    /** 哔哩哔哩 BV 号 */
    private String bvid;

    /** 哔哩哔哩 cid */
    private String cid;

    /** 时长（毫秒） */
    private Integer duration;

    /** 是否大会员专享：1 是，0 否 */
    private Integer vip;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getBangumiId() {
        return bangumiId;
    }

    public void setBangumiId(Long bangumiId) {
        this.bangumiId = bangumiId;
    }

    public Integer getEpNo() {
        return epNo;
    }

    public void setEpNo(Integer epNo) {
        this.epNo = epNo;
    }

    public String getEpTitle() {
        return epTitle;
    }

    public void setEpTitle(String epTitle) {
        this.epTitle = epTitle;
    }

    public String getBvid() {
        return bvid;
    }

    public void setBvid(String bvid) {
        this.bvid = bvid;
    }

    public String getCid() {
        return cid;
    }

    public void setCid(String cid) {
        this.cid = cid;
    }

    public Integer getDuration() {
        return duration;
    }

    public void setDuration(Integer duration) {
        this.duration = duration;
    }

    public Integer getVip() {
        return vip;
    }

    public void setVip(Integer vip) {
        this.vip = vip;
    }
}
