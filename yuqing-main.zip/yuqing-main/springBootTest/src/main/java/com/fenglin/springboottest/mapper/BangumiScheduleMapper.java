package com.fenglin.springboottest.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.fenglin.springboottest.entity.BangumiSchedule;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface BangumiScheduleMapper extends BaseMapper<BangumiSchedule> {
}
