package com.fenglin.springboottest.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.fenglin.springboottest.entity.BangumiEpisode;
import org.apache.ibatis.annotations.Mapper;

/** 番剧分集播放源 Mapper */
@Mapper
public interface BangumiEpisodeMapper extends BaseMapper<BangumiEpisode> {
}
