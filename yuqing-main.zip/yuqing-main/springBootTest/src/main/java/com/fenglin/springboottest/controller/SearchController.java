package com.fenglin.springboottest.controller;

import com.fenglin.springboottest.common.Result;
import com.fenglin.springboottest.dto.SearchRequest;
import com.fenglin.springboottest.service.SearchService;
import com.fenglin.springboottest.vo.HotKeywordVO;
import com.fenglin.springboottest.vo.SearchResultVO;
import jakarta.validation.Valid;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 * 搜索接口：首页导航栏搜索框 + 分类筛选页共用。
 *
 * GET /api/search                组合搜索（关键词 + 分级分类 + 内容分级 + 排序 + 分页）
 * GET /api/search/hot            热门搜索词
 * GET /api/search/suggest        搜索建议（输入联想）
 */
@RestController
@RequestMapping("/api/search")
public class SearchController {

    private final SearchService searchService;

    public SearchController(SearchService searchService) {
        this.searchService = searchService;
    }

    /** 组合搜索 */
    @GetMapping
    public Result<SearchResultVO> search(@Valid SearchRequest request) {
        return Result.ok(searchService.search(request));
    }

    /** 热门搜索词 */
    @GetMapping("/hot")
    public Result<List<HotKeywordVO>> hot(@RequestParam(defaultValue = "10") int limit) {
        return Result.ok(searchService.hotKeywords(limit));
    }

    /** 搜索建议 */
    @GetMapping("/suggest")
    public Result<List<String>> suggest(@RequestParam("q") String q,
                                        @RequestParam(defaultValue = "8") int limit) {
        return Result.ok(searchService.suggest(q, limit));
    }
}
