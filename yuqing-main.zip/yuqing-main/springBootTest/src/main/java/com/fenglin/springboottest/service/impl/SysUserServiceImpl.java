package com.fenglin.springboottest.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.fenglin.springboottest.common.Regexp;
import com.fenglin.springboottest.entity.SysUser;
import com.fenglin.springboottest.mapper.SysUserMapper;
import com.fenglin.springboottest.service.SysUserService;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

@Service
public class SysUserServiceImpl extends ServiceImpl<SysUserMapper, SysUser> implements SysUserService {

    /** 权限取值：0 管理员（可进后台），1 默认权限 */
    public static final int PERMISSION_ADMIN = 0;
    public static final int PERMISSION_DEFAULT = 1;

    @Override
    public SysUser login(String account, String rawPassword) {
        SysUser user = findByAccount(account);
        if (user == null) {
            throw new IllegalArgumentException("账号不存在，先去注册一个吧");
        }
        if (user.getStatus() != null && user.getStatus() == 0) {
            throw new IllegalArgumentException("账号已被禁用，请联系管理员");
        }
        if (!matches(user.getPassword(), rawPassword)) {
            throw new IllegalArgumentException("密码错误，再试一次吧");
        }
        return user;
    }

    @Override
    public SysUser loginAdmin(String account, String rawPassword) {
        SysUser user = findByAccount(account);
        if (user == null) {
            throw new IllegalArgumentException("管理员账号不存在");
        }
        // 后台管理系统只认管理员权限（permission=0），默认权限用户一律拒绝
        if (user.getPermission() == null || user.getPermission() != PERMISSION_ADMIN) {
            throw new IllegalArgumentException("该账号没有后台管理权限");
        }
        if (user.getStatus() != null && user.getStatus() == 0) {
            throw new IllegalArgumentException("该管理员账号已被禁用");
        }
        if (!matches(user.getPassword(), rawPassword)) {
            throw new IllegalArgumentException("密码错误，请重新输入");
        }
        return user;
    }

    @Override
    public SysUser register(String username, String email, String rawPassword, String nickname) {
        if (this.count(new LambdaQueryWrapper<SysUser>().eq(SysUser::getUsername, username)) > 0) {
            throw new IllegalArgumentException("用户名已被占用");
        }
        if (StringUtils.hasText(email)) {
            if (!Regexp.isEmail(email)) {
                throw new IllegalArgumentException("邮箱格式不太对哦～");
            }
            if (this.count(new LambdaQueryWrapper<SysUser>().eq(SysUser::getEmail, email)) > 0) {
                throw new IllegalArgumentException("该邮箱已注册过账号");
            }
        }
        if (!Regexp.isPassword(rawPassword)) {
            throw new IllegalArgumentException("密码需为 6-15 位，且包含数字、大小写字母和特殊字符");
        }

        SysUser user = new SysUser();
        user.setUsername(username);
        user.setEmail(StringUtils.hasText(email) ? email : null);
        // 明文存储密码（按需求不做加密）
        user.setPassword(rawPassword);
        user.setNickname(StringUtils.hasText(nickname) ? nickname : username);
        // 注册用户一律为默认权限，管理员权限需在后台手动授予
        user.setPermission(PERMISSION_DEFAULT);
        user.setStatus(1);
        this.save(user);
        return user;
    }

    @Override
    public SysUser updateProfile(Long userId, String nickname, String email) {
        SysUser user = this.getById(userId);
        if (user == null) {
            throw new IllegalArgumentException("账号不存在");
        }
        if (user.getStatus() != null && user.getStatus() == 0) {
            throw new IllegalArgumentException("账号已被禁用，请联系管理员");
        }
        boolean changed = false;
        if (StringUtils.hasText(nickname)) {
            if (nickname.trim().length() > 32) {
                throw new IllegalArgumentException("昵称最多 32 个字符");
            }
            user.setNickname(nickname.trim());
            changed = true;
        }
        if (StringUtils.hasText(email)) {
            if (!Regexp.isEmail(email)) {
                throw new IllegalArgumentException("邮箱格式不太对哦～");
            }
            if (this.count(new LambdaQueryWrapper<SysUser>()
                    .eq(SysUser::getEmail, email)
                    .ne(SysUser::getId, userId)) > 0) {
                throw new IllegalArgumentException("该邮箱已注册过账号");
            }
            user.setEmail(email.trim());
            changed = true;
        }
        if (!changed) {
            throw new IllegalArgumentException("没有可更新的内容");
        }
        this.updateById(user);
        return user;
    }

    @Override
    public void changePassword(Long userId, String oldRaw, String newRaw) {
        SysUser user = this.getById(userId);
        if (user == null) {
            throw new IllegalArgumentException("账号不存在");
        }
        if (user.getStatus() != null && user.getStatus() == 0) {
            throw new IllegalArgumentException("账号已被禁用，请联系管理员");
        }
        if (!matches(user.getPassword(), oldRaw)) {
            throw new IllegalArgumentException("原密码错误");
        }
        if (!Regexp.isPassword(newRaw)) {
            throw new IllegalArgumentException("新密码需为 6-15 位，且包含数字、大小写字母和特殊字符");
        }
        if (newRaw.equals(user.getPassword())) {
            throw new IllegalArgumentException("新密码不能与旧密码相同");
        }
        // 明文存储密码（按需求不做加密）
        user.setPassword(newRaw);
        this.updateById(user);
    }

    /** account 支持用户名或邮箱 */
    private SysUser findByAccount(String account) {
        return this.getOne(new LambdaQueryWrapper<SysUser>()
                .eq(SysUser::getUsername, account)
                .or()
                .eq(SysUser::getEmail, account)
                .last("limit 1"), false);
    }

    /** 明文密码比对 */
    private boolean matches(String storedPassword, String rawPassword) {
        return storedPassword != null && storedPassword.equals(rawPassword);
    }
}
