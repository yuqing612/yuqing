package com.fenglin.springboottest.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.fenglin.springboottest.entity.SysUser;
import com.fenglin.springboottest.mapper.SysUserMapper;
import com.fenglin.springboottest.service.SysUserService;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

@Service
public class SysUserServiceImpl extends ServiceImpl<SysUserMapper, SysUser> implements SysUserService {

    private final BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();

    @Override
    public SysUser login(String account, String rawPassword) {
        SysUser user = this.getOne(new LambdaQueryWrapper<SysUser>()
                .eq(SysUser::getUsername, account)
                .or()
                .eq(SysUser::getEmail, account)
                .last("limit 1"), false);
        if (user == null) {
            throw new IllegalArgumentException("账号不存在，先去注册一个吧");
        }
        if (user.getStatus() != null && user.getStatus() == 0) {
            throw new IllegalArgumentException("账号已被禁用，请联系管理员");
        }
        if (!passwordEncoder.matches(rawPassword, user.getPassword())) {
            throw new IllegalArgumentException("密码错误，再试一次吧");
        }
        return user;
    }

    @Override
    public SysUser register(String username, String email, String rawPassword, String nickname) {
        long nameCount = this.count(new LambdaQueryWrapper<SysUser>()
                .eq(SysUser::getUsername, username));
        if (nameCount > 0) {
            throw new IllegalArgumentException("用户名已被占用");
        }
        if (StringUtils.hasText(email)) {
            long emailCount = this.count(new LambdaQueryWrapper<SysUser>()
                    .eq(SysUser::getEmail, email));
            if (emailCount > 0) {
                throw new IllegalArgumentException("该邮箱已注册过账号");
            }
        }

        SysUser user = new SysUser();
        user.setUsername(username);
        user.setEmail(StringUtils.hasText(email) ? email : null);
        user.setPassword(passwordEncoder.encode(rawPassword));
        user.setNickname(StringUtils.hasText(nickname) ? nickname : username);
        user.setStatus(1);
        this.save(user);
        return user;
    }
}
