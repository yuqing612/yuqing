package com.fenglin.springboottest.vo;

import com.fasterxml.jackson.annotation.JsonInclude;

import java.util.List;

/**
 * 搜索筛选条件回显：让前端知道后端实际按什么条件过滤的，
 * 尤其 categoryIds 是"父分类展开后的完整子孙集合"。
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public class SearchFilterVO {

    /** 搜索范围：all / video / bangumi */
    private String scope;

    /** 用户传入的分类 id */
    private Long categoryId;

    /** 展开后的全部分类 id（含子孙） */
    private List<Long> categoryIds;

    /** 分类名称路径，如 "动画 / 治愈" */
    private String categoryPath;

    /** 内容分级筛选 */
    private String rating;

    /** 地区筛选 */
    private String region;

    /** 排序方式 */
    private String sort;

    public String getScope() {
        return scope;
    }

    public void setScope(String scope) {
        this.scope = scope;
    }

    public Long getCategoryId() {
        return categoryId;
    }

    public void setCategoryId(Long categoryId) {
        this.categoryId = categoryId;
    }

    public List<Long> getCategoryIds() {
        return categoryIds;
    }

    public void setCategoryIds(List<Long> categoryIds) {
        this.categoryIds = categoryIds;
    }

    public String getCategoryPath() {
        return categoryPath;
    }

    public void setCategoryPath(String categoryPath) {
        this.categoryPath = categoryPath;
    }

    public String getRating() {
        return rating;
    }

    public void setRating(String rating) {
        this.rating = rating;
    }

    public String getRegion() {
        return region;
    }

    public void setRegion(String region) {
        this.region = region;
    }

    public String getSort() {
        return sort;
    }

    public void setSort(String sort) {
        this.sort = sort;
    }
}
