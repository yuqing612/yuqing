package com.fenglin.springboottest.common;

/**
 * 当前登录的后台管理员上下文（基于 ThreadLocal）。
 * 由 AdminAuthInterceptor 在请求开始时写入，请求结束后清除。
 */
public final class AdminContext {

    private static final ThreadLocal<Long> ADMIN_ID = new ThreadLocal<>();
    private static final ThreadLocal<String> TOKEN = new ThreadLocal<>();

    private AdminContext() {
    }

    public static void set(Long adminId, String token) {
        ADMIN_ID.set(adminId);
        TOKEN.set(token);
    }

    public static Long getAdminId() {
        return ADMIN_ID.get();
    }

    public static String getToken() {
        return TOKEN.get();
    }

    public static void clear() {
        ADMIN_ID.remove();
        TOKEN.remove();
    }
}
