package com.fenglin.springboottest.controller;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.fenglin.springboottest.common.Result;
import com.fenglin.springboottest.entity.Video;
import com.fenglin.springboottest.mapper.VideoMapper;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.HashMap;
import java.util.Map;

/**
 * 后台视频管理：首页「热门推荐 / 播放器」数据源的增删改查。
 * 路径统一在 /api/admin/videos 下，由 AdminAuthInterceptor 保证仅 ADMIN 可访问。
 */
@RestController
@RequestMapping("/api/admin/videos")
public class AdminVideoController {

    private final VideoMapper videoMapper;

    public AdminVideoController(VideoMapper videoMapper) {
        this.videoMapper = videoMapper;
    }

    /** 分页列表 + 关键词搜索（标题 / UP主 / 标签） */
    @GetMapping
    public Result<Map<String, Object>> list(
            @RequestParam(defaultValue = "") String keyword,
            @RequestParam(defaultValue = "1") long page,
            @RequestParam(defaultValue = "10") long size) {
        QueryWrapper<Video> qw = new QueryWrapper<>();
        if (keyword != null && !keyword.trim().isEmpty()) {
            String kw = keyword.trim();
            qw.like("title", kw).or().like("uploader", kw).or().like("tags", kw);
        }
        qw.orderByDesc("id");
        IPage<Video> p = videoMapper.selectPage(new Page<>(page, size), qw);
        Map<String, Object> data = new HashMap<>();
        data.put("list", p.getRecords());
        data.put("total", p.getTotal());
        data.put("page", p.getCurrent());
        data.put("size", p.getSize());
        return Result.ok(data);
    }

    /** 详情 */
    @GetMapping("/{id}")
    public Result<Video> detail(@PathVariable Long id) {
        Video v = videoMapper.selectById(id);
        if (v == null) {
            return Result.fail("视频不存在");
        }
        return Result.ok(v);
    }

    /** 新增 */
    @PostMapping
    public Result<Video> create(@RequestBody Video video) {
        video.setId(null);
        videoMapper.insert(video);
        return Result.ok(video);
    }

    /** 修改 */
    @PutMapping("/{id}")
    public Result<Video> update(@PathVariable Long id, @RequestBody Video video) {
        Video exist = videoMapper.selectById(id);
        if (exist == null) {
            return Result.fail("视频不存在");
        }
        video.setId(id);
        videoMapper.updateById(video);
        return Result.ok(videoMapper.selectById(id));
    }

    /** 删除 */
    @DeleteMapping("/{id}")
    public Result<Void> delete(@PathVariable Long id) {
        if (videoMapper.selectById(id) == null) {
            return Result.fail("视频不存在");
        }
        videoMapper.deleteById(id);
        return Result.ok();
    }
}
