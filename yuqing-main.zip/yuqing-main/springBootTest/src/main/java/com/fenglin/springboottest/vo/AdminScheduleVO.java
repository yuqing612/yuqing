package com.fenglin.springboottest.vo;

/**
 * 后台时间表管理条目：比前台 ScheduleItemVO 多了 id 与番剧标题，便于编辑与删除。
 */
public class AdminScheduleVO {

    private Long id;
    private Long bangumiId;
    private String bangumiTitle;
    /** 放送星期：1=周一 … 7=周日 */
    private Integer weekday;
    /** 放送时间 HH:mm */
    private String airTime;
    /** 当日更新至第几话 */
    private Integer episode;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getBangumiId() {
        return bangumiId;
    }

    public void setBangumiId(Long bangumiId) {
        this.bangumiId = bangumiId;
    }

    public String getBangumiTitle() {
        return bangumiTitle;
    }

    public void setBangumiTitle(String bangumiTitle) {
        this.bangumiTitle = bangumiTitle;
    }

    public Integer getWeekday() {
        return weekday;
    }

    public void setWeekday(Integer weekday) {
        this.weekday = weekday;
    }

    public String getAirTime() {
        return airTime;
    }

    public void setAirTime(String airTime) {
        this.airTime = airTime;
    }

    public Integer getEpisode() {
        return episode;
    }

    public void setEpisode(Integer episode) {
        this.episode = episode;
    }
}
