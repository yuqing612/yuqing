package com.fenglin.springboottest.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Base64;
import java.util.List;
import java.util.zip.GZIPInputStream;

/**
 * HLS 去广告服务（{@code HlsAdFreeService}）。
 *
 * <p><b>背景</b><br>
 * 部分聚合站的 HLS 源会在正片中间与片尾插入整段广告（实测《总之就是非常可爱》
 * 12 集，每集 2 段，合计约 34 秒），画面内容为博彩广告。
 * 这些广告是独立编码的独立分片，与正片分辨率 / 帧率 / 采样率都不同
 * （正片 1280x720@23.98fps/44.1kHz，广告 1920x1080@30fps/48kHz），
 * 在 m3u8 里由 {@code EXT-X-DISCONTINUITY} 标记分隔成独立分组。
 *
 * <p><b>去广告原理</b><br>
 * 播放前先拉取上游 m3u8，按 {@code EXT-X-DISCONTINUITY} 把分片切成若干组，
 * 识别出时长明显偏短的组（广告片：正片段动辄数百秒，广告段仅 16~26 秒），
 * 把这些组的分片从清单里剔除，再把剩余分片的 URI 重写为本服务的分片代理地址。
 * 整个过程不改动任何视频数据流，纯粹在清单层面跳过广告分片。
 *
 * <p><b>为什么阈值取 60 秒</b><br>
 * 广告段时长在 12 集之间完全一致（同一批素材重复投放），实测值 16.47s / 17.67s / 25.76s；
 * 而正片段最短也有 300 秒量级。60 秒落在两者之间且留有充分余量，
 * 即使个别源的广告段偏长也能覆盖，同时绝不会误伤正片。
 *
 * <p><b>多码率链路</b><br>
 * 上游主清单（index.m3u8）里是 {@code EXT-X-STREAM-INF} + 相对子清单地址。
 * 若原样返回，播放器会绕过本代理直连子清单，广告就又回来了。
 * 因此主清单里的码率地址同样重写为代理地址，保证整条链路都经过去广告处理。
 */
@Service
public class HlsAdFreeService {

    private static final Logger log = LoggerFactory.getLogger(HlsAdFreeService.class);

    /** 广告分组的最长时长（秒）。超过该值视为正片段，不予删除。 */
    private static final double AD_GROUP_MAX_SECONDS = 60.0;

    /** 判定广告组时要求正片段明显更长，防止阈值设置失误导致大面积误删。 */
    private static final double MAIN_MIN_SECONDS = 120.0;

    /** 上游拉取超时（毫秒）。 */
    private static final int UPSTREAM_TIMEOUT_MS = 15000;

    /** 分片代理地址前缀（相对路径，经前端 Vite 代理转发到后端）。 */
    public static final String SEGMENT_PROXY_PREFIX = "/api/hls/segment?u=";

    /** 清单代理地址前缀（相对路径）。 */
    public static final String PLAYLIST_PROXY_PREFIX = "/api/hls/playlist?u=";

    /** 允许代理的上游主机白名单后缀，防止被当成任意 URL 转发器滥用。 */
    private static final List<String> ALLOWED_HOST_SUFFIXES = List.of(
            "play-cdn15.com",
            "bvvvvvvvvv1f.com",
            "ajupf.com"
    );

    /**
     * 一个 m3u8 分组：连续的若干分片，由 DISCONTINUITY 边界切分。
     */
    private static final class SegmentGroup {
        /** 组内分片行在原始清单中的起始下标（含）。 */
        int startLine;
        /** 组内分片行在原始清单中的结束下标（含）。 */
        int endLine;
        /** 组内分片总时长（秒）。 */
        double duration;
        /** 组内分片数量。 */
        int count;

        boolean isAdCandidate() {
            return count > 0 && duration > 0 && duration <= AD_GROUP_MAX_SECONDS;
        }
    }

    /**
     * 拉取上游清单并剔除广告分片。
     *
     * @param upstreamUrl 上游 m3u8 地址
     * @return 改写后的清单内容；拉取失败时返回 null，调用方应回退到直连播放
     */
    public String rewritePlaylist(String upstreamUrl) {
        String raw = fetchText(upstreamUrl);
        if (raw == null || !raw.contains("#EXTM3U")) {
            return null;
        }
        // 主清单（多码率）：不含分片，只需把码率地址改写到代理上
        if (raw.contains("#EXT-X-STREAM-INF")) {
            return rewriteVariantUrls(raw, upstreamUrl);
        }
        return stripAdSegments(raw, upstreamUrl);
    }

    /**
     * 主清单改写：把每条码率（子清单）地址重写为清单代理地址，
     * 使播放器继续走代理，从而对子清单也执行去广告。
     */
    private String rewriteVariantUrls(String raw, String baseUrl) {
        String[] lines = raw.split("\r?\n", -1);
        StringBuilder sb = new StringBuilder(raw.length());
        for (String line : lines) {
            String t = line.trim();
            if (!t.isEmpty() && !t.startsWith("#")) {
                sb.append(PLAYLIST_PROXY_PREFIX)
                        .append(encodeUrl(resolve(baseUrl, t)))
                        .append('\n');
            } else {
                sb.append(line).append('\n');
            }
        }
        return sb.toString();
    }

    /**
     * 从媒体清单中剔除广告分组，并把剩余分片 URI 重写为代理地址。
     */
    private String stripAdSegments(String raw, String baseUrl) {
        String[] lines = raw.split("\r?\n", -1);

        // 1) 按 DISCONTINUITY 切分分组
        List<Integer> boundaries = new ArrayList<>();
        boundaries.add(-1);
        for (int i = 0; i < lines.length; i++) {
            if (lines[i].trim().startsWith("#EXT-X-DISCONTINUITY")) {
                boundaries.add(i);
            }
        }
        boundaries.add(lines.length);

        List<SegmentGroup> groups = new ArrayList<>();
        for (int b = 0; b < boundaries.size() - 1; b++) {
            int from = boundaries.get(b) + 1;
            int to = boundaries.get(b + 1);
            if (from > to) {
                continue;
            }
            SegmentGroup g = new SegmentGroup();
            g.startLine = from;
            g.endLine = Math.min(to, lines.length) - 1;
            for (int i = from; i < to && i < lines.length; i++) {
                String t = lines[i].trim();
                if (t.startsWith("#EXTINF:")) {
                    g.duration += parseExtinf(t);
                } else if (!t.isEmpty() && !t.startsWith("#")) {
                    g.count++;
                }
            }
            groups.add(g);
        }

        if (groups.isEmpty()) {
            return raw;
        }

        // 2) 识别广告组：时长 <= 阈值，且不能是第一组（片头），且必须存在足够长的正片段
        List<Integer> adGroupIndexes = new ArrayList<>();
        boolean hasLongMain = false;
        for (SegmentGroup g : groups) {
            if (g.duration >= MAIN_MIN_SECONDS) {
                hasLongMain = true;
                break;
            }
        }
        if (hasLongMain) {
            for (int i = 1; i < groups.size(); i++) {
                if (groups.get(i).isAdCandidate()) {
                    adGroupIndexes.add(i);
                }
            }
        }
        // 安全兜底：不能把所有组都当成广告
        if (adGroupIndexes.size() >= groups.size() - 1) {
            adGroupIndexes.clear();
        }

        if (adGroupIndexes.isEmpty()) {
            return raw;
        }

        // 3) 标记要删除的行
        boolean[] drop = new boolean[lines.length];
        for (int gi : adGroupIndexes) {
            SegmentGroup g = groups.get(gi);
            for (int i = g.startLine; i <= g.endLine && i < lines.length; i++) {
                drop[i] = true;
            }
            // 组前的 DISCONTINUITY 标记一并去掉，避免播放器在此处产生不必要的时间轴跳变
            for (int i = g.startLine - 1; i >= 0; i--) {
                String t = lines[i].trim();
                if (t.startsWith("#EXT-X-DISCONTINUITY")) {
                    drop[i] = true;
                    break;
                }
                if (!t.isEmpty() && !t.startsWith("#")) {
                    break;
                }
            }
        }

        // 4) 输出新清单：删除广告行，分片 URI 重写为代理地址
        StringBuilder sb = new StringBuilder(raw.length());
        double keptDuration = 0;
        int keptSegments = 0;
        for (int i = 0; i < lines.length; i++) {
            if (drop[i]) {
                continue;
            }
            String t = lines[i].trim();
            if (t.startsWith("#EXTINF:")) {
                keptDuration += parseExtinf(t);
            } else if (!t.isEmpty() && !t.startsWith("#")) {
                keptSegments++;
                sb.append(SEGMENT_PROXY_PREFIX)
                        .append(encodeUrl(resolve(baseUrl, t)))
                        .append('\n');
                continue;
            }
            sb.append(lines[i]).append('\n');
        }

        log.info("HLS 去广告改写完成: 上游={} 原始组数={} 判定广告组={} 保留分片={} 时长={}s",
                baseUrl, groups.size(), adGroupIndexes, keptSegments,
                String.format("%.2f", keptDuration));
        return sb.toString();
    }

    /**
     * 拉取上游文本（自动处理 gzip）。
     */
    public String fetchText(String url) {
        HttpURLConnection conn = null;
        try {
            conn = (HttpURLConnection) new URL(url).openConnection();
            conn.setConnectTimeout(UPSTREAM_TIMEOUT_MS);
            conn.setReadTimeout(UPSTREAM_TIMEOUT_MS);
            conn.setRequestProperty("User-Agent",
                    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/124.0 Safari/537.36");
            conn.setRequestProperty("Accept", "*/*");
            conn.setRequestProperty("Accept-Encoding", "gzip");
            int code = conn.getResponseCode();
            if (code != 200) {
                log.warn("拉取上游清单失败: {} HTTP {}", url, code);
                return null;
            }
            InputStream in = conn.getInputStream();
            if ("gzip".equalsIgnoreCase(conn.getContentEncoding())) {
                in = new GZIPInputStream(in);
            }
            StringBuilder sb = new StringBuilder();
            try (BufferedReader br = new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8))) {
                String line;
                while ((line = br.readLine()) != null) {
                    sb.append(line).append('\n');
                }
            }
            return sb.toString();
        } catch (Exception e) {
            log.warn("拉取上游清单异常: {} - {}", url, e.getMessage());
            return null;
        } finally {
            if (conn != null) {
                conn.disconnect();
            }
        }
    }

    /**
     * 拉取上游二进制数据（分片），返回 null 表示失败。
     */
    public byte[] fetchBinary(String url, String rangeHeader) {
        HttpURLConnection conn = null;
        try {
            conn = (HttpURLConnection) new URL(url).openConnection();
            conn.setConnectTimeout(UPSTREAM_TIMEOUT_MS);
            conn.setReadTimeout(UPSTREAM_TIMEOUT_MS);
            conn.setRequestProperty("User-Agent",
                    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/124.0 Safari/537.36");
            if (rangeHeader != null && !rangeHeader.isBlank()) {
                conn.setRequestProperty("Range", rangeHeader);
            }
            int code = conn.getResponseCode();
            if (code != 200 && code != 206) {
                log.warn("拉取上游分片失败: {} HTTP {}", url, code);
                return null;
            }
            try (InputStream in = conn.getInputStream()) {
                return in.readAllBytes();
            }
        } catch (Exception e) {
            log.warn("拉取上游分片异常: {} - {}", url, e.getMessage());
            return null;
        } finally {
            if (conn != null) {
                conn.disconnect();
            }
        }
    }

    /**
     * 判断 URL 是否在允许代理的主机白名单内。
     */
    public boolean isAllowedUpstream(String url) {
        try {
            String host = new URL(url).getHost();
            if (host == null) {
                return false;
            }
            host = host.toLowerCase();
            for (String suffix : ALLOWED_HOST_SUFFIXES) {
                if (host.equals(suffix) || host.endsWith("." + suffix)) {
                    return true;
                }
            }
            return false;
        } catch (Exception e) {
            return false;
        }
    }

    /** 把相对地址补成绝对地址 */
    private static String resolve(String base, String rel) {
        try {
            return new URL(new URL(base), rel).toString();
        } catch (Exception e) {
            return rel;
        }
    }

    /** 解析 #EXTINF 的时长（秒） */
    private static double parseExtinf(String line) {
        int colon = line.indexOf(':');
        if (colon < 0) {
            return 0;
        }
        String rest = line.substring(colon + 1);
        int comma = rest.indexOf(',');
        if (comma >= 0) {
            rest = rest.substring(0, comma);
        }
        try {
            return Double.parseDouble(rest.trim());
        } catch (NumberFormatException e) {
            return 0;
        }
    }

    /** URL 安全编码（作为查询参数值传递） */
    public static String encodeUrl(String url) {
        return Base64.getUrlEncoder().withoutPadding()
                .encodeToString(url.getBytes(StandardCharsets.UTF_8));
    }

    /** URL 安全解码 */
    public static String decodeUrl(String encoded) {
        return new String(Base64.getUrlDecoder().decode(encoded), StandardCharsets.UTF_8);
    }
}
