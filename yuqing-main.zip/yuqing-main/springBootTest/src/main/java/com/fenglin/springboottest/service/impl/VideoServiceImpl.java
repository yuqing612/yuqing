package com.fenglin.springboottest.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.fenglin.springboottest.entity.Video;
import com.fenglin.springboottest.mapper.VideoMapper;
import com.fenglin.springboottest.service.VideoService;
import com.fenglin.springboottest.vo.VideoVO;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class VideoServiceImpl extends ServiceImpl<VideoMapper, Video> implements VideoService {

    @Override
    public List<VideoVO> listDailyRecommend() {
        List<Video> list = this.list(new LambdaQueryWrapper<Video>()
                .eq(Video::getDailyPick, 1)
                .orderByDesc(Video::getPlay));
        if (list.isEmpty()) {
            // 当日无推荐标记时回退为全部视频
            list = this.list(new LambdaQueryWrapper<Video>().orderByDesc(Video::getPlay));
        }
        return list.stream().map(VideoServiceImpl::toVO).collect(Collectors.toList());
    }

    @Override
    public List<VideoVO> listRank() {
        List<Video> list = this.list(new LambdaQueryWrapper<Video>().orderByDesc(Video::getPlay));
        List<VideoVO> vos = list.stream().map(VideoServiceImpl::toVO).collect(Collectors.toList());
        for (int i = 0; i < vos.size(); i++) {
            vos.get(i).setRank(i + 1);
        }
        return vos;
    }

    @Override
    public List<VideoVO> search(String q) {
        String kw = (q == null ? "" : q).trim();
        if (kw.isEmpty()) {
            return listDailyRecommend();
        }
        List<Video> list = this.list(new LambdaQueryWrapper<Video>()
                .like(Video::getTitle, kw)
                .or().like(Video::getUploader, kw)
                .or().like(Video::getTags, kw)
                .orderByDesc(Video::getPlay));
        return list.stream().map(VideoServiceImpl::toVO).collect(Collectors.toList());
    }

    @Override
    public VideoVO getDetail(Long id) {
        Video v = this.getById(id);
        return v == null ? null : toVO(v);
    }

    @Override
    public List<VideoVO> listFavorites() {
        return this.list(new LambdaQueryWrapper<Video>()
                        .eq(Video::getFav, 1)
                        .orderByDesc(Video::getPlay))
                .stream().map(VideoServiceImpl::toVO).collect(Collectors.toList());
    }

    /** 实体转对外视图对象：tags 逗号串 -> 字符串数组，fav 0/1 -> 布尔 */
    private static VideoVO toVO(Video v) {
        VideoVO vo = new VideoVO();
        vo.setId(v.getId());
        vo.setTitle(v.getTitle());
        vo.setUploader(v.getUploader());
        vo.setViews(v.getViews());
        vo.setPlay(v.getPlay());
        vo.setDanmaku(v.getDanmaku());
        vo.setDuration(v.getDuration());
        vo.setTags(splitTags(v.getTags()));
        vo.setDesc(v.getDescription());
        vo.setFav(v.getFav() != null && v.getFav() == 1);
        vo.setGrad(v.getGrad());
        vo.setCoverUrl(v.getCoverUrl());
        vo.setSrc(v.getSrc());
        vo.setSourceType(normalizeSourceType(v.getSourceType()));
        vo.setVid(v.getVid());
        return vo;
    }

    /**
     * 播放源类型归一化：只有 "tencent" 视为腾讯视频，其余一律按原生直链处理，
     * 保证历史数据（source_type 为 null 或空串）行为不变。
     */
    public static String normalizeSourceType(String sourceType) {
        return "tencent".equalsIgnoreCase(sourceType == null ? "" : sourceType.trim())
                ? "tencent"
                : "native";
    }

    /**
     * 生成腾讯视频 iframe 播放器地址。
     * vid 形如 v3186hgiqhs；前端直接把它放进 iframe 的 src 即可播放。
     */
    public static String buildTencentSrc(String vid) {
        if (vid == null || vid.isBlank()) {
            return "";
        }
        String v = vid.trim();

        // 1) 带 vid= 查询参数时优先取参数值
        java.util.regex.Matcher m = java.util.regex.Pattern
                .compile("[?&]vid=([A-Za-z0-9]+)").matcher(v);
        if (m.find()) {
            v = m.group(1);
        } else {
            // 2) 否则取路径最后一段（x/page/v3186hgiqhs.html -> v3186hgiqhs）
            int cut = v.indexOf('?');
            if (cut >= 0) {
                v = v.substring(0, cut);
            }
            int hash = v.indexOf('#');
            if (hash >= 0) {
                v = v.substring(0, hash);
            }
            int slash = v.lastIndexOf('/');
            if (slash >= 0) {
                v = v.substring(slash + 1);
            }
            // 3) 去掉扩展名（.html）与其它非字母数字字符
            int dot = v.indexOf('.');
            if (dot >= 0) {
                v = v.substring(0, dot);
            }
            v = v.replaceAll("[^A-Za-z0-9]", "");
        }

        if (v.isEmpty()) {
            return "";
        }
        return "https://v.qq.com/txp/iframe/player.html?vid=" + v + "&auto=0";
    }

    private static List<String> splitTags(String tags) {
        if (tags == null || tags.isEmpty()) {
            return new ArrayList<>();
        }
        return Arrays.stream(tags.split(","))
                .map(String::trim)
                .filter(s -> !s.isEmpty())
                .collect(Collectors.toList());
    }
}
