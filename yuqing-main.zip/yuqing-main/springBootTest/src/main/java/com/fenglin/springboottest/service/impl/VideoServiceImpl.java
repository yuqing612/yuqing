package com.fenglin.springboottest.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.fenglin.springboottest.entity.Video;
import com.fenglin.springboottest.entity.VideoEpisode;
import com.fenglin.springboottest.mapper.VideoEpisodeMapper;
import com.fenglin.springboottest.mapper.VideoMapper;
import com.fenglin.springboottest.service.VideoService;
import com.fenglin.springboottest.vo.VideoEpisodeVO;
import com.fenglin.springboottest.vo.VideoVO;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;

@Service
public class VideoServiceImpl extends ServiceImpl<VideoMapper, Video> implements VideoService {

    private final VideoEpisodeMapper episodeMapper;

    public VideoServiceImpl(VideoEpisodeMapper episodeMapper) {
        this.episodeMapper = episodeMapper;
    }

    @Override
    public List<VideoVO> listDailyRecommend() {
        List<Video> list = this.list(new LambdaQueryWrapper<Video>()
                .eq(Video::getDailyPick, 1)
                .orderByDesc(Video::getPlay));
        if (list.isEmpty()) {
            // 当日无推荐标记时回退为全部视频
            list = this.list(new LambdaQueryWrapper<Video>().orderByDesc(Video::getPlay));
        }
        return withEpisodes(list.stream().map(VideoServiceImpl::toVO).collect(Collectors.toList()));
    }

    @Override
    public List<VideoVO> listRank() {
        List<Video> list = this.list(new LambdaQueryWrapper<Video>().orderByDesc(Video::getPlay));
        List<VideoVO> vos = withEpisodes(list.stream().map(VideoServiceImpl::toVO).collect(Collectors.toList()));
        for (int i = 0; i < vos.size(); i++) {
            vos.get(i).setRank(i + 1);
        }
        return vos;
    }

    @Override
    public List<VideoVO> search(String q) {
        String kw = (q == null ? "" : q).trim();
        if (kw.isEmpty()) {
            return listDailyRecommend();
        }
        List<Video> list = this.list(new LambdaQueryWrapper<Video>()
                .like(Video::getTitle, kw)
                .or().like(Video::getUploader, kw)
                .or().like(Video::getTags, kw)
                .orderByDesc(Video::getPlay));
        return withEpisodes(list.stream().map(VideoServiceImpl::toVO).collect(Collectors.toList()));
    }

    @Override
    public VideoVO getDetail(Long id) {
        Video v = this.getById(id);
        if (v == null) {
            return null;
        }
        List<VideoVO> vos = withEpisodes(Collections.singletonList(toVO(v)));
        return vos.get(0);
    }

    @Override
    public List<VideoVO> listFavorites() {
        List<Video> list = this.list(new LambdaQueryWrapper<Video>()
                .eq(Video::getFav, 1)
                .orderByDesc(Video::getPlay));
        return withEpisodes(list.stream().map(VideoServiceImpl::toVO).collect(Collectors.toList()));
    }

    /**
     * 批量补齐分集播放源。
     * 一次性按 video_id 集合查分集表，避免逐条视频查询造成 N+1。
     * 没有配置分集的视频，episodeList 为空列表，前端据此隐藏选集面板。
     */
    private List<VideoVO> withEpisodes(List<VideoVO> vos) {
        if (vos == null || vos.isEmpty()) {
            return vos == null ? new ArrayList<>() : vos;
        }
        List<Long> ids = vos.stream()
                .map(VideoVO::getId)
                .filter(Objects::nonNull)
                .distinct()
                .collect(Collectors.toList());
        if (ids.isEmpty()) {
            return vos;
        }
        List<VideoEpisode> rows = episodeMapper.selectList(new LambdaQueryWrapper<VideoEpisode>()
                .in(VideoEpisode::getVideoId, ids)
                .orderByAsc(VideoEpisode::getVideoId)
                .orderByAsc(VideoEpisode::getEpNo));
        if (rows.isEmpty()) {
            return vos;
        }
        Map<Long, List<VideoEpisodeVO>> grouped = rows.stream()
                .collect(Collectors.groupingBy(
                        VideoEpisode::getVideoId,
                        LinkedHashMap::new,
                        Collectors.mapping(this::toEpisodeVO, Collectors.toList())));
        for (VideoVO vo : vos) {
            vo.setEpisodeList(grouped.getOrDefault(vo.getId(), Collections.emptyList()));
        }
        return vos;
    }

    private VideoEpisodeVO toEpisodeVO(VideoEpisode e) {
        VideoEpisodeVO vo = new VideoEpisodeVO();
        vo.setId(e.getId());
        vo.setVideoId(e.getVideoId());
        vo.setEpNo(e.getEpNo());
        vo.setTitle(e.getEpTitle());
        // 有 m3u8 直链（omofun 源）时直连播放，否则退回 B 站官方 iframe 地址
        String m3u8 = e.getM3u8Url();
        vo.setM3u8Url(m3u8);
        vo.setSrc(m3u8 != null && !m3u8.isBlank()
                ? m3u8
                : VideoServiceImpl.buildBilibiliSrc(e.getBvid()));
        vo.setDuration(e.getDuration());
        vo.setVip(e.getVip() != null && e.getVip() == 1);
        return vo;
    }

    /** 实体转对外视图对象：tags 逗号串 -> 字符串数组，fav 0/1 -> 布尔 */
    private static VideoVO toVO(Video v) {
        VideoVO vo = new VideoVO();
        vo.setId(v.getId());
        vo.setTitle(v.getTitle());
        vo.setUploader(v.getUploader());
        vo.setViews(v.getViews());
        vo.setPlay(v.getPlay());
        vo.setDanmaku(v.getDanmaku());
        vo.setDuration(v.getDuration());
        vo.setTags(splitTags(v.getTags()));
        vo.setDesc(v.getDescription());
        vo.setFav(v.getFav() != null && v.getFav() == 1);
        vo.setGrad(v.getGrad());
        vo.setCoverUrl(v.getCoverUrl());
        vo.setSrc(v.getSrc());
        vo.setSourceType(normalizeSourceType(v.getSourceType()));
        vo.setVid(v.getVid());
        vo.setBvid(v.getBvid());
        vo.setOmofunId(v.getOmofunId());
        return vo;
    }

    /**
     * 播放源类型归一化：
     *   tencent   -> 腾讯视频
     *   bilibili  -> 哔哩哔哩
     *   omofun    -> 动漫共和国（m3u8 直链，前端用 hls.js 播放）
     * 其余（含 null / 空串）一律按原生直链处理，保证历史数据行为不变。
     */
    public static String normalizeSourceType(String sourceType) {
        String t = sourceType == null ? "" : sourceType.trim();
        if ("tencent".equalsIgnoreCase(t)) {
            return "tencent";
        }
        if ("bilibili".equalsIgnoreCase(t)) {
            return "bilibili";
        }
        if ("omofun".equalsIgnoreCase(t)) {
            return "omofun";
        }
        return "native";
    }

    /**
     * 生成动漫共和国（OMoFun）播放页地址。
     *
     * <p>该站为苹果 CMS 架构，播放页形如：
     * <pre>https://www.omofun23.com/index.php/vod/play/id/{vodId}/sid/{sid}/nid/{nid}.html</pre>
     * 其中 vodId 为作品 id、sid 为线路、nid 为集号。
     *
     * <p>播放页内嵌的官方播放器会自行解析出 m3u8 直链并提供清晰度切换，
     * 因此这里直接给出播放页地址，由前端以 iframe 嵌入。
     */
    public static String buildOmofunSrc(String vodId, int sid, int nid) {
        if (vodId == null || vodId.isBlank()) {
            return "";
        }
        String id = vodId.trim().replaceAll("[^0-9A-Za-z]", "");
        if (id.isEmpty()) {
            return "";
        }
        int s = sid > 0 ? sid : 1;
        int n = nid > 0 ? nid : 1;
        return "https://www.omofun23.com/index.php/vod/play/id/" + id
                + "/sid/" + s + "/nid/" + n + ".html";
    }

    /**
     * 生成腾讯视频 iframe 播放器地址。
     * vid 形如 v3186hgiqhs；前端直接把它放进 iframe 的 src 即可播放。
     */
    public static String buildTencentSrc(String vid) {
        if (vid == null || vid.isBlank()) {
            return "";
        }
        String v = vid.trim();

        // 1) 带 vid= 查询参数时优先取参数值
        java.util.regex.Matcher m = java.util.regex.Pattern
                .compile("[?&]vid=([A-Za-z0-9]+)").matcher(v);
        if (m.find()) {
            v = m.group(1);
        } else {
            // 2) 否则取路径最后一段（x/page/v3186hgiqhs.html -> v3186hgiqhs）
            int cut = v.indexOf('?');
            if (cut >= 0) {
                v = v.substring(0, cut);
            }
            int hash = v.indexOf('#');
            if (hash >= 0) {
                v = v.substring(0, hash);
            }
            int slash = v.lastIndexOf('/');
            if (slash >= 0) {
                v = v.substring(slash + 1);
            }
            // 3) 去掉扩展名（.html）与其它非字母数字字符
            int dot = v.indexOf('.');
            if (dot >= 0) {
                v = v.substring(0, dot);
            }
            v = v.replaceAll("[^A-Za-z0-9]", "");
        }

        if (v.isEmpty()) {
            return "";
        }
        return "https://v.qq.com/txp/iframe/player.html?vid=" + v + "&auto=0";
    }

    /**
     * 生成哔哩哔哩官方 iframe 播放器地址。
     *
     * <p>入参允许填写以下任意一种形式，服务端统一解析：
     * <ul>
     *   <li>纯 BV 号：BV1Lk8C6bE3z</li>
     *   <li>带分P：BV1Lk8C6bE3z?p=3</li>
     *   <li>完整播放页地址：https://www.bilibili.com/video/BV1Lk8C6bE3z/?p=3</li>
     * </ul>
     * 分P 页码从地址里的 p 参数提取，缺省为第 1P。
     * 前端直接把该地址放进 iframe 的 src 即可播放。
     */
    public static String buildBilibiliSrc(String bvid) {
        if (bvid == null || bvid.isBlank()) {
            return "";
        }
        String raw = bvid.trim();

        // 1) 提取分P 页码：兼容 ?p=3、&p=3、/p=3 三种写法
        java.util.regex.Matcher pm = java.util.regex.Pattern
                .compile("[?&/]p=(\\d+)").matcher(raw);
        int page = 1;
        if (pm.find()) {
            try {
                int parsed = Integer.parseInt(pm.group(1));
                if (parsed > 0) {
                    page = parsed;
                }
            } catch (NumberFormatException ignored) {
                // 页码非法时退回第 1P
            }
        }

        // 2) 提取 BV 号（B 站 BV 号固定为 BV + 10 位字母数字）
        java.util.regex.Matcher bm = java.util.regex.Pattern
                .compile("BV[0-9A-Za-z]{10}").matcher(raw);
        if (!bm.find()) {
            return "";
        }
        String bv = bm.group();

        return "https://player.bilibili.com/player.html?bvid=" + bv
                + "&p=" + page
                + "&autoplay=0"
                + "&high_quality=1"
                + "&danmaku=0";
    }

    private static List<String> splitTags(String tags) {
        if (tags == null || tags.isEmpty()) {
            return new ArrayList<>();
        }
        return Arrays.stream(tags.split(","))
                .map(String::trim)
                .filter(s -> !s.isEmpty())
                .collect(Collectors.toList());
    }
}
