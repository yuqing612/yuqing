package com.fenglin.springboottest.vo;

import com.fasterxml.jackson.annotation.JsonInclude;

/**
 * 视频分集播放源出参。
 *
 * <p>src 已由服务端拼装成 B 站官方 iframe 播放器地址，前端直接放进 iframe 即可播放。
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public class VideoEpisodeVO {

    private Long id;

    /** 所属视频 id */
    private Long videoId;

    /** 集号，从 1 开始 */
    private Integer epNo;

    /** 本集标题 */
    private String title;

    /** 播放地址（已拼装好的 iframe 地址） */
    private String src;

    /**
     * m3u8 直链（动漫共和国等 HLS 源）。
     * 前端优先用它配合 hls.js 直连播放，效果与站内一致且无第三方页面框。
     */
    private String m3u8Url;

    /** 时长（毫秒） */
    private Integer duration;

    /** 是否大会员专享：true 需登录 B 站大会员观看 */
    private Boolean vip;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getVideoId() {
        return videoId;
    }

    public void setVideoId(Long videoId) {
        this.videoId = videoId;
    }

    public Integer getEpNo() {
        return epNo;
    }

    public void setEpNo(Integer epNo) {
        this.epNo = epNo;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getSrc() {
        return src;
    }

    public void setSrc(String src) {
        this.src = src;
    }

    public String getM3u8Url() {
        return m3u8Url;
    }

    public void setM3u8Url(String m3u8Url) {
        this.m3u8Url = m3u8Url;
    }

    public Integer getDuration() {
        return duration;
    }

    public void setDuration(Integer duration) {
        this.duration = duration;
    }

    public Boolean getVip() {
        return vip;
    }

    public void setVip(Boolean vip) {
        this.vip = vip;
    }
}
