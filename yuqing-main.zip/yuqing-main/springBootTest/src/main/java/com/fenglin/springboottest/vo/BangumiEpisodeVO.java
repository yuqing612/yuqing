package com.fenglin.springboottest.vo;

/**
 * 番剧分集播放源出参。
 *
 * <p>src 已由服务端拼装成 B 站官方 iframe 播放器地址，前端直接放进 iframe 即可播放。
 */
public class BangumiEpisodeVO {

    private Long id;

    /** 所属番剧 id */
    private Long bangumiId;

    /** 集号，从 1 开始 */
    private Integer epNo;

    /** 本集标题 */
    private String title;

    /** 播放地址（已拼装好的 iframe 地址） */
    private String src;

    /** 时长（毫秒） */
    private Integer duration;

    /** 是否大会员专享：true 需登录 B 站大会员观看 */
    private Boolean vip;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getBangumiId() {
        return bangumiId;
    }

    public void setBangumiId(Long bangumiId) {
        this.bangumiId = bangumiId;
    }

    public Integer getEpNo() {
        return epNo;
    }

    public void setEpNo(Integer epNo) {
        this.epNo = epNo;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getSrc() {
        return src;
    }

    public void setSrc(String src) {
        this.src = src;
    }

    public Integer getDuration() {
        return duration;
    }

    public void setDuration(Integer duration) {
        this.duration = duration;
    }

    public Boolean getVip() {
        return vip;
    }

    public void setVip(Boolean vip) {
        this.vip = vip;
    }
}
