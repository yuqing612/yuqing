package com.fenglin.springboottest.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.fenglin.springboottest.entity.Banner;
import com.fenglin.springboottest.vo.BannerVO;

import java.util.List;

/**
 * 首页轮播服务。
 */
public interface BannerService extends IService<Banner> {

    /** 启用中的轮播位列表（带关联番剧信息） */
    List<BannerVO> listActive();
}
