package com.fenglin.springboottest.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

import java.math.BigDecimal;

/**
 * 后台新增/编辑番剧的请求体。
 * tags 用斜杠分隔（与 bangumi.tags 列的存储格式一致）。
 */
public class BangumiForm {

    @NotBlank(message = "请填写番剧标题")
    private String title;

    /** 内联 SVG 源码（3:4 竖版海报），体积大，新建时可留空走渐变兜底 */
    private String coverSvg;

    /** 外部封面图 URL，优先级高于 coverSvg */
    private String coverUrl;

    /** CSS 渐变封面 */
    private String coverGradient;

    /** 播放源类型：native / tencent / bilibili */
    private String sourceType;

    /** 腾讯视频 VID（source_type=tencent 时有效） */
    private String vid;

    /** 哔哩哔哩 BV 号（source_type=bilibili 时有效） */
    private String bvid;

    /** 原生直链播放地址（source_type=native 时有效） */
    private String src;

    @NotNull(message = "请填写总集数")
    private Integer episodes;

    /** 连载中 / 已完结 */
    private String status;

    @NotNull(message = "请填写评分")
    private BigDecimal score;

    /** 制作公司 */
    private String studio;

    /** 分类：日漫 / 国漫 / 剧场 / 美漫 */
    private String category;

    /** 标签，斜杠分隔 */
    private String tags;

    /** 简介 */
    private String description;

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getCoverSvg() {
        return coverSvg;
    }

    public void setCoverSvg(String coverSvg) {
        this.coverSvg = coverSvg;
    }

    public String getCoverUrl() {
        return coverUrl;
    }

    public void setCoverUrl(String coverUrl) {
        this.coverUrl = coverUrl;
    }

    public String getCoverGradient() {
        return coverGradient;
    }

    public void setCoverGradient(String coverGradient) {
        this.coverGradient = coverGradient;
    }

    public String getSourceType() {
        return sourceType;
    }

    public void setSourceType(String sourceType) {
        this.sourceType = sourceType;
    }

    public String getVid() {
        return vid;
    }

    public void setVid(String vid) {
        this.vid = vid;
    }

    public String getBvid() {
        return bvid;
    }

    public void setBvid(String bvid) {
        this.bvid = bvid;
    }

    public String getSrc() {
        return src;
    }

    public void setSrc(String src) {
        this.src = src;
    }

    public Integer getEpisodes() {
        return episodes;
    }

    public void setEpisodes(Integer episodes) {
        this.episodes = episodes;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public BigDecimal getScore() {
        return score;
    }

    public void setScore(BigDecimal score) {
        this.score = score;
    }

    public String getStudio() {
        return studio;
    }

    public void setStudio(String studio) {
        this.studio = studio;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public String getTags() {
        return tags;
    }

    public void setTags(String tags) {
        this.tags = tags;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }
}
