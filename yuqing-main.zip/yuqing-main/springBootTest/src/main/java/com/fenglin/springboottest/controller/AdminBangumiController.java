package com.fenglin.springboottest.controller;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.fenglin.springboottest.common.Result;
import com.fenglin.springboottest.entity.Bangumi;
import com.fenglin.springboottest.mapper.BangumiMapper;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.HashMap;
import java.util.Map;

/**
 * 后台番剧管理：首页 Hero 轮播 / 番剧新番墙数据源的增删改查。
 * 路径统一在 /api/admin/bangumi 下，由 AdminAuthInterceptor 保证仅 ADMIN 可访问。
 */
@RestController
@RequestMapping("/api/admin/bangumi")
public class AdminBangumiController {

    private final BangumiMapper bangumiMapper;

    public AdminBangumiController(BangumiMapper bangumiMapper) {
        this.bangumiMapper = bangumiMapper;
    }

    /** 分页列表 + 关键词搜索（标题 / 制作公司 / 标签 / 分类） */
    @GetMapping
    public Result<Map<String, Object>> list(
            @RequestParam(defaultValue = "") String keyword,
            @RequestParam(defaultValue = "1") long page,
            @RequestParam(defaultValue = "10") long size) {
        QueryWrapper<Bangumi> qw = new QueryWrapper<>();
        // cover_svg 是整幅内联插画源码，单条可达数十 KB；后台列表用不到，
        // 插画走 /api/bangumi/{id}/cover 单独取，这里排除以免列表响应过大
        qw.select("id", "title", "cover_url", "cover_gradient", "episodes", "status",
                "score", "studio", "category", "tags", "description", "create_time", "update_time");
        if (keyword != null && !keyword.trim().isEmpty()) {
            String kw = keyword.trim();
            qw.like("title", kw).or().like("studio", kw).or().like("tags", kw).or().like("category", kw);
        }
        qw.orderByDesc("id");
        IPage<Bangumi> p = bangumiMapper.selectPage(new Page<>(page, size), qw);
        Map<String, Object> data = new HashMap<>();
        data.put("list", p.getRecords());
        data.put("total", p.getTotal());
        data.put("page", p.getCurrent());
        data.put("size", p.getSize());
        return Result.ok(data);
    }

    /** 详情 */
    @GetMapping("/{id}")
    public Result<Bangumi> detail(@PathVariable Long id) {
        Bangumi b = bangumiMapper.selectById(id);
        if (b == null) {
            return Result.fail("番剧不存在");
        }
        return Result.ok(b);
    }

    /** 新增 */
    @PostMapping
    public Result<Bangumi> create(@RequestBody Bangumi bangumi) {
        bangumi.setId(null);
        bangumiMapper.insert(bangumi);
        return Result.ok(bangumi);
    }

    /** 修改 */
    @PutMapping("/{id}")
    public Result<Bangumi> update(@PathVariable Long id, @RequestBody Bangumi bangumi) {
        Bangumi exist = bangumiMapper.selectById(id);
        if (exist == null) {
            return Result.fail("番剧不存在");
        }
        bangumi.setId(id);
        bangumiMapper.updateById(bangumi);
        return Result.ok(bangumiMapper.selectById(id));
    }

    /** 删除 */
    @DeleteMapping("/{id}")
    public Result<Void> delete(@PathVariable Long id) {
        if (bangumiMapper.selectById(id) == null) {
            return Result.fail("番剧不存在");
        }
        bangumiMapper.deleteById(id);
        return Result.ok();
    }
}
