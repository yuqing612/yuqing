package com.fenglin.springboottest.config;

import com.fenglin.springboottest.common.AdminContext;
import com.fenglin.springboottest.service.AdminTokenService;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;
import org.springframework.web.servlet.HandlerInterceptor;

import java.io.IOException;

/**
 * 后台管理员鉴权拦截器：保护 /api/admin/**（除登录接口），
 * 校验后台专用 JWT，通过后把 adminId 与原始令牌写入 AdminContext。
 * 令牌缺失或无效直接返回 401，不再进入 Controller。
 */
@Component
public class AdminAuthInterceptor implements HandlerInterceptor {

    private final AdminTokenService tokenService;

    public AdminAuthInterceptor(AdminTokenService tokenService) {
        this.tokenService = tokenService;
    }

    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws IOException {
        if ("OPTIONS".equalsIgnoreCase(request.getMethod())) {
            return true;
        }
        String token = extractToken(request.getHeader("Authorization"));
        Long adminId = tokenService.resolve(token);
        if (adminId == null) {
            writeUnauthorized(response);
            return false;
        }
        AdminContext.set(adminId, token);
        return true;
    }

    @Override
    public void afterCompletion(HttpServletRequest request, HttpServletResponse response, Object handler, Exception ex) {
        AdminContext.clear();
    }

    private String extractToken(String authorization) {
        if (!StringUtils.hasText(authorization)) {
            return null;
        }
        return authorization.startsWith("Bearer ") ? authorization.substring(7).trim() : authorization.trim();
    }

    private void writeUnauthorized(HttpServletResponse response) throws IOException {
        response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
        response.setContentType("application/json;charset=UTF-8");
        response.getWriter().write("{\"code\":401,\"message\":\"后台登录状态已失效，请重新登录\",\"data\":null}");
    }
}
