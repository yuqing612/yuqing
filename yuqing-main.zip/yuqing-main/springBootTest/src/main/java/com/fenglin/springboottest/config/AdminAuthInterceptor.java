package com.fenglin.springboottest.config;

import com.fenglin.springboottest.common.AuthContext;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.HandlerInterceptor;

import java.io.IOException;

/**
 * 后台管理鉴权拦截器：仅放行 role = ADMIN 的账号。
 * 依赖 AuthInterceptor 先执行并写入 AuthContext（含 role）。
 * 路径由 WebConfig 限定在 /api/admin/**。
 */
@Component
public class AdminAuthInterceptor implements HandlerInterceptor {

    private static final String ADMIN = "ADMIN";

    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws IOException {
        if ("OPTIONS".equalsIgnoreCase(request.getMethod())) {
            return true;
        }
        String role = AuthContext.getRole();
        if (!ADMIN.equals(role)) {
            writeForbidden(response);
            return false;
        }
        return true;
    }

    private void writeForbidden(HttpServletResponse response) throws IOException {
        response.setStatus(HttpServletResponse.SC_FORBIDDEN);
        response.setContentType("application/json;charset=UTF-8");
        response.getWriter().write("{\"code\":403,\"message\":\"无后台管理权限\",\"data\":null}");
    }
}
