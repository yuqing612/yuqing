package com.fenglin.springboottest.controller;

import com.fenglin.springboottest.common.Result;
import com.fenglin.springboottest.service.CategoryService;
import com.fenglin.springboottest.vo.CategoryVO;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 * 分类树接口：首页分类导航与搜索筛选面板的数据来源。
 *
 * GET /api/categories?module=video    分类树（顶级分区 + 子分类）
 */
@RestController
@RequestMapping("/api/categories")
public class CategoryController {

    private final CategoryService categoryService;

    public CategoryController(CategoryService categoryService) {
        this.categoryService = categoryService;
    }

    /**
     * 分类树。
     *
     * @param module video（视频分区）/ bangumi（番剧分区）/ all（全部）
     */
    @GetMapping
    public Result<List<CategoryVO>> tree(@RequestParam(defaultValue = "video") String module) {
        return Result.ok(categoryService.tree(module, true));
    }
}
