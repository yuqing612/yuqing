package com.fenglin.springboottest.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;

/**
 * 视频分集播放源实体，对应 video_episode 表。
 *
 * <p>与番剧分集（bangumi_episode）同构：一个 video 条目可能对应一部番剧的
 * 多个正片分集（如《赛马娘 第二季》13 话），单个 bvid 字段放不下，
 * 这里按集独立存储播放源，服务端据此拼装官方 iframe 播放器地址。
 */
@TableName("video_episode")
public class VideoEpisode {

    @TableId(type = IdType.AUTO)
    private Long id;

    /** 所属视频 id（video.id） */
    private Long videoId;

    /** 集号，从 1 开始 */
    private Integer epNo;

    /** 本集标题 */
    private String epTitle;

    /** 哔哩哔哩 BV 号 */
    private String bvid;

    /** 哔哩哔哩 cid */
    private String cid;

    /**
     * m3u8 直链（动漫共和国等 HLS 源，source_type = omofun 时有效）。
     * 前端优先用它配合 hls.js 直连播放，避免嵌第三方页面框。
     */
    private String m3u8Url;

    /** 时长（毫秒） */
    private Integer duration;

    /** 是否大会员专享：1 是，0 否 */
    private Integer vip;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getVideoId() {
        return videoId;
    }

    public void setVideoId(Long videoId) {
        this.videoId = videoId;
    }

    public Integer getEpNo() {
        return epNo;
    }

    public void setEpNo(Integer epNo) {
        this.epNo = epNo;
    }

    public String getEpTitle() {
        return epTitle;
    }

    public void setEpTitle(String epTitle) {
        this.epTitle = epTitle;
    }

    public String getBvid() {
        return bvid;
    }

    public void setBvid(String bvid) {
        this.bvid = bvid;
    }

    public String getCid() {
        return cid;
    }

    public void setCid(String cid) {
        this.cid = cid;
    }

    public String getM3u8Url() {
        return m3u8Url;
    }

    public void setM3u8Url(String m3u8Url) {
        this.m3u8Url = m3u8Url;
    }

    public Integer getDuration() {
        return duration;
    }

    public void setDuration(Integer duration) {
        this.duration = duration;
    }

    public Integer getVip() {
        return vip;
    }

    public void setVip(Integer vip) {
        this.vip = vip;
    }
}
