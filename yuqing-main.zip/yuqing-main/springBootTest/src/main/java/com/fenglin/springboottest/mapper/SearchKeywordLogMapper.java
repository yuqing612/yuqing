package com.fenglin.springboottest.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.fenglin.springboottest.entity.SearchKeywordLog;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface SearchKeywordLogMapper extends BaseMapper<SearchKeywordLog> {
}
