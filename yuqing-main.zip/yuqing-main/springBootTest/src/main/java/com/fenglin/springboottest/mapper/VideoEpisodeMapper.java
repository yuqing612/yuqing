package com.fenglin.springboottest.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.fenglin.springboottest.entity.VideoEpisode;
import org.apache.ibatis.annotations.Mapper;

/** 视频分集播放源 Mapper */
@Mapper
public interface VideoEpisodeMapper extends BaseMapper<VideoEpisode> {
}
