package com.fenglin.springboottest.vo;

import java.util.List;

/**
 * 番剧出参视图，字段与前端 mock 数据一一对应，
 * 前端切换到真实接口后页面零改动。
 */
public class BangumiVO {

    private Long id;

    private String title;

    /** CSS 渐变封面，用于 :style="{ background: b.cover }" */
    private String cover;

    /** 插画地址：外部 URL 或 /api/bangumi/{id}/cover；无图时为 null */
    private String illust;

    /**
     * 外部封面图原始地址。
     * 前台列表用不到，但后台编辑需要它回填表单，
     * 否则编辑其它字段时会把已有封面地址清空。
     */
    private String coverUrl;

    /**
     * 播放地址。原生源为直链 mp4；腾讯 / B 站源为服务端拼装好的 iframe 地址。
     * 前端据此决定用 <video> 还是 <iframe> 播放。
     */
    private String src;

    /** 播放源类型：native / tencent / bilibili */
    private String sourceType;

    /** 腾讯视频 VID（source_type=tencent 时有效） */
    private String vid;

    /** 哔哩哔哩 BV 号（source_type=bilibili 时有效） */
    private String bvid;

    /**
     * 分集播放源列表（来自 bangumi_episode 表）。
     * 有分集时前端可展示选集面板，一键切换到对应集的 iframe 播放器。
     */
    private java.util.List<BangumiEpisodeVO> episodeList;

    private Integer episodes;

    private String status;

    /** 评分，前端直接 toFixed(1) */
    private Double score;

    private String studio;

    private String category;

    private List<String> tags;

    private String desc;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getCover() {
        return cover;
    }

    public void setCover(String cover) {
        this.cover = cover;
    }

    public String getIllust() {
        return illust;
    }

    public void setIllust(String illust) {
        this.illust = illust;
    }

    public String getCoverUrl() {
        return coverUrl;
    }

    public void setCoverUrl(String coverUrl) {
        this.coverUrl = coverUrl;
    }

    public String getSrc() {
        return src;
    }

    public void setSrc(String src) {
        this.src = src;
    }

    public String getSourceType() {
        return sourceType;
    }

    public void setSourceType(String sourceType) {
        this.sourceType = sourceType;
    }

    public String getVid() {
        return vid;
    }

    public void setVid(String vid) {
        this.vid = vid;
    }

    public String getBvid() {
        return bvid;
    }

    public void setBvid(String bvid) {
        this.bvid = bvid;
    }

    public java.util.List<BangumiEpisodeVO> getEpisodeList() {
        return episodeList;
    }

    public void setEpisodeList(java.util.List<BangumiEpisodeVO> episodeList) {
        this.episodeList = episodeList;
    }

    public Integer getEpisodes() {
        return episodes;
    }

    public void setEpisodes(Integer episodes) {
        this.episodes = episodes;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Double getScore() {
        return score;
    }

    public void setScore(Double score) {
        this.score = score;
    }

    public String getStudio() {
        return studio;
    }

    public void setStudio(String studio) {
        this.studio = studio;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public List<String> getTags() {
        return tags;
    }

    public void setTags(List<String> tags) {
        this.tags = tags;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }
}
