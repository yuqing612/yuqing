package com.fenglin.springboottest.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.fenglin.springboottest.entity.SysUser;

public interface SysUserService extends IService<SysUser> {

    /**
     * 登录校验：account 支持用户名或邮箱
     *
     * @throws IllegalArgumentException 账号不存在 / 被禁用 / 密码错误
     */
    SysUser login(String account, String rawPassword);

    /**
     * 注册新用户
     *
     * @throws IllegalArgumentException 用户名或邮箱已被占用
     */
    SysUser register(String username, String email, String rawPassword, String nickname);
}
