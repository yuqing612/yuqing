package com.fenglin.springboottest.service;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.JwtException;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.security.Keys;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import javax.crypto.SecretKey;
import java.nio.charset.StandardCharsets;
import java.util.Date;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * JWT 登录令牌服务（HS256）。
 * - 无状态：后端重启后已签发的 token 依然有效；
 * - 勾选"记住我"有效期 7 天，否则 12 小时（app.jwt.expire-* 可配）；
 * - 登出通过 jti 黑名单实现，黑名单条目随 token 过期自动清理；
 * - 修改密码通过"会话纪元"实现：改密后该账号此前签发的所有 token 立即失效，
 *   避免"改了密码但旧会话仍能用"的安全缺口。
 */
@Service
public class AuthTokenService {

    private final SecretKey key;
    private final long expireRemember;
    private final long expireSession;

    /** 已登出但未过期的 token jti -> 过期时间戳 */
    private final Map<String, Long> blacklist = new ConcurrentHashMap<>();

    /**
     * 账号 id -> 会话纪元号。
     * 纪元号在修改密码时递增，token 中携带签发时的纪元号，
     * 校验时与当前纪元号比对，不一致说明该 token 签发于改密之前，直接判失效。
     */
    private final Map<Long, Long> epochs = new ConcurrentHashMap<>();

    public AuthTokenService(
            @Value("${app.jwt.secret}") String secret,
            @Value("${app.jwt.expire-remember:604800000}") long expireRemember,
            @Value("${app.jwt.expire-session:43200000}") long expireSession) {
        this.key = Keys.hmacShaKeyFor(secret.getBytes(StandardCharsets.UTF_8));
        this.expireRemember = expireRemember;
        this.expireSession = expireSession;
    }

    /** 登录成功后签发 JWT，subject 为 userId */
    public String create(Long userId, boolean remember) {
        cleanBlacklist();
        long ttl = remember ? expireRemember : expireSession;
        Date now = new Date();
        return Jwts.builder()
                .id(UUID.randomUUID().toString().replace("-", ""))
                .subject(String.valueOf(userId))
                .claim("ep", currentEpoch(userId))
                .issuedAt(now)
                .expiration(new Date(now.getTime() + ttl))
                .signWith(key)
                .compact();
    }

    /** 校验 token，返回 userId；无效、过期、已登出或改密前签发均返回 null */
    public Long resolve(String token) {
        if (token == null || token.isBlank()) {
            return null;
        }
        try {
            Claims claims = Jwts.parser()
                    .verifyWith(key)
                    .build()
                    .parseSignedClaims(token)
                    .getPayload();
            if (claims.getId() != null && blacklist.containsKey(claims.getId())) {
                return null;
            }
            Long userId = Long.valueOf(claims.getSubject());
            // 纪元号不一致 = 该 token 是改密之前签发的，立即失效
            Long tokenEpoch = claims.get("ep", Long.class);
            if (tokenEpoch == null || tokenEpoch != currentEpoch(userId)) {
                return null;
            }
            return userId;
        } catch (JwtException | IllegalArgumentException e) {
            return null;
        }
    }

    /** 登出：把 jti 加入黑名单直至 token 原本过期 */
    public void revoke(String token) {
        if (token == null || token.isBlank()) {
            return;
        }
        try {
            Claims claims = Jwts.parser()
                    .verifyWith(key)
                    .build()
                    .parseSignedClaims(token)
                    .getPayload();
            if (claims.getId() != null && claims.getExpiration() != null) {
                blacklist.put(claims.getId(), claims.getExpiration().getTime());
            }
        } catch (JwtException | IllegalArgumentException ignored) {
            /* 无效 token 无需处理 */
        }
    }

    private void cleanBlacklist() {
        long now = System.currentTimeMillis();
        blacklist.entrySet().removeIf(e -> e.getValue() < now);
    }

    /** 读取账号当前会话纪元号，没有记录时视为 0 */
    private long currentEpoch(Long userId) {
        return epochs.getOrDefault(userId, 0L);
    }

    /**
     * 修改密码后调用：递增该账号的会话纪元号，
     * 使其此前签发的所有 token 立即失效，用户需用新密码重新登录。
     */
    public void invalidateSessions(Long userId) {
        if (userId == null) {
            return;
        }
        epochs.merge(userId, 1L, Long::sum);
    }
}
