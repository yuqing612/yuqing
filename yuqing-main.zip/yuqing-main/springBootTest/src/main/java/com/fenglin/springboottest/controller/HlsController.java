package com.fenglin.springboottest.controller;

import com.fenglin.springboottest.service.HlsAdFreeService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * HLS 去广告代理接口。
 *
 * <p>前端播放时不再直连上游 m3u8，而是请求本服务：
 * <pre>
 *   GET /api/hls/playlist?u={base64(上游m3u8地址)}   -&gt; 改写后的清单（已剔除广告分片）
 *   GET /api/hls/segment?u={base64(分片地址)}       -&gt; 上游分片字节流
 * </pre>
 *
 * <p>清单里的分片地址被重写为 {@code /api/hls/segment?u=...}，
 * 因此整条播放链路都会经过本服务，广告分片自然不会出现在播放器里。
 *
 * <p><b>鉴权</b>：这两个接口承载视频流，播放器的分片请求由 hls.js 自动发起，
 * 不便携带 Authorization 头（hls.js 默认不注入自定义头）。
 * 因此这里放行匿名访问，但用主机白名单限制可代理的上游域名，
 * 避免接口被当成任意 URL 转发器使用。
 */
@RestController
@RequestMapping("/api/hls")
public class HlsController {

    private static final Logger log = LoggerFactory.getLogger(HlsController.class);

    private final HlsAdFreeService hlsAdFreeService;

    public HlsController(HlsAdFreeService hlsAdFreeService) {
        this.hlsAdFreeService = hlsAdFreeService;
    }

    /**
     * 取上游清单并剔除广告分片。
     */
    @GetMapping("/playlist")
    public ResponseEntity<String> playlist(@RequestParam("u") String encoded) {
        String upstream = decode(encoded);
        if (upstream == null || !hlsAdFreeService.isAllowedUpstream(upstream)) {
            return ResponseEntity.badRequest().body("#EXTM3U\n");
        }
        String rewritten = hlsAdFreeService.rewritePlaylist(upstream);
        if (rewritten == null) {
            // 上游拉取失败：返回 502，让前端的多线路容灾机制切到下一条线路
            return ResponseEntity.status(502).build();
        }
        return ResponseEntity.ok()
                .contentType(MediaType.parseMediaType("application/vnd.apple.mpegurl"))
                .cacheControl(org.springframework.http.CacheControl.noCache())
                .body(rewritten);
    }

    /**
     * 转发上游分片字节流。
     */
    @GetMapping("/segment")
    public ResponseEntity<byte[]> segment(@RequestParam("u") String encoded,
                                          @RequestHeader(value = "Range", required = false) String range) {
        String upstream = decode(encoded);
        if (upstream == null || !hlsAdFreeService.isAllowedUpstream(upstream)) {
            return ResponseEntity.badRequest().build();
        }
        byte[] data = hlsAdFreeService.fetchBinary(upstream, range);
        if (data == null) {
            return ResponseEntity.status(502).build();
        }
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.parseMediaType("video/mp2t"));
        headers.setCacheControl(org.springframework.http.CacheControl.noCache());
        headers.setContentLength(data.length);
        return ResponseEntity.ok().headers(headers).body(data);
    }

    /** 解码 base64 参数，失败返回 null */
    private String decode(String encoded) {
        if (encoded == null || encoded.isBlank()) {
            return null;
        }
        try {
            String url = HlsAdFreeService.decodeUrl(encoded);
            return url.isBlank() ? null : url;
        } catch (IllegalArgumentException e) {
            return null;
        }
    }
}
