package com.fenglin.springboottest;

import com.fenglin.springboottest.service.LoginAttemptService;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * 登录失败限流行为测试。
 *
 * 重点覆盖：锁定期结束后失败计数必须重置，
 * 否则账号会被「一次失败即续锁」地无限锁定（回归防护）。
 */
class LoginAttemptServiceTest {

    private static final String ACCOUNT = "limit-test-user";

    @Test
    void 连续失败达到阈值后应锁定() {
        LoginAttemptService svc = new LoginAttemptService();
        for (int i = 0; i < 5; i++) {
            assertFalse(svc.isLocked(ACCOUNT), "第 " + (i + 1) + " 次失败时不应锁定");
            svc.onFailure(ACCOUNT);
        }
        assertTrue(svc.isLocked(ACCOUNT), "第 5 次失败后应被锁定");
        assertTrue(svc.remainingSeconds(ACCOUNT) > 0, "锁定时应剩余正的秒数");
    }

    @Test
    void 锁定期间剩余时间应随时间递减() {
        LoginAttemptService svc = new LoginAttemptService();
        for (int i = 0; i < 5; i++) {
            svc.onFailure(ACCOUNT);
        }
        long first = svc.remainingSeconds(ACCOUNT);
        assertTrue(first > 0);
        // 剩余秒数不应超过锁定期上限 15 分钟
        assertTrue(first <= 15 * 60, "剩余时间不应超过 15 分钟，实际=" + first);
    }

    @Test
    void 成功后应清空失败计数() {
        LoginAttemptService svc = new LoginAttemptService();
        svc.onFailure(ACCOUNT);
        svc.onFailure(ACCOUNT);
        svc.onSuccess(ACCOUNT);
        assertFalse(svc.isLocked(ACCOUNT));
        // 成功后再失败 4 次仍不应锁定（计数已归零）
        for (int i = 0; i < 4; i++) {
            svc.onFailure(ACCOUNT);
        }
        assertFalse(svc.isLocked(ACCOUNT), "成功后失败计数应已重置，4 次失败不应触发锁定");
    }

    @Test
    void 账号名应忽略大小写与首尾空格() {
        LoginAttemptService svc = new LoginAttemptService();
        svc.onFailure("  Limit-Test-User  ");
        assertTrue(svc.remainingSeconds("LIMIT-TEST-USER") >= 0);
        assertFalse(svc.isLocked("limit-test-user"));
    }

    @Test
    void 锁定期结束后失败计数应重置而非立即续锁() {
        LoginAttemptService svc = new LoginAttemptService();
        for (int i = 0; i < 5; i++) {
            svc.onFailure(ACCOUNT);
        }
        assertTrue(svc.isLocked(ACCOUNT));

        // 通过反射把 lockUntil 拨到过去，模拟「锁定期已结束」
        try {
            java.lang.reflect.Field attemptsField = LoginAttemptService.class.getDeclaredField("attempts");
            attemptsField.setAccessible(true);
            java.util.concurrent.ConcurrentHashMap<?, ?> map =
                    (java.util.concurrent.ConcurrentHashMap<?, ?>) attemptsField.get(svc);
            Object entry = map.get(ACCOUNT);
            java.lang.reflect.Field lockUntilField = entry.getClass().getDeclaredField("lockUntil");
            lockUntilField.setAccessible(true);
            lockUntilField.setLong(entry, System.currentTimeMillis() - 1);
        } catch (ReflectiveOperationException e) {
            throw new AssertionError("反射操作失败，无法模拟锁定期结束", e);
        }

        assertFalse(svc.isLocked(ACCOUNT), "锁定期已过，不应再处于锁定状态");

        // 关键回归点：此时再失败一次，计数应从 0 开始累加为 1，而不是从 5 累加为 6
        svc.onFailure(ACCOUNT);
        assertFalse(svc.isLocked(ACCOUNT), "锁定期结束后的第一次失败不应立刻重新锁定（无限续锁回归）");

        // 计数已重置为 1，再失败 4 次累计到 5 才会再次锁定
        for (int i = 0; i < 3; i++) {
            svc.onFailure(ACCOUNT);
        }
        assertFalse(svc.isLocked(ACCOUNT), "累计失败 4 次（重置后）不应锁定");
        svc.onFailure(ACCOUNT);
        assertTrue(svc.isLocked(ACCOUNT), "重置后累计失败 5 次应再次锁定");
    }
}
