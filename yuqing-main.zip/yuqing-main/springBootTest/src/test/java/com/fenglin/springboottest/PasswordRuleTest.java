package com.fenglin.springboottest;

import com.fenglin.springboottest.common.Regexp;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * 密码规则回归测试。
 *
 * 背景：2026-10-26 发现后台管理员改密接口（AdminUserService.changePassword）
 * 漏掉了密码强度校验，导致可以把 admin 密码改成 "123456"。
 * 前台改密/注册一直有校验，后台没有 —— 现已统一到 {@link Regexp}。
 */
class PasswordRuleTest {

    @Test
    void 合规密码应通过() {
        assertTrue(Regexp.isPassword("Admin@123456"), "12位含大小写数字特殊字符");
        assertTrue(Regexp.isPassword("Abcd@1"), "最短 6 位边界");
        assertTrue(Regexp.isPassword("Abcdefgh1@"), "15 位上边界");
    }

    @Test
    void 弱密码应被拒绝() {
        assertFalse(Regexp.isPassword("123456"), "纯数字");
        assertFalse(Regexp.isPassword("abcdefg1@"), "缺大写字母");
        assertFalse(Regexp.isPassword("Abcdefg1"), "缺特殊字符");
        assertFalse(Regexp.isPassword("ABCDEFG1@"), "缺小写字母");
    }

    @Test
    void 长度越界应被拒绝() {
        assertFalse(Regexp.isPassword("Abc@1"), "不足 6 位");
        assertFalse(Regexp.isPassword("Abcdefgh12345678@"), "超过 15 位");
    }

    @Test
    void 空值与null应被拒绝() {
        assertFalse(Regexp.isPassword(null));
        assertFalse(Regexp.isPassword(""));
    }
}
