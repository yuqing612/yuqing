-- =========================================================
-- 《总之就是非常可爱》改用「动漫共和国」(OMoFun) 播放源
-- 说明：
--   1. 该站播放页为苹果 CMS 架构：
--        https://www.omofun23.com/index.php/vod/play/id/43835/sid/1/nid/{集号}.html
--      页面内嵌官方播放器，会自行解析 m3u8 直链并提供清晰度切换。
--   2. 同时把各集解析出的 m3u8 直链存入 video_episode.m3u8_url，
--      前端优先用 hls.js 直连播放（体验与站内一致、无第三方页面框）。
--   3. 第 1 话免登录可播，第 2~13 话在原站为大会员专享（vip = 1）。
--   4. 幂等：可重复执行。
-- =========================================================

-- ---------- 1. 视频条目：切换到动漫共和国源 ----------
UPDATE video
SET title        = '《总之就是非常可爱》',
    uploader     = '动漫共和国',
    views        = '2.2亿',
    play         = 220000000,
    danmaku      = '306.4万',
    duration     = '23:41',
    tags         = '恋爱,日常,漫画改,甜,校园',
    description  = '由崎星空对神秘美少女——司一见钟情。面对星空决死的告白，她的回答是「如果你愿意和我结婚，那我就跟你交往」？！充满了星空与司的爱，可爱&高贵的新婚生活开始了！全 12 话正片。',
    grad         = 'linear-gradient(135deg,#7dd3fc,#ff8fb1)',
    cover_url    = '/tonikawa.webp',
    src          = 'https://www.omofun23.com/index.php/vod/play/id/43835/sid/1/nid/1.html',
    source_type  = 'omofun',
    bvid         = NULL,
    omofun_id    = '43835',
    fav          = 1,
    daily_pick   = 1
WHERE id = 1;

-- ---------- 2. 分集播放源：12 话正片（omofun 播放页 + m3u8 直链） ----------
DELETE FROM video_episode WHERE video_id = 1;

INSERT INTO video_episode (video_id, ep_no, ep_title, bvid, cid, m3u8_url, duration, vip) VALUES
(1,  1, '结婚', '', NULL, 'https://vodcnd09.ajupf.com/20251008/Y8RoHmhl/index.m3u8', 1421000, 0),
(1,  2, '初夜', '', NULL, 'https://vodcnd09.ajupf.com/20251008/Q5F5NSWo/index.m3u8', 1421000, 1),
(1,  3, '姐妹', '', NULL, 'https://vodcnd09.ajupf.com/20251008/69Y49RGm/index.m3u8', 1421000, 1),
(1,  4, '约定', '', NULL, 'https://vodcnd09.ajupf.com/20251008/AvXIWivo/index.m3u8', 1421000, 1),
(1,  5, '戒指', '', NULL, 'https://vodcnd09.ajupf.com/20251008/skGJyyTH/index.m3u8', 1421000, 1),
(1,  6, '报告', '', NULL, 'https://vodcnd09.ajupf.com/20251008/AqJMS4Qq/index.m3u8', 1421000, 1),
(1,  7, '旅行', '', NULL, 'https://vodcnd09.ajupf.com/20251008/OsbF19iK/index.m3u8', 1421000, 1),
(1,  8, '亲子', '', NULL, 'https://vodcnd09.ajupf.com/20251008/xvAVkKLR/index.m3u8', 1421000, 1),
(1,  9, '日常', '', NULL, 'https://vodcnd09.ajupf.com/20251008/38DN167T/index.m3u8', 1421000, 1),
(1, 10, '归路', '', NULL, 'https://vodcnd09.ajupf.com/20251008/ZGGhxdn3/index.m3u8', 1421000, 1),
(1, 11, '友人', '', NULL, 'https://vodcnd09.ajupf.com/20251008/pnpLnceA/index.m3u8', 1421000, 1),
(1, 12, '夫妻', '', NULL, 'https://vodcnd09.ajupf.com/20251008/DhtxnlRc/index.m3u8', 1421000, 1);

-- ---------- 3. 校验 ----------
SELECT id, title, uploader, source_type, omofun_id, cover_url
FROM video WHERE id = 1;

SELECT ep_no, ep_title, m3u8_url, duration, vip
FROM video_episode WHERE video_id = 1 ORDER BY ep_no;
