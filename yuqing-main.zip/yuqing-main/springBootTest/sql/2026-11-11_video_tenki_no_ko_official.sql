-- =========================================================
-- 首页视频 id=2《天气之子》：把播放源修正为 B 站官方「新海诚电影《天气之子》正片」
--
-- 背景（2026-11-11 实测）：
--   1. 原 6 集挂的是 BV1a2dnYtERg，B 站 API 返回标题
--      「太好哭了吧！『若能与你共乘海浪之上』日语中字」（汤浅政明，非新海诚），
--      6 个分P / cid / 时长 119:49 全部对得上 —— 属于挂错片，必须替换。
--   2. B 站《天气之子》官方正片在 season_id=33343（ep500908），
--      共 2 个版本，badge = 会员，即大会员专享，官方无「免费正片」：
--        ep332611 日语原版 BV1WA411v7nS / cid 215977954 / 6741000ms（112:21）
--        ep332658 中文配音 BV15i4y137Zs / cid 214644049 / 6732000ms（112:12）
--      up 主「哔哩哔哩电影」，播放 5148.5万 / 弹幕 113.4万。
--   3. 搜索到的免费 UGC「完整版」要么是 reaction / 资源引流 / OST 合集，
--      要么总长 142~237 分钟（≠112 分钟正片）、账号已注销，
--      不是可验证的正片，故不采用，也不把 vip 假装写成 0。
--
-- 结论：内容换成官方正片，选集由 6 集改为 2 个音轨版本，vip = 1 如实标注。
--       player.bilibili.com iframe 可正常打开（HTTP 200），
--       未登录时由 B 站自身展示试看 / 大会员提示，不是黑屏。
--       播放源地址由后端 buildBilibiliSrc(bvid) 统一拼装，无需改 Java / 重启 8081。
-- =========================================================

UPDATE video SET
    title         = '《天气之子》',
    uploader      = '哔哩哔哩电影',
    views         = '5148.5万',
    play          = 51484609,
    danmaku       = '113.4万',
    duration      = '112:21',
    tags          = '新海诚,剧场版,奇幻,恋爱,动画,治愈',
    description   = '高一那年夏天，帆高离开离岛的家乡独自来到东京，在出版社担任写手。东京开始下起连日大雨，他在雨中邂逅了与弟弟相依为命、能改变天气的美少女阳菜。「等等就会放晴了喔。」阳菜这样告诉着帆高——原来，她拥有「改变天气」的奇妙能力。新海诚继《你的名字。》之后的又一部剧场版动画，B 站官方正片（日语原版 / 中文配音，大会员专享）。',
    cover_url     = '/tenki-no-ko.webp',
    src           = 'https://player.bilibili.com/player.html?bvid=BV1WA411v7nS&p=1&autoplay=0&high_quality=1&danmaku=0',
    source_type   = 'bilibili',
    vid           = NULL,
    bvid          = 'BV1WA411v7nS',
    omofun_id     = NULL,
    daily_pick    = 1
WHERE id = 2;

-- 先清后插，保证幂等；原 6 行为错片分P，全部移除
DELETE FROM video_episode WHERE video_id = 2;

INSERT INTO video_episode
    (video_id, ep_no, ep_title, bvid, cid, m3u8_url, source_m3u8_urls, duration, vip)
VALUES
    (2, 1, '剧场版正片 · 日语原版', 'BV1WA411v7nS', '215977954', NULL, NULL, 6741000, 1),
    (2, 2, '剧场版正片 · 中文配音', 'BV15i4y137Zs', '214644049', NULL, NULL, 6732000, 1);

-- 校验
SELECT id, title, uploader, duration, source_type, bvid, src FROM video WHERE id = 2;
SELECT ep_no, ep_title, bvid, cid, duration, vip FROM video_episode WHERE video_id = 2 ORDER BY ep_no;
