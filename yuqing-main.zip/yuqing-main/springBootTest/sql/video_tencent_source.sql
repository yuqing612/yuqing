-- =========================================================
-- 视频表接入「腾讯视频播放源」
-- 说明：
--   1. 新增 source_type 字段区分播放源类型：
--        native  = 原生直链音视频（src 为 mp4 等直链，前端用 <video> 播放）
--        tencent = 腾讯视频（src 为 v.qq.com iframe 播放器地址，前端用 <iframe> 嵌入播放）
--      历史数据默认 native，行为不变。
--   2. 新增 vid 字段保存腾讯视频 VID（如 v3186hgiqhs），
--      src 由服务端依据 vid 自动拼装，后台保存时无需手写整段 iframe 地址。
--   3. 把「超时空辉夜姬」这条切到腾讯视频源：
--      vid = v3186hgiqhs —— Netflix 官方号发布的《超时空辉夜姬！》正式预告（01:29）。
--      注：该片为 Netflix 独播，腾讯视频站内无正片版权页，故取官方正片预告。
-- =========================================================

ALTER TABLE video
    ADD COLUMN source_type VARCHAR(16) NOT NULL DEFAULT 'native'
        COMMENT '播放源类型：native 原生直链 / tencent 腾讯视频' AFTER src,
    ADD COLUMN vid VARCHAR(64) DEFAULT NULL
        COMMENT '腾讯视频 VID（source_type=tencent 时有效）' AFTER source_type;

UPDATE video
SET title       = '超时空辉夜姬',
    uploader    = 'Netflix影视',
    duration    = '01:29',
    src         = 'https://v.qq.com/txp/iframe/player.html?vid=v3186hgiqhs&auto=0',
    source_type = 'tencent',
    vid         = 'v3186hgiqhs',
    cover_url   = '/kaguya.webp'
WHERE title = '超时空辉夜姬';

SELECT id, title, uploader, duration, source_type, vid, src FROM video WHERE title = '超时空辉夜姬';
