-- =========================================================
-- 修复：Unknown column 'source_m3u8_urls' in 'field list'
--
-- 【问题根因】
--   VideoEpisode 实体含 sourceM3u8Urls 字段，MyBatis-Plus 的 selectList
--   会把它映射成 source_m3u8_urls 一起查询；但线上库是按旧版
--   yuqing_db.sql 建的，video_episode 表没有这一列，于是首页
--   /api/videos 系列接口全部抛 bad SQL grammar -> 前端「服务器开小差了」。
--
-- 【修复】
--   补上备用线路列，与 sql/video_episode_table.sql 中的定义保持一致。
--   通过 information_schema 判断，可重复执行；已有该列时自动跳过。
--   只加列、不删改任何数据，执行后无需重启后端（SQL 每次重新生成）。
-- =========================================================

SET @ddl = IF(
    (SELECT COUNT(*) FROM information_schema.COLUMNS
      WHERE TABLE_SCHEMA = DATABASE()
        AND TABLE_NAME   = 'video_episode'
        AND COLUMN_NAME  = 'source_m3u8_urls') > 0,
    'SELECT ''source_m3u8_urls 已存在，跳过'' AS result',
    'ALTER TABLE video_episode
       ADD COLUMN source_m3u8_urls VARCHAR(1024) DEFAULT NULL
       COMMENT ''备用播放线路，多条以 | 分隔，按优先级排列''
       AFTER m3u8_url'
);
PREPARE stmt FROM @ddl;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

-- 校验
SHOW COLUMNS FROM video_episode LIKE 'source_m3u8_urls';
