-- =========================================================
-- 《赛马娘芦毛灰姑娘》23 集播放源切换到「去广告」静态清单
--
-- 源站每集插入两块广告（中段 4 片 16.47s + 片尾 5 片 17.67s = 34.13s），
-- 已按 DISCONTINUITY 分组 + 固定时长序列剔除，静态清单位于：
--   anime-login-vue/public/clean/umamusume/ep01.m3u8 ~ ep23.m3u8
-- 清单内分片 URL 全部绝对化，前端 hls.js 直连 CDN，无需后端代理。
-- 备用线路同样插了 9 片 / 25.76s 广告，已生成 epNN-b.m3u8 作为降级线路，
-- 保证首选挂掉时切过去的也是无广告版本。
--
-- 【幂等】只 UPDATE，不删表、不改标题/时长/vip，可重复执行。
-- 【回滚】backup/video_umamusume_before_ad_free_20261111.sql
-- =========================================================

UPDATE video_episode SET m3u8_url = '/clean/umamusume/ep01.m3u8', source_m3u8_urls = '/clean/umamusume/ep01.m3u8|/clean/umamusume/ep01-b.m3u8' WHERE video_id = 6 AND ep_no = 1;
UPDATE video_episode SET m3u8_url = '/clean/umamusume/ep02.m3u8', source_m3u8_urls = '/clean/umamusume/ep02.m3u8|/clean/umamusume/ep02-b.m3u8' WHERE video_id = 6 AND ep_no = 2;
UPDATE video_episode SET m3u8_url = '/clean/umamusume/ep03.m3u8', source_m3u8_urls = '/clean/umamusume/ep03.m3u8|/clean/umamusume/ep03-b.m3u8' WHERE video_id = 6 AND ep_no = 3;
UPDATE video_episode SET m3u8_url = '/clean/umamusume/ep04.m3u8', source_m3u8_urls = '/clean/umamusume/ep04.m3u8|/clean/umamusume/ep04-b.m3u8' WHERE video_id = 6 AND ep_no = 4;
UPDATE video_episode SET m3u8_url = '/clean/umamusume/ep05.m3u8', source_m3u8_urls = '/clean/umamusume/ep05.m3u8|/clean/umamusume/ep05-b.m3u8' WHERE video_id = 6 AND ep_no = 5;
UPDATE video_episode SET m3u8_url = '/clean/umamusume/ep06.m3u8', source_m3u8_urls = '/clean/umamusume/ep06.m3u8|/clean/umamusume/ep06-b.m3u8' WHERE video_id = 6 AND ep_no = 6;
UPDATE video_episode SET m3u8_url = '/clean/umamusume/ep07.m3u8', source_m3u8_urls = '/clean/umamusume/ep07.m3u8|/clean/umamusume/ep07-b.m3u8' WHERE video_id = 6 AND ep_no = 7;
UPDATE video_episode SET m3u8_url = '/clean/umamusume/ep08.m3u8', source_m3u8_urls = '/clean/umamusume/ep08.m3u8|/clean/umamusume/ep08-b.m3u8' WHERE video_id = 6 AND ep_no = 8;
UPDATE video_episode SET m3u8_url = '/clean/umamusume/ep09.m3u8', source_m3u8_urls = '/clean/umamusume/ep09.m3u8|/clean/umamusume/ep09-b.m3u8' WHERE video_id = 6 AND ep_no = 9;
UPDATE video_episode SET m3u8_url = '/clean/umamusume/ep10.m3u8', source_m3u8_urls = '/clean/umamusume/ep10.m3u8|/clean/umamusume/ep10-b.m3u8' WHERE video_id = 6 AND ep_no = 10;
UPDATE video_episode SET m3u8_url = '/clean/umamusume/ep11.m3u8', source_m3u8_urls = '/clean/umamusume/ep11.m3u8|/clean/umamusume/ep11-b.m3u8' WHERE video_id = 6 AND ep_no = 11;
UPDATE video_episode SET m3u8_url = '/clean/umamusume/ep12.m3u8', source_m3u8_urls = '/clean/umamusume/ep12.m3u8|/clean/umamusume/ep12-b.m3u8' WHERE video_id = 6 AND ep_no = 12;
UPDATE video_episode SET m3u8_url = '/clean/umamusume/ep13.m3u8', source_m3u8_urls = '/clean/umamusume/ep13.m3u8|/clean/umamusume/ep13-b.m3u8' WHERE video_id = 6 AND ep_no = 13;
UPDATE video_episode SET m3u8_url = '/clean/umamusume/ep14.m3u8', source_m3u8_urls = '/clean/umamusume/ep14.m3u8|/clean/umamusume/ep14-b.m3u8' WHERE video_id = 6 AND ep_no = 14;
UPDATE video_episode SET m3u8_url = '/clean/umamusume/ep15.m3u8', source_m3u8_urls = '/clean/umamusume/ep15.m3u8|/clean/umamusume/ep15-b.m3u8' WHERE video_id = 6 AND ep_no = 15;
UPDATE video_episode SET m3u8_url = '/clean/umamusume/ep16.m3u8', source_m3u8_urls = '/clean/umamusume/ep16.m3u8|/clean/umamusume/ep16-b.m3u8' WHERE video_id = 6 AND ep_no = 16;
UPDATE video_episode SET m3u8_url = '/clean/umamusume/ep17.m3u8', source_m3u8_urls = '/clean/umamusume/ep17.m3u8|/clean/umamusume/ep17-b.m3u8' WHERE video_id = 6 AND ep_no = 17;
UPDATE video_episode SET m3u8_url = '/clean/umamusume/ep18.m3u8', source_m3u8_urls = '/clean/umamusume/ep18.m3u8|/clean/umamusume/ep18-b.m3u8' WHERE video_id = 6 AND ep_no = 18;
UPDATE video_episode SET m3u8_url = '/clean/umamusume/ep19.m3u8', source_m3u8_urls = '/clean/umamusume/ep19.m3u8|/clean/umamusume/ep19-b.m3u8' WHERE video_id = 6 AND ep_no = 19;
UPDATE video_episode SET m3u8_url = '/clean/umamusume/ep20.m3u8', source_m3u8_urls = '/clean/umamusume/ep20.m3u8|/clean/umamusume/ep20-b.m3u8' WHERE video_id = 6 AND ep_no = 20;
UPDATE video_episode SET m3u8_url = '/clean/umamusume/ep21.m3u8', source_m3u8_urls = '/clean/umamusume/ep21.m3u8|/clean/umamusume/ep21-b.m3u8' WHERE video_id = 6 AND ep_no = 21;
UPDATE video_episode SET m3u8_url = '/clean/umamusume/ep22.m3u8', source_m3u8_urls = '/clean/umamusume/ep22.m3u8|/clean/umamusume/ep22-b.m3u8' WHERE video_id = 6 AND ep_no = 22;
UPDATE video_episode SET m3u8_url = '/clean/umamusume/ep23.m3u8', source_m3u8_urls = '/clean/umamusume/ep23.m3u8|/clean/umamusume/ep23-b.m3u8' WHERE video_id = 6 AND ep_no = 23;

-- 视频条目自身的 src：分集数据缺失时 PlayerPanel 会用它兜底起播
UPDATE video SET src = '/clean/umamusume/ep01.m3u8' WHERE id = 6;

-- ---------- 校验 ----------
SELECT ep_no, m3u8_url, source_m3u8_urls FROM video_episode WHERE video_id = 6 ORDER BY ep_no;
SELECT COUNT(*) AS ad_free_episodes FROM video_episode WHERE video_id = 6 AND m3u8_url LIKE '/clean/umamusume/%';
SELECT id, src, source_type FROM video WHERE id = 6;
