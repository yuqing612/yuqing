-- =========================================================
-- 后台管理系统 · 管理员角色迁移脚本
-- 适用场景：在已导入 yuqing_db.sql（旧版无 role 列）的库上执行。
-- 全新导入 yuqing_db.sql（已含 role 列）无需本脚本。
-- 执行方式：mysql -u<user> -p yuqing_db < admin_role.sql
-- =========================================================

USE yuqing_db;

-- 1. 若 role 列不存在则补齐（兼容旧表）
SET @exist := (
    SELECT COUNT(*)
    FROM information_schema.COLUMNS
    WHERE TABLE_SCHEMA = DATABASE()
      AND TABLE_NAME   = 'sys_user'
      AND COLUMN_NAME  = 'role'
);
SET @sql := IF(
    @exist = 0,
    "ALTER TABLE sys_user ADD COLUMN role VARCHAR(20) NOT NULL DEFAULT 'USER' COMMENT '角色：USER 普通用户，ADMIN 管理员' AFTER status",
    "SELECT 'role 列已存在，跳过 ALTER' AS info"
);
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

-- 2. 将演示账号 sakura 提升为管理员
UPDATE sys_user
SET role = 'ADMIN'
WHERE username = 'sakura';

-- 3. 确认结果
SELECT id, username, nickname, role
FROM sys_user
WHERE username = 'sakura';
