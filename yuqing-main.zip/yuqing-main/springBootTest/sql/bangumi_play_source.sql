-- =========================================================
-- 番剧表新增「播放源」字段
-- 说明：
--   1. 与 video 表的播放源设计保持一致，便于同一套前端播放器逻辑复用：
--        source_type = 'native'   原生直链（src 为 mp4 等直链，前端用 <video> 播放）
--        source_type = 'tencent'  腾讯视频（v.qq.com iframe 播放器）
--        source_type = 'bilibili' 哔哩哔哩（player.bilibili.com iframe 播放器）
--        vid   腾讯视频 VID（source_type=tencent 时有效）
--        bvid  哔哩哔哩 BV 号（source_type=bilibili 时有效）
--      历史数据默认 native，行为不变（无播放源的番剧卡片只展示信息）。
--   2. src 由服务端依据 VID / BV 号自动拼装，无需手写整段地址。
--   3. 迁移脚本会先补列，再把 id=102 换成《赛马娘芦毛灰姑娘》并接入 B 站源。
-- =========================================================

ALTER TABLE bangumi
    ADD COLUMN src VARCHAR(255) DEFAULT '' COMMENT '播放地址' AFTER cover_gradient,
    ADD COLUMN source_type VARCHAR(16) NOT NULL DEFAULT 'native'
        COMMENT '播放源类型：native 原生直链 / tencent 腾讯视频 / bilibili 哔哩哔哩' AFTER src,
    ADD COLUMN vid VARCHAR(64) DEFAULT NULL COMMENT '腾讯视频 VID（source_type=tencent 时有效）' AFTER source_type,
    ADD COLUMN bvid VARCHAR(64) DEFAULT NULL COMMENT '哔哩哔哩 BV 号（source_type=bilibili 时有效）' AFTER vid;
