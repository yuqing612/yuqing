-- =========================================================
-- 把「虚拟歌姬演唱会 · 全息现场实录」换成《赛马娘芦毛灰姑娘》
-- 说明：
--   1. 该条从原生直链（googleapis 示例 mp4）切换到哔哩哔哩官方番剧源；
--   2. B 站番剧《赛马娘 芦毛灰姑娘》（season_id=91812 / md25581526）
--      共 23 集，正片由「哔哩哔哩番剧」独家正版发布：
--        bvid = BV145G1z9E71 —— 第 1 集「横空出世」
--          时长 23:47，免登录可播（rights.pay = 0），iframe 直接嵌入；
--        其余 22 集为大会员专享，故取第 1 集作为公开可播的播放源。
--   3. 服务端依据 bvid 自动拼装 iframe 地址，无需手写整段 src。
--   4. 封面用站内静态资源 public/umamusume.webp（用户提供的竖版海报，
--      已裁成 16:9 卡片比例并做模糊延展背景）。
--   5. 按 id = 6 精确定位，避免误伤同名的「超时空辉夜姬」（id = 4）。
-- =========================================================

UPDATE video
SET title       = '赛马娘芦毛灰姑娘',
    uploader    = '哔哩哔哩番剧',
    views       = '466.7万',
    play        = 4667408,
    danmaku     = '1.1万',
    duration    = '23:47',
    tags        = '赛马娘,热血,运动,原创动画',
    description = '《周刊YOUNG JUMP》销量破 800 万的漫画终于动画化。地方出身的怪物小栗帽，迎战人称「最强」的玉藻十字。灰扑扑的少女，踏入全新的领域——驰骋火热梦想的灰姑娘故事，继续奔跑。',
    grad        = 'linear-gradient(135deg,#a78bfa,#7dd3fc)',
    cover_url   = '/umamusume.webp',
    src         = 'https://player.bilibili.com/player.html?bvid=BV145G1z9E71&p=1&autoplay=0&high_quality=1&danmaku=0',
    source_type = 'bilibili',
    vid         = NULL,
    bvid        = 'BV145G1z9E71'
WHERE id = 6;

SELECT id, title, uploader, views, duration, tags, cover_url,
       source_type, vid, bvid, src, daily_pick, fav
FROM video WHERE id = 6;
