-- =========================================================
-- 把「次元歌单 · 春日恋爱循环」换成《赛马娘第二季》
-- 说明：
--   1. 该条（video.id = 8）从原生直链（googleapis 示例 mp4）切换到
--      哔哩哔哩官方番剧源；
--   2. B 站番剧《赛马娘 第二季》（season_id=36579 / md16842709）
--      全 13 话，正片由「哔哩哔哩番剧」独家正版发布：
--        第 1 话「东海帝王」bvid = BV1Yv411x7n5，免登录可播（badge 为空）；
--        第 2~13 话为大会员专享（badge = 会员），共 12 集。
--      本脚本把 13 话全部写入 video_episode，前端选集面板逐集切换。
--   3. 服务端依据 bvid 自动拼装 iframe 地址，无需手写整段 src。
--   4. 封面用站内静态资源 public/umamusume-s2.webp
--      （用户提供的第二季海报，已裁成 16:9 卡片比例并做模糊延展背景）。
--   5. 按 id = 8 精确定位，避免误伤同名的其它条目。
-- =========================================================

UPDATE video
SET title       = '赛马娘第二季',
    uploader    = '哔哩哔哩番剧',
    views       = '7075.4万',
    play        = 70754000,
    danmaku     = '47.1万',
    duration    = '23:56',
    tags        = '赛马娘,热血,运动,偶像,催泪',
    description = '憧憬着皇帝，向不败的三连冠冲刺的马娘东海帝皇，以及背负着名家的荣耀，向天皇赏连霸发起挑战的目白麦昆。二人既是对手，也是伙伴，一同向着梦想——「闪光系列赛」的优胜，全力奔跑！',
    grad        = 'linear-gradient(135deg,#a78bfa,#7dd3fc)',
    cover_url   = '/umamusume-s2.webp',
    src         = 'https://player.bilibili.com/player.html?bvid=BV1Yv411x7n5&p=1&autoplay=0&high_quality=1&danmaku=0',
    source_type = 'bilibili',
    vid         = NULL,
    bvid        = 'BV1Yv411x7n5'
WHERE id = 8;

-- =========================================================
-- 分集播放源：13 话正片（第 1 话免登录，2~13 话为大会员专享）
-- =========================================================
DELETE FROM video_episode WHERE video_id = 8;

INSERT INTO video_episode (video_id, ep_no, ep_title, bvid, cid, duration, vip) VALUES
(8,  1, '东海帝王',     'BV1Yv411x7n5', '281777756', 1436000, 0),
(8,  2, '绝不让步',     'BV1ev411x7Ao', '281045002', 1436000, 1),
(8,  3, '邂逅',         'BV1PU4y147g8', '284145505', 1436000, 1),
(8,  4, 'TM对决',       'BV1Mh41117Nz', '287471033', 1436000, 1),
(8,  5, '不败和连霸',   'BV1AU4y1x74L', '290997395', 1436000, 1),
(8,  6, '为了什么',     'BV1L54y1W7Ar', '301258371', 1436000, 1),
(8,  7, '祝福之名',     'BV1xA411M7QS', '298010391', 1436000, 1),
(8,  8, '小小的祈愿',   'BV1aA411M7Fo', '301200230', 1436000, 1),
(8,  9, '秒表',         'BV1Ur4y1A7h5', '304652816', 1436000, 1),
(8, 10, '一定 必定',    'BV1Jy4y187je', '307506532', 1436000, 1),
(8, 11, '这个心情是',   'BV1Bh411Q79Z', '310621258', 1436000, 1),
(8, 12, '两人',         'BV1zh411Q7B5', '313794727', 1436000, 1),
(8, 13, '驰骋于梦想中', 'BV1Nf4y1x7rf', '321741984', 1436000, 1);

SELECT id, title, uploader, views, duration, tags, cover_url,
       source_type, vid, bvid, src, daily_pick, fav
FROM video WHERE id = 8;

SELECT ep_no, ep_title, bvid, cid, duration, vip
FROM video_episode WHERE video_id = 8 ORDER BY ep_no;
