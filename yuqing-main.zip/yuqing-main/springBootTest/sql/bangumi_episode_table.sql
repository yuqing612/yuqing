-- =========================================================
-- 番剧分集播放源表
-- 说明：
--   1. 一部番剧往往有多个正片分集（如《赛马娘芦毛灰姑娘》23 集），
--      单个 bvid 字段放不下，这里独立建表按集存储播放源。
--   2. 每集记录 B 站番剧对应的 bvid + cid，服务端据此拼装官方 iframe 播放器地址：
--        https://player.bilibili.com/player.html?bvid={bvid}&p=1&autoplay=0&high_quality=1&danmaku=0
--      cid 单独保存，便于按需换用 cid 形式的播放地址。
--   3. vip 标记：该集是否为大会员专享（B 站番剧 badge = '会员'）。
--      免费集（vip = 0）免登录即可播放；会员集需登录 B 站大会员账号。
--   4. 与 bangumi 表一对多，删除番剧时级联清理。
-- =========================================================

CREATE TABLE IF NOT EXISTS bangumi_episode (
    id          BIGINT       NOT NULL AUTO_INCREMENT COMMENT '主键',
    bangumi_id  BIGINT       NOT NULL                COMMENT '所属番剧 id',
    ep_no       INT          NOT NULL                COMMENT '集号，从 1 开始',
    ep_title    VARCHAR(64)  DEFAULT ''              COMMENT '本集标题',
    bvid        VARCHAR(64)  NOT NULL                COMMENT '哔哩哔哩 BV 号',
    cid         VARCHAR(32)  DEFAULT NULL            COMMENT '哔哩哔哩 cid',
    duration    INT          DEFAULT 0               COMMENT '时长（毫秒）',
    vip         TINYINT      NOT NULL DEFAULT 0      COMMENT '是否大会员专享：1 是，0 否',
    create_time DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    update_time DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP
                            ON UPDATE CURRENT_TIMESTAMP          COMMENT '更新时间',
    PRIMARY KEY (id),
    UNIQUE KEY uk_bangumi_ep (bangumi_id, ep_no),
    KEY idx_bangumi (bangumi_id)
) ENGINE = InnoDB
  DEFAULT CHARSET = utf8mb4
  COMMENT = '番剧分集播放源表';

-- 《赛马娘芦毛灰姑娘》（B 站番剧 season_id=91812 / md25581526）23 集正片
-- 第 1 集免登录可播，其余 22 集为大会员专享。
DELETE FROM bangumi_episode WHERE bangumi_id = 102;

INSERT INTO bangumi_episode (bangumi_id, ep_no, ep_title, bvid, cid, duration, vip) VALUES
(102, 1, '横空出世', 'BV145G1z9E71', '29719990069', 1427000, 0),
(102, 2, '让我出赛吧', 'BV1TVG1zsEhh', '29719989807', 1427000, 1),
(102, 3, '顶峰的景色', 'BV1zkV2z7Egk', '31271489307', 1425966, 1),
(102, 4, '初级皇冠赛', 'BV1fkV2z7ECr', '29816129421', 1427000, 1),
(102, 5, '最好的选择', 'BV1y4jJzWEzB', '30103899380', 1421000, 1),
(102, 6, '怪物', 'BV1To7GzyEdR', '30211903081', 1427000, 1),
(102, 7, '特雷森学园', 'BV1tpTTzKEPr', '31069045039', 1425966, 1),
(102, 8, '正确的资质', 'BV1CWMuzTE5f', '30474702196', 1426000, 1),
(102, 9, '日本德比', 'BV1qPKczcEr1', '31271489354', 1425924, 1),
(102, 10, '最强', 'BV1rKKEzXEdJ', '30683955894', 1427000, 1),
(102, 11, '笠松的明星', 'BV1nv3uz6ELE', '30829511375', 1426000, 1),
(102, 12, '天皇赏（秋）', 'BV1du31zPEMD', '30899177537', 1427000, 1),
(102, 13, '日本第一', 'BV1ztuizGEmR', '31028217668', 1366000, 1),
(102, 14, '新的山峰', 'BV1Gt2MBFERH', '33787675312', 1427000, 1),
(102, 15, '我们的故事', 'BV1qJ2MBvEw4', '33787675474', 1426000, 1),
(102, 16, '世界级', 'BV1GTCeBZE1r', '34057552637', 1427000, 1),
(102, 17, '日本杯', 'BV12nUgBbE4d', '34219756747', 1427000, 1),
(102, 18, '狂野滑稽表演者', 'BV1wqSCBDEzM', '34417084110', 1427000, 1),
(102, 19, '未知的「领域」', 'BV1Ct2aBjEDm', '34496056358', 1427000, 1),
(102, 20, '答案', 'BV11dmCBDEgX', '34747780858', 1426000, 1),
(102, 21, '有马纪念', 'BV1T2BSBUE9R', '34969421621', 1427000, 1),
(102, 22, '灰发怪物', 'BV14XvHBFEi8', '35052390780', 1426000, 1),
(102, 23, '新时代', 'BV1arvHBqEW2', '35054029983', 1412000, 1);

SELECT COUNT(*) AS 集数, SUM(vip) AS 会员集, SUM(1 - vip) AS 免费集
FROM bangumi_episode WHERE bangumi_id = 102;
