-- =========================================================
-- 把番剧「魔法少女小满的午后」换成《赛马娘芦毛灰姑娘》
-- 说明：
--   1. id = 102 原本是虚构作品「魔法少女小满的午后」，现替换为真实作品：
--      《赛马娘 芦毛灰姑娘》（B 站番剧 season_id=91812 / md25581526）
--      —— 小栗帽为主角的原创动画，共 23 集，B 站评分 9.9。
--   2. 播放源接入 B 站官方番剧正片：
--      bvid = BV145G1z9E71 —— 第 1 集「横空出世」
--        时长 23:47，免登录可播（rights.pay = 0），iframe 直接嵌入；
--        其余 22 集为大会员专享，故取第 1 集作为公开可播的播放源。
--      服务端依据 bvid 自动拼装 iframe 地址，无需手写整段 src。
--   3. 封面用站内静态资源 public/umamusume-poster.webp
--      （用户提供的竖版海报，已裁成 3:4 番剧海报比例）。
--   4. 原内联 SVG 插画清空（cover_url 优先于 cover_svg，留着会冗余占空间）。
--   5. 关联的放送计划集数同步调整到 23 集正篇范围内。
-- =========================================================

UPDATE bangumi
SET title        = '赛马娘芦毛灰姑娘',
    cover_svg    = NULL,
    cover_url    = '/umamusume-poster.webp',
    cover_gradient = 'linear-gradient(135deg,#ff6f9c,#c084fc)',
    episodes     = 23,
    status       = '已完结',
    score        = 9.9,
    studio       = 'CygamesPictures',
    category     = '日漫',
    tags         = '漫画改/热血/运动/励志',
    description  = '《周刊YOUNG JUMP》销量破 800 万的漫画终于动画化。地方出身的怪物小栗帽，迎战人称「最强」的玉藻十字。灰扑扑的少女，即将踏入全新的领域——驰骋火热梦想的灰姑娘故事，继续奔跑！',
    src          = 'https://player.bilibili.com/player.html?bvid=BV145G1z9E71&p=1&autoplay=0&high_quality=1&danmaku=0',
    source_type  = 'bilibili',
    vid          = NULL,
    bvid         = 'BV145G1z9E71'
WHERE id = 102;

-- 放送计划集数跟随新作品的 23 集正篇
UPDATE bangumi_schedule
SET episode = 19
WHERE bangumi_id = 102 AND episode > 23;

SELECT id, title, episodes, status, studio, category, score, tags,
       cover_url, source_type, bvid, src
FROM bangumi WHERE id = 102;

SELECT id, bangumi_id, weekday, air_time, episode
FROM bangumi_schedule WHERE bangumi_id = 102;
