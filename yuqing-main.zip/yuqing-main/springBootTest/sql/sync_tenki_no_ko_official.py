# -*- coding: utf-8 -*-
"""把《天气之子》官方正片源同步到 mockData.js 与两份建库种子脚本。

用法：python sync_tenki_no_ko_official.py
幂等：重复执行时，已经是新数据的文件会跳过（不重复写入）。
"""
from pathlib import Path
import hashlib
import re

ROOT = Path(r'C:\Users\Administrator\Desktop\yuqing-main')
SEEDS = [ROOT / 'yuqing_db.sql', ROOT / 'springBootTest' / 'sql' / 'yuqing_db.sql']
MOCK = ROOT / 'anime-login-vue' / 'src' / 'api' / 'mockData.js'
OLD_SQL = ROOT / 'springBootTest' / 'sql' / '2026-11-11_video_tenki_no_ko.sql'

DESC = ('高一那年夏天，帆高离开离岛的家乡独自来到东京，在出版社担任写手。'
        '东京开始下起连日大雨，他在雨中邂逅了与弟弟相依为命、能改变天气的美少女阳菜。'
        '「等等就会放晴了喔。」阳菜这样告诉着帆高——原来，她拥有「改变天气」的奇妙能力。'
        '新海诚继《你的名字。》之后的又一部剧场版动画，B 站官方正片（日语原版 / 中文配音，大会员专享）。')
SRC = 'https://player.bilibili.com/player.html?bvid=BV1WA411v7nS&p=1&autoplay=0&high_quality=1&danmaku=0'

# ---------- 种子脚本 ----------
SEED_VIDEO_LINE = (
    "('《天气之子》', '哔哩哔哩电影', '5148.5万', 51484609, '113.4万', '112:21', "
    "'新海诚,剧场版,奇幻,恋爱,动画,治愈', '" + DESC + "', 0, "
    "'linear-gradient(135deg,#7dd3fc,#a78bfa)', '/tenki-no-ko.webp', '" + SRC + "', "
    "'bilibili', NULL, 'BV1WA411v7nS', NULL, 1),"
)

SEED_EPISODE_BLOCK = """-- 《天气之子》（B 站官方新海诚电影正片，season_id=33343 / ep500908）
-- 原 BV1a2dnYtERg 是《若能与你共乘海浪之上》6 分P，属于挂错片，已作废。
-- 官方正片共 2 个音轨版本，badge = 会员，故 vip = 1；B 站不存在官方免费正片。
-- 播放地址由后端 buildBilibiliSrc(bvid) 统一拼装官方 iframe，无需手填 src。
INSERT INTO video_episode (video_id, ep_no, ep_title, bvid, cid, m3u8_url, duration, vip) VALUES
(2, 1, '剧场版正片 · 日语原版', 'BV1WA411v7nS', '215977954', NULL, 6741000, 1),
(2, 2, '剧场版正片 · 中文配音', 'BV15i4y137Zs', '214644049', NULL, 6732000, 1);"""

OLD_EP_END = "(2, 6, '第 6 段 结局', 'BV1a2dnYtERg?p=6', '29294789084', NULL, 1470000, 0);"


def sync_seed(path: Path) -> None:
    text = path.read_text(encoding='utf-8')
    changed = False

    if 'BV1WA411v7nS' not in text:
        pattern = re.compile(r"^\('《天气之子》'.*,$", re.M)
        assert len(pattern.findall(text)) == 1, f'{path.name}: video 行未唯一匹配'
        text = pattern.sub(lambda m: SEED_VIDEO_LINE, text, count=1)
        changed = True

    if 'BV1a2dnYtERg?p=6' in text:
        start = text.index('-- 《天气之子》（B 站免费正片')
        end = text.index(OLD_EP_END, start) + len(OLD_EP_END)
        text = text[:start] + SEED_EPISODE_BLOCK + text[end:]
        changed = True

    if changed:
        path.write_text(text, encoding='utf-8', newline='\n')
    print(f'[seed] {path.relative_to(ROOT)} -> {"updated" if changed else "already up to date"}')


# ---------- mockData.js ----------
MOCK_VIDEO_OLD = """  {
    id: 2,
    title: '《天气之子》',
    uploader: '十五漫屋',
    views: '32.1万',
    play: 321057,
    danmaku: '4049',
    duration: '119:49',
    tags: ['新海诚', '剧场版', '奇幻', '恋爱', '动画', '治愈'],
    desc: '高一那年夏天，帆高离开离海的家乡独自来到东京，在出版社担任写手。东京开始下起连日大雨，他在雨中邂逅了与弟弟相依为命、能改变天气的美少女阳菜。「等等就会放晴了喔。」阳菜这样告诉着帆高——原来，她拥有「改变天气」的奇妙能力。新海诚继《你的名字。》之后的又一部剧场版动画，B 站免费正片日语中字版。',
    fav: false,
    grad: 'linear-gradient(135deg,#7dd3fc,#a78bfa)',
    coverUrl: '/tenki-no-ko.webp',
    /* B 站免费正片源：sourceType = bilibili 时前端用 iframe 嵌入官方播放器 */
    sourceType: 'bilibili',
    bvid: 'BV1a2dnYtERg?p=1',
    src: 'https://player.bilibili.com/player.html?bvid=BV1a2dnYtERg&p=1&autoplay=0&high_quality=1&danmaku=0'
  },"""

MOCK_VIDEO_NEW = """  {
    id: 2,
    title: '《天气之子》',
    uploader: '哔哩哔哩电影',
    views: '5148.5万',
    play: 51484609,
    danmaku: '113.4万',
    duration: '112:21',
    tags: ['新海诚', '剧场版', '奇幻', '恋爱', '动画', '治愈'],
    desc: '""" + DESC + """',
    fav: false,
    grad: 'linear-gradient(135deg,#7dd3fc,#a78bfa)',
    coverUrl: '/tenki-no-ko.webp',
    /* B 站官方正片源：season 33343，日语原版 / 中文配音两个版本，大会员专享 */
    sourceType: 'bilibili',
    bvid: 'BV1WA411v7nS',
    src: '""" + SRC + """'
  },"""

MOCK_SRC_OLD = "  2: 'https://player.bilibili.com/player.html?bvid=BV1a2dnYtERg&p=1&autoplay=0&high_quality=1&danmaku=0',"
MOCK_SRC_NEW = "  2: '" + SRC + "',"

MOCK_EPS_OLD = """  /* 《天气之子》B 站免费正片：正片被拆成 6 个分P，合计 119:49，与剧场版正片总时长一致 */
  2: [
    { epNo: 1, title: 'l1 开场', bvid: 'BV1a2dnYtERg?p=1', duration: 1151000, vip: false },
    { epNo: 2, title: '第 2 段', bvid: 'BV1a2dnYtERg?p=2', duration: 1111000, vip: false },
    { epNo: 3, title: '第 3 段', bvid: 'BV1a2dnYtERg?p=3', duration: 1151000, vip: false },
    { epNo: 4, title: '第 4 段', bvid: 'BV1a2dnYtERg?p=4', duration: 1149000, vip: false },
    { epNo: 5, title: '第 5 段', bvid: 'BV1a2dnYtERg?p=5', duration: 1157000, vip: false },
    { epNo: 6, title: '第 6 段 结局', bvid: 'BV1a2dnYtERg?p=6', duration: 1470000, vip: false }
  ],"""

MOCK_EPS_NEW = """  /* 《天气之子》B 站官方正片：season 33343 两个音轨版本，均为大会员专享（vip = true） */
  2: [
    { epNo: 1, title: '剧场版正片 · 日语原版', bvid: 'BV1WA411v7nS', duration: 6741000, vip: true },
    { epNo: 2, title: '剧场版正片 · 中文配音', bvid: 'BV15i4y137Zs', duration: 6732000, vip: true }
  ],"""


def replace_once(text: str, old: str, new: str, label: str) -> str:
    n = text.count(old)
    assert n == 1, f'{label}: 期望 1 处匹配，实际 {n} 处'
    return text.replace(old, new, 1)


def sync_mock() -> None:
    text = MOCK.read_text(encoding='utf-8')
    if 'BV1a2dnYtERg' in text:
        text = replace_once(text, MOCK_VIDEO_OLD, MOCK_VIDEO_NEW, 'mockData VIDEOS[1]')
        text = replace_once(text, MOCK_SRC_OLD, MOCK_SRC_NEW, 'mockData VIDEO_SRC[2]')
        text = replace_once(text, MOCK_EPS_OLD, MOCK_EPS_NEW, 'mockData VIDEO_EPISODES[2]')
        MOCK.write_text(text, encoding='utf-8', newline='\n')
        print('[mock] src/api/mockData.js -> updated')
    else:
        print('[mock] src/api/mockData.js -> already up to date')


# ---------- 旧错片迁移脚本封存 ----------
WARNING = """-- ########################################################################
-- ## 已作废（2026-11-11）：本脚本指向 BV1a2dnYtERg，B 站 API 实测该视频是
-- ##   《若能与你共乘海浪之上》（汤浅政明），不是新海诚《天气之子》，禁止再导入。
-- ## 请改用同目录 2026-11-11_video_tenki_no_ko_official.sql。
-- ## 下方原始 SQL 全部逐行注释封存，仅保留作历史对照。
-- ########################################################################
"""


def seal_old_sql() -> None:
    text = OLD_SQL.read_text(encoding='utf-8')
    if text.startswith('-- #### 已作废') or text.startswith('-- ## 已作废'):
        print('[legacy] 旧脚本已封存')
        return
    lines = text.splitlines()
    body = '\n'.join(
        ('-- ' + ln) if ln.strip() and not ln.lstrip().startswith('--') else ln
        for ln in lines
    )
    OLD_SQL.write_text(WARNING + body + '\n', encoding='utf-8', newline='\n')
    print('[legacy] 旧脚本已注释封存')


def main() -> None:
    for p in SEEDS:
        sync_seed(p)
    sync_mock()
    seal_old_sql()

    hashes = [hashlib.md5(p.read_bytes()).hexdigest() for p in SEEDS]
    print('[check] seed md5:', *hashes)
    assert hashes[0] == hashes[1], '两份种子脚本内容不一致！'
    print('[check] 两份种子脚本完全一致 OK')


if __name__ == '__main__':
    main()
