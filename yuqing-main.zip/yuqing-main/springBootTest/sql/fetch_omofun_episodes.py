import json
import re
import sys
import time
import urllib.request

UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"
BASE = "https://www.omofun23.com/index.php/vod/play/id/43835/sid/1/nid/{}.html"

PAT = re.compile(r"var\s+player_aaaa\s*=\s*(\{.*?\})\s*</script>", re.S)


def fetch(nid):
    req = urllib.request.Request(BASE.format(nid), headers={"User-Agent": UA})
    with urllib.request.urlopen(req, timeout=25) as r:
        html = r.read().decode("utf-8", "replace")
    m = PAT.search(html)
    if not m:
        return None
    return json.loads(m.group(1))


out = []
for nid in range(1, 13):
    try:
        d = fetch(nid)
        if not d:
            print(nid, "PARSE_FAIL", file=sys.stderr)
            continue
        out.append(
            {
                "nid": nid,
                "url": d.get("url", ""),
                "from": d.get("from", ""),
                "note": d.get("note", ""),
            }
        )
        print(nid, d.get("url", ""))
    except Exception as e:
        print(nid, "ERR", e, file=sys.stderr)
    time.sleep(0.6)

with open("omofun_eps.json", "w", encoding="utf-8") as f:
    json.dump(out, f, ensure_ascii=False, indent=2)
print("saved", len(out))
