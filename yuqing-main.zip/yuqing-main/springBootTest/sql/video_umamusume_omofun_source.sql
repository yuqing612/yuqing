-- =========================================================
-- 《赛马娘芦毛灰姑娘》首页视频改用「动漫共和国」(OMoFun) 播放源
--
-- 【改动范围】video.id = 6（首页每日推荐 / 热播视频卡片）
--   由 B 站官方 iframe（仅第 1 集免费、其余 22 集大会员专享）
--   切换为动漫共和国 HLS（m3u8）直链，前端用 hls.js 播放。
--
-- 【源站构成】动漫共和国把这部 23 集番拆成多个条目：
--   - id=43207  「赛马娘 芦毛灰姑娘」23 集合并条目，唯一线路 dbm3u8
--     指向 vodcnd0x.ajupf.com，该域名已无 DNS A 记录（全 23 集不可播）；
--   - id=92287  第 1 季 13 集，sid=3「1080zyk」+ sid=2「bfzym3u8」；
--   - id=143558 Part2 10 集，sid=1「1080zyk」+ sid=2「bfzym3u8」。
--   因此 omofun_id 记为完整条目 43207，实际直链按季取可用线路：
--     第  1~13 集 → 92287 sid=3（主）/ sid=2（备）
--     第 14~23 集 → 143558 sid=1（主）/ sid=2（备）
--
-- 【可用性】23 集逐集实测：主清单 / 子清单 / 首个视频分片均为 HTTP 200，
--   Access-Control-Allow-Origin: *，无 Referer 防盗链；备用线路主清单同为 200。
--   trysee=0、points=0 → 全 23 集免登录可播，vip 一律置 0。
--   主备地址写入 source_m3u8_urls，首选失效时前端 HlsPlayer 自动降级。
--
-- 【幂等】可重复执行（先清后插 + DDL 判断）。
-- 【回滚】见 backup/video_umamusume_before_omofun_20261111.sql
-- 【2026-11-11 追加：去广告】源站把同一批插播广告切成两块塞进每集正片：
--   主线路：中段 4 片 / 16.47s + 片尾 5 片 / 17.67s = 9 片 / 34.13s；
--   备用线路：中段 9 片 / 25.76s。23 集结构完全一致，按 DISCONTINUITY 分组 +
--   固定 EXTINF 时长序列精确剔除，静态清单位于 public/clean/umamusume/：
--     epNN.m3u8（主）、epNN-b.m3u8（备），分片 URL 已绝对化，前端 hls.js 直连。
--   生成脚本见工作区 build_clean_playlists.py / build_backup_clean.py；
--   重建库后执行本脚本即可得到无广告源（启动脚本 1.7 段会自动补跑）。
--   注意：静态清单是分片 URL 快照，CDN 换地址时需重新生成。
--
-- =========================================================

-- ---------- 0. 确保备用线路列存在 ----------
SET @ddl = IF(
    (SELECT COUNT(*) FROM information_schema.COLUMNS
      WHERE TABLE_SCHEMA = DATABASE()
        AND TABLE_NAME   = 'video_episode'
        AND COLUMN_NAME  = 'source_m3u8_urls') > 0,
    'SELECT ''source_m3u8_urls 已存在，跳过'' AS result',
    'ALTER TABLE video_episode ADD COLUMN source_m3u8_urls VARCHAR(1024) DEFAULT NULL COMMENT ''备用播放线路，多条以 | 分隔'' AFTER m3u8_url'
);
PREPARE stmt FROM @ddl;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

-- ---------- 1. 视频条目：切到动漫共和国源 ----------
UPDATE video
SET uploader    = '动漫共和国',
    src         = '/clean/umamusume/ep01.m3u8',
    source_type = 'omofun',
    vid         = NULL,
    bvid        = NULL,
    omofun_id   = '43207',
    fav         = 1,
    daily_pick  = 1
WHERE id = 6;

-- ---------- 2. 分集播放源：23 话正片（主线路 + 备用线路） ----------
DELETE FROM video_episode WHERE video_id = 6;

INSERT INTO video_episode
  (video_id, ep_no, ep_title, bvid, cid, m3u8_url, source_m3u8_urls, duration, vip)
VALUES
(6,  1, '横空出世', '', NULL, '/clean/umamusume/ep01.m3u8', '/clean/umamusume/ep01.m3u8|/clean/umamusume/ep01-b.m3u8', 1427000, 0),
(6,  2, '让我出赛吧', '', NULL, '/clean/umamusume/ep02.m3u8', '/clean/umamusume/ep02.m3u8|/clean/umamusume/ep02-b.m3u8', 1427000, 0),
(6,  3, '顶峰的景色', '', NULL, '/clean/umamusume/ep03.m3u8', '/clean/umamusume/ep03.m3u8|/clean/umamusume/ep03-b.m3u8', 1425966, 0),
(6,  4, '初级皇冠赛', '', NULL, '/clean/umamusume/ep04.m3u8', '/clean/umamusume/ep04.m3u8|/clean/umamusume/ep04-b.m3u8', 1427000, 0),
(6,  5, '最好的选择', '', NULL, '/clean/umamusume/ep05.m3u8', '/clean/umamusume/ep05.m3u8|/clean/umamusume/ep05-b.m3u8', 1421000, 0),
(6,  6, '怪物', '', NULL, '/clean/umamusume/ep06.m3u8', '/clean/umamusume/ep06.m3u8|/clean/umamusume/ep06-b.m3u8', 1427000, 0),
(6,  7, '特雷森学园', '', NULL, '/clean/umamusume/ep07.m3u8', '/clean/umamusume/ep07.m3u8|/clean/umamusume/ep07-b.m3u8', 1425966, 0),
(6,  8, '正确的资质', '', NULL, '/clean/umamusume/ep08.m3u8', '/clean/umamusume/ep08.m3u8|/clean/umamusume/ep08-b.m3u8', 1426000, 0),
(6,  9, '日本德比', '', NULL, '/clean/umamusume/ep09.m3u8', '/clean/umamusume/ep09.m3u8|/clean/umamusume/ep09-b.m3u8', 1425924, 0),
(6, 10, '最强', '', NULL, '/clean/umamusume/ep10.m3u8', '/clean/umamusume/ep10.m3u8|/clean/umamusume/ep10-b.m3u8', 1427000, 0),
(6, 11, '笠松的明星', '', NULL, '/clean/umamusume/ep11.m3u8', '/clean/umamusume/ep11.m3u8|/clean/umamusume/ep11-b.m3u8', 1426000, 0),
(6, 12, '天皇赏（秋）', '', NULL, '/clean/umamusume/ep12.m3u8', '/clean/umamusume/ep12.m3u8|/clean/umamusume/ep12-b.m3u8', 1427000, 0),
(6, 13, '日本第一', '', NULL, '/clean/umamusume/ep13.m3u8', '/clean/umamusume/ep13.m3u8|/clean/umamusume/ep13-b.m3u8', 1366000, 0),
(6, 14, '新的山峰', '', NULL, '/clean/umamusume/ep14.m3u8', '/clean/umamusume/ep14.m3u8|/clean/umamusume/ep14-b.m3u8', 1427000, 0),
(6, 15, '我们的故事', '', NULL, '/clean/umamusume/ep15.m3u8', '/clean/umamusume/ep15.m3u8|/clean/umamusume/ep15-b.m3u8', 1426000, 0),
(6, 16, '世界级', '', NULL, '/clean/umamusume/ep16.m3u8', '/clean/umamusume/ep16.m3u8|/clean/umamusume/ep16-b.m3u8', 1427000, 0),
(6, 17, '日本杯', '', NULL, '/clean/umamusume/ep17.m3u8', '/clean/umamusume/ep17.m3u8|/clean/umamusume/ep17-b.m3u8', 1427000, 0),
(6, 18, '狂野滑稽表演者', '', NULL, '/clean/umamusume/ep18.m3u8', '/clean/umamusume/ep18.m3u8|/clean/umamusume/ep18-b.m3u8', 1427000, 0),
(6, 19, '未知的「领域」', '', NULL, '/clean/umamusume/ep19.m3u8', '/clean/umamusume/ep19.m3u8|/clean/umamusume/ep19-b.m3u8', 1427000, 0),
(6, 20, '答案', '', NULL, '/clean/umamusume/ep20.m3u8', '/clean/umamusume/ep20.m3u8|/clean/umamusume/ep20-b.m3u8', 1426000, 0),
(6, 21, '有马纪念', '', NULL, '/clean/umamusume/ep21.m3u8', '/clean/umamusume/ep21.m3u8|/clean/umamusume/ep21-b.m3u8', 1427000, 0),
(6, 22, '灰发怪物', '', NULL, '/clean/umamusume/ep22.m3u8', '/clean/umamusume/ep22.m3u8|/clean/umamusume/ep22-b.m3u8', 1426000, 0),
(6, 23, '新时代', '', NULL, '/clean/umamusume/ep23.m3u8', '/clean/umamusume/ep23.m3u8|/clean/umamusume/ep23-b.m3u8', 1412000, 0);

-- ---------- 3. 校验 ----------
SELECT id, title, uploader, source_type, omofun_id, bvid, src FROM video WHERE id = 6;
SELECT ep_no, ep_title, m3u8_url, duration, vip
FROM video_episode WHERE video_id = 6 ORDER BY ep_no;
