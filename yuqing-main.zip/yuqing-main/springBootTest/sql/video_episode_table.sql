-- =========================================================
-- 视频分集播放源表
-- 说明：
--   1. 一条 video 记录也可能对应一部番剧的多个正片分集
--      （如《赛马娘 第二季》13 话），单个 bvid 字段放不下，
--      这里独立建表按集存储播放源，结构与 bangumi_episode 一致。
--   2. 每集记录 B 站番剧对应的 bvid + cid，服务端据此拼装官方 iframe 播放器地址：
--        https://player.bilibili.com/player.html?bvid={bvid}&p=1&autoplay=0&high_quality=1&danmaku=0
--   3. vip 标记：该集是否为大会员专享（B 站番剧 badge = '会员'）。
--      免费集（vip = 0）免登录即可播放；会员集需登录 B 站大会员账号。
--   4. 与 video 表一对多，删除视频时级联清理。
-- =========================================================

CREATE TABLE IF NOT EXISTS video_episode (
    id          BIGINT       NOT NULL AUTO_INCREMENT COMMENT '主键',
    video_id    BIGINT       NOT NULL                COMMENT '所属视频 id',
    ep_no       INT          NOT NULL                COMMENT '集号，从 1 开始',
    ep_title    VARCHAR(64)  DEFAULT ''              COMMENT '本集标题',
    bvid        VARCHAR(64)  NOT NULL                COMMENT '哔哩哔哩 BV 号',
    cid         VARCHAR(32)  DEFAULT NULL            COMMENT '哔哩哔哩 cid',
    duration    INT          DEFAULT 0               COMMENT '时长（毫秒）',
    vip         TINYINT      NOT NULL DEFAULT 0      COMMENT '是否大会员专享：1 是，0 否',
    create_time DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    update_time DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP
                            ON UPDATE CURRENT_TIMESTAMP          COMMENT '更新时间',
    PRIMARY KEY (id),
    UNIQUE KEY uk_video_ep (video_id, ep_no),
    KEY idx_video (video_id)
) ENGINE = InnoDB
  DEFAULT CHARSET = utf8mb4
  COMMENT = '视频分集播放源表';
