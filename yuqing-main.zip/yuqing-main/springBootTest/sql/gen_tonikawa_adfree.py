# -*- coding: utf-8 -*-
"""
《总之就是非常可爱》（Fly Me to the Moon）12 集去广告清单生成器。

【背景】
上游源（动漫共和国）每集在正片中段与片尾插入两块博彩广告：
  A 线路（vip15.play-cdn15.com）：中段 4 片 / 16.47s + 片尾 5 片 / 17.67s = 34.14s
  B 线路（p.bvvvvvvvvv1f.com）  ：中段 9 片 / 25.76s
广告在 m3u8 中以 EXT-X-DISCONTINUITY 分隔成独立分组，且是独立编码
（广告 1920x1080@30fps/48kHz，正片 1280x720@23.98fps/44.1kHz）。

【做法】
拉取上游清单 -> 按 DISCONTINUITY 分组 -> 剔除时长明显偏短的广告组 ->
把剩余分片 URI 绝对化 -> 输出静态 m3u8 到 public/clean/tonikawa/。
分片仍直连 CDN（Access-Control-Allow-Origin: *），前端 hls.js 无需后端代理。

与赛马娘（public/clean/umamusume/）采用同一套规则，保证全站行为一致。

【用法】
  python springBootTest/sql/gen_tonikawa_adfree.py
"""
import os
import re
import sys
import urllib.request
from urllib.parse import urljoin

# ---------- 12 集播放源（A 首选线路 / B 备用线路） ----------
EPISODES = [
    (1,  'https://vip15.play-cdn15.com/20230327/4354_41b31ccb/index.m3u8',
         'https://p.bvvvvvvvvv1f.com/video/replace0001/20250123mbKW1Fwlindex.m3u8/index.m3u8'),
    (2,  'https://vip15.play-cdn15.com/20230327/4360_30600f8c/index.m3u8',
         'https://p.bvvvvvvvvv1f.com/video/replace0001/20250123hSvR6zovindex.m3u8/index.m3u8'),
    (3,  'https://vip15.play-cdn15.com/20230327/4366_a575ae0f/index.m3u8',
         'https://p.bvvvvvvvvv1f.com/video/replace0001/20250123zqlM9txZindex.m3u8/index.m3u8'),
    (4,  'https://vip15.play-cdn15.com/20230327/4358_66be29ac/index.m3u8',
         'https://p.bvvvvvvvvv1f.com/video/replace0001/20250123wadj8241index.m3u8/index.m3u8'),
    (5,  'https://vip15.play-cdn15.com/20230327/4359_b58ae158/index.m3u8',
         'https://p.bvvvvvvvvv1f.com/video/replace0001/202501235lEfXl91index.m3u8/index.m3u8'),
    (6,  'https://vip15.play-cdn15.com/20230327/4355_53b3b78d/index.m3u8',
         'https://p.bvvvvvvvvv1f.com/video/replace0001/20250123eAJDbXzaindex.m3u8/index.m3u8'),
    (7,  'https://vip15.play-cdn15.com/20230327/4357_a76e4be5/index.m3u8',
         'https://p.bvvvvvvvvv1f.com/video/replace0001/20250123M4VE7xuGindex.m3u8/index.m3u8'),
    (8,  'https://vip15.play-cdn15.com/20230327/4356_0e008563/index.m3u8',
         'https://p.bvvvvvvvvv1f.com/video/replace0001/20250123Kq420rFiindex.m3u8/index.m3u8'),
    (9,  'https://vip15.play-cdn15.com/20230327/4362_20c8cd33/index.m3u8',
         'https://p.bvvvvvvvvv1f.com/video/replace0001/20250123Kb7cRj9Sindex.m3u8/index.m3u8'),
    (10, 'https://vip15.play-cdn15.com/20230327/4361_04876fc6/index.m3u8',
         'https://p.bvvvvvvvvv1f.com/video/replace0001/202501235hcVV08iindex.m3u8/index.m3u8'),
    (11, 'https://vip15.play-cdn15.com/20230327/4364_bac7a0f2/index.m3u8',
         'https://p.bvvvvvvvvv1f.com/video/replace0001/20250123Vup3ABBbindex.m3u8/index.m3u8'),
    (12, 'https://vip15.play-cdn15.com/20230327/4363_d62fd67c/index.m3u8',
         'https://p.bvvvvvvvvv1f.com/video/replace0001/20250123RwepkGQuindex.m3u8/index.m3u8'),
]

# ---------- 可调参数 ----------
UA = ('Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 '
      '(KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36')
AD_GROUP_MAX_SECONDS = 60.0      # 广告组时长上限（正片最短 300s+，广告 16~26s）
MAIN_MIN_SECONDS = 120.0          # 正片段的时长下限，用于确认清单里确实存在正片
TIMEOUT = 30

# 输出目录：public/clean/tonikawa/
SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
PROJECT_ROOT = os.path.abspath(os.path.join(SCRIPT_DIR, '..', '..'))
OUT_DIR = os.path.join(PROJECT_ROOT, 'anime-login-vue', 'public', 'clean', 'tonikawa')


def fetch(url, timeout=TIMEOUT):
    """拉取文本，自动处理 gzip。"""
    req = urllib.request.Request(url, headers={
        'User-Agent': UA,
        'Accept': '*/*',
        'Accept-Encoding': 'gzip',
    })
    with urllib.request.urlopen(req, timeout=timeout) as r:
        raw = r.read()
    if raw[:2] == b'\x1f\x8b':
        import gzip
        raw = gzip.decompress(raw)
    return raw.decode('utf-8', 'replace')


def resolve_media_playlist(url):
    """上游给的是主清单（index.m3u8 -> 2000k/hls/mixed.m3u8），下钻到媒体清单。"""
    text = fetch(url)
    if '#EXT-X-STREAM-INF' not in text:
        return url, text
    for line in text.splitlines():
        line = line.strip()
        if line and not line.startswith('#'):
            child = urljoin(url, line)
            return child, fetch(child)
    return url, text


def parse_groups(lines):
    """按 EXT-X-DISCONTINUITY 把分片切成组。

    返回 [(start_line, end_line, duration, count)]，行号含端点。
    """
    boundaries = [-1]
    for i, ln in enumerate(lines):
        if ln.strip() == '#EXT-X-DISCONTINUITY':
            boundaries.append(i)
    boundaries.append(len(lines))

    groups = []
    for b in range(len(boundaries) - 1):
        start = boundaries[b] + 1
        end = boundaries[b + 1]
        if start > end:
            continue
        duration = 0.0
        count = 0
        for i in range(start, min(end, len(lines))):
            t = lines[i].strip()
            if t.startswith('#EXTINF:'):
                m = re.match(r'#EXTINF:([0-9.]+)', t)
                if m:
                    duration += float(m.group(1))
            elif t and not t.startswith('#'):
                count += 1
        groups.append((start, min(end, len(lines)) - 1, duration, count))
    return groups


def build_clean_playlist(url):
    """返回 (清单内容, 统计信息)。拉取失败返回 (None, None)。"""
    media_url, raw = resolve_media_playlist(url)
    lines = raw.splitlines()
    groups = parse_groups(lines)

    if not groups:
        return None, None

    # 确认清单里确实存在足够长的正片段，否则不冒险改写
    has_main = any(g[2] >= MAIN_MIN_SECONDS for g in groups)
    if not has_main:
        return None, None

    # 广告组：时长 <= 阈值，且不是第一组（第一组是片头，必须保留）
    ad_groups = [i for i, g in enumerate(groups)
                 if i > 0 and g[3] > 0 and 0 < g[2] <= AD_GROUP_MAX_SECONDS]
    # 安全兜底：不能把所有组都当广告
    if len(ad_groups) >= len(groups) - 1:
        return None, None

    # 标记要删除的行
    drop = set()
    for gi in ad_groups:
        start, end, _, _ = groups[gi]
        for i in range(start, end + 1):
            drop.add(i)
        # 组前的 DISCONTINUITY 标记一并去掉（它标记的是广告组的起点）
        for i in range(start - 1, -1, -1):
            t = lines[i].strip()
            if t == '#EXT-X-DISCONTINUITY':
                drop.add(i)
                break
            if t and not t.startswith('#'):
                break

    # A 线路的 #EXT-X-ENDLIST 排在片尾广告组之后，会随广告段一起被删掉。
    # 少了它播放器无法判定播放结束（会一直等流），因此单独保留并在末尾补回。
    endlist_line = None
    for i, ln in enumerate(lines):
        if ln.strip() == '#EXT-X-ENDLIST':
            endlist_line = ln
            drop.discard(i)
            break

    out = []
    kept_duration = 0.0
    kept_count = 0
    for i, ln in enumerate(lines):
        if i in drop:
            continue
        t = ln.strip()
        if t.startswith('#EXTINF:'):
            m = re.match(r'#EXTINF:([0-9.]+)', t)
            if m:
                kept_duration += float(m.group(1))
            out.append(ln)
        elif t and not t.startswith('#'):
            kept_count += 1
            # 分片 URI 绝对化，前端 hls.js 可直连 CDN
            out.append(urljoin(media_url, t))
        else:
            out.append(ln)

    # 末尾补回 ENDLIST
    if endlist_line is not None and not any(l.strip() == '#EXT-X-ENDLIST' for l in out):
        out.append(endlist_line)

    stats = {
        'media_url': media_url,
        'groups': len(groups),
        'ad_groups': ad_groups,
        'removed_seg': sum(groups[i][3] for i in ad_groups),
        'removed_dur': round(sum(groups[i][2] for i in ad_groups), 2),
        'kept_seg': kept_count,
        'kept_dur': round(kept_duration, 2),
        'origin_dur': round(sum(g[2] for g in groups), 2),
    }
    return '\n'.join(out) + '\n', stats


def main():
    os.makedirs(OUT_DIR, exist_ok=True)
    print('输出目录:', OUT_DIR)
    print()
    ok = 0
    for ep, url_a, url_b in EPISODES:
        for url, suffix in ((url_a, ''), (url_b, '-b')):
            name = 'ep%02d%s.m3u8' % (ep, suffix)
            path = os.path.join(OUT_DIR, name)
            try:
                content, stats = build_clean_playlist(url)
            except Exception as e:
                print('  [%s] 失败: %s' % (name, e))
                continue
            if content is None:
                print('  [%s] 失败：无法解析清单或未识别到广告段')
                continue
            with open(path, 'w', encoding='utf-8', newline='\n') as f:
                f.write(content)
            ok += 1
            print('  [%s] 分组=%d 剔除组=%s 删掉 %d 片 / %.2fs -> 保留 %d 片 / %.2fs'
                  % (name, stats['groups'], stats['ad_groups'],
                     stats['removed_seg'], stats['removed_dur'],
                     stats['kept_seg'], stats['kept_dur']))
    print()
    print('完成，共生成 %d 个清单' % ok)
    return 0 if ok else 1


if __name__ == '__main__':
    sys.exit(main())
