-- =========================================================
-- 回滚：撤销 2026-11-11_video_tenki_no_ko_official.sql
-- 注意：这里恢复的是「旧状态」，即挂错片的 BV1a2dnYtERg《若能与你共乘海浪之上》
--       6 分P 数据。仅用于误操作回滚 / 对照，不建议长期保留。
-- =========================================================

UPDATE video SET
    title         = '《天气之子》',
    uploader      = '十五漫屋',
    views         = '32.1万',
    play          = 321057,
    danmaku       = '4049',
    duration      = '119:49',
    tags          = '新海诚,剧场版,奇幻,恋爱,动画,治愈',
    description   = '高一那年夏天，帆高离开离岛的家乡独自来到东京，在出版社担任写手。东京开始下起连日大雨，他在雨中邂逅了与弟弟相依为命、能改变天气的美少女阳菜。「等等就会放晴了喔。」阳菜这样告诉着帆高——原来，她拥有「改变天气」的奇妙能力。新海诚继《你的名字。》之后的又一部剧场版动画，B 站免费正片日语中字版。',
    cover_url     = '/tenki-no-ko.webp',
    src           = 'https://player.bilibili.com/player.html?bvid=BV1a2dnYtERg&p=1&autoplay=0&high_quality=1&danmaku=0',
    source_type   = 'bilibili',
    vid           = NULL,
    bvid          = 'BV1a2dnYtERg?p=1',
    omofun_id     = NULL,
    daily_pick    = 1
WHERE id = 2;

DELETE FROM video_episode WHERE video_id = 2;

INSERT INTO video_episode (video_id, ep_no, ep_title, bvid, cid, m3u8_url, duration, vip) VALUES
(2, 1, 'l1 开场',     'BV1a2dnYtERg?p=1', '29294329968', NULL, 1151000, 0),
(2, 2, '第 2 段',     'BV1a2dnYtERg?p=2', '29294726045', NULL, 1111000, 0),
(2, 3, '第 3 段',     'BV1a2dnYtERg?p=3', '29294726372', NULL, 1151000, 0),
(2, 4, '第 4 段',     'BV1a2dnYtERg?p=4', '29294726822', NULL, 1149000, 0),
(2, 5, '第 5 段',     'BV1a2dnYtERg?p=5', '29294788686', NULL, 1157000, 0),
(2, 6, '第 6 段 结局','BV1a2dnYtERg?p=6', '29294789084', NULL, 1470000, 0);

SELECT id, title, uploader, duration, source_type, bvid FROM video WHERE id = 2;
SELECT ep_no, ep_title, bvid, vip FROM video_episode WHERE video_id = 2 ORDER BY ep_no;
