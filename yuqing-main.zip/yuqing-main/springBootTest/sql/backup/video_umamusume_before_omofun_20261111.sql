-- 《赛马娘芦毛灰姑娘》切换动漫共和国源之前的回滚脚本
-- 执行后恢复为 B 站官方番剧 iframe 源，并清空新建的 23 集分集数据。
UPDATE video
SET uploader    = '哔哩哔哩番剧',
    src         = 'https://player.bilibili.com/player.html?bvid=BV145G1z9E71&p=1&autoplay=0&high_quality=1&danmaku=0',
    source_type = 'bilibili',
    vid         = NULL,
    bvid        = 'BV145G1z9E71',
    omofun_id   = NULL
WHERE id = 6;

DELETE FROM video_episode WHERE video_id = 6;
