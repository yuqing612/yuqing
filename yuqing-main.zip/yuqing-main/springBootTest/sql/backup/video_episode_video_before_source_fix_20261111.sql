-- MySQL dump 10.13  Distrib 8.0.39, for Win64 (x86_64)
--
-- Host: localhost    Database: yuqing_db
-- ------------------------------------------------------
-- Server version	8.0.39

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `video_episode`
--

DROP TABLE IF EXISTS `video_episode`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `video_episode` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '主键',
  `video_id` bigint NOT NULL COMMENT '所属视频 id',
  `ep_no` int NOT NULL COMMENT '集号，从 1 开始',
  `ep_title` varchar(64) DEFAULT '' COMMENT '本集标题',
  `bvid` varchar(64) NOT NULL DEFAULT '' COMMENT '哔哩哔哩 BV 号',
  `cid` varchar(32) DEFAULT NULL COMMENT '哔哩哔哩 cid',
  `m3u8_url` varchar(512) DEFAULT NULL COMMENT 'm3u8 直链（source_type=omofun 时有效）',
  `source_m3u8_urls` varchar(1024) DEFAULT NULL COMMENT '备用播放线路，多条以 | 分隔，按优先级排列',
  `duration` int DEFAULT '0' COMMENT '时长（毫秒）',
  `vip` tinyint NOT NULL DEFAULT '0' COMMENT '是否大会员专享：1 是，0 否',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_video_ep` (`video_id`,`ep_no`),
  KEY `idx_video` (`video_id`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='视频分集播放源表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `video_episode`
--

LOCK TABLES `video_episode` WRITE;
/*!40000 ALTER TABLE `video_episode` DISABLE KEYS */;
INSERT INTO `video_episode` VALUES (1,8,1,'东海帝王','BV1Yv411x7n5','281777756',NULL,NULL,1436000,0,'2026-11-11 08:29:07','2026-11-11 08:29:07'),(2,8,2,'绝不让步','BV1ev411x7Ao','281045002',NULL,NULL,1436000,1,'2026-11-11 08:29:07','2026-11-11 08:29:07'),(3,8,3,'邂逅','BV1PU4y147g8','284145505',NULL,NULL,1436000,1,'2026-11-11 08:29:07','2026-11-11 08:29:07'),(4,8,4,'TM对决','BV1Mh41117Nz','287471033',NULL,NULL,1436000,1,'2026-11-11 08:29:07','2026-11-11 08:29:07'),(5,8,5,'不败和连霸','BV1AU4y1x74L','290997395',NULL,NULL,1436000,1,'2026-11-11 08:29:07','2026-11-11 08:29:07'),(6,8,6,'为了什么','BV1L54y1W7Ar','301258371',NULL,NULL,1436000,1,'2026-11-11 08:29:07','2026-11-11 08:29:07'),(7,8,7,'祝福之名','BV1xA411M7QS','298010391',NULL,NULL,1436000,1,'2026-11-11 08:29:07','2026-11-11 08:29:07'),(8,8,8,'小小的祈愿','BV1aA411M7Fo','301200230',NULL,NULL,1436000,1,'2026-11-11 08:29:07','2026-11-11 08:29:07'),(9,8,9,'秒表','BV1Ur4y1A7h5','304652816',NULL,NULL,1436000,1,'2026-11-11 08:29:07','2026-11-11 08:29:07'),(10,8,10,'一定 必定','BV1Jy4y187je','307506532',NULL,NULL,1436000,1,'2026-11-11 08:29:07','2026-11-11 08:29:07'),(11,8,11,'这个心情是','BV1Bh411Q79Z','310621258',NULL,NULL,1436000,1,'2026-11-11 08:29:07','2026-11-11 08:29:07'),(12,8,12,'两人','BV1zh411Q7B5','313794727',NULL,NULL,1436000,1,'2026-11-11 08:29:07','2026-11-11 08:29:07'),(13,8,13,'驰骋于梦想中','BV1Nf4y1x7rf','321741984',NULL,NULL,1436000,1,'2026-11-11 08:29:07','2026-11-11 08:29:07'),(14,1,1,'结婚','',NULL,'https://vodcnd09.ajupf.com/20251008/Y8RoHmhl/index.m3u8',NULL,1421000,0,'2026-11-11 08:29:07','2026-11-11 08:29:07'),(15,1,2,'初夜','',NULL,'https://vodcnd09.ajupf.com/20251008/Q5F5NSWo/index.m3u8',NULL,1421000,1,'2026-11-11 08:29:07','2026-11-11 08:29:07'),(16,1,3,'姐妹','',NULL,'https://vodcnd09.ajupf.com/20251008/69Y49RGm/index.m3u8',NULL,1421000,1,'2026-11-11 08:29:07','2026-11-11 08:29:07'),(17,1,4,'约定','',NULL,'https://vodcnd09.ajupf.com/20251008/AvXIWivo/index.m3u8',NULL,1421000,1,'2026-11-11 08:29:07','2026-11-11 08:29:07'),(18,1,5,'戒指','',NULL,'https://vodcnd09.ajupf.com/20251008/skGJyyTH/index.m3u8',NULL,1421000,1,'2026-11-11 08:29:07','2026-11-11 08:29:07'),(19,1,6,'报告','',NULL,'https://vodcnd09.ajupf.com/20251008/AqJMS4Qq/index.m3u8',NULL,1421000,1,'2026-11-11 08:29:07','2026-11-11 08:29:07'),(20,1,7,'旅行','',NULL,'https://vodcnd09.ajupf.com/20251008/OsbF19iK/index.m3u8',NULL,1421000,1,'2026-11-11 08:29:07','2026-11-11 08:29:07'),(21,1,8,'亲子','',NULL,'https://vodcnd09.ajupf.com/20251008/xvAVkKLR/index.m3u8',NULL,1421000,1,'2026-11-11 08:29:07','2026-11-11 08:29:07'),(22,1,9,'日常','',NULL,'https://vodcnd09.ajupf.com/20251008/38DN167T/index.m3u8',NULL,1421000,1,'2026-11-11 08:29:07','2026-11-11 08:29:07'),(23,1,10,'归路','',NULL,'https://vodcnd09.ajupf.com/20251008/ZGGhxdn3/index.m3u8',NULL,1421000,1,'2026-11-11 08:29:07','2026-11-11 08:29:07'),(24,1,11,'友人','',NULL,'https://vodcnd09.ajupf.com/20251008/pnpLnceA/index.m3u8',NULL,1421000,1,'2026-11-11 08:29:07','2026-11-11 08:29:07'),(25,1,12,'夫妻','',NULL,'https://vodcnd09.ajupf.com/20251008/DhtxnlRc/index.m3u8',NULL,1421000,1,'2026-11-11 08:29:07','2026-11-11 08:29:07');
/*!40000 ALTER TABLE `video_episode` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `video`
--

DROP TABLE IF EXISTS `video`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `video` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '主键',
  `title` varchar(200) NOT NULL COMMENT '标题',
  `uploader` varchar(64) DEFAULT '' COMMENT 'UP 主 / 投稿方',
  `views` varchar(32) DEFAULT '' COMMENT '播放量展示文案（如 128.5万）',
  `play` bigint DEFAULT '0' COMMENT '真实播放量（用于排行排序）',
  `danmaku` varchar(32) DEFAULT '' COMMENT '弹幕数展示文案（如 3.2万）',
  `duration` varchar(16) DEFAULT '' COMMENT '时长（如 04:12）',
  `tags` varchar(128) DEFAULT '' COMMENT '标签，逗号分隔',
  `description` varchar(500) DEFAULT '' COMMENT '简介',
  `fav` tinyint NOT NULL DEFAULT '0' COMMENT '是否收藏：1 收藏，0 否',
  `grad` varchar(128) DEFAULT '' COMMENT '封面渐变 CSS（如 linear-gradient(...)）',
  `cover_url` varchar(255) DEFAULT NULL COMMENT '封面图 URL（有值时优先于 grad 展示）',
  `src` varchar(255) DEFAULT '' COMMENT '播放地址',
  `source_type` varchar(16) NOT NULL DEFAULT 'native' COMMENT '播放源类型：native 原生直链 / tencent 腾讯视频 / bilibili 哔哩哔哩 / omofun 动漫共和国',
  `vid` varchar(64) DEFAULT NULL COMMENT '腾讯视频 VID（source_type=tencent 时有效）',
  `bvid` varchar(64) DEFAULT NULL COMMENT '哔哩哔哩 BV 号（source_type=bilibili 时有效）',
  `omofun_id` varchar(32) DEFAULT NULL COMMENT '动漫共和国作品 id（source_type=omofun 时有效）',
  `daily_pick` tinyint NOT NULL DEFAULT '1' COMMENT '是否每日推荐：1 推荐，0 否',
  `recommend_date` date DEFAULT NULL COMMENT '推荐日期（每日推荐轮换用）',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='视频表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `video`
--

LOCK TABLES `video` WRITE;
/*!40000 ALTER TABLE `video` DISABLE KEYS */;
INSERT INTO `video` VALUES (1,'《总之就是非常可爱》','动漫共和国','2.2亿',220000000,'306.4万','23:41','恋爱,日常,漫画改,甜,校园','由崎星空对神秘美少女——司一见钟情。面对星空决死的告白，她的回答是「如果你愿意和我结婚，那我就跟你交往」？！充满了星空与司的爱，可爱&高贵的新婚生活开始了！全 12 话正片。',1,'linear-gradient(135deg,#7dd3fc,#ff8fb1)','/tonikawa.webp','https://www.omofun23.com/index.php/vod/play/id/43835/sid/1/nid/1.html','omofun',NULL,NULL,'43835',1,NULL,'2026-11-11 08:29:07','2026-11-11 08:29:07'),(2,'纸片人女友的一天 · 原创短篇动画','星屑工坊','56.1万',561000,'8742','08:47','原创,日常,甜','从清晨的第一缕光到深夜的台灯，她把平凡的日子过成了童话。',0,'linear-gradient(135deg,#7dd3fc,#a78bfa)',NULL,'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4','native',NULL,NULL,NULL,1,NULL,'2026-11-11 08:29:07','2026-11-11 08:29:07'),(3,'雨夜便利店 · 慢节奏 ASMR 白噪音','夜猫电台','23.9万',239000,'1920','30:00','ASMR,助眠,雨声','关东煮的热气、窗外的雨、以及永远为你亮着的那盏灯。',1,'linear-gradient(135deg,#c084fc,#7dd3fc)',NULL,'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4','native',NULL,NULL,NULL,0,NULL,'2026-11-11 08:29:07','2026-11-11 08:29:07'),(4,'超时空辉夜姬','多叻嘿嘿','1.9万',19548,'13','02:21:23','同人,战斗,燃','为了夺回被夺走的星光，少女拔出了沉睡千年的剑。',0,'linear-gradient(135deg,#ff6f9c,#c084fc)','/kaguya.webp','https://player.bilibili.com/player.html?bvid=BV1Lk8C6bE3z&p=3&autoplay=0&high_quality=1&danmaku=0','bilibili',NULL,'BV1Lk8C6bE3z?p=3',NULL,1,NULL,'2026-11-11 08:29:07','2026-11-11 08:29:07'),(5,'猫咪咖啡馆营业中 · 治愈 vlog','软糖日记','78.4万',784000,'4531','12:33','vlog,猫,治愈','三只店长猫，一杯手冲，和刚好路过的你。',0,'linear-gradient(135deg,#ffd98a,#ff8fb1)',NULL,'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4','native',NULL,NULL,NULL,0,NULL,'2026-11-11 08:29:07','2026-11-11 08:29:07'),(6,'赛马娘芦毛灰姑娘','哔哩哔哩番剧','466.7万',4667408,'1.1万','23:47','赛马娘,热血,运动,原创动画','《周刊YOUNG JUMP》销量破 800 万的漫画终于动画化。地方出身的怪物小栗帽，迎战人称「最强」的玉藻十字。灰扑扑的少女，踏入全新的领域——驰骋火热梦想的灰姑娘故事，继续奔跑。',1,'linear-gradient(135deg,#a78bfa,#7dd3fc)','/umamusume.webp','https://player.bilibili.com/player.html?bvid=BV145G1z9E71&p=1&autoplay=0&high_quality=1&danmaku=0','bilibili',NULL,'BV145G1z9E71',NULL,1,NULL,'2026-11-11 08:29:07','2026-11-11 08:29:07'),(7,'深夜画室 · 厚涂立绘绘制过程','小满Official','45.2万',452000,'3201','21:08','绘画,教程,厚涂','从线稿到高光，一笔一画把纸片人养成会呼吸的少女。',0,'linear-gradient(135deg,#ff8fb1,#a78bfa)',NULL,'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4','native',NULL,NULL,NULL,0,NULL,'2026-11-11 08:29:07','2026-11-11 08:29:07'),(8,'赛马娘第二季','哔哩哔哩番剧','7075.4万',70754000,'47.1万','23:56','赛马娘,热血,运动,偶像,催泪','憧憬着皇帝，向不败的三连冠冲刺的马娘东海帝皇，以及背负着名家的荣耀，向天皇赏连霸发起挑战的目白麦昆。二人既是对手，也是伙伴，一同向着梦想——「闪光系列赛」的优胜，全力奔跑！',1,'linear-gradient(135deg,#a78bfa,#7dd3fc)','/umamusume-s2.webp','https://player.bilibili.com/player.html?bvid=BV1Yv411x7n5&p=1&autoplay=0&high_quality=1&danmaku=0','bilibili',NULL,'BV1Yv411x7n5',NULL,1,NULL,'2026-11-11 08:29:07','2026-11-11 08:29:07');
/*!40000 ALTER TABLE `video` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-11-11  8:58:56
