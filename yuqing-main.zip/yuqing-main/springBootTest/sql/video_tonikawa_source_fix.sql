-- =========================================================
-- 《总之就是非常可爱》播放源修复（omofun 线路切换 + 多线路容灾）
--
-- 【问题根因】
--   原 video_episode.m3u8_url 全部指向 vodcnd09.ajupf.com 这个 CDN 域名，
--   该域名已停止解析（8.8.8.8 / 223.5.5.5 权威 DNS 均无 A 记录），
--   导致 hls.js 拉取主清单直接失败 → 12 集全部无法播放。
--
-- 【修复方案】
--   切换到 omofun 的 sid=4 线路（vip15.play-cdn15.com）：
--     - 主清单 / 子清单 / 视频分片 三级均已实测 200；
--     - Access-Control-Allow-Origin: *，hls.js 可跨域直连；
--     - 无 Referer 防盗链限制；
--     - trysee=0、points=0，即全 12 集免登录可播，无需大会员。
--
-- 【多线路容灾】
--   source_m3u8_urls 按优先级存放多条线路，前端 HlsPlayer 依次尝试，
--   首选线路失效时自动降级到下一条，避免再次出现「整部番全挂」。
--
--   线路优先级（两条均已逐集实测主清单 + 分片 200）：
--     1) sid=4  vip15.play-cdn15.com  —— 单码率 2000k，首选
--     2) sid=3  p.bvvvvvvvvv1f.com     —— 备用线路
--
-- 【时长】子清单实际累加为 1454 秒（约 24:14），此前填的 1421 秒来自
--   B 站元数据，与实际片长略有出入，此处按实测值修正。
--
-- 【幂等】可重复执行（先清后插）。
-- =========================================================

-- ---------- 0. 确保备用线路列存在 ----------
-- 旧版建库脚本缺 source_m3u8_urls 列，直接执行本脚本会报
-- Unknown column 'source_m3u8_urls'，同时后端查分集也会 500。
-- 用 information_schema 判断，可重复执行；完整迁移另见
-- sql/video_episode_add_source_m3u8_urls.sql。
SET @ddl = IF(
    (SELECT COUNT(*) FROM information_schema.COLUMNS
      WHERE TABLE_SCHEMA = DATABASE()
        AND TABLE_NAME   = 'video_episode'
        AND COLUMN_NAME  = 'source_m3u8_urls') > 0,
    'SELECT ''source_m3u8_urls 已存在，跳过'' AS result',
    'ALTER TABLE video_episode ADD COLUMN source_m3u8_urls VARCHAR(1024) DEFAULT NULL COMMENT ''备用播放线路，多条以 | 分隔'' AFTER m3u8_url'
);
PREPARE stmt FROM @ddl;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

DELETE FROM video_episode WHERE video_id = 1;

INSERT INTO video_episode
  (video_id, ep_no, ep_title, bvid, cid, m3u8_url, source_m3u8_urls, duration, vip)
VALUES
(1,  1, '结婚', '', NULL,
 'https://vip15.play-cdn15.com/20230327/4354_41b31ccb/index.m3u8',
 'https://vip15.play-cdn15.com/20230327/4354_41b31ccb/index.m3u8|https://p.bvvvvvvvvv1f.com/video/replace0001/20250123mbKW1Fwlindex.m3u8/index.m3u8',
 1454000, 0),
(1,  2, '初夜', '', NULL,
 'https://vip15.play-cdn15.com/20230327/4360_30600f8c/index.m3u8',
 'https://vip15.play-cdn15.com/20230327/4360_30600f8c/index.m3u8|https://p.bvvvvvvvvv1f.com/video/replace0001/20250123hSvR6zovindex.m3u8/index.m3u8',
 1454000, 0),
(1,  3, '姐妹', '', NULL,
 'https://vip15.play-cdn15.com/20230327/4366_a575ae0f/index.m3u8',
 'https://vip15.play-cdn15.com/20230327/4366_a575ae0f/index.m3u8|https://p.bvvvvvvvvv1f.com/video/replace0001/20250123zqlM9txZindex.m3u8/index.m3u8',
 1454000, 0),
(1,  4, '约定', '', NULL,
 'https://vip15.play-cdn15.com/20230327/4358_66be29ac/index.m3u8',
 'https://vip15.play-cdn15.com/20230327/4358_66be29ac/index.m3u8|https://p.bvvvvvvvvv1f.com/video/replace0001/20250123wadj8241index.m3u8/index.m3u8',
 1454000, 0),
(1,  5, '戒指', '', NULL,
 'https://vip15.play-cdn15.com/20230327/4359_b58ae158/index.m3u8',
 'https://vip15.play-cdn15.com/20230327/4359_b58ae158/index.m3u8|https://p.bvvvvvvvvv1f.com/video/replace0001/202501235lEfXl91index.m3u8/index.m3u8',
 1454000, 0),
(1,  6, '报告', '', NULL,
 'https://vip15.play-cdn15.com/20230327/4355_53b3b78d/index.m3u8',
 'https://vip15.play-cdn15.com/20230327/4355_53b3b78d/index.m3u8|https://p.bvvvvvvvvv1f.com/video/replace0001/20250123eAJDbXzaindex.m3u8/index.m3u8',
 1454000, 0),
(1,  7, '旅行', '', NULL,
 'https://vip15.play-cdn15.com/20230327/4357_a76e4be5/index.m3u8',
 'https://vip15.play-cdn15.com/20230327/4357_a76e4be5/index.m3u8|https://p.bvvvvvvvvv1f.com/video/replace0001/20250123M4VE7xuGindex.m3u8/index.m3u8',
 1454000, 0),
(1,  8, '亲子', '', NULL,
 'https://vip15.play-cdn15.com/20230327/4356_0e008563/index.m3u8',
 'https://vip15.play-cdn15.com/20230327/4356_0e008563/index.m3u8|https://p.bvvvvvvvvv1f.com/video/replace0001/20250123Kq420rFiindex.m3u8/index.m3u8',
 1454000, 0),
(1,  9, '日常', '', NULL,
 'https://vip15.play-cdn15.com/20230327/4362_20c8cd33/index.m3u8',
 'https://vip15.play-cdn15.com/20230327/4362_20c8cd33/index.m3u8|https://p.bvvvvvvvvv1f.com/video/replace0001/20250123Kb7cRj9Sindex.m3u8/index.m3u8',
 1454000, 0),
(1, 10, '归路', '', NULL,
 'https://vip15.play-cdn15.com/20230327/4361_04876fc6/index.m3u8',
 'https://vip15.play-cdn15.com/20230327/4361_04876fc6/index.m3u8|https://p.bvvvvvvvvv1f.com/video/replace0001/202501235hcVV08iindex.m3u8/index.m3u8',
 1454000, 0),
(1, 11, '友人', '', NULL,
 'https://vip15.play-cdn15.com/20230327/4364_bac7a0f2/index.m3u8',
 'https://vip15.play-cdn15.com/20230327/4364_bac7a0f2/index.m3u8|https://p.bvvvvvvvvv1f.com/video/replace0001/20250123Vup3ABBbindex.m3u8/index.m3u8',
 1454000, 0),
(1, 12, '夫妻', '', NULL,
 'https://vip15.play-cdn15.com/20230327/4363_d62fd67c/index.m3u8',
 'https://vip15.play-cdn15.com/20230327/4363_d62fd67c/index.m3u8|https://p.bvvvvvvvvv1f.com/video/replace0001/20250123RwepkGQuindex.m3u8/index.m3u8',
 1454000, 0);

-- ---------- 视频条目：src 指向首集直链（首页直点播放时的兜底） ----------
UPDATE video
SET src         = 'https://vip15.play-cdn15.com/20230327/4354_41b31ccb/index.m3u8',
    uploader    = '动漫共和国',
    source_type = 'omofun',
    omofun_id   = '43835',
    duration    = '24:14',
    fav         = 1,
    daily_pick  = 1
WHERE id = 1;

-- ---------- 校验 ----------
SELECT id, title, uploader, source_type, omofun_id, duration, src FROM video WHERE id = 1;

SELECT ep_no, ep_title, m3u8_url, duration, vip
FROM video_episode WHERE video_id = 1 ORDER BY ep_no;
