-- =========================================================
-- 首页模块建表脚本（分类树 / 首页轮播 / 搜索热词 / 视频番剧补字段）
-- 项目：anime-login-vue 前端 + springBootTest 后端
-- 执行：mysql -uyuqing -p yuqing_db < sql/home_module.sql
-- 说明：
--   1. 本脚本可重复执行（IF NOT EXISTS + INSERT IGNORE / ON DUPLICATE KEY UPDATE）。
--   2. 分类树为两级结构：顶级分区(一级) → 子分类(二级)，
--      视频与番剧通过 category_id 关联，检索父分类时自动包含全部子孙分类。
--   3. video.content_rating 为内容分级（全年龄 / 12+ / 16+ / 18+），
--      与"分级分类"中的"分级"对应；分类层级对应"分类"。
--   4. 老的 video.tags / bangumi.category 字符串列全部保留，兼容既有代码，
--      新增的 category_id / content_rating 由后台或脚本同步维护。
-- =========================================================

USE yuqing_db;

-- -------------------------------------------------------------
-- 1) 分类树表
--    module：video=视频分区，bangumi=番剧分区，all=两者通用
--    level ：1=顶级分区，2=子分类（预留 3 级扩展）
-- -------------------------------------------------------------
CREATE TABLE IF NOT EXISTS category (
    id          BIGINT       NOT NULL AUTO_INCREMENT COMMENT '主键',
    parent_id   BIGINT       NOT NULL DEFAULT 0       COMMENT '父分类 id，0 表示顶级',
    name        VARCHAR(32)  NOT NULL                COMMENT '分类名称',
    slug        VARCHAR(48)  NOT NULL                COMMENT '英文标识（前端路由/筛选参数）',
    module      VARCHAR(16)  NOT NULL DEFAULT 'video' COMMENT '归属模块：video / bangumi / all',
    level       TINYINT      NOT NULL DEFAULT 1      COMMENT '层级：1 顶级分区，2 子分类',
    icon        VARCHAR(64)  DEFAULT NULL            COMMENT '图标标识',
    color       VARCHAR(32)  DEFAULT NULL            COMMENT '主题色（十六进制）',
    description VARCHAR(200) DEFAULT NULL            COMMENT '分类描述',
    sort_order  INT          NOT NULL DEFAULT 0      COMMENT '排序，越小越靠前',
    enabled     TINYINT      NOT NULL DEFAULT 1      COMMENT '是否启用：1 启用，0 停用',
    create_time DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    update_time DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP
                             ON UPDATE CURRENT_TIMESTAMP        COMMENT '更新时间',
    PRIMARY KEY (id),
    UNIQUE KEY uk_module_slug (module, slug),
    KEY idx_parent (parent_id),
    KEY idx_module_level (module, level, enabled)
) ENGINE = InnoDB
  DEFAULT CHARSET = utf8mb4
  COMMENT = '分类树表（两级分区，支持父子级联检索）';

-- 视频分区
INSERT INTO category (id, parent_id, name, slug, module, level, icon, color, description, sort_order, enabled) VALUES
(201, 0, '动画', 'anime',    'video', 1, 'movie',    '#c084fc', '番剧、原创动画与二次创作',       10, 1),
(202, 0, '音乐', 'music',    'video', 1, 'music',    '#7dd3fc', '原创曲、翻唱、演奏与歌单',       20, 1),
(203, 0, '游戏', 'game',     'video', 1, 'gamepad',  '#ffd98a', '实况、攻略与赛事集锦',           30, 1),
(204, 0, '生活', 'life',     'video', 1, 'coffee',   '#ff8fb1', 'Vlog、美食与治愈系日常',          40, 1),
(205, 0, '知识', 'knowledge','video', 1, 'book',     '#34d399', '科普、教程与技术拆解',           50, 1),
(206, 0, '舞蹈', 'dance',    'video', 1, 'star',     '#a78bfa', '宅舞、舞台与编舞教学',           60, 1),
-- 动画下的子分类
(211, 201, '番剧',   'anime-series',  'video', 2, NULL, '#c084fc', '连载与完结的番剧正片',     11, 1),
(212, 201, '短剧',   'anime-short',   'video', 2, NULL, '#d8b4fe', '短篇原创与剧情短片',       12, 1),
(213, 201, '绘画',   'painting',      'video', 2, NULL, '#f0abfc', '厚涂、立绘与绘制过程',     13, 1),
(214, 201, '三维',   'cg',            'video', 2, NULL, '#c4b5fd', 'CG、建模与渲染',           14, 1),
-- 音乐下的子分类
(221, 202, '原创曲', 'original',      'video', 2, NULL, '#7dd3fc', '原创音乐与填词',           21, 1),
(222, 202, '翻唱',   'cover',         'video', 2, NULL, '#93c5fd', '翻唱与改编',               22, 1),
(223, 202, '歌单',   'playlist',      'video', 2, NULL, '#bfdbfe', '主题歌单与循环播放',       23, 1),
-- 游戏下的子分类
(231, 203, '实况',   'gameplay',      'video', 2, NULL, '#ffd98a', '通关实况与娱乐向游戏',     31, 1),
(232, 203, '攻略',   'guide',         'video', 2, NULL, '#fde68a', '攻略、教程与解析',         32, 1),
-- 生活下的子分类
(241, 204, 'Vlog',   'vlog',          'video', 2, NULL, '#ff8fb1', '日常记录与生活随拍',       41, 1),
(242, 204, '美食',   'food',          'video', 2, NULL, '#fda4af', '美食探店与料理教学',       42, 1),
(243, 204, '治愈',   'healing',       'video', 2, NULL, '#fbcfe8', '助眠、ASMR 与治愈混剪',    43, 1),
-- 知识下的子分类
(251, 205, '科普',   'science',       'video', 2, NULL, '#34d399', '硬核科普与冷知识',         51, 1),
(252, 205, '技术',   'tech',          'video', 2, NULL, '#6ee7b7', '软硬件与技术解析',         52, 1),
-- 舞蹈下的子分类
(261, 206, '宅舞',   '宅舞',           'video', 2, NULL, '#a78bfa', '宅舞与舞蹈切片',           61, 1),
(262, 206, '教学',   'dance-tutorial', 'video', 2, NULL, '#c4b5fd', '编舞与动作教学',           62, 1)
ON DUPLICATE KEY UPDATE
    name        = VALUES(name),
    parent_id   = VALUES(parent_id),
    module      = VALUES(module),
    level       = VALUES(level),
    icon        = VALUES(icon),
    color       = VALUES(color),
    description = VALUES(description),
    sort_order  = VALUES(sort_order),
    enabled     = VALUES(enabled);

-- 番剧分区（与视频分开，module= bangumi）
INSERT INTO category (id, parent_id, name, slug, module, level, icon, color, description, sort_order, enabled) VALUES
(301, 0, '番剧', 'bangumi', 'bangumi', 1, 'tv',      '#c084fc', '所有番剧作品',               10, 1),
(311, 301, '日漫', 'jp',      'bangumi', 2, NULL, '#c084fc', '日本番剧作品',               11, 1),
(312, 301, '国漫', 'cn',      'bangumi', 2, NULL, '#ff8fb1', '国产动画作品',               12, 1),
(313, 301, '剧场', 'theater', 'bangumi', 2, NULL, '#ffd98a', '剧场版与 OVA',               13, 1),
(314, 301, '美漫', 'west',    'bangumi', 2, NULL, '#7dd3fc', '欧美动画作品',               14, 1)
ON DUPLICATE KEY UPDATE
    name        = VALUES(name),
    parent_id   = VALUES(parent_id),
    module      = VALUES(module),
    level       = VALUES(level),
    icon        = VALUES(icon),
    color       = VALUES(color),
    description = VALUES(description),
    sort_order  = VALUES(sort_order),
    enabled     = VALUES(enabled);


-- -------------------------------------------------------------
-- 2) 首页轮播表（Hero 轮播位）
--    content_type + content_id 指向 bangumi.id / video.id
-- -------------------------------------------------------------
CREATE TABLE IF NOT EXISTS banner (
    id             BIGINT       NOT NULL AUTO_INCREMENT COMMENT '主键',
    title          VARCHAR(64)  NOT NULL                COMMENT '主标题',
    subtitle       VARCHAR(200) DEFAULT NULL            COMMENT '副标题',
    content_type   VARCHAR(16)  NOT NULL DEFAULT 'bangumi' COMMENT '关联内容类型：bangumi / video',
    content_id     BIGINT       DEFAULT NULL            COMMENT '关联内容 id（bangumi.id 或 video.id）',
    cover_url      VARCHAR(255) DEFAULT NULL            COMMENT '外部封面图 URL',
    cover_gradient VARCHAR(200) DEFAULT NULL            COMMENT 'CSS 渐变兜底',
    tag            VARCHAR(32)  DEFAULT NULL            COMMENT '角标文案（如"独家"）',
    sort_order     INT          NOT NULL DEFAULT 0      COMMENT '排序，越小越靠前',
    enabled        TINYINT      NOT NULL DEFAULT 1      COMMENT '是否启用',
    start_time     DATETIME     DEFAULT NULL            COMMENT '投放开始时间',
    end_time       DATETIME     DEFAULT NULL            COMMENT '投放结束时间',
    create_time    DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    update_time    DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP
                               ON UPDATE CURRENT_TIMESTAMP        COMMENT '更新时间',
    PRIMARY KEY (id),
    KEY idx_sort (enabled, sort_order),
    KEY idx_content (content_type, content_id)
) ENGINE = InnoDB
  DEFAULT CHARSET = utf8mb4
  COMMENT = '首页轮播表';

INSERT INTO banner (id, title, subtitle, content_type, content_id, cover_gradient, tag, sort_order, enabled) VALUES
(1, '星屑列车开往黎明', '末日后的轨道上，少女与一台会说话的旧列车驶向传说的黎明站。', 'bangumi', 101, 'linear-gradient(135deg,#ff8fb1,#c084fc)', '独家', 10, 1),
(2, '魔法少女小满的午后', '只要在下午三点许愿，任何小事都会变成闪闪发光的奇迹。',     'bangumi', 102, 'linear-gradient(135deg,#7dd3fc,#a78bfa)', '热播', 20, 1),
(3, '晚晴剑歌', '一把断剑，一座空城，她在雨里等一个再也不会回来的人。',               'bangumi', 103, 'linear-gradient(135deg,#ff6f9c,#c084fc)', '新剧', 30, 1),
(4, '樱色咖啡店物语', '转角那家咖啡店，每位客人都带着一段想被温柔接住的故事。',       'bangumi', 106, 'linear-gradient(135deg,#ff8fb1,#a78bfa)', '治愈', 40, 1),
(5, '深空抒情诗', '一艘载满歌声的飞船，在星云间寻找失落的故乡频率。',                 'bangumi', 105, 'linear-gradient(135deg,#a78bfa,#7dd3fc)', '独家', 50, 1)
ON DUPLICATE KEY UPDATE
    title          = VALUES(title),
    subtitle       = VALUES(subtitle),
    content_type   = VALUES(content_type),
    content_id     = VALUES(content_id),
    cover_gradient = VALUES(cover_gradient),
    tag            = VALUES(tag),
    sort_order     = VALUES(sort_order),
    enabled        = VALUES(enabled);


-- -------------------------------------------------------------
-- 3) 搜索热词统计表
--    记录用户搜索过的关键词，用于首页"热门搜索"与搜索建议
-- -------------------------------------------------------------
CREATE TABLE IF NOT EXISTS search_keyword_log (
    id              BIGINT       NOT NULL AUTO_INCREMENT COMMENT '主键',
    keyword         VARCHAR(64)  NOT NULL                COMMENT '搜索关键词（原文）',
    normalized_key  VARCHAR(64)  NOT NULL                COMMENT '归一化关键词（小写去空格，用于聚合）',
    search_count    INT          NOT NULL DEFAULT 1      COMMENT '搜索次数',
    result_count    INT          NOT NULL DEFAULT 0      COMMENT '最近一次搜索的结果数',
    last_search_time DATETIME    NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '最近搜索时间',
    create_time     DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    update_time     DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP
                                ON UPDATE CURRENT_TIMESTAMP        COMMENT '更新时间',
    PRIMARY KEY (id),
    UNIQUE KEY uk_normalized_key (normalized_key),
    KEY idx_count (search_count),
    KEY idx_last_time (last_search_time)
) ENGINE = InnoDB
  DEFAULT CHARSET = utf8mb4
  COMMENT = '搜索热词统计表';


-- -------------------------------------------------------------
-- 4) video 表补字段（分类关联 + 内容分级 + 权重）
--    MySQL 的 ALTER TABLE ADD COLUMN 不支持 IF NOT EXISTS，
--    这里用 INFORMATION_SCHEMA 判断列是否存在，保证脚本可重复执行。
-- -------------------------------------------------------------
DROP PROCEDURE IF EXISTS yq_add_column;
DELIMITER $$
CREATE PROCEDURE yq_add_column(
    IN p_table  VARCHAR(64),
    IN p_column VARCHAR(64),
    IN p_define VARCHAR(512)
)
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS
        WHERE TABLE_SCHEMA = DATABASE()
          AND TABLE_NAME   = p_table
          AND COLUMN_NAME  = p_column
    ) THEN
        SET @ddl = CONCAT('ALTER TABLE `', p_table, '` ADD COLUMN `', p_column, '` ', p_define);
        PREPARE stmt FROM @ddl;
        EXECUTE stmt;
        DEALLOCATE PREPARE stmt;
    END IF;
END$$
DELIMITER ;

CALL yq_add_column('video', 'category_id',      "BIGINT DEFAULT NULL COMMENT '子分类 id（关联 category.id，module=video）' AFTER daily_pick");
CALL yq_add_column('video', 'content_rating',   "VARCHAR(16) DEFAULT '全年龄' COMMENT '内容分级：全年龄 / 12+ / 16+ / 18+' AFTER category_id");
CALL yq_add_column('video', 'recommend_weight', "INT NOT NULL DEFAULT 0 COMMENT '推荐权重，越大越靠前' AFTER content_rating");
CALL yq_add_column('video', 'region',           "VARCHAR(16) DEFAULT '内地' COMMENT '地区：内地 / 港澳台 / 海外' AFTER recommend_weight");

-- -------------------------------------------------------------
-- 5) bangumi 表补字段（分类关联 + 内容分级）
-- -------------------------------------------------------------
CALL yq_add_column('bangumi', 'category_id',    "BIGINT DEFAULT NULL COMMENT '子分类 id（关联 category.id，module=bangumi）' AFTER category");
CALL yq_add_column('bangumi', 'content_rating', "VARCHAR(16) DEFAULT '全年龄' COMMENT '内容分级：全年龄 / 12+ / 16+ / 18+' AFTER category_id");

DROP PROCEDURE IF EXISTS yq_add_column;

-- 索引同样做存在性判断
DROP PROCEDURE IF EXISTS yq_add_index;
DELIMITER $$
CREATE PROCEDURE yq_add_index(
    IN p_table VARCHAR(64),
    IN p_index VARCHAR(64),
    IN p_cols  VARCHAR(512)
)
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM INFORMATION_SCHEMA.STATISTICS
        WHERE TABLE_SCHEMA = DATABASE()
          AND TABLE_NAME   = p_table
          AND INDEX_NAME   = p_index
    ) THEN
        SET @ddl = CONCAT('ALTER TABLE `', p_table, '` ADD INDEX `', p_index, '` (', p_cols, ')');
        PREPARE stmt FROM @ddl;
        EXECUTE stmt;
        DEALLOCATE PREPARE stmt;
    END IF;
END$$
DELIMITER ;

-- 已有数据回填：按 tags 关键词归类到子分类
UPDATE video SET category_id = 211, content_rating = '全年龄', region = '内地' WHERE id IN (1, 2, 4);
UPDATE video SET category_id = 243, content_rating = '全年龄', region = '内地' WHERE id IN (3, 5);
UPDATE video SET category_id = 223, content_rating = '全年龄', region = '内地' WHERE id IN (6, 8);
UPDATE video SET category_id = 213, content_rating = '全年龄', region = '内地' WHERE id = 7;
UPDATE video SET recommend_weight = 10 WHERE id = 1;
UPDATE video SET recommend_weight = 8  WHERE id = 4;
UPDATE video SET recommend_weight = 6  WHERE id = 6;

UPDATE bangumi SET category_id = 311 WHERE category = '日漫';
UPDATE bangumi SET category_id = 312 WHERE category = '国漫';
UPDATE bangumi SET category_id = 313 WHERE category = '剧场';
UPDATE bangumi SET category_id = 314 WHERE category = '美漫';

-- -------------------------------------------------------------
-- 6) 常用查询索引
-- -------------------------------------------------------------
CALL yq_add_index('video',   'idx_video_category', 'category_id');
CALL yq_add_index('video',   'idx_video_rating',   'content_rating');
CALL yq_add_index('video',   'idx_video_pick',     'daily_pick, recommend_weight, play');
CALL yq_add_index('bangumi', 'idx_bangumi_category', 'category_id');

DROP PROCEDURE IF EXISTS yq_add_index;

-- -------------------------------------------------------------
-- 7) 校验
-- -------------------------------------------------------------
SELECT module, level, COUNT(*) AS cnt FROM category GROUP BY module, level ORDER BY module, level;
SELECT id, title, category_id, content_rating, recommend_weight FROM video ORDER BY id;
SELECT id, title, category, category_id FROM bangumi ORDER BY id;
