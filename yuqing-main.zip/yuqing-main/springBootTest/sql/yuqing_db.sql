-- =========================================================
-- yuqing_db 数据库初始化脚本
-- 项目：anime-login-vue 前端 + springBootTest 后端
-- 说明：
--   1. 前两句（创建 yuqing 用户 + 授权）需要 root 权限执行一次；
--      如果 yuqing 用户已存在，可跳过。
--   2. 建库建表语句用 yuqing 或 root 执行均可。
--   3. 后端启动时会自动初始化测试账号 sakura / Test@123456，
--      无需手工插入用户数据。
-- =========================================================

-- 创建应用专用账号（root 执行，已存在则忽略）
CREATE USER IF NOT EXISTS 'yuqing'@'localhost' IDENTIFIED BY '123456';
CREATE USER IF NOT EXISTS 'yuqing'@'%' IDENTIFIED BY '123456';

-- 创建数据库
CREATE DATABASE IF NOT EXISTS yuqing_db
    DEFAULT CHARACTER SET utf8mb4
    COLLATE utf8mb4_general_ci;

-- 授权（root 执行）
GRANT ALL PRIVILEGES ON yuqing_db.* TO 'yuqing'@'localhost';
GRANT ALL PRIVILEGES ON yuqing_db.* TO 'yuqing'@'%';
FLUSH PRIVILEGES;

USE yuqing_db;

-- 用户表
CREATE TABLE IF NOT EXISTS sys_user (
    id          BIGINT       NOT NULL AUTO_INCREMENT COMMENT '主键',
    username    VARCHAR(32)  NOT NULL                COMMENT '登录用户名',
    email       VARCHAR(64)  DEFAULT NULL            COMMENT '邮箱（可空）',
    password    VARCHAR(100) NOT NULL                COMMENT '密码（BCrypt 加密存储）',
    nickname    VARCHAR(32)  DEFAULT NULL            COMMENT '展示昵称',
    status      TINYINT      NOT NULL DEFAULT 1      COMMENT '状态：1 正常，0 禁用',
    create_time DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP                COMMENT '创建时间',
    update_time DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP
                             ON UPDATE CURRENT_TIMESTAMP                       COMMENT '更新时间',
    PRIMARY KEY (id),
    UNIQUE KEY uk_username (username),
    UNIQUE KEY uk_email (email)
) ENGINE = InnoDB
  DEFAULT CHARSET = utf8mb4
  COMMENT = '用户表';
