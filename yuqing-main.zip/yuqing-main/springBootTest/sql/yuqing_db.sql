-- =========================================================
-- yuqing_db 数据库初始化脚本
-- 项目：anime-login-vue 前端 + springBootTest 后端
-- 说明：
--   1. 前两句（创建 yuqing 用户 + 授权）需要 root 权限执行一次；
--      如果 yuqing 用户已存在，可跳过。
--   2. 建库建表语句用 yuqing 或 root 执行均可。
--   3. 后端启动时会自动初始化测试账号 sakura / Test@123456，
--      无需手工插入用户数据。
--   4. 番剧表 bangumi 含 12 部作品的插画（cover_svg 内联 SVG 源码），
--      重复执行本脚本会重建种子数据，插画可直接覆盖更新。
-- =========================================================

-- 显式声明客户端字符集，避免 Windows 下 mysql 客户端默认 GBK 解析 UTF-8 脚本报错
SET NAMES utf8mb4;

-- 创建应用专用账号（root 执行，已存在则忽略）
CREATE USER IF NOT EXISTS 'yuqing'@'localhost' IDENTIFIED BY '123456';
CREATE USER IF NOT EXISTS 'yuqing'@'%' IDENTIFIED BY '123456';

-- 创建数据库
CREATE DATABASE IF NOT EXISTS yuqing_db
    DEFAULT CHARACTER SET utf8mb4
    COLLATE utf8mb4_general_ci;

-- 授权（root 执行）
GRANT ALL PRIVILEGES ON yuqing_db.* TO 'yuqing'@'localhost';
GRANT ALL PRIVILEGES ON yuqing_db.* TO 'yuqing'@'%';
FLUSH PRIVILEGES;

USE yuqing_db;

-- 用户表
CREATE TABLE IF NOT EXISTS sys_user (
    id          BIGINT       NOT NULL AUTO_INCREMENT COMMENT '主键',
    username    VARCHAR(32)  NOT NULL                COMMENT '登录用户名',
    email       VARCHAR(64)  DEFAULT NULL            COMMENT '邮箱（可空）',
    password    VARCHAR(100) NOT NULL                COMMENT '密码（明文存储）',
    nickname    VARCHAR(32)  DEFAULT NULL            COMMENT '展示昵称',
    permission  TINYINT      NOT NULL DEFAULT 1      COMMENT '权限：0 管理员（可进后台），1 默认权限',
    status      TINYINT      NOT NULL DEFAULT 1      COMMENT '状态：1 正常，0 禁用',
    create_time DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP                COMMENT '创建时间',
    update_time DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP
                             ON UPDATE CURRENT_TIMESTAMP                       COMMENT '更新时间',
    PRIMARY KEY (id),
    UNIQUE KEY uk_username (username),
    UNIQUE KEY uk_email (email)
) ENGINE = InnoDB
  DEFAULT CHARSET = utf8mb4
  COMMENT = '用户表';


-- =========================================================
-- 番剧表 + 12 部番剧插画种子数据
-- 说明：
--   1. cover_svg 存放插画的完整 SVG 源码（3:4 竖版海报），
--      自包含、不依赖任何静态资源目录，后端可直接取出返回。
--   2. 取图优先级：cover_url（外部图）> cover_svg（内联插画）
--      > cover_gradient（纯 CSS 渐变兜底）。
--   3. id 与前端 mock 数据保持一致（101~112），改用真实后端
--      时前端页面无需任何改动。
-- =========================================================

CREATE TABLE IF NOT EXISTS bangumi (
    id             BIGINT        NOT NULL AUTO_INCREMENT COMMENT '主键（101~112，与前端 mock 数据一致）',
    title          VARCHAR(64)   NOT NULL                COMMENT '番剧标题',
    cover_svg      LONGTEXT      DEFAULT NULL            COMMENT '番剧插画：内联 SVG 源码（3:4 竖版海报）',
    cover_url      VARCHAR(255)  DEFAULT NULL            COMMENT '外部封面图 URL，有值时优先于 cover_svg',
    cover_gradient VARCHAR(200)  DEFAULT NULL            COMMENT 'CSS 渐变封面，无图时兜底展示',
    src             VARCHAR(255)  DEFAULT ''              COMMENT '播放地址',
    source_type     VARCHAR(16)   NOT NULL DEFAULT 'native' COMMENT '播放源类型：native 原生直链 / tencent 腾讯视频 / bilibili 哔哩哔哩',
    vid             VARCHAR(64)   DEFAULT NULL            COMMENT '腾讯视频 VID（source_type=tencent 时有效）',
    bvid            VARCHAR(64)   DEFAULT NULL            COMMENT '哔哩哔哩 BV 号（source_type=bilibili 时有效）',
    episodes       INT           NOT NULL DEFAULT 12     COMMENT '总集数',
    status         VARCHAR(16)   NOT NULL DEFAULT '连载中' COMMENT '连载中 / 已完结',
    score          DECIMAL(3, 1) NOT NULL DEFAULT 8.0    COMMENT '评分',
    studio         VARCHAR(64)   DEFAULT NULL            COMMENT '制作公司',
    category       VARCHAR(16)   DEFAULT NULL            COMMENT '分类：日漫 / 国漫 / 剧场 / 美漫',
    tags           VARCHAR(128)  DEFAULT NULL            COMMENT '标签，斜杠分隔',
    description    VARCHAR(500)  DEFAULT NULL            COMMENT '简介',
    create_time    DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP                COMMENT '创建时间',
    update_time    DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP
                                 ON UPDATE CURRENT_TIMESTAMP                       COMMENT '更新时间',
    PRIMARY KEY (id),
    KEY idx_category (category),
    KEY idx_status (status)
) ENGINE = InnoDB
  DEFAULT CHARSET = utf8mb4
  COMMENT = '番剧表';

-- 种子数据（重复执行会先清空再插入，保证插画可反复更新）
DELETE FROM bangumi;

INSERT INTO bangumi (id, title, cover_svg, cover_url, cover_gradient, src, source_type, vid, bvid, episodes, status, score, studio, category, tags, description) VALUES
(101, '星屑列车开往黎明', '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 300 400" width="300" height="400"><defs><linearGradient id="s101" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#231a45"/><stop offset=".38" stop-color="#5b3f8f"/><stop offset=".72" stop-color="#d9628f"/><stop offset="1" stop-color="#ffc38a"/></linearGradient><radialGradient id="g101" cx=".5" cy=".5" r=".5"><stop offset="0" stop-color="#fff6de"/><stop offset=".45" stop-color="#ffd98a" stop-opacity=".8"/><stop offset="1" stop-color="#ffb26b" stop-opacity="0"/></radialGradient><linearGradient id="d101" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#2b1f4d"/><stop offset="1" stop-color="#150e26"/></linearGradient></defs><rect width="300" height="400" fill="url(#s101)"/><g fill="#fff"><circle cx="30" cy="34" r="1.7"/><circle cx="72" cy="18" r="1.2" opacity=".7"/><circle cx="108" cy="46" r="1.9" opacity=".85"/><circle cx="150" cy="24" r="1.1" opacity=".6"/><circle cx="196" cy="40" r="1.6" opacity=".8"/><circle cx="238" cy="16" r="1.3" opacity=".7"/><circle cx="270" cy="52" r="1.8" opacity=".9"/><circle cx="54" cy="74" r="1.1" opacity=".5"/><circle cx="222" cy="88" r="1.2" opacity=".5"/><circle cx="128" cy="98" r="1" opacity=".45"/><circle cx="24" cy="120" r="1.2" opacity=".4"/><circle cx="262" cy="118" r="1" opacity=".4"/></g><circle cx="196" cy="238" r="98" fill="url(#g101)"/><circle cx="196" cy="238" r="27" fill="#fff2d2"/><path d="M0 254 C40 238 78 246 112 252 C150 259 178 242 214 246 C252 250 276 260 300 252 L300 300 L0 300 Z" fill="#3a2760" opacity=".92"/><g fill="#1f1636"><rect x="0" y="228" width="300" height="9" rx="3"/><rect x="42" y="237" width="11" height="66"/><rect x="128" y="237" width="11" height="66"/><rect x="214" y="237" width="11" height="66"/><rect x="288" y="237" width="11" height="66"/></g><g><rect x="150" y="196" width="132" height="32" rx="13" fill="#2b1f4d"/><rect x="150" y="196" width="132" height="13" rx="6.5" fill="#3d2c69"/><g fill="#ffd98a"><rect x="160" y="203" width="15" height="12" rx="4"/><rect x="181" y="203" width="15" height="12" rx="4"/><rect x="202" y="203" width="15" height="12" rx="4"/><rect x="223" y="203" width="15" height="12" rx="4"/><rect x="244" y="203" width="15" height="12" rx="4"/></g><g fill="#150e26"><circle cx="160" cy="230" r="5"/><circle cx="184" cy="230" r="5"/><circle cx="252" cy="230" r="5"/><circle cx="276" cy="230" r="5"/></g><rect x="279" y="180" width="6" height="18" fill="#2b1f4d"/><circle cx="282" cy="177" r="5" fill="#ffeaa8"/></g><path d="M0 300 C60 292 120 306 180 298 C230 292 268 302 300 296 L300 400 L0 400 Z" fill="url(#d101)"/><g fill="#120c22"><circle cx="66" cy="286" r="13"/><path d="M51 288 c-4 -16 6 -26 15 -26 c11 0 19 10 15 26 c-2 6 -6 8 -15 8 c-9 0 -13 -2 -15 -8 z"/><path d="M66 300 c-11 0 -18 9 -19 22 l-4 34 h46 l-4 -34 c-1 -13 -8 -22 -19 -22 z"/><rect x="45" y="348" width="11" height="20" rx="5"/><rect x="76" y="348" width="11" height="20" rx="5"/><rect x="86" y="326" width="24" height="28" rx="5"/><path d="M92 326 c0 -6 12 -6 12 0" stroke="#120c22" stroke-width="3" fill="none"/></g><g fill="#ffd98a" opacity=".85"><circle cx="120" cy="332" r="2"/><circle cx="200" cy="352" r="1.6"/><circle cx="252" cy="322" r="2.2"/><circle cx="30" cy="382" r="1.8"/><circle cx="164" cy="374" r="1.4"/><circle cx="284" cy="366" r="1.6"/></g></svg>', NULL, 'linear-gradient(135deg,#ff8fb1,#c084fc)', '', 'native', NULL, NULL, 12, '连载中', 9.2, '桜动画', '日漫', '原创/科幻/治愈', '末日后的轨道上，少女与一台会说话的旧列车驶向传说的黎明站。');

INSERT INTO bangumi (id, title, cover_svg, cover_url, cover_gradient, src, source_type, vid, bvid, episodes, status, score, studio, category, tags, description) VALUES
(102, '赛马娘芦毛灰姑娘', NULL, '/umamusume-poster.webp', 'linear-gradient(135deg,#ff6f9c,#c084fc)', 'https://player.bilibili.com/player.html?bvid=BV145G1z9E71&p=1&autoplay=0&high_quality=1&danmaku=0', 'bilibili', NULL, 'BV145G1z9E71', 23, '已完结', 9.9, 'CygamesPictures', '日漫', '漫画改/热血/运动/励志', '《周刊YOUNG JUMP》销量破 800 万的漫画终于动画化。地方出身的怪物小栗帽，迎战人称「最强」的玉藻十字。灰扑扑的少女，即将踏入全新的领域——驰骋火热梦想的灰姑娘故事，继续奔跑！');

INSERT INTO bangumi (id, title, cover_svg, cover_url, cover_gradient, src, source_type, vid, bvid, episodes, status, score, studio, category, tags, description) VALUES
(103, '晚晴剑歌', '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 300 400" width="300" height="400"><defs><linearGradient id="s103" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#151634"/><stop offset=".45" stop-color="#3d2a5e"/><stop offset=".8" stop-color="#7c4a72"/><stop offset="1" stop-color="#b06a7e"/></linearGradient><radialGradient id="g103" cx=".5" cy=".5" r=".5"><stop offset="0" stop-color="#fff8e2"/><stop offset=".5" stop-color="#ffe9b8" stop-opacity=".55"/><stop offset="1" stop-color="#ffd98a" stop-opacity="0"/></radialGradient><linearGradient id="d103" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#241a3c"/><stop offset="1" stop-color="#100b1e"/></linearGradient></defs><rect width="300" height="400" fill="url(#s103)"/><circle cx="222" cy="86" r="94" fill="url(#g103)"/><circle cx="222" cy="86" r="30" fill="#fff7e4"/><g fill="#fff" opacity=".5"><circle cx="46" cy="42" r="1.5"/><circle cx="92" cy="28" r="1.1"/><circle cx="140" cy="52" r="1.3"/><circle cx="30" cy="96" r="1.2"/><circle cx="268" cy="150" r="1.3"/><circle cx="76" cy="126" r="1"/></g><path d="M0 250 L60 176 L104 226 L150 168 L206 240 L250 196 L300 252 L300 300 L0 300 Z" fill="#2b1f47"/><path d="M0 276 L54 232 L118 280 L176 236 L238 282 L300 250 L300 320 L0 320 Z" fill="#1d1533"/><path d="M20 316 C64 298 106 272 150 254 C194 272 236 298 280 316 Z" fill="#150f28"/><rect x="62" y="312" width="176" height="56" fill="#100b1e"/><rect x="120" y="330" width="24" height="26" rx="3" fill="#ffb26b" opacity=".85"/><rect x="196" y="330" width="24" height="26" rx="3" fill="#ffb26b" opacity=".6"/><g><path d="M202 186 L202 268" stroke="#dfe6f5" stroke-width="6" stroke-linecap="round"/><rect x="193" y="264" width="18" height="6" rx="3" fill="#a78bfa"/><path d="M203 272 L203 290" stroke="#6d4a9c" stroke-width="5" stroke-linecap="round"/><path d="M205 198 c22 10 34 -8 29 -23 c-3 -12 -18 -9 -20 3" stroke="#ff5c7a" stroke-width="4" fill="none" stroke-linecap="round"/></g><g fill="#0d0818"><circle cx="150" cy="196" r="12"/><path d="M136 200 c-3 -14 5 -22 14 -22 c10 0 16 8 13 22z"/><path d="M150 208 c-10 0 -16 8 -17 20 l-5 30 h44 l-5 -30 c-1 -12 -7 -20 -17 -20z"/><path d="M128 246 c-10 6 -14 12 -16 18 h76 c-2 -6 -6 -12 -16 -18z"/></g><path d="M112 172 C126 148 174 148 188 172 C172 180 128 180 112 172 Z" fill="#3a1f3f"/><path d="M150 172 v-16" stroke="#3a1f3f" stroke-width="3" stroke-linecap="round"/><g stroke="#cfe0ff" stroke-width="1.4" opacity=".26" stroke-linecap="round"><path d="M18 62 l-9 24"/><path d="M52 40 l-9 24"/><path d="M86 78 l-9 24"/><path d="M120 52 l-9 24"/><path d="M154 96 l-9 24"/><path d="M188 60 l-9 24"/><path d="M222 104 l-9 24"/><path d="M256 72 l-9 24"/><path d="M286 124 l-9 24"/><path d="M36 148 l-9 24"/><path d="M104 168 l-9 24"/><path d="M176 196 l-9 24"/><path d="M244 168 l-9 24"/><path d="M66 214 l-9 24"/><path d="M290 214 l-9 24"/></g><path d="M0 356 C70 348 140 360 200 352 C250 346 274 356 300 350 L300 400 L0 400 Z" fill="url(#d103)"/></svg>', NULL, 'linear-gradient(135deg,#ff6f9c,#c084fc)', '', 'native', NULL, NULL, 13, '连载中', 9.0, '苍崎制作', '国漫', '武侠/古风/燃', '一把断剑，一座空城，她在雨里等一个再也不会回来的人。');

INSERT INTO bangumi (id, title, cover_svg, cover_url, cover_gradient, src, source_type, vid, bvid, episodes, status, score, studio, category, tags, description) VALUES
(104, '便利屋猫咪日记', '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 300 400" width="300" height="400"><defs><linearGradient id="s104" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#7dd3fc"/><stop offset=".4" stop-color="#ffd98a"/><stop offset=".75" stop-color="#ff8fb1"/><stop offset="1" stop-color="#b06ad0"/></linearGradient><linearGradient id="d104" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#3a2a5c"/><stop offset="1" stop-color="#1c1530"/></linearGradient><radialGradient id="w104" cx=".5" cy=".5" r=".5"><stop offset="0" stop-color="#ffe6a8" stop-opacity=".95"/><stop offset="1" stop-color="#ffb26b" stop-opacity=".12"/></radialGradient></defs><rect width="300" height="400" fill="url(#s104)"/><circle cx="150" cy="118" r="72" fill="url(#w104)"/><circle cx="150" cy="118" r="34" fill="#fff0c8" opacity=".9"/><g fill="#4a3468" opacity=".85"><rect x="0" y="176" width="70" height="150"/><rect x="232" y="196" width="68" height="130"/></g><g><rect x="62" y="186" width="176" height="140" fill="#f3e7ff"/><path d="M56 186 h188 l-10 26 h-168z" fill="#ff8fb1"/><g fill="#fff" opacity=".85"><path d="M78 186 h20 l-4 26 h-20z"/><path d="M124 186 h20 l-4 26 h-20z"/><path d="M170 186 h20 l-4 26 h-20z"/></g><rect x="78" y="224" width="144" height="82" rx="6" fill="#ffd98a"/><g fill="#b06a3a" opacity=".45"><rect x="92" y="252" width="12" height="30" rx="3"/><rect x="112" y="246" width="12" height="36" rx="3"/><rect x="186" y="250" width="12" height="32" rx="3"/></g><rect x="196" y="248" width="30" height="58" rx="4" fill="#6d4a9c"/><circle cx="220" cy="278" r="3" fill="#ffd98a"/><rect x="100" y="200" width="100" height="18" rx="6" fill="#fff" opacity=".92"/><g fill="#a78bfa" opacity=".7"><rect x="110" y="206" width="34" height="6" rx="3"/><rect x="152" y="206" width="38" height="6" rx="3"/></g></g><path d="M0 326 C60 318 130 332 190 324 C240 318 272 328 300 322 L300 400 L0 400 Z" fill="url(#d104)"/><g><path d="M104 350 c-26 4 -34 -18 -18 -30 c10 -8 22 -2 22 12" fill="none" stroke="#ffe3c7" stroke-width="14" stroke-linecap="round"/><path d="M112 356 c0 -34 18 -56 44 -56 c26 0 44 22 44 56z" fill="#ffe3c7"/><circle cx="156" cy="288" r="30" fill="#ffe3c7"/><path d="M132 270 l-6 -26 l24 14z" fill="#ffe3c7"/><path d="M180 270 l6 -26 l-24 14z" fill="#ffe3c7"/><path d="M133 266 l-3 -14 l13 8z" fill="#ff9dbb"/><path d="M179 266 l3 -14 l-13 8z" fill="#ff9dbb"/><g stroke="#4a3468" stroke-width="3" fill="none" stroke-linecap="round"><path d="M140 288 q6 -7 12 0"/><path d="M162 288 q6 -7 12 0"/></g><path d="M154 298 q4 4 8 0" stroke="#4a3468" stroke-width="2.5" fill="none" stroke-linecap="round"/><g stroke="#4a3468" stroke-width="2" opacity=".5" stroke-linecap="round"><path d="M126 296 h-16"/><path d="M128 302 l-15 5"/><path d="M188 296 h16"/><path d="M186 302 l15 5"/></g><ellipse cx="132" cy="354" rx="13" ry="7" fill="#fff2e0"/><ellipse cx="180" cy="354" rx="13" ry="7" fill="#fff2e0"/><path d="M138 314 q18 10 36 0" stroke="#ff6f9c" stroke-width="5" fill="none" stroke-linecap="round"/><circle cx="156" cy="322" r="5" fill="#ffd98a"/></g><g><rect x="216" y="318" width="22" height="38" rx="6" fill="#fff" opacity=".92"/><rect x="222" y="310" width="10" height="10" rx="2" fill="#7dd3fc"/></g><g fill="#ffd98a" opacity=".8"><circle cx="60" cy="360" r="2"/><circle cx="264" cy="352" r="2.2"/><circle cx="36" cy="386" r="1.6"/></g></svg>', NULL, 'linear-gradient(135deg,#ffd98a,#ff8fb1)', '', 'native', NULL, NULL, 10, '已完结', 8.4, '软糖动画', '日漫', '治愈/猫/日常', '帮邻居送牛奶、替老人修水管，顺手拯救一下世界也不错。');

INSERT INTO bangumi (id, title, cover_svg, cover_url, cover_gradient, src, source_type, vid, bvid, episodes, status, score, studio, category, tags, description) VALUES
(105, '深空抒情诗', '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 300 400" width="300" height="400"><defs><linearGradient id="s105" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#160e38"/><stop offset=".45" stop-color="#43206e"/><stop offset=".8" stop-color="#1d3f7a"/><stop offset="1" stop-color="#0d1130"/></linearGradient><radialGradient id="n105" cx=".5" cy=".5" r=".5"><stop offset="0" stop-color="#c084fc" stop-opacity=".55"/><stop offset="1" stop-color="#c084fc" stop-opacity="0"/></radialGradient><radialGradient id="n105b" cx=".5" cy=".5" r=".5"><stop offset="0" stop-color="#7dd3fc" stop-opacity=".5"/><stop offset="1" stop-color="#7dd3fc" stop-opacity="0"/></radialGradient><linearGradient id="p105" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#a78bfa"/><stop offset="1" stop-color="#5b3fa0"/></linearGradient><g id="note105" fill="#ffd98a"><ellipse cx="0" cy="0" rx="8.5" ry="6.5" transform="rotate(-20)"/><rect x="5.4" y="-31" width="3.2" height="31"/><path d="M8.6 -31 q15 4 13 19 q-4 -11 -13 -11z"/></g></defs><rect width="300" height="400" fill="url(#s105)"/><ellipse cx="96" cy="128" rx="130" ry="96" fill="url(#n105)"/><ellipse cx="216" cy="286" rx="120" ry="90" fill="url(#n105b)"/><g fill="#fff"><circle cx="28" cy="40" r="1.8"/><circle cx="72" cy="22" r="1.2" opacity=".7"/><circle cx="118" cy="58" r="1.6" opacity=".85"/><circle cx="164" cy="30" r="1.1" opacity=".6"/><circle cx="206" cy="52" r="1.7" opacity=".8"/><circle cx="248" cy="22" r="1.3" opacity=".7"/><circle cx="276" cy="76" r="1.9" opacity=".9"/><circle cx="46" cy="92" r="1.1" opacity=".5"/><circle cx="150" cy="104" r="1.3" opacity=".55"/><circle cx="232" cy="120" r="1.2" opacity=".5"/><circle cx="18" cy="150" r="1.4" opacity=".5"/><circle cx="284" cy="168" r="1.1" opacity=".45"/><circle cx="88" cy="188" r="1" opacity=".4"/><circle cx="262" cy="206" r="1.3" opacity=".45"/></g><g><ellipse cx="66" cy="322" rx="94" ry="22" fill="none" stroke="#c9b3ff" stroke-width="5" opacity=".55"/><circle cx="66" cy="322" r="56" fill="url(#p105)"/><path d="M22 300 q44 16 88 0" stroke="#fff" stroke-width="3" fill="none" opacity=".28"/><path d="M18 336 q48 18 96 -4" stroke="#fff" stroke-width="3" fill="none" opacity=".2"/><ellipse cx="66" cy="322" rx="94" ry="22" fill="none" stroke="#e6dbff" stroke-width="5" opacity=".8"/></g><path d="M186 186 C150 214 118 236 74 250" stroke="#7dd3fc" stroke-width="3" fill="none" opacity=".5" stroke-linecap="round" stroke-dasharray="12 9"/><g transform="translate(168 156) rotate(-16)"><ellipse cx="0" cy="0" rx="60" ry="17" fill="#efe9ff"/><ellipse cx="-8" cy="-6" rx="42" ry="9" fill="#fff" opacity=".55"/><path d="M-60 0 l-20 -15 l7 15 l-7 15z" fill="#ff8fb1"/><path d="M20 -16 q22 -14 36 2" stroke="#c084fc" stroke-width="4" fill="none" stroke-linecap="round"/><circle cx="28" cy="0" r="8" fill="#7dd3fc"/><circle cx="28" cy="0" r="3.4" fill="#fff"/></g><use href="#note105" transform="translate(60 96) rotate(-8) scale(1.1)"/><use href="#note105" transform="translate(232 214) rotate(12)"/><use href="#note105" transform="translate(122 268) rotate(-14) scale(.85)"/><use href="#note105" transform="translate(252 128) rotate(6) scale(.7)"/><g stroke="#ffd98a" fill="none" stroke-linecap="round" opacity=".55"><path d="M40 234 q14 -12 28 0" stroke-width="3"/><path d="M32 246 q22 -18 44 0" stroke-width="3"/><path d="M24 258 q30 -24 60 0" stroke-width="3"/></g><circle cx="284" cy="330" r="1.8" fill="#fff" opacity=".7"/><circle cx="150" cy="352" r="1.4" fill="#fff" opacity=".5"/></svg>', NULL, 'linear-gradient(135deg,#a78bfa,#7dd3fc)', '', 'native', NULL, NULL, 12, '连载中', 8.9, '棱镜动画', '日漫', '太空/音乐/群像', '一艘载满歌声的飞船，在星云间寻找失落的故乡频率。');

INSERT INTO bangumi (id, title, cover_svg, cover_url, cover_gradient, src, source_type, vid, bvid, episodes, status, score, studio, category, tags, description) VALUES
(106, '樱色咖啡店物语', '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 300 400" width="300" height="400"><defs><linearGradient id="s106" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#ffe9f2"/><stop offset=".5" stop-color="#ffd0e2"/><stop offset="1" stop-color="#f3bcd6"/></linearGradient><linearGradient id="w106" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#ffe6a8"/><stop offset="1" stop-color="#ffb26b"/></linearGradient><radialGradient id="g106" cx=".5" cy=".5" r=".5"><stop offset="0" stop-color="#fff6de" stop-opacity=".9"/><stop offset="1" stop-color="#ffd98a" stop-opacity="0"/></radialGradient><g id="bl106"><circle cx="0" cy="-7" r="6.2" fill="#ffb3cd"/><circle cx="7" cy="-2" r="6.2" fill="#ffb3cd"/><circle cx="4.5" cy="6" r="6.2" fill="#ffb3cd"/><circle cx="-4.5" cy="6" r="6.2" fill="#ffb3cd"/><circle cx="-7" cy="-2" r="6.2" fill="#ffb3cd"/><circle cx="0" cy="0" r="3.2" fill="#ffd98a"/></g></defs><rect width="300" height="400" fill="url(#s106)"/><circle cx="150" cy="150" r="110" fill="url(#g106)"/><g><path d="M-4 34 C56 52 118 36 178 60" stroke="#8a5568" stroke-width="7" fill="none" stroke-linecap="round"/><path d="M92 62 C118 74 140 72 168 82" stroke="#8a5568" stroke-width="5" fill="none" stroke-linecap="round"/><use href="#bl106" transform="translate(30 40)"/><use href="#bl106" transform="translate(66 52) scale(1.15)"/><use href="#bl106" transform="translate(104 44) scale(.9)"/><use href="#bl106" transform="translate(140 52)"/><use href="#bl106" transform="translate(176 66) scale(1.1)"/><use href="#bl106" transform="translate(120 82) scale(.8)"/></g><g><rect x="40" y="150" width="220" height="200" fill="#fff6fa"/><rect x="30" y="140" width="240" height="14" rx="4" fill="#e9c5d8"/><rect x="110" y="118" width="80" height="22" rx="8" fill="#fff"/><g transform="translate(150 129)"><path d="M-13 -6 h22 v10 h-18 q-4 0 -4 -4z" fill="#ff8fb1"/><path d="M13 -4 q7 0 7 -5 t-7 -5" stroke="#ff8fb1" stroke-width="2.5" fill="none"/><path d="M-6 -11 q3 -4 0 -7" stroke="#ffb3cd" stroke-width="2.5" fill="none" stroke-linecap="round"/><path d="M0 -11 q3 -4 0 -7" stroke="#ffb3cd" stroke-width="2.5" fill="none" stroke-linecap="round"/><path d="M6 -11 q3 -4 0 -7" stroke="#ffb3cd" stroke-width="2.5" fill="none" stroke-linecap="round"/></g><path d="M34 164 h232 v32 h-232z" fill="#ff8fb1"/><g fill="#ff8fb1"><circle cx="50" cy="196" r="11"/><circle cx="74" cy="196" r="11"/><circle cx="98" cy="196" r="11"/><circle cx="122" cy="196" r="11"/><circle cx="146" cy="196" r="11"/><circle cx="170" cy="196" r="11"/><circle cx="194" cy="196" r="11"/><circle cx="218" cy="196" r="11"/><circle cx="242" cy="196" r="11"/></g><g fill="#fff" opacity=".82"><rect x="60" y="164" width="16" height="32"/><rect x="120" y="164" width="16" height="32"/><rect x="180" y="164" width="16" height="32"/></g><rect x="56" y="214" width="150" height="96" rx="8" fill="url(#w106)"/><g fill="#a8622f" opacity=".45"><path d="M96 292 h46 l-5 -34 h-36z"/><path d="M142 260 q12 2 12 10 t-12 10" stroke="#a8622f" stroke-width="4" fill="none"/><rect x="88" y="296" width="62" height="6" rx="3"/><path d="M108 252 q-6 -8 0 -14 q6 6 0 14z"/><path d="M122 252 q-6 -8 0 -14 q6 6 0 14z"/></g><rect x="214" y="240" width="34" height="70" rx="5" fill="#b06ad0"/><circle cx="242" cy="276" r="3.4" fill="#ffd98a"/></g><path d="M0 340 C60 332 130 346 190 338 C240 332 272 342 300 336 L300 400 L0 400 Z" fill="#e5b9cf"/><path d="M0 366 C70 358 140 372 200 364 C248 358 274 368 300 362 L300 400 L0 400 Z" fill="#d79fbc"/><g fill="#ffb3cd"><ellipse cx="42" cy="250" rx="6" ry="4" transform="rotate(24 42 250)"/><ellipse cx="268" cy="282" rx="6" ry="4" transform="rotate(-30 268 282)"/><ellipse cx="82" cy="330" rx="7" ry="4.5" transform="rotate(16 82 330)"/><ellipse cx="228" cy="356" rx="6" ry="4" transform="rotate(-18 228 356)"/><ellipse cx="150" cy="382" rx="7" ry="4.5" transform="rotate(28 150 382)"/><ellipse cx="20" cy="386" rx="6" ry="4" transform="rotate(-12 20 386)"/></g></svg>', NULL, 'linear-gradient(135deg,#ff8fb1,#a78bfa)', '', 'native', NULL, NULL, 24, '已完结', 8.6, '桜动画', '日漫', '美食/治愈/群像', '转角那家咖啡店，每位客人都带着一段想被温柔接住的故事。');

INSERT INTO bangumi (id, title, cover_svg, cover_url, cover_gradient, src, source_type, vid, bvid, episodes, status, score, studio, category, tags, description) VALUES
(107, '机甲学徒守则', '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 300 400" width="300" height="400"><defs><linearGradient id="s107" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#5b3fa0"/><stop offset=".42" stop-color="#c96a9c"/><stop offset=".72" stop-color="#ff9f6b"/><stop offset="1" stop-color="#ffd98a"/></linearGradient><radialGradient id="g107" cx=".5" cy=".5" r=".5"><stop offset="0" stop-color="#fff6de"/><stop offset=".5" stop-color="#ffe0a0" stop-opacity=".7"/><stop offset="1" stop-color="#ffb26b" stop-opacity="0"/></radialGradient><linearGradient id="d107" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#2b1f4d"/><stop offset="1" stop-color="#150e26"/></linearGradient></defs><rect width="300" height="400" fill="url(#s107)"/><circle cx="150" cy="222" r="120" fill="url(#g107)"/><circle cx="150" cy="222" r="46" fill="#fff3d6" opacity=".95"/><g fill="#fff" opacity=".35"><ellipse cx="52" cy="76" rx="34" ry="12"/><ellipse cx="240" cy="104" rx="40" ry="13"/><ellipse cx="176" cy="62" rx="26" ry="10"/></g><g fill="#3a2a5c"><rect x="14" y="196" width="96" height="150"/><path d="M8 196 L62 168 L116 196 Z"/><rect x="196" y="210" width="92" height="136"/><path d="M190 210 L242 184 L294 210 Z"/></g><g fill="#ffd98a" opacity=".85"><rect x="30" y="222" width="16" height="22" rx="2"/><rect x="60" y="222" width="16" height="22" rx="2"/><rect x="30" y="262" width="16" height="22" rx="2"/><rect x="60" y="262" width="16" height="22" rx="2"/><rect x="214" y="236" width="16" height="22" rx="2"/><rect x="244" y="236" width="16" height="22" rx="2"/><rect x="214" y="276" width="16" height="22" rx="2"/></g><g stroke="#ffd98a" stroke-width="6" fill="none" stroke-dasharray="7 8" opacity=".8"><circle cx="46" cy="150" r="19"/><circle cx="256" cy="164" r="14"/></g><g stroke="#ffd98a" stroke-width="3" fill="none" opacity=".6"><circle cx="46" cy="150" r="8"/><circle cx="256" cy="164" r="6"/></g><g fill="#2b1f4d"><path d="M206 214 h52 l10 30 h-72z"/><rect x="106" y="276" width="26" height="70" rx="12"/><rect x="168" y="276" width="26" height="70" rx="12"/><path d="M96 292 h108 l12 34 h-132z"/><path d="M118 240 h64 l10 32 h-84z"/><rect x="108" y="264" width="84" height="34" rx="12"/></g><rect x="128" y="274" width="44" height="14" rx="7" fill="#7dd3fc"/><rect x="132" y="277" width="16" height="8" rx="4" fill="#fff" opacity=".65"/><path d="M150 240 v-26" stroke="#2b1f4d" stroke-width="4" stroke-linecap="round"/><circle cx="150" cy="208" r="5.5" fill="#ff5c7a"/><g fill="#3d2c69"><rect x="112" y="240" width="16" height="26" rx="6"/><rect x="172" y="240" width="16" height="26" rx="6"/></g><path d="M0 340 C60 332 130 346 190 338 C240 332 272 342 300 336 L300 400 L0 400 Z" fill="url(#d107)"/><g stroke="#ffd98a" stroke-width="3" stroke-linecap="round" opacity=".9"><path d="M196 300 l14 10"/><path d="M212 314 l10 8"/><path d="M96 296 l-14 10"/><path d="M82 310 l-10 8"/></g><g fill="#fff" opacity=".5"><circle cx="60" cy="368" r="1.6"/><circle cx="240" cy="358" r="1.8"/><circle cx="150" cy="384" r="1.4"/></g></svg>', NULL, 'linear-gradient(135deg,#c084fc,#7dd3fc)', '', 'native', NULL, NULL, 13, '连载中', 8.8, '青空制作', '国漫', '机甲/校园/热血', '入学第一天，她把全校最强的机甲拆成了零件标本。');

INSERT INTO bangumi (id, title, cover_svg, cover_url, cover_gradient, src, source_type, vid, bvid, episodes, status, score, studio, category, tags, description) VALUES
(108, '妖怪百物语·春', '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 300 400" width="300" height="400"><defs><linearGradient id="s108" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#101538"/><stop offset=".45" stop-color="#2e2158"/><stop offset=".8" stop-color="#54356e"/><stop offset="1" stop-color="#7c4a72"/></linearGradient><radialGradient id="g108" cx=".5" cy=".5" r=".5"><stop offset="0" stop-color="#fff8e2"/><stop offset=".5" stop-color="#ffe9b8" stop-opacity=".55"/><stop offset="1" stop-color="#ffd98a" stop-opacity="0"/></radialGradient><radialGradient id="o108" cx=".5" cy=".5" r=".5"><stop offset="0" stop-color="#bff3ff"/><stop offset="1" stop-color="#4ad6ff" stop-opacity="0"/></radialGradient><linearGradient id="d108" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#241a3c"/><stop offset="1" stop-color="#100b1e"/></linearGradient></defs><rect width="300" height="400" fill="url(#s108)"/><circle cx="238" cy="70" r="92" fill="url(#g108)"/><circle cx="238" cy="70" r="28" fill="#fff7e4"/><g fill="#fff" opacity=".55"><circle cx="34" cy="42" r="1.6"/><circle cx="78" cy="26" r="1.2"/><circle cx="120" cy="56" r="1.4"/><circle cx="26" cy="94" r="1.1"/><circle cx="176" cy="34" r="1.2"/><circle cx="60" cy="132" r="1.3"/><circle cx="272" cy="150" r="1.2"/><circle cx="284" cy="196" r="1.5"/></g><g fill="#ff5c7a"><rect x="52" y="138" width="196" height="15" rx="5"/><rect x="66" y="153" width="13" height="132" rx="3"/><rect x="221" y="153" width="13" height="132" rx="3"/><rect x="112" y="196" width="76" height="11" rx="4"/><rect x="60" y="176" width="180" height="10" rx="4"/></g><g fill="#ff8fb1" opacity=".55"><rect x="52" y="138" width="196" height="6" rx="3"/></g><g stroke="#7dd3fc" stroke-width="3" stroke-linecap="round" fill="none" opacity=".6"><path d="M8 30 q40 26 74 34"/><path d="M20 46 q-14 26 -10 48"/><path d="M44 40 q-6 30 -2 52"/><path d="M70 50 q2 28 10 46"/></g><g fill="#ffb3cd" opacity=".9"><circle cx="14" cy="66" r="3.4"/><circle cx="38" cy="92" r="3"/><circle cx="70" cy="98" r="3.4"/><circle cx="26" cy="112" r="2.6"/></g><g><circle cx="52" cy="330" r="30" fill="url(#o108)"/><path d="M52 306 q12 16 6 26 q-4 8 -10 8 q-6 0 -10 -8 q-6 -10 6 -26z" fill="#8ee7ff"/><circle cx="248" cy="344" r="24" fill="url(#o108)"/><path d="M248 326 q10 13 5 21 q-3 7 -8 7 q-5 0 -8 -7 q-5 -8 5 -21z" fill="#8ee7ff"/></g><g transform="translate(150 306)"><path d="M-16 -46 l-21 -31 l31 15z" fill="#fff8f2"/><path d="M16 -46 l21 -31 l-31 15z" fill="#fff8f2"/><path d="M0 -50 c-31 0 -47 20 -47 46 c0 25 14 45 31 55 c8 5 24 5 32 0 c17 -10 31 -30 31 -55 c0 -26 -16 -46 -47 -46z" fill="#fff8f2"/><path d="M-15 -44 l-12 -19 l18 10z" fill="#ff6f9c"/><path d="M15 -44 l12 -19 l-18 10z" fill="#ff6f9c"/><g stroke="#ff5c7a" stroke-width="6" fill="none" stroke-linecap="round"><path d="M-27 -10 q10 -13 21 0"/><path d="M6 -10 q10 -13 21 0"/></g><g fill="#ff5c7a"><rect x="-36" y="-32" width="17" height="5" rx="2.5"/><rect x="19" y="-32" width="17" height="5" rx="2.5"/></g><path d="M-7 13 q7 6 14 0" stroke="#ff5c7a" stroke-width="4" fill="none" stroke-linecap="round"/><circle cx="-25" cy="25" r="4.2" fill="#ff5c7a"/><circle cx="25" cy="25" r="4.2" fill="#ff5c7a"/></g><path d="M0 366 C70 358 140 372 200 364 C248 358 274 368 300 362 L300 400 L0 400 Z" fill="url(#d108)"/><g fill="#ffb3cd" opacity=".85"><ellipse cx="88" cy="256" rx="6" ry="4" transform="rotate(22 88 256)"/><ellipse cx="212" cy="230" rx="6" ry="4" transform="rotate(-26 212 230)"/><ellipse cx="126" cy="352" rx="6" ry="4" transform="rotate(14 126 352)"/><ellipse cx="180" cy="382" rx="6" ry="4" transform="rotate(-16 180 382)"/></g></svg>', NULL, 'linear-gradient(135deg,#ff6f9c,#a78bfa)', '', 'native', NULL, NULL, 11, '已完结', 9.1, '苍崎制作', '日漫', '妖怪/单元剧/和风', '春夜里，妖怪们排队来借一样人类弄丢的东西。');

INSERT INTO bangumi (id, title, cover_svg, cover_url, cover_gradient, src, source_type, vid, bvid, episodes, status, score, studio, category, tags, description) VALUES
(109, '星海航路·剧场版', '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 300 400" width="300" height="400"><defs><linearGradient id="s109" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#0b1038"/><stop offset=".42" stop-color="#2c2170"/><stop offset=".72" stop-color="#1d3f7a"/><stop offset="1" stop-color="#0a1030"/></linearGradient><radialGradient id="g109" cx=".5" cy=".5" r=".5"><stop offset="0" stop-color="#fff8e6"/><stop offset=".5" stop-color="#ffe9b8" stop-opacity=".6"/><stop offset="1" stop-color="#ffd98a" stop-opacity="0"/></radialGradient><radialGradient id="m109" cx=".35" cy=".3" r=".8"><stop offset="0" stop-color="#fffdf2"/><stop offset="1" stop-color="#d9c7ff"/></radialGradient></defs><rect width="300" height="400" fill="url(#s109)"/><g fill="#fff"><circle cx="30" cy="36" r="1.7"/><circle cx="74" cy="20" r="1.2" opacity=".7"/><circle cx="118" cy="48" r="1.5" opacity=".85"/><circle cx="162" cy="26" r="1.1" opacity=".6"/><circle cx="206" cy="44" r="1.6" opacity=".8"/><circle cx="250" cy="22" r="1.3" opacity=".7"/><circle cx="278" cy="66" r="1.8" opacity=".9"/><circle cx="48" cy="86" r="1.1" opacity=".5"/><circle cx="146" cy="98" r="1.2" opacity=".5"/><circle cx="234" cy="112" r="1.4" opacity=".55"/><circle cx="18" cy="140" r="1.3" opacity=".45"/><circle cx="288" cy="150" r="1.1" opacity=".4"/><circle cx="92" cy="172" r="1" opacity=".4"/><circle cx="196" cy="184" r="1.2" opacity=".45"/><circle cx="264" cy="196" r="1" opacity=".4"/><circle cx="36" cy="204" r="1.2" opacity=".4"/></g><circle cx="228" cy="92" r="76" fill="url(#g109)"/><circle cx="228" cy="92" r="42" fill="url(#m109)"/><g fill="#c9b3ff" opacity=".35"><circle cx="212" cy="76" r="9"/><circle cx="244" cy="104" r="6"/><circle cx="222" cy="112" r="5"/></g><path d="M0 262 C40 250 80 274 120 264 C160 254 200 278 240 266 C270 257 286 268 300 262 L300 400 L0 400 Z" fill="#141d55"/><g fill="#fff"><circle cx="40" cy="290" r="1.6" opacity=".9"/><circle cx="86" cy="310" r="1.3" opacity=".75"/><circle cx="132" cy="284" r="1.8" opacity=".85"/><circle cx="180" cy="308" r="1.4" opacity=".7"/><circle cx="228" cy="292" r="1.6" opacity=".8"/><circle cx="266" cy="316" r="1.2" opacity=".65"/><circle cx="64" cy="342" r="1.5" opacity=".7"/><circle cx="152" cy="352" r="1.7" opacity=".75"/><circle cx="248" cy="360" r="1.4" opacity=".6"/><circle cx="20" cy="322" r="1.2" opacity=".6"/><circle cx="200" cy="376" r="1.3" opacity=".55"/><circle cx="104" cy="386" r="1.5" opacity=".6"/></g><path d="M0 300 C50 288 90 312 140 300 C190 288 240 310 300 296 L300 400 L0 400 Z" fill="#0b1136" opacity=".85"/><g fill="#e8e0ff" opacity=".9"><path d="M158 218 Q196 250 158 284 Z"/><path d="M150 222 Q116 252 150 282 Z"/></g><path d="M154 210 v78" stroke="#1a1338" stroke-width="5" stroke-linecap="round"/><path d="M104 286 h100 l-16 28 h-68z" fill="#1a1338"/><path d="M104 286 h100 v6 h-100z" fill="#ff8fb1"/><circle cx="154" cy="204" r="4.5" fill="#ffd98a"/><g transform="translate(238 214) rotate(-12)"><rect x="-26" y="-17" width="52" height="34" rx="4" fill="#fff8ee"/><path d="M-26 -17 L0 2 L26 -17" stroke="#c084fc" stroke-width="3" fill="none"/><circle cx="0" cy="2" r="4.4" fill="#ff8fb1"/></g><circle cx="238" cy="214" r="44" fill="none" stroke="#ffd98a" stroke-width="2" opacity=".35"/><g stroke="#fff" stroke-width="2" opacity=".3" stroke-linecap="round" fill="none"><path d="M120 296 h68"/><path d="M132 314 h44"/><path d="M142 332 h24"/></g></svg>', NULL, 'linear-gradient(135deg,#7dd3fc,#ff8fb1)', '', 'native', NULL, NULL, 1, '已完结', 9.3, '棱镜动画', '剧场', '剧场版/科幻/冒险', '一封信，一片海，和一场跨越十二年的告别。');

INSERT INTO bangumi (id, title, cover_svg, cover_url, cover_gradient, src, source_type, vid, bvid, episodes, status, score, studio, category, tags, description) VALUES
(110, '樱之纪念日·剧场版', '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 300 400" width="300" height="400"><defs><linearGradient id="s110" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#fff2f8"/><stop offset=".42" stop-color="#ffd9ea"/><stop offset=".78" stop-color="#ffc0d8"/><stop offset="1" stop-color="#f0a6c6"/></linearGradient><radialGradient id="g110" cx=".5" cy=".5" r=".5"><stop offset="0" stop-color="#fffbe8"/><stop offset=".5" stop-color="#ffe9a8" stop-opacity=".55"/><stop offset="1" stop-color="#ffd98a" stop-opacity="0"/></radialGradient><linearGradient id="d110" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#e9bcd4"/><stop offset="1" stop-color="#d49bbc"/></linearGradient><g id="bl110"><circle cx="0" cy="-6.5" r="5.8" fill="#ff9dc0"/><circle cx="6.5" cy="-2" r="5.8" fill="#ff9dc0"/><circle cx="4" cy="5.5" r="5.8" fill="#ff9dc0"/><circle cx="-4" cy="5.5" r="5.8" fill="#ff9dc0"/><circle cx="-6.5" cy="-2" r="5.8" fill="#ff9dc0"/><circle cx="0" cy="0" r="3" fill="#ffe0ec"/></g></defs><rect width="300" height="400" fill="url(#s110)"/><circle cx="240" cy="66" r="104" fill="url(#g110)"/><circle cx="240" cy="66" r="34" fill="#fff8e0"/><g fill="#fff" opacity=".55"><ellipse cx="72" cy="88" rx="36" ry="13"/><ellipse cx="188" cy="132" rx="30" ry="11"/><ellipse cx="256" cy="168" rx="26" ry="10"/></g><g><path d="M96 340 C92 296 88 268 96 240 l28 -4 C116 274 116 306 122 340z" fill="#8a5568"/><path d="M96 268 C74 254 58 240 46 222" stroke="#8a5568" stroke-width="9" fill="none" stroke-linecap="round"/><path d="M118 258 C140 246 154 232 168 216" stroke="#8a5568" stroke-width="9" fill="none" stroke-linecap="round"/><path d="M104 232 C86 214 78 198 76 178" stroke="#8a5568" stroke-width="7" fill="none" stroke-linecap="round"/></g><g><circle cx="48" cy="164" r="42" fill="#ffb3cd"/><circle cx="96" cy="132" r="52" fill="#ffa8c6"/><circle cx="146" cy="152" r="44" fill="#ffb3cd"/><circle cx="66" cy="200" r="40" fill="#ff9dc0"/><circle cx="126" cy="196" r="38" fill="#ffb3cd"/><circle cx="176" cy="182" r="32" fill="#ffa8c6"/><circle cx="196" cy="150" r="26" fill="#ffc0d8"/><circle cx="104" cy="168" r="46" fill="#ffc0d8" opacity=".6"/></g><g><use href="#bl110" transform="translate(60 140)"/><use href="#bl110" transform="translate(118 118) scale(1.1)"/><use href="#bl110" transform="translate(158 168)"/><use href="#bl110" transform="translate(86 196) scale(.9)"/><use href="#bl110" transform="translate(140 208)"/><use href="#bl110" transform="translate(188 156) scale(.85)"/><use href="#bl110" transform="translate(30 186) scale(.8)"/></g><path d="M0 334 C70 326 140 340 200 332 C248 326 274 336 300 330 L300 400 L0 400 Z" fill="url(#d110)"/><g fill="#7a4a63"><rect x="150" y="316" width="118" height="9" rx="4"/><rect x="150" y="332" width="118" height="9" rx="4"/><rect x="158" y="341" width="9" height="26" rx="4"/><rect x="252" y="341" width="9" height="26" rx="4"/></g><g fill="#4b2f6e"><circle cx="180" cy="278" r="14"/><path d="M180 292 c-11 0 -18 9 -19 22 l-3 22 h44 l-3 -22 c-1 -13 -8 -22 -19 -22z"/><path d="M164 288 c-3 -14 5 -22 16 -22 c11 0 19 8 16 22z"/></g><g fill="#6d4a9c"><circle cx="240" cy="282" r="13"/><path d="M240 295 c-10 0 -16 8 -17 20 l-3 20 h40 l-3 -20 c-1 -12 -7 -20 -17 -20z"/><path d="M226 291 c-3 -13 4 -20 14 -20 c10 0 17 7 14 20z"/></g><g><ellipse cx="44" cy="240" rx="7" ry="4.6" fill="#ff9dc0" transform="rotate(24 44 240)"/><ellipse cx="218" cy="248" rx="7" ry="4.6" fill="#ff9dc0" transform="rotate(-28 218 248)"/><ellipse cx="96" cy="286" rx="7.5" ry="5" fill="#ffb3cd" transform="rotate(16 96 286)"/><ellipse cx="272" cy="300" rx="7" ry="4.6" fill="#ff9dc0" transform="rotate(-20 272 300)"/><ellipse cx="140" cy="330" rx="7" ry="4.6" fill="#ffb3cd" transform="rotate(30 140 330)"/><ellipse cx="24" cy="352" rx="7.5" ry="5" fill="#ff9dc0" transform="rotate(-14 24 352)"/><ellipse cx="196" cy="366" rx="7" ry="4.6" fill="#ffb3cd" transform="rotate(22 196 366)"/><ellipse cx="264" cy="386" rx="7.5" ry="5" fill="#ff9dc0" transform="rotate(-24 264 386)"/></g></svg>', NULL, 'linear-gradient(135deg,#ff8fb1,#c084fc)', '', 'native', NULL, NULL, 1, '已完结', 9.0, '桜动画', '剧场', '剧场版/恋爱/催泪', '樱花落下的速度，刚好是我想起你的速度。');

INSERT INTO bangumi (id, title, cover_svg, cover_url, cover_gradient, src, source_type, vid, bvid, episodes, status, score, studio, category, tags, description) VALUES
(111, '赛博小吃街', '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 300 400" width="300" height="400"><defs><linearGradient id="s111" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#0d1130"/><stop offset=".5" stop-color="#241a4a"/><stop offset="1" stop-color="#3a2159"/></linearGradient><radialGradient id="b111" cx=".5" cy=".5" r=".5"><stop offset="0" stop-color="#ffd98a" stop-opacity=".85"/><stop offset="1" stop-color="#ffd98a" stop-opacity="0"/></radialGradient><linearGradient id="d111" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#1a1236"/><stop offset="1" stop-color="#0c0820"/></linearGradient><linearGradient id="n111" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#ff8fb1"/><stop offset="1" stop-color="#ff5c7a"/></linearGradient></defs><rect width="300" height="400" fill="url(#s111)"/><g fill="#1e1740"><rect x="-4" y="60" width="86" height="290"/><rect x="218" y="80" width="86" height="270"/><rect x="86" y="120" width="60" height="230"/><rect x="154" y="140" width="64" height="210"/></g><g fill="#ffd98a" opacity=".7"><rect x="14" y="96" width="12" height="16" rx="2"/><rect x="42" y="96" width="12" height="16" rx="2"/><rect x="14" y="134" width="12" height="16" rx="2"/><rect x="42" y="152" width="12" height="16" rx="2"/><rect x="14" y="188" width="12" height="16" rx="2"/><rect x="42" y="206" width="12" height="16" rx="2"/><rect x="232" y="112" width="12" height="16" rx="2"/><rect x="262" y="112" width="12" height="16" rx="2"/><rect x="232" y="158" width="12" height="16" rx="2"/><rect x="262" y="176" width="12" height="16" rx="2"/><rect x="232" y="212" width="12" height="16" rx="2"/><rect x="262" y="230" width="12" height="16" rx="2"/><rect x="98" y="164" width="12" height="16" rx="2"/><rect x="98" y="212" width="12" height="16" rx="2"/><rect x="170" y="184" width="12" height="16" rx="2"/><rect x="196" y="184" width="12" height="16" rx="2"/></g><g><rect x="14" y="72" width="20" height="118" rx="6" fill="none" stroke="#ff5c7a" stroke-width="4" opacity=".35"/><rect x="16" y="74" width="16" height="114" rx="5" fill="#ff5c7a"/><g fill="#2a1030"><rect x="21" y="84" width="6" height="6" rx="1"/><rect x="21" y="98" width="6" height="6" rx="1"/><rect x="21" y="112" width="6" height="6" rx="1"/><rect x="21" y="126" width="6" height="6" rx="1"/><rect x="21" y="140" width="6" height="6" rx="1"/><rect x="21" y="154" width="6" height="6" rx="1"/></g></g><g><rect x="262" y="92" width="20" height="104" rx="6" fill="none" stroke="#7dd3fc" stroke-width="4" opacity=".35"/><rect x="264" y="94" width="16" height="100" rx="5" fill="#7dd3fc"/><g fill="#0e2038"><rect x="269" y="104" width="6" height="16" rx="2"/><rect x="269" y="128" width="6" height="16" rx="2"/><rect x="269" y="152" width="6" height="16" rx="2"/></g></g><g><rect x="122" y="150" width="18" height="76" rx="6" fill="none" stroke="#ffd98a" stroke-width="4" opacity=".35"/><rect x="124" y="152" width="14" height="72" rx="5" fill="#ffd98a"/><g fill="#3a2a10"><rect x="129" y="162" width="4" height="14" rx="2"/><rect x="129" y="184" width="4" height="14" rx="2"/><rect x="129" y="206" width="4" height="6" rx="2"/></g></g><g><path d="M60 118 h180 v6 h-180z" fill="#3a2a5c"/><g><path d="M78 124 v-16" stroke="#3a2a5c" stroke-width="3"/><ellipse cx="78" cy="132" rx="14" ry="16" fill="#ff5c7a"/><rect x="72" y="112" width="12" height="6" rx="2" fill="#ffd98a"/><rect x="72" y="146" width="12" height="6" rx="2" fill="#ffd98a"/></g><g><path d="M150 124 v-16" stroke="#3a2a5c" stroke-width="3"/><ellipse cx="150" cy="132" rx="14" ry="16" fill="#ff5c7a"/><rect x="144" y="112" width="12" height="6" rx="2" fill="#ffd98a"/><rect x="144" y="146" width="12" height="6" rx="2" fill="#ffd98a"/></g><g><path d="M222 124 v-16" stroke="#3a2a5c" stroke-width="3"/><ellipse cx="222" cy="132" rx="14" ry="16" fill="#ff5c7a"/><rect x="216" y="112" width="12" height="6" rx="2" fill="#ffd98a"/><rect x="216" y="146" width="12" height="6" rx="2" fill="#ffd98a"/></g></g><g stroke="#fff" stroke-width="3" fill="none" opacity=".45" stroke-linecap="round"><path d="M112 236 q-10 -16 2 -28 q10 -10 0 -22"/><path d="M150 228 q-10 -18 2 -32 q10 -10 0 -22"/><path d="M188 236 q-10 -16 2 -28 q10 -10 0 -22"/></g><g><path d="M70 292 h160 q-10 74 -80 74 q-70 0 -80 -74z" fill="url(#n111)"/><rect x="62" y="278" width="176" height="18" rx="9" fill="#ffb3cd"/><g stroke="#fff3d6" stroke-width="4" fill="none" stroke-linecap="round"><path d="M96 280 q10 -18 22 -2 q10 14 20 -4 q10 -16 22 2"/><path d="M104 268 q12 -14 22 0 q10 12 20 -2"/></g><g stroke="#ffd98a" stroke-width="5" stroke-linecap="round"><path d="M186 244 L128 292"/><path d="M196 236 L136 290"/></g><g fill="#ffd98a"><ellipse cx="150" cy="256" rx="16" ry="8" transform="rotate(-18 150 256)"/></g><circle cx="150" cy="330" r="6" fill="#fff" opacity=".35"/></g><path d="M0 356 C70 348 140 362 200 354 C248 348 274 358 300 352 L300 400 L0 400 Z" fill="url(#d111)"/><g opacity=".28"><rect x="0" y="372" width="300" height="6" fill="#ff5c7a"/><rect x="0" y="386" width="300" height="4" fill="#7dd3fc"/></g></svg>', NULL, 'linear-gradient(135deg,#c084fc,#ff8fb1)', '', 'native', NULL, NULL, 16, '连载中', 8.5, '青空制作', '国漫', '美食/科幻/单元剧', '霓虹灯下的深夜食堂，每碗面都藏着一段心事。');

INSERT INTO bangumi (id, title, cover_svg, cover_url, cover_gradient, src, source_type, vid, bvid, episodes, status, score, studio, category, tags, description) VALUES
(112, '星际巡逻队', '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 300 400" width="300" height="400"><defs><linearGradient id="s112" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#0a1032"/><stop offset=".45" stop-color="#241c60"/><stop offset=".8" stop-color="#1c3c78"/><stop offset="1" stop-color="#0a1030"/></linearGradient><radialGradient id="p112" cx=".35" cy=".3" r=".85"><stop offset="0" stop-color="#ffd98a"/><stop offset=".55" stop-color="#e08a6b"/><stop offset="1" stop-color="#7c4a9c"/></radialGradient><radialGradient id="f112" cx=".5" cy=".5" r=".5"><stop offset="0" stop-color="#fff" stop-opacity=".8"/><stop offset="1" stop-color="#fff" stop-opacity="0"/></radialGradient></defs><rect width="300" height="400" fill="url(#s112)"/><g fill="#fff"><circle cx="26" cy="32" r="1.7"/><circle cx="70" cy="18" r="1.2" opacity=".7"/><circle cx="112" cy="46" r="1.5" opacity=".85"/><circle cx="156" cy="24" r="1.1" opacity=".6"/><circle cx="198" cy="42" r="1.6" opacity=".8"/><circle cx="242" cy="20" r="1.3" opacity=".7"/><circle cx="272" cy="62" r="1.8" opacity=".9"/><circle cx="44" cy="82" r="1.1" opacity=".5"/><circle cx="140" cy="94" r="1.2" opacity=".5"/><circle cx="228" cy="108" r="1.4" opacity=".55"/><circle cx="16" cy="128" r="1.3" opacity=".45"/><circle cx="286" cy="142" r="1.1" opacity=".4"/><circle cx="88" cy="162" r="1" opacity=".4"/><circle cx="62" cy="196" r="1.2" opacity=".4"/></g><circle cx="150" cy="120" r="70" fill="url(#f112)" opacity=".35"/><g><ellipse cx="236" cy="336" rx="118" ry="28" fill="none" stroke="#e6dbff" stroke-width="5" opacity=".55"/><circle cx="236" cy="336" r="72" fill="url(#p112)"/><path d="M186 310 q50 18 100 -2" stroke="#fff" stroke-width="3" fill="none" opacity=".25"/><path d="M182 352 q54 20 108 -6" stroke="#fff" stroke-width="3" fill="none" opacity=".18"/><ellipse cx="236" cy="336" rx="118" ry="28" fill="none" stroke="#fff6de" stroke-width="5" opacity=".85"/></g><g transform="translate(96 158) rotate(-12)"><ellipse cx="0" cy="0" rx="56" ry="21" fill="#efe9ff"/><ellipse cx="-6" cy="-8" rx="40" ry="10" fill="#fff" opacity=".5"/><path d="M-56 0 l-18 -19 l6 19 l-6 19z" fill="#ff8fb1"/><path d="M-12 -19 q26 -24 50 -8 l6 13 q-30 -10 -56 6z" fill="#7dd3fc"/><circle cx="26" cy="-2" r="13" fill="#7dd3fc"/><circle cx="26" cy="-2" r="9" fill="#fff" opacity=".75"/><circle cx="22" cy="-2" r="4.4" fill="#2b1f4d"/><rect x="-30" y="18" width="26" height="6" rx="3" fill="#c084fc"/></g><circle cx="46" cy="176" r="6" fill="#ff5c7a"/><circle cx="46" cy="176" r="13" fill="none" stroke="#ff5c7a" stroke-width="2" opacity=".45"/><g><path d="M226 96 l-56 -34" stroke="#fff" stroke-width="3" stroke-linecap="round" opacity=".45"/><circle cx="228" cy="98" r="7" fill="#fff"/><circle cx="228" cy="98" r="4" fill="#cfe0ff"/></g><g transform="translate(238 66) rotate(18)"><circle cx="0" cy="0" r="17" fill="#6d4a9c"/><circle cx="0" cy="0" r="6.5" fill="#0f1436"/><circle cx="-6" cy="-6" r="3" fill="#a78bfa" opacity=".7"/></g><g transform="translate(58 262) rotate(-14)"><circle cx="0" cy="0" r="19" fill="#c084fc"/><circle cx="0" cy="0" r="7" fill="#0f1436"/><circle cx="6" cy="-7" r="3" fill="#e6dbff" opacity=".6"/></g><g stroke="#7dd3fc" stroke-width="2.5" fill="none" opacity=".5" stroke-linecap="round"><path d="M28 330 q16 -12 32 0"/><path d="M18 346 q26 -20 52 0"/></g><circle cx="150" cy="380" r="1.6" fill="#fff" opacity=".5"/><circle cx="46" cy="386" r="1.4" fill="#fff" opacity=".45"/></svg>', NULL, 'linear-gradient(135deg,#a78bfa,#7dd3fc)', '', 'native', NULL, NULL, 20, '连载中', 8.3, '棱镜动画', '美漫', '科幻/搞笑/冒险', '宇宙边界的巡逻小队，今天的任务依然是——摸鱼失败。');

-- =========================================================
-- 番剧放送时间表 + 种子数据
-- 说明：
--   1. weekday 用 1~7 表示周一~周日（与 Java DayOfWeek 对齐）。
--   2. 与 bangumi 表用 bangumi_id 关联（不建外键，方便单独清数据）。
--   3. 首页"番剧时间表"侧栏读取此表，返回结构：
--      { weekdays, today, items: { 周一: [{ title, ep, time }] } }
-- =========================================================

CREATE TABLE IF NOT EXISTS bangumi_schedule (
    id          BIGINT      NOT NULL AUTO_INCREMENT COMMENT '主键',
    bangumi_id  BIGINT      NOT NULL                COMMENT '番剧 id，逻辑关联 bangumi.id',
    weekday     TINYINT     NOT NULL                COMMENT '放送日：1=周一 … 7=周日',
    air_time    VARCHAR(8)  NOT NULL                COMMENT '放送时间 HH:mm',
    episode     INT         NOT NULL DEFAULT 1      COMMENT '当日更新至第几话',
    create_time DATETIME    NOT NULL DEFAULT CURRENT_TIMESTAMP                COMMENT '创建时间',
    update_time DATETIME    NOT NULL DEFAULT CURRENT_TIMESTAMP
                            ON UPDATE CURRENT_TIMESTAMP                       COMMENT '更新时间',
    PRIMARY KEY (id),
    UNIQUE KEY uk_bangumi_weekday (bangumi_id, weekday),
    KEY idx_weekday (weekday)
) ENGINE = InnoDB
  DEFAULT CHARSET = utf8mb4
  COMMENT = '番剧放送时间表';

-- 种子数据（重复执行会先清空再插入）
DELETE FROM bangumi_schedule;

INSERT INTO bangumi_schedule (bangumi_id, weekday, air_time, episode) VALUES
(101, 1, '20:00', 8),    -- 星屑列车开往黎明 · 周一
(104, 1, '22:30', 6),    -- 便利屋猫咪日记 · 周一
(102, 2, '19:30', 19),   -- 赛马娘芦毛灰姑娘 · 周二
(105, 2, '21:00', 5),    -- 深空抒情诗 · 周二
(103, 3, '20:30', 7),    -- 晚晴剑歌 · 周三
(107, 3, '23:00', 4),    -- 机甲学徒守则 · 周三
(106, 4, '20:00', 14),   -- 樱色咖啡店物语 · 周四
(108, 4, '22:00', 9),    -- 妖怪百物语·春 · 周四
(101, 5, '20:00', 9),    -- 星屑列车开往黎明 · 周五
(105, 5, '21:00', 6),    -- 深空抒情诗 · 周五
(102, 6, '18:00', 20),   -- 赛马娘芦毛灰姑娘 · 周六
(103, 6, '20:30', 8),    -- 晚晴剑歌 · 周六
(107, 6, '23:00', 5),    -- 机甲学徒守则 · 周六
(106, 7, '19:00', 15),   -- 樱色咖啡店物语 · 周日
(108, 7, '21:30', 10);   -- 妖怪百物语·春 · 周日


-- =========================================================
-- 番剧分集播放源表 + 种子数据（首页 / 番剧页 选集面板数据源）
-- 说明：
--   1. 一部番剧的多个正片分集各自对应 B 站上的一个视频，
--      单个 bvid 字段放不下，这里独立建表按集存储播放源。
--   2. 每集记录 bvid + cid，服务端据此拼装官方 iframe 播放器地址。
--   3. vip 标记：该集是否为大会员专享（B 站番剧 badge = '会员'）。
--      免费集（vip = 0）免登录即可播放；会员集需登录 B 站大会员账号。
-- =========================================================

CREATE TABLE IF NOT EXISTS bangumi_episode (
    id          BIGINT       NOT NULL AUTO_INCREMENT COMMENT '主键',
    bangumi_id  BIGINT       NOT NULL                COMMENT '所属番剧 id',
    ep_no       INT          NOT NULL                COMMENT '集号，从 1 开始',
    ep_title    VARCHAR(64)  DEFAULT ''              COMMENT '本集标题',
    bvid        VARCHAR(64)  NOT NULL                COMMENT '哔哩哔哩 BV 号',
    cid         VARCHAR(32)  DEFAULT NULL            COMMENT '哔哩哔哩 cid',
    duration    INT          DEFAULT 0               COMMENT '时长（毫秒）',
    vip         TINYINT      NOT NULL DEFAULT 0      COMMENT '是否大会员专享：1 是，0 否',
    create_time DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    update_time DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP
                            ON UPDATE CURRENT_TIMESTAMP          COMMENT '更新时间',
    PRIMARY KEY (id),
    UNIQUE KEY uk_bangumi_ep (bangumi_id, ep_no),
    KEY idx_bangumi (bangumi_id)
) ENGINE = InnoDB
  DEFAULT CHARSET = utf8mb4
  COMMENT = '番剧分集播放源表';

-- 种子数据（重复执行会先清空再插入）
DELETE FROM bangumi_episode;

-- 《赛马娘芦毛灰姑娘》（B 站番剧 season_id=91812 / md25581526）23 集正片
-- 第 1 集免登录可播，其余 22 集为大会员专享。
INSERT INTO bangumi_episode (bangumi_id, ep_no, ep_title, bvid, cid, duration, vip) VALUES
(102, 1, '横空出世', 'BV145G1z9E71', '29719990069', 1427000, 0),
(102, 2, '让我出赛吧', 'BV1TVG1zsEhh', '29719989807', 1427000, 1),
(102, 3, '顶峰的景色', 'BV1zkV2z7Egk', '31271489307', 1425966, 1),
(102, 4, '初级皇冠赛', 'BV1fkV2z7ECr', '29816129421', 1427000, 1),
(102, 5, '最好的选择', 'BV1y4jJzWEzB', '30103899380', 1421000, 1),
(102, 6, '怪物', 'BV1To7GzyEdR', '30211903081', 1427000, 1),
(102, 7, '特雷森学园', 'BV1tpTTzKEPr', '31069045039', 1425966, 1),
(102, 8, '正确的资质', 'BV1CWMuzTE5f', '30474702196', 1426000, 1),
(102, 9, '日本德比', 'BV1qPKczcEr1', '31271489354', 1425924, 1),
(102, 10, '最强', 'BV1rKKEzXEdJ', '30683955894', 1427000, 1),
(102, 11, '笠松的明星', 'BV1nv3uz6ELE', '30829511375', 1426000, 1),
(102, 12, '天皇赏（秋）', 'BV1du31zPEMD', '30899177537', 1427000, 1),
(102, 13, '日本第一', 'BV1ztuizGEmR', '31028217668', 1366000, 1),
(102, 14, '新的山峰', 'BV1Gt2MBFERH', '33787675312', 1427000, 1),
(102, 15, '我们的故事', 'BV1qJ2MBvEw4', '33787675474', 1426000, 1),
(102, 16, '世界级', 'BV1GTCeBZE1r', '34057552637', 1427000, 1),
(102, 17, '日本杯', 'BV12nUgBbE4d', '34219756747', 1427000, 1),
(102, 18, '狂野滑稽表演者', 'BV1wqSCBDEzM', '34417084110', 1427000, 1),
(102, 19, '未知的「领域」', 'BV1Ct2aBjEDm', '34496056358', 1427000, 1),
(102, 20, '答案', 'BV11dmCBDEgX', '34747780858', 1426000, 1),
(102, 21, '有马纪念', 'BV1T2BSBUE9R', '34969421621', 1427000, 1),
(102, 22, '灰发怪物', 'BV14XvHBFEi8', '35052390780', 1426000, 1),
(102, 23, '新时代', 'BV1arvHBqEW2', '35054029983', 1412000, 1);


-- =========================================================
-- 视频表 + 每日推荐种子数据（首页热门推荐 / 每日推荐 数据源）
-- 说明：id 与前端 mock 数据保持一致（1~8），切换真实后端时前端页面无需任何改动。
-- =========================================================

CREATE TABLE IF NOT EXISTS video (
    id              BIGINT       NOT NULL AUTO_INCREMENT COMMENT '主键',
    title           VARCHAR(200) NOT NULL                COMMENT '标题',
    uploader        VARCHAR(64)  DEFAULT ''              COMMENT 'UP 主 / 投稿方',
    views           VARCHAR(32)  DEFAULT ''              COMMENT '播放量展示文案（如 128.5万）',
    play            BIGINT       DEFAULT 0               COMMENT '真实播放量（用于排行排序）',
    danmaku         VARCHAR(32)  DEFAULT ''              COMMENT '弹幕数展示文案（如 3.2万）',
    duration        VARCHAR(16)  DEFAULT ''              COMMENT '时长（如 04:12）',
    tags            VARCHAR(128) DEFAULT ''              COMMENT '标签，逗号分隔',
    description     VARCHAR(500) DEFAULT ''              COMMENT '简介',
    fav             TINYINT      NOT NULL DEFAULT 0      COMMENT '是否收藏：1 收藏，0 否',
    grad            VARCHAR(128) DEFAULT ''              COMMENT '封面渐变 CSS（如 linear-gradient(...)）',
    cover_url       VARCHAR(255) DEFAULT NULL            COMMENT '封面图 URL（有值时优先于 grad 展示）',
    src             VARCHAR(255) DEFAULT ''              COMMENT '播放地址',
    source_type     VARCHAR(16)  NOT NULL DEFAULT 'native' COMMENT '播放源类型：native 原生直链 / tencent 腾讯视频 / bilibili 哔哩哔哩 / omofun 动漫共和国',
    vid             VARCHAR(64)  DEFAULT NULL            COMMENT '腾讯视频 VID（source_type=tencent 时有效）',
    bvid            VARCHAR(64)  DEFAULT NULL            COMMENT '哔哩哔哩 BV 号（source_type=bilibili 时有效）',
    omofun_id       VARCHAR(32)  DEFAULT NULL            COMMENT '动漫共和国作品 id（source_type=omofun 时有效）',
    daily_pick      TINYINT      NOT NULL DEFAULT 1      COMMENT '是否每日推荐：1 推荐，0 否',
    recommend_date  DATE         DEFAULT NULL            COMMENT '推荐日期（每日推荐轮换用）',
    create_time     DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP                COMMENT '创建时间',
    update_time     DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP
                                ON UPDATE CURRENT_TIMESTAMP                       COMMENT '更新时间',
    PRIMARY KEY (id)
) ENGINE = InnoDB
  DEFAULT CHARSET = utf8mb4
  COMMENT = '视频表';

-- 种子数据（重复执行会先清空再插入，方便后续更新）
DELETE FROM video;

INSERT INTO video (title, uploader, views, play, danmaku, duration, tags, description, fav, grad, cover_url, src, source_type, vid, bvid, omofun_id, daily_pick) VALUES
('《总之就是非常可爱》', '动漫共和国', '2.2亿', 220000000, '306.4万', '23:41', '恋爱,日常,漫画改,甜,校园', '由崎星空对神秘美少女——司一见钟情。面对星空决死的告白，她的回答是「如果你愿意和我结婚，那我就跟你交往」？！充满了星空与司的爱，可爱&高贵的新婚生活开始了！全 12 话正片。', 1, 'linear-gradient(135deg,#7dd3fc,#ff8fb1)', '/tonikawa.webp', 'https://www.omofun23.com/index.php/vod/play/id/43835/sid/1/nid/1.html', 'omofun', NULL, NULL, '43835', 1),
('纸片人女友的一天 · 原创短篇动画', '星屑工坊', '56.1万', 561000, '8742', '08:47', '原创,日常,甜', '从清晨的第一缕光到深夜的台灯，她把平凡的日子过成了童话。', 0, 'linear-gradient(135deg,#7dd3fc,#a78bfa)', NULL, 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4', 'native', NULL, NULL, NULL, 1),
('雨夜便利店 · 慢节奏 ASMR 白噪音', '夜猫电台', '23.9万', 239000, '1920', '30:00', 'ASMR,助眠,雨声', '关东煮的热气、窗外的雨、以及永远为你亮着的那盏灯。', 1, 'linear-gradient(135deg,#c084fc,#7dd3fc)', NULL, 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4', 'native', NULL, NULL, NULL, 0),
('超时空辉夜姬', '多叻嘿嘿', '1.9万', 19548, '13', '02:21:23', '同人,战斗,燃', '为了夺回被夺走的星光，少女拔出了沉睡千年的剑。', 0, 'linear-gradient(135deg,#ff6f9c,#c084fc)', '/kaguya.webp', 'https://player.bilibili.com/player.html?bvid=BV1Lk8C6bE3z&p=3&autoplay=0&high_quality=1&danmaku=0', 'bilibili', NULL, 'BV1Lk8C6bE3z?p=3', NULL, 1),
('猫咪咖啡馆营业中 · 治愈 vlog', '软糖日记', '78.4万', 784000, '4531', '12:33', 'vlog,猫,治愈', '三只店长猫，一杯手冲，和刚好路过的你。', 0, 'linear-gradient(135deg,#ffd98a,#ff8fb1)', NULL, 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4', 'native', NULL, NULL, NULL, 0),
('赛马娘芦毛灰姑娘', '哔哩哔哩番剧', '466.7万', 4667408, '1.1万', '23:47', '赛马娘,热血,运动,原创动画', '《周刊YOUNG JUMP》销量破 800 万的漫画终于动画化。地方出身的怪物小栗帽，迎战人称「最强」的玉藻十字。灰扑扑的少女，踏入全新的领域——驰骋火热梦想的灰姑娘故事，继续奔跑。', 1, 'linear-gradient(135deg,#a78bfa,#7dd3fc)', '/umamusume.webp', 'https://player.bilibili.com/player.html?bvid=BV145G1z9E71&p=1&autoplay=0&high_quality=1&danmaku=0', 'bilibili', NULL, 'BV145G1z9E71', NULL, 1),
('深夜画室 · 厚涂立绘绘制过程', '小满Official', '45.2万', 452000, '3201', '21:08', '绘画,教程,厚涂', '从线稿到高光，一笔一画把纸片人养成会呼吸的少女。', 0, 'linear-gradient(135deg,#ff8fb1,#a78bfa)', NULL, 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4', 'native', NULL, NULL, NULL, 0),
('赛马娘第二季', '哔哩哔哩番剧', '7075.4万', 70754000, '47.1万', '23:56', '赛马娘,热血,运动,偶像,催泪', '憧憬着皇帝，向不败的三连冠冲刺的马娘东海帝皇，以及背负着名家的荣耀，向天皇赏连霸发起挑战的目白麦昆。二人既是对手，也是伙伴，一同向着梦想——「闪光系列赛」的优胜，全力奔跑！', 1, 'linear-gradient(135deg,#a78bfa,#7dd3fc)', '/umamusume-s2.webp', 'https://player.bilibili.com/player.html?bvid=BV1Yv411x7n5&p=1&autoplay=0&high_quality=1&danmaku=0', 'bilibili', NULL, 'BV1Yv411x7n5', NULL, 1);

-- =========================================================
-- 视频分集播放源表
-- 说明：
--   1. 一条 video 记录也可能对应一部番剧的多个正片分集
--      （如《赛马娘 第二季》13 话），单个 bvid 字段放不下，
--      这里独立建表按集存储播放源，结构与 bangumi_episode 一致。
--   2. 每集记录播放源：
--        - B 站源（bvid + cid）：服务端拼装官方 iframe 播放器地址
--          https://player.bilibili.com/player.html?bvid={bvid}&p=1&autoplay=0&high_quality=1&danmaku=0
--        - 动漫共和国源（m3u8_url）：前端用 hls.js 直连播放，支持清晰度分级切换
--   3. vip 标记：该集是否为大会员专享（B 站番剧 badge = '会员'）。
--      免费集（vip = 0）免登录即可播放；会员集需登录 B 站大会员账号。
-- =========================================================

CREATE TABLE IF NOT EXISTS video_episode (
    id          BIGINT       NOT NULL AUTO_INCREMENT COMMENT '主键',
    video_id    BIGINT       NOT NULL                COMMENT '所属视频 id',
    ep_no       INT          NOT NULL                COMMENT '集号，从 1 开始',
    ep_title    VARCHAR(64)  DEFAULT ''              COMMENT '本集标题',
    bvid        VARCHAR(64)  NOT NULL DEFAULT ''      COMMENT '哔哩哔哩 BV 号',
    cid         VARCHAR(32)  DEFAULT NULL            COMMENT '哔哩哔哩 cid',
    m3u8_url    VARCHAR(512) DEFAULT NULL            COMMENT 'm3u8 直链（source_type=omofun 时有效）',
    duration    INT          DEFAULT 0               COMMENT '时长（毫秒）',
    vip         TINYINT      NOT NULL DEFAULT 0      COMMENT '是否大会员专享：1 是，0 否',
    create_time DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    update_time DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP
                            ON UPDATE CURRENT_TIMESTAMP          COMMENT '更新时间',
    PRIMARY KEY (id),
    UNIQUE KEY uk_video_ep (video_id, ep_no),
    KEY idx_video (video_id)
) ENGINE = InnoDB
  DEFAULT CHARSET = utf8mb4
  COMMENT = '视频分集播放源表';

-- 《赛马娘 第二季》（B 站番剧 season_id=36579）13 话正片
-- 第 1 话免登录可播，第 2~13 话为大会员专享（12 集）。
DELETE FROM video_episode;

INSERT INTO video_episode (video_id, ep_no, ep_title, bvid, cid, m3u8_url, duration, vip) VALUES
(8,  1, '东海帝王',     'BV1Yv411x7n5', '281777756', NULL, 1436000, 0),
(8,  2, '绝不让步',     'BV1ev411x7Ao', '281045002', NULL, 1436000, 1),
(8,  3, '邂逅',         'BV1PU4y147g8', '284145505', NULL, 1436000, 1),
(8,  4, 'TM对决',       'BV1Mh41117Nz', '287471033', NULL, 1436000, 1),
(8,  5, '不败和连霸',   'BV1AU4y1x74L', '290997395', NULL, 1436000, 1),
(8,  6, '为了什么',     'BV1L54y1W7Ar', '301258371', NULL, 1436000, 1),
(8,  7, '祝福之名',     'BV1xA411M7QS', '298010391', NULL, 1436000, 1),
(8,  8, '小小的祈愿',   'BV1aA411M7Fo', '301200230', NULL, 1436000, 1),
(8,  9, '秒表',         'BV1Ur4y1A7h5', '304652816', NULL, 1436000, 1),
(8, 10, '一定 必定',    'BV1Jy4y187je', '307506532', NULL, 1436000, 1),
(8, 11, '这个心情是',   'BV1Bh411Q79Z', '310621258', NULL, 1436000, 1),
(8, 12, '两人',         'BV1zh411Q7B5', '313794727', NULL, 1436000, 1),
(8, 13, '驰骋于梦想中', 'BV1Nf4y1x7rf', '321741984', NULL, 1436000, 1),
-- 《总之就是非常可爱》（动漫共和国 omofun 作品 id=43835）12 话正片
-- m3u8 直链由播放页解析而来，前端用 hls.js 直连播放；第 1 话免登录，其余为大会员专享。
(1,  1, '结婚', '', NULL, 'https://vodcnd09.ajupf.com/20251008/Y8RoHmhl/index.m3u8', 1421000, 0),
(1,  2, '初夜', '', NULL, 'https://vodcnd09.ajupf.com/20251008/Q5F5NSWo/index.m3u8', 1421000, 1),
(1,  3, '姐妹', '', NULL, 'https://vodcnd09.ajupf.com/20251008/69Y49RGm/index.m3u8', 1421000, 1),
(1,  4, '约定', '', NULL, 'https://vodcnd09.ajupf.com/20251008/AvXIWivo/index.m3u8', 1421000, 1),
(1,  5, '戒指', '', NULL, 'https://vodcnd09.ajupf.com/20251008/skGJyyTH/index.m3u8', 1421000, 1),
(1,  6, '报告', '', NULL, 'https://vodcnd09.ajupf.com/20251008/AqJMS4Qq/index.m3u8', 1421000, 1),
(1,  7, '旅行', '', NULL, 'https://vodcnd09.ajupf.com/20251008/OsbF19iK/index.m3u8', 1421000, 1),
(1,  8, '亲子', '', NULL, 'https://vodcnd09.ajupf.com/20251008/xvAVkKLR/index.m3u8', 1421000, 1),
(1,  9, '日常', '', NULL, 'https://vodcnd09.ajupf.com/20251008/38DN167T/index.m3u8', 1421000, 1),
(1, 10, '归路', '', NULL, 'https://vodcnd09.ajupf.com/20251008/ZGGhxdn3/index.m3u8', 1421000, 1),
(1, 11, '友人', '', NULL, 'https://vodcnd09.ajupf.com/20251008/pnpLnceA/index.m3u8', 1421000, 1),
(1, 12, '夫妻', '', NULL, 'https://vodcnd09.ajupf.com/20251008/DhtxnlRc/index.m3u8', 1421000, 1);
-- 《总之就是非常可爱》（B 站番剧 season_id=34230 / md28229676）12 话正片
-- 第 1 话免登录可播，第 2~12 话为大会员专享。
(1,  1, '结婚', 'BV1pK411N7xH', '262040750', 1421000, 0),
(1,  2, '初夜', 'BV1BV41127rg', '262042709', 1421000, 1),
(1,  3, '姐妹', 'BV1zk4y1C7wD', '247259716', 1421000, 1),
(1,  4, '约定', 'BV19v411k79d', '269192650', 1421000, 1),
(1,  5, '戒指', 'BV1hy4y1r7Ki', '251336808', 1421000, 1),
(1,  6, '报告', 'BV1nK4y1E7sC', '253140575', 1421000, 1),
(1,  7, '旅行', 'BV1wy4y1q7DK', '255419739', 1421000, 1),
(1,  8, '亲子', 'BV1py4y1z7QH', '257830784', 1421000, 1),
(1,  9, '日常', 'BV15D4y1X7a3', '260256302', 1421000, 1),
(1, 10, '归路', 'BV1BX4y1M7yC', '262759909', 1421000, 1),
(1, 11, '友人', 'BV1ky4y1S7jp', '265418888', 1421000, 1),
(1, 12, '夫妻', 'BV1f64y1f7dS', '268132262', 1421000, 1);


