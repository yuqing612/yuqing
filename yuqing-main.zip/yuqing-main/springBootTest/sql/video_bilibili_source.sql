-- =========================================================
-- 视频表接入「哔哩哔哩播放源」
-- 说明：
--   1. 新增 bvid 字段保存哔哩哔哩 BV 号（如 BV1Lk8C6bE3z），
--      source_type = 'bilibili' 时生效。
--   2. source_type 取值扩展为：
--        native    = 原生直链音视频（src 为 mp4 等直链，前端用 <video> 播放）
--        tencent   = 腾讯视频（v.qq.com iframe 播放器）
--        bilibili  = 哔哩哔哩（player.bilibili.com iframe 播放器）
--      历史数据默认 native，行为不变。
--   3. 把「超时空辉夜姬」这条从腾讯视频预告切到 B 站完整正片：
--      bvid = BV1Lk8C6bE3z?p=3
--        —— P3「电影正片」为纯净正片（无主播画面），时长 141:23，
--           与官方正片片长约 142 分钟一致，1080P。
--      服务端依据 bvid 自动拼装 iframe 地址，无需手写整段 src。
-- =========================================================

ALTER TABLE video
    ADD COLUMN bvid VARCHAR(64) DEFAULT NULL
        COMMENT '哔哩哔哩 BV 号（source_type=bilibili 时有效）' AFTER vid;

ALTER TABLE video
    MODIFY COLUMN source_type VARCHAR(16) NOT NULL DEFAULT 'native'
        COMMENT '播放源类型：native 原生直链 / tencent 腾讯视频 / bilibili 哔哩哔哩';

UPDATE video
SET uploader    = '多叻嘿嘿',
    views       = '1.9万',
    play        = 19548,
    danmaku     = '13',
    duration    = '02:21:23',
    src         = 'https://player.bilibili.com/player.html?bvid=BV1Lk8C6bE3z&p=3&autoplay=0&high_quality=1&danmaku=0',
    source_type = 'bilibili',
    vid         = NULL,
    bvid        = 'BV1Lk8C6bE3z?p=3'
WHERE title = '超时空辉夜姬';

SELECT id, title, uploader, duration, source_type, vid, bvid, src
FROM video WHERE title = '超时空辉夜姬';
