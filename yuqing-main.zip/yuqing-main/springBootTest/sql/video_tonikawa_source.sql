-- =========================================================
-- 《总之就是非常可爱》（Fly Me to the Moon / トニカワイライ）板块改造
-- 说明：
--   1. 原 video id=1 是「【4K】樱花飘落的次元车站 · 治愈系混剪」，
--      这里改为《总之就是非常可爱》，并换上该番的官方封面 /tonikawa.webp。
--   2. 播放源改为 B 站官方番剧正片（season_id=34230，media_id=28229676），
--      12 集正片逐集写入 video_episode，前端可按集数切换播放。
--   3. 第 1 话免登录可播，第 2~12 话为大会员专享（vip=1）。
--   4. 幂等：可重复执行（先清后插）。
-- =========================================================

-- ---------- 1. 视频条目本身：改名 + 换封面 + 切到 B 站源 ----------
UPDATE video
SET title        = '《总之就是非常可爱》',
    uploader     = '哔哩哔哩番剧',
    views        = '2.2亿',
    play         = 220000000,
    danmaku      = '306.4万',
    duration     = '23:41',
    tags         = '恋爱,日常,漫画改,甜,校园',
    description  = '由崎星空对神秘美少女——司一见钟情。面对星空决死的告白，她的回答是「如果你愿意和我结婚，那我就跟你交往」？！充满了星空与司的爱，可爱&高贵的新婚生活开始了！全 12 话正片。',
    grad         = 'linear-gradient(135deg,#7dd3fc,#ff8fb1)',
    cover_url    = '/tonikawa.webp',
    src          = 'https://player.bilibili.com/player.html?bvid=BV1pK411N7xH&p=1&autoplay=0&high_quality=1&danmaku=0',
    source_type  = 'bilibili',
    bvid         = 'BV1pK411N7xH',
    fav          = 1,
    daily_pick   = 1
WHERE id = 1;

-- ---------- 2. 分集播放源：12 话正片 ----------
DELETE FROM video_episode WHERE video_id = 1;

INSERT INTO video_episode (video_id, ep_no, ep_title, bvid, cid, duration, vip) VALUES
(1,  1, '结婚', 'BV1pK411N7xH', '262040750', 1421000, 0),
(1,  2, '初夜', 'BV1BV41127rg', '262042709', 1421000, 1),
(1,  3, '姐妹', 'BV1zk4y1C7wD', '247259716', 1421000, 1),
(1,  4, '约定', 'BV19v411k79d', '269192650', 1421000, 1),
(1,  5, '戒指', 'BV1hy4y1r7Ki', '251336808', 1421000, 1),
(1,  6, '报告', 'BV1nK4y1E7sC', '253140575', 1421000, 1),
(1,  7, '旅行', 'BV1wy4y1q7DK', '255419739', 1421000, 1),
(1,  8, '亲子', 'BV1py4y1z7QH', '257830784', 1421000, 1),
(1,  9, '日常', 'BV15D4y1X7a3', '260256302', 1421000, 1),
(1, 10, '归路', 'BV1BX4y1M7yC', '262759909', 1421000, 1),
(1, 11, '友人', 'BV1ky4y1S7jp', '265418888', 1421000, 1),
(1, 12, '夫妻', 'BV1f64y1f7dS', '268132262', 1421000, 1);

-- ---------- 3. 校验 ----------
SELECT id, title, uploader, duration, source_type, bvid, cover_url
FROM video WHERE id = 1;

SELECT ep_no, ep_title, bvid, cid, duration, vip
FROM video_episode WHERE video_id = 1 ORDER BY ep_no;
