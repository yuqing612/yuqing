<script setup>
/* =========================================================
   用户管理 —— 前台注册用户
   - 列表分页 + 关键词搜索（用户名 / 昵称 / 邮箱）
   - 启用 / 禁用用户：禁用后无法在前台登录
   ========================================================= */
import { ref, reactive, onMounted, computed } from 'vue'
import { fetchAdminUsers, toggleAdminUserStatus } from '../../api/admin'
import AdminToast from './AdminToast.vue'
import '../../styles/admin.css'

const list = ref([])
const total = ref(0)
const page = ref(1)
const size = 10
const keyword = ref('')
const loading = ref(true)
const errorMsg = ref('')
const switching = ref({})

const toast = reactive({ show: false, message: '', type: 'ok' })
let toastTimer = null
function notify(message, type = 'ok') {
  toast.message = message
  toast.type = type
  toast.show = true
  clearTimeout(toastTimer)
  toastTimer = setTimeout(() => (toast.show = false), 2400)
}

async function toggleStatus(row) {
  switching.value[row.id] = true
  try {
    const updated = await toggleAdminUserStatus(row.id)
    row.status = updated.status
    notify(updated.status === 1 ? '用户已启用' : '用户已禁用')
  } catch (e) {
    notify(e.message || '操作失败', 'err')
  } finally {
    switching.value[row.id] = false
  }
}

async function load() {
  loading.value = true
  errorMsg.value = ''
  try {
    const res = await fetchAdminUsers({ page: page.value, size, keyword: keyword.value.trim() })
    list.value = res.records || []
    total.value = res.total || 0
  } catch (e) {
    errorMsg.value = e.message || '用户列表加载失败'
    list.value = []
    total.value = 0
  } finally {
    loading.value = false
  }
}

function search() {
  page.value = 1
  load()
}

function resetSearch() {
  keyword.value = ''
  page.value = 1
  load()
}

const totalPages = computed(() => Math.max(1, Math.ceil(total.value / size)))
const pageNumbers = computed(() => {
  const n = totalPages.value
  const cur = page.value
  if (n <= 5) return Array.from({ length: n }, (_, i) => i + 1)
  const start = Math.max(1, Math.min(cur - 2, n - 4))
  return Array.from({ length: 5 }, (_, i) => start + i)
})

function goPage(p) {
  if (p < 1 || p > totalPages.value || p === page.value) return
  page.value = p
  load()
}

function formatTime(t) {
  if (!t) return '—'
  return String(t).replace('T', ' ').slice(0, 19)
}

onMounted(load)
</script>

<template>
  <div class="admin-page">
    <AdminToast :show="toast.show" :message="toast.message" :type="toast.type" />

    <div class="panel">
      <div class="panel-head">
        <h3>注册用户</h3>
        <div class="toolbar">
          <div class="search-box">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round">
              <circle cx="11" cy="11" r="7" />
              <path d="m21 21-4.3-4.3" />
            </svg>
            <input v-model="keyword" type="text" placeholder="搜索用户名 / 昵称 / 邮箱" @keyup.enter="search" />
          </div>
          <button class="btn ghost" type="button" @click="search">搜索</button>
          <button class="btn ghost" type="button" @click="resetSearch">重置</button>
        </div>
      </div>

      <div v-if="errorMsg" class="alert error" style="margin: 16px 20px 0">
        <span>⚠ {{ errorMsg }}</span>
        <button class="btn ghost sm" type="button" @click="load">重新加载</button>
      </div>

      <div class="table-wrap">
        <table class="data">
          <thead>
            <tr>
              <th style="width: 70px">ID</th>
              <th>用户名 / 昵称</th>
              <th style="width: 200px">邮箱</th>
              <th style="width: 160px">注册时间</th>
              <th style="width: 110px">状态</th>
              <th style="width: 120px">操作</th>
            </tr>
          </thead>
          <tbody>
            <tr v-for="u in list" :key="u.id">
              <td class="num cell-sub">{{ u.id }}</td>
              <td>
                <p class="cell-main">{{ u.username }}</p>
                <p class="cell-sub">{{ u.nickname || '未设置昵称' }}</p>
              </td>
              <td>{{ u.email || '—' }}</td>
              <td class="num cell-sub">{{ formatTime(u.createTime) }}</td>
              <td>
                <span class="tag" :class="u.status === 1 ? 'green' : 'grey'">
                  {{ u.status === 1 ? '正常' : '已禁用' }}
                </span>
              </td>
              <td class="actions">
                <div class="row-actions">
                  <button
                    class="btn sm"
                    :class="u.status === 1 ? 'danger' : 'ghost'"
                    type="button"
                    :disabled="switching[u.id]"
                    @click="toggleStatus(u)"
                  >
                    {{ u.status === 1 ? '禁用' : '启用' }}
                  </button>
                </div>
              </td>
            </tr>
          </tbody>
        </table>

        <div v-if="loading" class="state">
          <i class="loader-spin"></i>
          <p style="margin-top: 10px">加载中…</p>
        </div>
        <div v-else-if="!list.length" class="state">
          <svg width="38" height="38" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6">
            <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2M9 11a4 4 0 1 0 0-8 4 4 0 0 0 0 8z" />
          </svg>
          <p>没有找到用户</p>
        </div>
      </div>

      <div v-if="total > 0" class="pager">
        <span class="info">共 {{ total }} 位用户 · 第 {{ page }} / {{ totalPages }} 页</span>
        <div class="pages">
          <button type="button" :disabled="page === 1" @click="goPage(page - 1)">上一页</button>
          <button
            v-for="p in pageNumbers"
            :key="p"
            type="button"
            :class="{ on: p === page }"
            @click="goPage(p)"
          >
            {{ p }}
          </button>
          <button type="button" :disabled="page === totalPages" @click="goPage(page + 1)">下一页</button>
        </div>
      </div>
    </div>
  </div>
</template>
