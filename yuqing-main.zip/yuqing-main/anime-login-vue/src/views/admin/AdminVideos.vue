<script setup>
/* =========================================================
   视频管理 —— 对应首页「热门推荐 / 视频播放器 / 热播排行」
   - 列表分页 + 关键词搜索（标题 / UP主 / 标签）
   - 新增 / 编辑 / 删除
   - 每日推荐开关：直接决定该视频是否出现在首页热门推荐
   ========================================================= */
import { ref, reactive, onMounted, computed } from 'vue'
import {
  fetchAdminVideos,
  createAdminVideo,
  updateAdminVideo,
  deleteAdminVideo,
  toggleAdminDailyPick,
  toggleAdminFav
} from '../../api/admin'
import AdminToast from './AdminToast.vue'
import AdminConfirm from './AdminConfirm.vue'
import '../../styles/admin.css'

const list = ref([])
const total = ref(0)
const page = ref(1)
const size = 10
const keyword = ref('')
const loading = ref(true)
const errorMsg = ref('')

const toast = reactive({ show: false, message: '', type: 'ok' })
let toastTimer = null
function notify(message, type = 'ok') {
  toast.message = message
  toast.type = type
  toast.show = true
  clearTimeout(toastTimer)
  toastTimer = setTimeout(() => (toast.show = false), 2400)
}

/* ---------- 编辑弹窗 ---------- */
const editing = ref(false)
const saving = ref(false)
const formError = ref('')
const isEdit = ref(false)
const blankForm = () => ({
  id: null,
  title: '',
  uploader: '',
  views: '',
  play: 0,
  danmaku: '',
  duration: '',
  tags: '',
  description: '',
  fav: 0,
  grad: 'linear-gradient(135deg,#ff8fb1,#c084fc)',
  coverUrl: '',
  src: '',
  sourceType: 'native',
  vid: '',
  bvid: '',
  dailyPick: 1
})
const form = reactive(blankForm())

function openCreate() {
  Object.assign(form, blankForm())
  isEdit.value = false
  formError.value = ''
  editing.value = true
}

function openEdit(row) {
  Object.assign(form, {
    id: row.id,
    title: row.title || '',
    uploader: row.uploader || '',
    views: row.views || '',
    play: row.play || 0,
    danmaku: row.danmaku || '',
    duration: row.duration || '',
    tags: (row.tags || []).join(','),
    description: row.desc || '',
    fav: row.fav ? 1 : 0,
    grad: row.grad || 'linear-gradient(135deg,#ff8fb1,#c084fc)',
    coverUrl: row.coverUrl || '',
    src: row.src || '',
    sourceType: ['tencent', 'bilibili'].includes(row.sourceType) ? row.sourceType : 'native',
    vid: row.vid || '',
    bvid: row.bvid || '',
    dailyPick: row.dailyPick ? 1 : 0
  })
  isEdit.value = true
  formError.value = ''
  editing.value = true
}

function closeEdit() {
  editing.value = false
  formError.value = ''
}

async function submit() {
  if (!form.title.trim()) {
    formError.value = '请填写视频标题'
    return
  }
  if (!form.uploader.trim()) {
    formError.value = '请填写 UP 主'
    return
  }
  if (form.sourceType === 'tencent' && !form.vid.trim()) {
    formError.value = '腾讯视频源需要填写 VID（如 v3186hgiqhs）'
    return
  }
  if (form.sourceType === 'bilibili' && !form.bvid.trim()) {
    formError.value = '哔哩哔哩源需要填写 BV 号（如 BV1Lk8C6bE3z）'
    return
  }
  saving.value = true
  formError.value = ''
  try {
    const payload = { ...form, play: Number(form.play) || 0 }
    if (isEdit.value) {
      await updateAdminVideo(form.id, payload)
      notify('视频已更新')
    } else {
      await createAdminVideo(payload)
      notify('视频已新增')
    }
    editing.value = false
    await load()
  } catch (e) {
    formError.value = e.message || '保存失败'
  } finally {
    saving.value = false
  }
}

/* ---------- 每日推荐开关 ---------- */
const switching = ref({})
async function togglePick(row) {
  switching.value[row.id] = true
  try {
    const updated = await toggleAdminDailyPick(row.id)
    row.dailyPick = updated.dailyPick
    notify(updated.dailyPick ? '已加入首页每日推荐' : '已移出首页每日推荐')
  } catch (e) {
    notify(e.message || '操作失败', 'err')
  } finally {
    switching.value[row.id] = false
  }
}

/* ---------- 收藏开关：直接控制前台收藏页 ---------- */
async function toggleFav(row) {
  switching.value[row.id] = true
  try {
    const updated = await toggleAdminFav(row.id)
    row.fav = updated.fav
    notify(updated.fav ? '已加入前台收藏页' : '已移出前台收藏页')
  } catch (e) {
    notify(e.message || '操作失败', 'err')
  } finally {
    switching.value[row.id] = false
  }
}

/* ---------- 删除 ---------- */
const removing = ref(false)
const pendingDelete = ref(null)
function askDelete(row) {
  pendingDelete.value = row
}
async function confirmDelete() {
  if (!pendingDelete.value) return
  removing.value = true
  try {
    await deleteAdminVideo(pendingDelete.value.id)
    notify('视频已删除')
    pendingDelete.value = null
    // 删掉当前页最后一条时回退一页
    if (list.value.length === 1 && page.value > 1) page.value -= 1
    await load()
  } catch (e) {
    notify(e.message || '删除失败', 'err')
  } finally {
    removing.value = false
  }
}

/* ---------- 列表 ---------- */
async function load() {
  loading.value = true
  errorMsg.value = ''
  try {
    const res = await fetchAdminVideos({ page: page.value, size, keyword: keyword.value.trim() })
    list.value = res.records || []
    total.value = res.total || 0
  } catch (e) {
    errorMsg.value = e.message || '视频列表加载失败'
    list.value = []
    total.value = 0
  } finally {
    loading.value = false
  }
}

function search() {
  page.value = 1
  load()
}

function resetSearch() {
  keyword.value = ''
  page.value = 1
  load()
}

const totalPages = computed(() => Math.max(1, Math.ceil(total.value / size)))
const pageNumbers = computed(() => {
  const n = totalPages.value
  const cur = page.value
  if (n <= 5) return Array.from({ length: n }, (_, i) => i + 1)
  const start = Math.max(1, Math.min(cur - 2, n - 4))
  return Array.from({ length: 5 }, (_, i) => start + i)
})

function goPage(p) {
  if (p < 1 || p > totalPages.value || p === page.value) return
  page.value = p
  load()
}

onMounted(load)
</script>

<template>
  <div class="admin-page">
    <AdminToast :show="toast.show" :message="toast.message" :type="toast.type" />
    <AdminConfirm
      :show="!!pendingDelete"
      title="删除视频"
      :message="`确定要删除视频 <b>${pendingDelete?.title || ''}</b> 吗？<br />该视频关联的放送计划会一并清除，此操作不可撤销。`"
      :loading="removing"
      @cancel="pendingDelete = null"
      @confirm="confirmDelete"
    />

    <div class="panel">
      <div class="panel-head">
        <div class="toolbar" style="flex: 1">
          <div class="search-box">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round">
              <circle cx="11" cy="11" r="7" />
              <path d="m21 21-4.3-4.3" />
            </svg>
            <input v-model="keyword" type="text" placeholder="搜索标题 / UP主 / 标签" @keyup.enter="search" />
          </div>
          <button class="btn ghost" type="button" @click="search">搜索</button>
          <button class="btn ghost" type="button" @click="resetSearch">重置</button>
          <span class="spacer"></span>
          <button class="btn primary" type="button" @click="openCreate">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round">
              <path d="M12 5v14M5 12h14" />
            </svg>
            新增视频
          </button>
        </div>
      </div>

      <div v-if="errorMsg" class="alert error" style="margin: 16px 20px 0">
        <span>⚠ {{ errorMsg }}</span>
        <button class="btn ghost sm" type="button" @click="load">重新加载</button>
      </div>

      <div class="table-wrap">
        <table class="data">
          <thead>
            <tr>
              <th style="width: 70px">封面</th>
              <th>标题 / UP主</th>
              <th style="width: 100px">播放量</th>
              <th style="width: 90px">弹幕</th>
              <th style="width: 80px">时长</th>
              <th style="width: 150px">标签</th>
              <th style="width: 90px">播放源</th>
              <th style="width: 110px">每日推荐</th>
              <th style="width: 110px">收藏</th>
              <th style="width: 130px">操作</th>
            </tr>
          </thead>
          <tbody>
            <tr v-for="v in list" :key="v.id">
              <td>
                <img v-if="v.coverUrl" class="thumb" :src="v.coverUrl" :alt="v.title" />
                <div v-else class="thumb-fallback">无图</div>
              </td>
              <td>
                <p class="cell-main">{{ v.title }}</p>
                <p class="cell-sub">{{ v.uploader }}</p>
              </td>
              <td class="num">
                <p class="cell-main">{{ v.views || '—' }}</p>
                <p class="cell-sub">{{ (v.play || 0).toLocaleString() }}</p>
              </td>
              <td class="num">{{ v.danmaku || '—' }}</td>
              <td class="num">{{ v.duration || '—' }}</td>
              <td>
                <span v-for="t in v.tags" :key="t" class="tag">{{ t }}</span>
                <span v-if="!v.tags || !v.tags.length" class="cell-sub">—</span>
              </td>
              <td>
                <span v-if="v.sourceType === 'tencent'" class="tag src-tencent">腾讯视频</span>
                <span v-else-if="v.sourceType === 'bilibili'" class="tag src-bili">哔哩哔哩</span>
                <span v-else class="cell-sub">原生直链</span>
                <p v-if="v.vid" class="cell-sub" style="margin: 4px 0 0">{{ v.vid }}</p>
                <p v-if="v.bvid" class="cell-sub" style="margin: 4px 0 0">{{ v.bvid }}</p>
              </td>
              <td>
                <div style="display: flex; align-items: center; gap: 9px">
                  <button
                    class="switch"
                    :class="{ on: v.dailyPick === 1 }"
                    type="button"
                    :disabled="switching[v.id]"
                    :title="v.dailyPick === 1 ? '取消每日推荐' : '设为每日推荐'"
                    @click="togglePick(v)"
                  ></button>
                  <span class="cell-sub" style="margin: 0">{{ v.dailyPick === 1 ? '已推荐' : '未推荐' }}</span>
                </div>
              </td>
              <td>
                <div style="display: flex; align-items: center; gap: 9px">
                  <button
                    class="switch"
                    :class="{ on: v.fav === true }"
                    type="button"
                    :disabled="switching[v.id]"
                    :title="v.fav === true ? '移出前台收藏页' : '加入前台收藏页'"
                    @click="toggleFav(v)"
                  ></button>
                  <span class="cell-sub" style="margin: 0">{{ v.fav === true ? '已收藏' : '未收藏' }}</span>
                </div>
              </td>
              <td class="actions">
                <div class="row-actions">
                  <button class="btn ghost sm" type="button" @click="openEdit(v)">编辑</button>
                  <button class="btn danger sm" type="button" @click="askDelete(v)">删除</button>
                </div>
              </td>
            </tr>
          </tbody>
        </table>

        <div v-if="loading" class="state">
          <i class="loader-spin"></i>
          <p style="margin-top: 10px">加载中…</p>
        </div>
        <div v-else-if="!list.length" class="state">
          <svg width="38" height="38" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6">
            <path d="M10 8l6 4-6 4V8zM3 6h18v12H3z" />
          </svg>
          <p>没有找到视频，换个关键词或新增一条吧</p>
        </div>
      </div>

      <div v-if="total > 0" class="pager">
        <span class="info">共 {{ total }} 条视频 · 第 {{ page }} / {{ totalPages }} 页</span>
        <div class="pages">
          <button type="button" :disabled="page === 1" @click="goPage(page - 1)">上一页</button>
          <button
            v-for="p in pageNumbers"
            :key="p"
            type="button"
            :class="{ on: p === page }"
            @click="goPage(p)"
          >
            {{ p }}
          </button>
          <button type="button" :disabled="page === totalPages" @click="goPage(page + 1)">下一页</button>
        </div>
      </div>
    </div>

    <!-- ============ 新增 / 编辑弹窗 ============ -->
    <div v-if="editing" class="modal-mask" @click.self="closeEdit">
      <div class="modal">
        <div class="modal-head">
          <h3>{{ isEdit ? '编辑视频' : '新增视频' }}</h3>
          <button class="close" type="button" @click="closeEdit">
            <svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round">
              <path d="M18 6L6 18M6 6l12 12" />
            </svg>
          </button>
        </div>

        <div class="modal-body">
          <p v-if="formError" class="alert error">⚠ {{ formError }}</p>

          <div class="form-grid">
            <div class="form-item full">
              <label>视频标题<span class="req">*</span></label>
              <input v-model="form.title" type="text" placeholder="如：【4K】樱花飘落的次元车站" />
            </div>

            <div class="form-item">
              <label>UP 主 / 投稿方<span class="req">*</span></label>
              <input v-model="form.uploader" type="text" placeholder="如：桜TV官方" />
            </div>

            <div class="form-item">
              <label>播放量文案</label>
              <input v-model="form.views" type="text" placeholder="如：128.5万（展示用）" />
              <span class="desc">首页显示的播放量文字</span>
            </div>

            <div class="form-item">
              <label>真实播放量</label>
              <input v-model="form.play" type="number" min="0" placeholder="1285000" />
              <span class="desc">用于热播排行排序</span>
            </div>

            <div class="form-item">
              <label>弹幕数</label>
              <input v-model="form.danmaku" type="text" placeholder="如：3.2万" />
            </div>

            <div class="form-item">
              <label>时长</label>
              <input v-model="form.duration" type="text" placeholder="如：04:12" />
            </div>

            <div class="form-item">
              <label>标签</label>
              <input v-model="form.tags" type="text" placeholder="治愈,混剪,4K" />
              <span class="desc">英文逗号分隔</span>
            </div>

            <div class="form-item full">
              <label>简介</label>
              <textarea v-model="form.description" placeholder="视频简介"></textarea>
            </div>

            <div class="form-item full">
              <label>封面图 URL</label>
              <input v-model="form.coverUrl" type="text" placeholder="留空则使用下方渐变封面" />
            </div>

            <div class="form-item full">
              <label>封面渐变 CSS</label>
              <input v-model="form.grad" type="text" placeholder="linear-gradient(135deg,#ff8fb1,#c084fc)" />
            </div>

            <div class="form-item full">
              <label>播放源类型</label>
              <select v-model="form.sourceType" class="form-select">
                <option value="native">原生直链（mp4 等直链文件）</option>
                <option value="tencent">腾讯视频（iframe 官方播放器）</option>
                <option value="bilibili">哔哩哔哩（iframe 官方播放器）</option>
              </select>
              <span class="desc">腾讯视频 / 哔哩哔哩由服务端依据 VID / BV 号自动拼装播放地址</span>
            </div>

            <div class="form-item full">
              <label>腾讯视频 VID</label>
              <input
                v-model="form.vid"
                type="text"
                placeholder="如：v3186hgiqhs"
                :disabled="form.sourceType !== 'tencent'"
              />
              <span class="desc">
                仅腾讯视频源需要填写。从腾讯视频播放页地址
                <code>v.qq.com/x/page/v3186hgiqhs.html</code> 中取 v 后面的那一段
              </span>
            </div>

            <div class="form-item full">
              <label>哔哩哔哩 BV 号</label>
              <input
                v-model="form.bvid"
                type="text"
                placeholder="如：BV1Lk8C6bE3z 或 BV1Lk8C6bE3z?p=3"
                :disabled="form.sourceType !== 'bilibili'"
              />
              <span class="desc">
                仅哔哩哔哩源需要填写。可直接粘贴完整播放页地址
                <code>bilibili.com/video/BV1Lk8C6bE3z/?p=3</code>，
                服务端会自动取 BV 号与分P 页码
              </span>
            </div>

            <div class="form-item full">
              <label>播放地址</label>
              <input
                v-model="form.src"
                type="text"
                placeholder="https://.../video.mp4"
                :disabled="form.sourceType !== 'native'"
              />
              <span v-if="form.sourceType !== 'native'" class="desc">
                非原生源无需填写，保存时会自动生成 iframe 播放地址
              </span>
            </div>

            <div class="form-item inline-check">
              <button
                class="switch"
                :class="{ on: form.dailyPick === 1 }"
                type="button"
                @click="form.dailyPick = form.dailyPick === 1 ? 0 : 1"
              ></button>
              <label>加入首页每日推荐</label>
            </div>

            <div class="form-item inline-check">
              <button
                class="switch"
                :class="{ on: form.fav === 1 }"
                type="button"
                @click="form.fav = form.fav === 1 ? 0 : 1"
              ></button>
              <label>标记为收藏</label>
            </div>
          </div>
        </div>

        <div class="modal-foot">
          <button class="btn ghost" type="button" :disabled="saving" @click="closeEdit">取消</button>
          <button class="btn primary" type="button" :disabled="saving" @click="submit">
            {{ saving ? '保存中…' : '保存' }}
          </button>
        </div>
      </div>
    </div>
  </div>
</template>
