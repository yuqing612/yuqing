<script setup>
/* =========================================================
   放送计划管理 —— 对应首页侧栏「番剧时间表」
   - 按星期分组展示，与首页时间表 Tab 一一对应
   - 新增 / 编辑 / 删除
   - 番剧下拉数据取自全部番剧列表
   ========================================================= */
import { ref, reactive, onMounted, computed } from 'vue'
import {
  fetchAdminSchedules,
  fetchAllAdminBangumi,
  createAdminSchedule,
  updateAdminSchedule,
  deleteAdminSchedule
} from '../../api/admin'
import AdminToast from './AdminToast.vue'
import AdminConfirm from './AdminConfirm.vue'
import '../../styles/admin.css'

const WEEKDAYS = [
  { value: 1, label: '周一' },
  { value: 2, label: '周二' },
  { value: 3, label: '周三' },
  { value: 4, label: '周四' },
  { value: 5, label: '周五' },
  { value: 6, label: '周六' },
  { value: 7, label: '周日' }
]

const list = ref([])
const bangumiOptions = ref([])
const loading = ref(true)
const errorMsg = ref('')

const toast = reactive({ show: false, message: '', type: 'ok' })
let toastTimer = null
function notify(message, type = 'ok') {
  toast.message = message
  toast.type = type
  toast.show = true
  clearTimeout(toastTimer)
  toastTimer = setTimeout(() => (toast.show = false), 2400)
}

/* ---------- 编辑弹窗 ---------- */
const editing = ref(false)
const saving = ref(false)
const formError = ref('')
const isEdit = ref(false)
const blankForm = () => ({
  id: null,
  bangumiId: null,
  weekday: 1,
  airTime: '20:00',
  episode: 1
})
const form = reactive(blankForm())

function openCreate() {
  Object.assign(form, blankForm())
  if (bangumiOptions.value.length) {
    form.bangumiId = bangumiOptions.value[0].id
  }
  isEdit.value = false
  formError.value = ''
  editing.value = true
}

function openEdit(row) {
  Object.assign(form, {
    id: row.id,
    bangumiId: row.bangumiId,
    weekday: row.weekday || 1,
    airTime: row.airTime || '20:00',
    episode: row.episode ?? 1
  })
  isEdit.value = true
  formError.value = ''
  editing.value = true
}

function closeEdit() {
  editing.value = false
  formError.value = ''
}

async function submit() {
  if (!form.bangumiId) {
    formError.value = '请选择番剧'
    return
  }
  if (!form.airTime || !/^\d{1,2}:\d{2}$/.test(form.airTime.trim())) {
    formError.value = '放送时间格式应为 HH:mm'
    return
  }
  saving.value = true
  formError.value = ''
  try {
    const payload = {
      bangumiId: Number(form.bangumiId),
      weekday: Number(form.weekday),
      airTime: form.airTime.trim(),
      episode: Number(form.episode) || 1
    }
    if (isEdit.value) {
      await updateAdminSchedule(form.id, payload)
      notify('放送计划已更新')
    } else {
      await createAdminSchedule(payload)
      notify('放送计划已新增')
    }
    editing.value = false
    await load()
  } catch (e) {
    formError.value = e.message || '保存失败'
  } finally {
    saving.value = false
  }
}

/* ---------- 删除 ---------- */
const removing = ref(false)
const pendingDelete = ref(null)
function askDelete(row) {
  pendingDelete.value = row
}
async function confirmDelete() {
  if (!pendingDelete.value) return
  removing.value = true
  try {
    await deleteAdminSchedule(pendingDelete.value.id)
    notify('放送计划已删除')
    pendingDelete.value = null
    await load()
  } catch (e) {
    notify(e.message || '删除失败', 'err')
  } finally {
    removing.value = false
  }
}

/* ---------- 列表 ---------- */
async function load() {
  loading.value = true
  errorMsg.value = ''
  try {
    const [rows, all] = await Promise.all([fetchAdminSchedules(), fetchAllAdminBangumi()])
    list.value = rows || []
    bangumiOptions.value = all || []
  } catch (e) {
    errorMsg.value = e.message || '放送计划加载失败'
    list.value = []
  } finally {
    loading.value = false
  }
}

/* 按星期分组 */
const grouped = computed(() =>
  WEEKDAYS.map((w) => ({
    ...w,
    items: list.value.filter((s) => s.weekday === w.value)
  }))
)

/* 今天高亮：与首页保持一致，取当前星期 */
const todayWeekday = computed(() => {
  const jsDay = new Date().getDay() // 0=周日
  return jsDay === 0 ? 7 : jsDay
})

onMounted(load)
</script>

<template>
  <div class="admin-page">
    <AdminToast :show="toast.show" :message="toast.message" :type="toast.type" />
    <AdminConfirm
      :show="!!pendingDelete"
      title="删除放送计划"
      :message="`确定要删除 <b>${pendingDelete?.bangumiTitle || ''}</b> 在 ${WEEKDAYS.find((w) => w.value === pendingDelete?.weekday)?.label || ''} ${pendingDelete?.airTime || ''} 的放送计划吗？`"
      :loading="removing"
      @cancel="pendingDelete = null"
      @confirm="confirmDelete"
    />

    <div class="panel">
      <div class="panel-head">
        <h3>番剧时间表</h3>
        <div class="toolbar">
          <span class="hint">首页侧栏「番剧时间表」板块的数据来源</span>
          <button class="btn primary" type="button" @click="openCreate">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round">
              <path d="M12 5v14M5 12h14" />
            </svg>
            新增计划
          </button>
        </div>
      </div>

      <div v-if="errorMsg" class="alert error" style="margin: 16px 20px 0">
        <span>⚠ {{ errorMsg }}</span>
        <button class="btn ghost sm" type="button" @click="load">重新加载</button>
      </div>

      <div v-if="loading" class="state">
        <i class="loader-spin"></i>
        <p style="margin-top: 10px">加载中…</p>
      </div>

      <div v-else class="week-grid">
        <section
          v-for="g in grouped"
          :key="g.value"
          class="week-card"
          :class="{ today: g.value === todayWeekday }"
        >
          <div class="wc-head">
            <h4>{{ g.label }}</h4>
            <span class="wc-count">{{ g.items.length }} 条</span>
            <span v-if="g.value === todayWeekday" class="wc-today">今天</span>
          </div>
          <ul class="wc-list">
            <li v-for="s in g.items" :key="s.id">
              <span class="wc-time">{{ s.airTime }}</span>
              <div class="wc-info">
                <p class="wc-title">{{ s.bangumiTitle || '（番剧已删除）' }}</p>
                <p class="wc-ep">更新至第 {{ s.episode }} 话</p>
              </div>
              <div class="row-actions">
                <button class="btn ghost sm" type="button" @click="openEdit(s)">编辑</button>
                <button class="btn danger sm icon" type="button" title="删除" @click="askDelete(s)">
                  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round">
                    <path d="M3 6h18M8 6V4h8v2M19 6l-1 14H6L5 6" />
                  </svg>
                </button>
              </div>
            </li>
            <li v-if="!g.items.length" class="wc-empty">当天暂无安排</li>
          </ul>
        </section>
      </div>
    </div>

    <!-- ============ 新增 / 编辑弹窗 ============ -->
    <div v-if="editing" class="modal-mask" @click.self="closeEdit">
      <div class="modal narrow">
        <div class="modal-head">
          <h3>{{ isEdit ? '编辑放送计划' : '新增放送计划' }}</h3>
          <button class="close" type="button" @click="closeEdit">
            <svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round">
              <path d="M18 6L6 18M6 6l12 12" />
            </svg>
          </button>
        </div>

        <div class="modal-body">
          <p v-if="formError" class="alert error">⚠ {{ formError }}</p>

          <div class="form-grid" style="grid-template-columns: 1fr">
            <div class="form-item">
              <label>番剧<span class="req">*</span></label>
              <select v-model="form.bangumiId">
                <option :value="null" disabled>请选择番剧</option>
                <option v-for="b in bangumiOptions" :key="b.id" :value="b.id">{{ b.title }}</option>
              </select>
            </div>

            <div class="form-item">
              <label>放送星期<span class="req">*</span></label>
              <select v-model="form.weekday">
                <option v-for="w in WEEKDAYS" :key="w.value" :value="w.value">{{ w.label }}</option>
              </select>
            </div>

            <div class="form-item">
              <label>放送时间<span class="req">*</span></label>
              <input v-model="form.airTime" type="time" step="60" />
            </div>

            <div class="form-item">
              <label>更新至第几话</label>
              <input v-model="form.episode" type="number" min="1" />
            </div>
          </div>
        </div>

        <div class="modal-foot">
          <button class="btn ghost" type="button" :disabled="saving" @click="closeEdit">取消</button>
          <button class="btn primary" type="button" :disabled="saving" @click="submit">
            {{ saving ? '保存中…' : '保存' }}
          </button>
        </div>
      </div>
    </div>
  </div>
</template>

<style scoped>
.week-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(272px, 1fr));
  gap: 14px;
  padding: 20px;
}
.week-card {
  border-radius: 15px;
  border: 1px solid rgba(126, 104, 180, 0.12);
  background: rgba(126, 104, 180, 0.03);
  overflow: hidden;
}
.week-card.today {
  border-color: rgba(192, 132, 252, 0.42);
  background: rgba(192, 132, 252, 0.06);
}
.wc-head {
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 12px 15px;
  border-bottom: 1px solid rgba(126, 104, 180, 0.1);
}
.wc-head h4 {
  font-size: 14px;
  font-weight: 800;
  color: var(--ink);
}
.wc-count {
  font-size: 11.5px;
  color: var(--ink-soft);
}
.wc-today {
  margin-left: auto;
  padding: 2px 9px;
  border-radius: 999px;
  font-size: 10.5px;
  font-weight: 700;
  color: #fff;
  background: var(--grad);
}
.wc-list {
  list-style: none;
  display: flex;
  flex-direction: column;
}
.wc-list li {
  display: flex;
  align-items: center;
  gap: 11px;
  padding: 11px 15px;
  border-bottom: 1px dashed rgba(126, 104, 180, 0.1);
}
.wc-list li:last-child {
  border-bottom: 0;
}
.wc-time {
  font-size: 12.5px;
  font-weight: 800;
  color: var(--accent);
  width: 42px;
  flex-shrink: 0;
  font-variant-numeric: tabular-nums;
}
.wc-info {
  flex: 1;
  min-width: 0;
}
.wc-title {
  font-size: 13px;
  font-weight: 700;
  color: var(--ink);
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}
.wc-ep {
  font-size: 11px;
  color: var(--ink-soft);
  margin-top: 2px;
}
.wc-empty {
  justify-content: center;
  color: var(--ink-soft);
  font-size: 12px;
  padding: 20px 15px !important;
}
</style>
