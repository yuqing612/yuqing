<script setup>
/* =========================================================
   概览统计：后台首页看板
   数据来源 GET /api/admin/stats
   展示首页各板块的数据体量、热门视频 Top5、番剧分类分布
   ========================================================= */
import { ref, onMounted, computed } from 'vue'
import { fetchAdminStats } from '../../api/admin'
import '../../styles/admin.css'

const stats = ref(null)
const loading = ref(true)
const errorMsg = ref('')

const CARDS = [
  { key: 'videoCount', label: '视频总数', unit: '个', icon: 'M10 8l6 4-6 4V8zM3 6h18v12H3z', tone: 'violet' },
  { key: 'dailyPickCount', label: '每日推荐', unit: '个', icon: 'M12 2l2.4 6.2L21 10l-5 4.2 1.5 6.8L12 17.6 6.5 21 8 14.2 3 10l6.6-1.8z', tone: 'pink' },
  { key: 'bangumiCount', label: '番剧总数', unit: '部', icon: 'M4 5h16v14H4zM8 5v14M4 9h4', tone: 'sky' },
  { key: 'scheduleCount', label: '放送计划', unit: '条', icon: 'M7 2v3M17 2v3M3 8h18M5 5h14a2 2 0 0 1 2 2v12a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V7a2 2 0 0 1 2-2z', tone: 'green' },
  { key: 'userCount', label: '注册用户', unit: '人', icon: 'M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2M9 11a4 4 0 1 0 0-8 4 4 0 0 0 0 8z', tone: 'amber' },
  { key: 'favCount', label: '收藏视频', unit: '个', icon: 'M19 21l-7-5-7 5V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2z', tone: 'rose' }
]

const cards = computed(() =>
  CARDS.map((c) => ({ ...c, value: stats.value?.[c.key] ?? 0 }))
)

/* 分类分布：转成带百分比的数据 */
const categories = computed(() => {
  const map = stats.value?.categoryStat || {}
  const total = Object.values(map).reduce((a, b) => a + b, 0)
  return Object.entries(map)
    .map(([name, count]) => ({
      name,
      count,
      percent: total ? Math.round((count / total) * 100) : 0
    }))
    .sort((a, b) => b.count - a.count)
})

/* 热门视频 Top5：按真实播放量排序 */
const topVideos = computed(() => stats.value?.topVideos || [])

const MAX_PLAY = computed(() =>
  Math.max(1, ...topVideos.value.map((v) => v.play || 0))
)

async function load() {
  loading.value = true
  errorMsg.value = ''
  try {
    stats.value = await fetchAdminStats()
  } catch (e) {
    errorMsg.value = e.message || '统计数据加载失败'
  } finally {
    loading.value = false
  }
}

onMounted(load)
</script>

<template>
  <div class="admin-page">
    <!-- 加载失败提示 -->
    <div v-if="errorMsg" class="alert error">
      <span>⚠ {{ errorMsg }}</span>
      <button class="btn ghost sm" type="button" @click="load">重新加载</button>
    </div>

    <!-- 统计卡片 -->
    <div class="cards">
      <article v-for="c in cards" :key="c.key" class="stat-card" :class="c.tone">
        <div class="sc-icon">
          <svg width="19" height="19" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round">
            <path :d="c.icon" />
          </svg>
        </div>
        <div class="sc-body">
          <p class="sc-label">{{ c.label }}</p>
          <p class="sc-value">
            {{ loading ? '—' : c.value }}
            <small>{{ c.unit }}</small>
          </p>
        </div>
      </article>
    </div>

    <!-- 总播放量 -->
    <div class="panel">
      <div class="panel-head">
        <h3>总播放量</h3>
        <span class="hint">全部视频真实播放量累计</span>
      </div>
      <div class="panel-body total-play">
        <p class="tp-num">{{ loading ? '—' : (stats?.totalPlay ?? 0).toLocaleString() }}</p>
        <p class="tp-label">次播放</p>
      </div>
    </div>

    <div class="two-col">
      <!-- 热门视频 Top5 -->
      <div class="panel">
        <div class="panel-head">
          <h3>热门视频 TOP 5</h3>
          <span class="hint">按真实播放量排序</span>
        </div>
        <div class="panel-body">
          <div v-if="!loading && topVideos.length" class="top-list">
            <div v-for="(v, i) in topVideos" :key="v.id" class="top-row">
              <span class="tr-no" :class="`t${i + 1}`">{{ i + 1 }}</span>
              <div class="tr-info">
                <p class="tr-title">{{ v.title }}</p>
                <p class="tr-up">{{ v.uploader }}</p>
                <div class="tr-bar">
                  <span :style="{ width: Math.round(((v.play || 0) / MAX_PLAY) * 100) + '%' }"></span>
                </div>
              </div>
              <div class="tr-metric">
                <p class="tr-play">{{ (v.play || 0).toLocaleString() }}</p>
                <p class="tr-views">{{ v.views || '—' }}</p>
              </div>
            </div>
          </div>
          <div v-else-if="loading" class="state"><i class="loader-spin"></i></div>
          <div v-else class="state">
            <p>暂无视频数据</p>
          </div>
        </div>
      </div>

      <!-- 番剧分类分布 -->
      <div class="panel">
        <div class="panel-head">
          <h3>番剧分类分布</h3>
          <span class="hint">首页分类 Tab 的数据来源</span>
        </div>
        <div class="panel-body">
          <div v-if="!loading && categories.length" class="cat-list">
            <div v-for="c in categories" :key="c.name" class="cat-row">
              <span class="cat-name">{{ c.name }}</span>
              <div class="cat-bar">
                <span :style="{ width: c.percent + '%' }"></span>
              </div>
              <span class="cat-count">{{ c.count }} 部 · {{ c.percent }}%</span>
            </div>
          </div>
          <div v-else-if="loading" class="state"><i class="loader-spin"></i></div>
          <div v-else class="state">
            <p>暂无番剧分类数据</p>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<style scoped>
/* ============ 统计卡片 ============ */
.cards {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(196px, 1fr));
  gap: 14px;
  margin-bottom: 18px;
}
.stat-card {
  display: flex;
  align-items: center;
  gap: 14px;
  padding: 18px 20px;
  border-radius: 18px;
  background: #fff;
  border: 1px solid rgba(126, 104, 180, 0.12);
  box-shadow: 0 14px 34px -26px rgba(90, 60, 140, 0.4);
  transition: 0.24s;
}
.stat-card:hover {
  transform: translateY(-3px);
  box-shadow: 0 22px 44px -26px rgba(90, 60, 140, 0.5);
}
.sc-icon {
  width: 44px;
  height: 44px;
  border-radius: 14px;
  display: grid;
  place-items: center;
  flex-shrink: 0;
}
.stat-card.violet .sc-icon {
  color: #7c3aed;
  background: rgba(167, 139, 250, 0.16);
}
.stat-card.pink .sc-icon {
  color: #db2777;
  background: rgba(255, 143, 177, 0.18);
}
.stat-card.sky .sc-icon {
  color: #0284c7;
  background: rgba(125, 211, 252, 0.2);
}
.stat-card.green .sc-icon {
  color: #047857;
  background: rgba(52, 211, 153, 0.18);
}
.stat-card.amber .sc-icon {
  color: #b45309;
  background: rgba(245, 158, 11, 0.18);
}
.stat-card.rose .sc-icon {
  color: #be123c;
  background: rgba(244, 63, 94, 0.14);
}
.sc-body {
  min-width: 0;
}
.sc-label {
  font-size: 12px;
  color: var(--ink-soft);
  letter-spacing: 0.04em;
}
.sc-value {
  font-size: 25px;
  font-weight: 800;
  color: var(--ink);
  line-height: 1.25;
  margin-top: 3px;
  font-variant-numeric: tabular-nums;
}
.sc-value small {
  font-size: 12px;
  font-weight: 600;
  color: var(--ink-soft);
  margin-left: 3px;
}

/* ============ 总播放量 ============ */
.total-play {
  display: flex;
  align-items: baseline;
  gap: 10px;
  padding: 24px 20px;
}
.tp-num {
  font-size: 38px;
  font-weight: 900;
  letter-spacing: -0.02em;
  background: var(--grad);
  -webkit-background-clip: text;
  background-clip: text;
  -webkit-text-fill-color: transparent;
  font-variant-numeric: tabular-nums;
}
.tp-label {
  font-size: 13px;
  color: var(--ink-soft);
}

/* ============ 双栏 ============ */
.two-col {
  display: grid;
  grid-template-columns: 1.15fr 1fr;
  gap: 18px;
  margin-top: 18px;
}
.two-col .panel + .panel {
  margin-top: 0;
}

/* 热门视频 */
.top-list {
  display: flex;
  flex-direction: column;
  gap: 15px;
}
.top-row {
  display: flex;
  align-items: flex-start;
  gap: 13px;
}
.tr-no {
  width: 25px;
  height: 25px;
  border-radius: 8px;
  display: grid;
  place-items: center;
  font-size: 12.5px;
  font-weight: 800;
  font-style: italic;
  color: var(--ink-soft);
  background: rgba(126, 104, 180, 0.09);
  flex-shrink: 0;
  margin-top: 1px;
}
.tr-no.t1 {
  color: #b45309;
  background: rgba(245, 158, 11, 0.18);
}
.tr-no.t2 {
  color: #4338ca;
  background: rgba(129, 140, 248, 0.18);
}
.tr-no.t3 {
  color: #c2410c;
  background: rgba(251, 146, 60, 0.18);
}
.tr-info {
  flex: 1;
  min-width: 0;
}
.tr-title {
  font-size: 13.5px;
  font-weight: 700;
  color: var(--ink);
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}
.tr-up {
  font-size: 11.5px;
  color: var(--ink-soft);
  margin-top: 3px;
}
.tr-bar {
  height: 5px;
  border-radius: 999px;
  background: rgba(126, 104, 180, 0.1);
  margin-top: 8px;
  overflow: hidden;
}
.tr-bar span {
  display: block;
  height: 100%;
  border-radius: 999px;
  background: var(--grad);
}
.tr-metric {
  text-align: right;
  flex-shrink: 0;
}
.tr-play {
  font-size: 14px;
  font-weight: 800;
  color: var(--ink);
  font-variant-numeric: tabular-nums;
}
.tr-views {
  font-size: 11px;
  color: var(--ink-soft);
  margin-top: 2px;
}

/* 分类分布 */
.cat-list {
  display: flex;
  flex-direction: column;
  gap: 14px;
}
.cat-row {
  display: grid;
  grid-template-columns: 60px 1fr auto;
  align-items: center;
  gap: 12px;
}
.cat-name {
  font-size: 13px;
  font-weight: 700;
  color: var(--ink);
}
.cat-bar {
  height: 8px;
  border-radius: 999px;
  background: rgba(126, 104, 180, 0.1);
  overflow: hidden;
}
.cat-bar span {
  display: block;
  height: 100%;
  border-radius: 999px;
  background: var(--grad);
  transition: width 0.5s;
}
.cat-count {
  font-size: 11.5px;
  color: var(--ink-soft);
  font-variant-numeric: tabular-nums;
  white-space: nowrap;
}

@media (max-width: 1000px) {
  .two-col {
    grid-template-columns: 1fr;
  }
}
</style>
