<script setup>
/* =========================================================
   后台管理系统登录页
   - 只有登录功能，没有注册入口
   - 调用 POST /api/admin/auth/login
   - 后端仅放行 permission=0 的管理员权限账号，
     默认权限（permission=1）的账号会被拒绝
   - 登录成功后写入后台专用令牌，跳转后台管理首页
   ========================================================= */
import { ref, computed, onMounted } from 'vue'
import { useRouter, useRoute } from 'vue-router'
import { adminLogin, saveAdminAuth, getAdminAuth } from '../../api/admin'

const router = useRouter()
const route = useRoute()

const account = ref('')
const password = ref('')
const remember = ref(true)
const showPassword = ref(false)
const errorMessage = ref('')
const loading = ref(false)

const passwordType = computed(() => (showPassword.value ? 'text' : 'password'))

function validate() {
  const acc = account.value.trim()
  if (!acc) {
    errorMessage.value = '请输入管理员账号'
    return null
  }
  if (!password.value) {
    errorMessage.value = '请输入密码'
    return null
  }
  return { acc, pwd: password.value }
}

async function onSubmit() {
  if (loading.value) return
  const payload = validate()
  if (!payload) return

  errorMessage.value = ''
  loading.value = true
  try {
    const data = await adminLogin({
      account: payload.acc,
      password: payload.pwd,
      remember: remember.value
    })
    saveAdminAuth(data, remember.value)
    const redirect = route.query.redirect
    router.replace(typeof redirect === 'string' && redirect ? redirect : '/admin')
  } catch (e) {
    errorMessage.value = e.message || '登录失败，请稍后再试'
  } finally {
    loading.value = false
  }
}

/* 已有有效令牌时直接进入后台 */
onMounted(async () => {
  const auth = getAdminAuth()
  if (auth && auth.token) {
    router.replace(typeof route.query.redirect === 'string' ? route.query.redirect : '/admin')
  }
})
</script>

<template>
  <div class="admin-login">
    <div class="aurora a1"></div>
    <div class="aurora a2"></div>
    <div class="aurora a3"></div>

    <div class="login-card">
      <!-- 左侧品牌区 -->
      <aside class="side">
        <div class="logo">
          <svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
            <path d="M3 21h18M5 21V8l7-5 7 5v13" />
            <path d="M9 21v-6h6v6" />
          </svg>
        </div>
        <h2>桜次元<br />后台管理系统</h2>
        <p class="side-desc">
          管理首页展示的全部内容数据：<br />
          Hero 轮播 · 热门推荐 · 番剧新番<br />
          热播排行 · 放送计划 · 注册用户
        </p>
        <ul class="side-list">
          <li><i></i>视频内容增删改查</li>
          <li><i></i>番剧与分类维护</li>
          <li><i></i>放送计划编排</li>
          <li><i></i>用户状态管理</li>
        </ul>
        <div class="side-foot">
          <span class="dot"></span>系统运行中
        </div>
      </aside>

      <!-- 右侧登录表单：只有登录，没有注册 -->
      <section class="form-side">
        <div class="form-head">
          <h1>管理员登录</h1>
          <p>请使用管理员账号进入后台</p>
        </div>

        <p v-if="errorMessage" class="err" role="alert">{{ errorMessage }}</p>

        <form novalidate @submit.prevent="onSubmit">
          <div class="field">
            <input id="acc" v-model="account" type="text" placeholder=" " autocomplete="username" />
            <label for="acc">管理员账号</label>
            <span class="ico">
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2" />
                <circle cx="12" cy="7" r="4" />
              </svg>
            </span>
          </div>

          <div class="field">
            <input id="pwd" v-model="password" :type="passwordType" placeholder=" " autocomplete="current-password" />
            <label for="pwd">密码</label>
            <span class="ico">
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                <rect x="4" y="11" width="16" height="10" rx="2.5" />
                <path d="M8 11V7a4 4 0 0 1 8 0v4" />
              </svg>
            </span>
            <button class="toggle" type="button" aria-label="显示密码" @click="showPassword = !showPassword">
              <svg v-if="showPassword" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                <path d="M2 2l20 20" />
                <path d="M6.7 6.8C4 8.6 1.5 12 1.5 12s3.5 6.5 10.5 6.5c1.6 0 3-.4 4.2-1" />
              </svg>
              <svg v-else width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                <path d="M1.5 12S5 5.5 12 5.5 22.5 12 22.5 12 19 18.5 12 18.5 1.5 12 1.5 12z" />
                <circle cx="12" cy="12" r="3.2" />
              </svg>
            </button>
          </div>

          <label class="check">
            <input v-model="remember" type="checkbox" />
            <span class="box">
              <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="3.4" stroke-linecap="round" stroke-linejoin="round">
                <path d="M20 6L9 17l-5-5" />
              </svg>
            </span>
            记住登录状态
          </label>

          <button class="submit" type="submit" :class="{ loading }">
            <span>
              进入后台
              <svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round">
                <path d="M5 12h14M13 6l6 6-6 6" />
              </svg>
            </span>
            <i class="spin"></i>
          </button>
        </form>

        <!-- 后台不开放注册，账号由系统预置 -->
        <p class="tip">
          <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
            <circle cx="12" cy="12" r="9" />
            <path d="M12 16v-5M12 8h.01" />
          </svg>
          仅管理员权限账号（permission=0）可登录后台，默认权限账号无法进入
        </p>

        <button class="back" type="button" @click="router.push('/')">
          <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round">
            <path d="M19 12H5M11 18l-6-6 6-6" />
          </svg>
          返回前台首页
        </button>
      </section>
    </div>
  </div>
</template>

<style scoped>
.admin-login {
  position: relative;
  min-height: 100vh;
  display: grid;
  place-items: center;
  padding: 28px;
  overflow: hidden;
  background: linear-gradient(150deg, #2b2140 0%, #1e1930 48%, #221d38 100%);
}

/* 背景光晕 */
.aurora {
  position: absolute;
  border-radius: 50%;
  filter: blur(90px);
  opacity: 0.5;
  pointer-events: none;
}
.a1 {
  width: 520px;
  height: 520px;
  background: #7dd3fc;
  top: -160px;
  left: -100px;
  animation: float1 20s ease-in-out infinite;
}
.a2 {
  width: 460px;
  height: 460px;
  background: #ff8fb1;
  bottom: -140px;
  right: -60px;
  animation: float2 24s ease-in-out infinite;
}
.a3 {
  width: 360px;
  height: 360px;
  background: #a78bfa;
  top: 42%;
  left: 46%;
  opacity: 0.28;
  animation: float1 28s ease-in-out infinite reverse;
}

.login-card {
  position: relative;
  z-index: 1;
  display: grid;
  grid-template-columns: 0.92fr 1.08fr;
  width: min(940px, 96vw);
  min-height: 600px;
  border-radius: 26px;
  overflow: hidden;
  background: rgba(255, 255, 255, 0.06);
  border: 1px solid rgba(255, 255, 255, 0.14);
  box-shadow: 0 40px 90px -40px rgba(0, 0, 0, 0.85);
  backdrop-filter: blur(22px);
  -webkit-backdrop-filter: blur(22px);
  animation: rise 0.65s cubic-bezier(0.2, 0.8, 0.25, 1) both;
}

/* ---------- 左侧品牌 ---------- */
.side {
  position: relative;
  padding: 46px 38px;
  display: flex;
  flex-direction: column;
  background: linear-gradient(160deg, rgba(125, 211, 252, 0.14), rgba(255, 143, 177, 0.12));
  border-right: 1px solid rgba(255, 255, 255, 0.1);
}
.logo {
  width: 50px;
  height: 50px;
  border-radius: 16px;
  background: var(--grad);
  display: grid;
  place-items: center;
  box-shadow: 0 12px 26px -10px rgba(192, 132, 252, 0.9);
  margin-bottom: 26px;
}
.side h2 {
  font-size: 26px;
  font-weight: 800;
  line-height: 1.4;
  letter-spacing: 0.04em;
  color: #fff;
  margin-bottom: 16px;
}
.side-desc {
  font-size: 12.5px;
  line-height: 1.9;
  color: rgba(255, 255, 255, 0.62);
  margin-bottom: 26px;
}
.side-list {
  list-style: none;
  display: flex;
  flex-direction: column;
  gap: 11px;
}
.side-list li {
  display: flex;
  align-items: center;
  gap: 10px;
  font-size: 13px;
  color: rgba(255, 255, 255, 0.78);
}
.side-list i {
  width: 6px;
  height: 6px;
  border-radius: 50%;
  background: var(--sky);
  box-shadow: 0 0 0 3px rgba(125, 211, 252, 0.22);
}
.side-foot {
  margin-top: auto;
  display: flex;
  align-items: center;
  gap: 8px;
  font-size: 11.5px;
  letter-spacing: 0.08em;
  color: rgba(255, 255, 255, 0.5);
}
.side-foot .dot {
  width: 7px;
  height: 7px;
  border-radius: 50%;
  background: #34d399;
  box-shadow: 0 0 0 3px rgba(52, 211, 153, 0.22);
  animation: pulse 2s infinite;
}

/* ---------- 右侧表单 ---------- */
.form-side {
  padding: 52px 50px 40px;
  display: flex;
  flex-direction: column;
  justify-content: center;
}
.form-head h1 {
  font-size: 25px;
  font-weight: 800;
  letter-spacing: 0.03em;
  color: #fff;
  margin-bottom: 8px;
}
.form-head p {
  font-size: 13px;
  color: rgba(255, 255, 255, 0.5);
  margin-bottom: 26px;
}
.err {
  color: #fda4af;
  font-size: 12.5px;
  background: rgba(244, 63, 94, 0.14);
  border: 1px solid rgba(244, 63, 94, 0.3);
  border-radius: 10px;
  padding: 9px 13px;
  margin-bottom: 16px;
}

.field {
  position: relative;
  margin-bottom: 17px;
}
.field input {
  width: 100%;
  height: 56px;
  padding: 22px 46px 8px 42px;
  border-radius: 15px;
  border: 1.5px solid rgba(255, 255, 255, 0.16);
  background: rgba(255, 255, 255, 0.07);
  font-size: 14.5px;
  color: #fff;
  outline: none;
  font-family: inherit;
  transition: 0.25s;
}
.field input::placeholder {
  color: transparent;
}
.field label {
  position: absolute;
  left: 42px;
  top: 18px;
  font-size: 14px;
  color: rgba(255, 255, 255, 0.45);
  pointer-events: none;
  transition: 0.24s cubic-bezier(0.2, 0.8, 0.25, 1);
}
.field input:focus + label,
.field input:not(:placeholder-shown) + label {
  top: 8px;
  font-size: 11px;
  color: var(--sky);
  font-weight: 600;
  letter-spacing: 0.08em;
}
.field input:focus {
  border-color: rgba(125, 211, 252, 0.7);
  background: rgba(255, 255, 255, 0.12);
  box-shadow: 0 0 0 5px rgba(125, 211, 252, 0.13);
}
.field .ico {
  position: absolute;
  left: 15px;
  top: 18px;
  color: rgba(255, 255, 255, 0.35);
  transition: 0.25s;
}
.field input:focus ~ .ico {
  color: var(--sky);
}
.toggle {
  position: absolute;
  right: 14px;
  top: 17px;
  width: 30px;
  height: 30px;
  border: 0;
  background: none;
  cursor: pointer;
  color: rgba(255, 255, 255, 0.35);
  border-radius: 8px;
  display: grid;
  place-items: center;
  transition: 0.2s;
}
.toggle:hover {
  color: var(--sky);
  background: rgba(125, 211, 252, 0.12);
}

.check {
  display: flex;
  align-items: center;
  gap: 9px;
  cursor: pointer;
  color: rgba(255, 255, 255, 0.6);
  font-size: 12.5px;
  user-select: none;
  margin: 4px 0 24px;
}
.check input {
  display: none;
}
.box {
  width: 18px;
  height: 18px;
  border-radius: 6px;
  border: 1.5px solid rgba(255, 255, 255, 0.25);
  background: rgba(255, 255, 255, 0.08);
  display: grid;
  place-items: center;
  transition: 0.22s;
}
.check input:checked + .box {
  background: var(--grad);
  border-color: transparent;
}
.box svg {
  opacity: 0;
  transform: scale(0.4);
  transition: 0.22s cubic-bezier(0.2, 1.4, 0.4, 1);
}
.check input:checked + .box svg {
  opacity: 1;
  transform: scale(1);
}

.submit {
  position: relative;
  width: 100%;
  height: 52px;
  border: 0;
  border-radius: 15px;
  cursor: pointer;
  overflow: hidden;
  background: var(--grad);
  background-size: 220% 100%;
  color: #fff;
  font-size: 15px;
  font-weight: 700;
  letter-spacing: 0.14em;
  box-shadow: 0 16px 34px -14px rgba(192, 132, 252, 0.95);
  transition: 0.22s;
}
.submit:hover {
  transform: translateY(-2px);
  background-position: 100% 0;
}
.submit.loading {
  pointer-events: none;
  color: transparent;
}
.submit span {
  position: relative;
  z-index: 2;
  display: inline-flex;
  align-items: center;
  gap: 9px;
}
.spin {
  position: absolute;
  inset: 0;
  margin: auto;
  width: 21px;
  height: 21px;
  border: 2.5px solid rgba(255, 255, 255, 0.35);
  border-top-color: #fff;
  border-radius: 50%;
  opacity: 0;
  animation: spin360 0.7s linear infinite;
}
.submit.loading .spin {
  opacity: 1;
}

.tip {
  display: flex;
  align-items: flex-start;
  gap: 8px;
  margin-top: 22px;
  padding: 11px 13px;
  border-radius: 12px;
  font-size: 11.5px;
  line-height: 1.7;
  color: rgba(255, 255, 255, 0.5);
  background: rgba(255, 255, 255, 0.05);
  border: 1px solid rgba(255, 255, 255, 0.09);
}
.tip svg {
  flex-shrink: 0;
  margin-top: 2px;
}
.back {
  margin-top: 18px;
  align-self: center;
  display: inline-flex;
  align-items: center;
  gap: 7px;
  background: none;
  border: 0;
  cursor: pointer;
  font-size: 12.5px;
  color: rgba(255, 255, 255, 0.45);
  transition: 0.2s;
}
.back:hover {
  color: var(--sky);
}

@media (max-width: 880px) {
  .login-card {
    grid-template-columns: 1fr;
  }
  .side {
    display: none;
  }
  .form-side {
    padding: 40px 28px 32px;
  }
}
</style>
