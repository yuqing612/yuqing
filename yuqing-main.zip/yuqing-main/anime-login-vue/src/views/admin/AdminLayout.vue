<script setup>
/* =========================================================
   后台管理系统布局：左侧导航 + 顶栏 + 内容区
   - 菜单覆盖首页展示的全部板块：概览 / 视频 / 番剧 / 放送计划 / 用户
   - 退出登录调用后端 revoke，清理后台令牌后回到登录页
   ========================================================= */
import { ref, computed, onMounted } from 'vue'
import { useRouter, useRoute } from 'vue-router'
import { adminLogout, adminMe, clearAdminAuth, getAdminAuth } from '../../api/admin'
import AdminPasswordModal from './AdminPasswordModal.vue'

const router = useRouter()
const route = useRoute()

const admin = ref(null)
const collapsing = ref(false)
const pwdModalShow = ref(false)

const MENU = [
  {
    group: '数据看板',
    items: [
      {
        name: 'admin-dashboard',
        label: '概览统计',
        icon: 'M3 13h8V3H3v10zm10 8h8V11h-8v10zM3 21h8v-6H3v6zM13 9h8V3h-8v6z'
      }
    ]
  },
  {
    group: '首页内容',
    items: [
      {
        name: 'admin-videos',
        label: '视频管理',
        icon: 'M10 8l6 4-6 4V8zM3 6h18v12H3z'
      },
      {
        name: 'admin-bangumi',
        label: '番剧管理',
        icon: 'M4 5h16v14H4zM8 5v14M4 9h4'
      },
      {
        name: 'admin-schedules',
        label: '放送计划',
        icon: 'M7 2v3M17 2v3M3 8h18M5 5h14a2 2 0 0 1 2 2v12a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V7a2 2 0 0 1 2-2z'
      }
    ]
  },
  {
    group: '系统',
    items: [
      {
        name: 'admin-users',
        label: '用户管理',
        icon: 'M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2M9 11a4 4 0 1 0 0-8 4 4 0 0 0 0 8zM23 21v-2a4 4 0 0 0-3-3.87M16 3.13a4 4 0 0 1 0 7.75'
      }
    ]
  }
]

const currentTitle = computed(() => {
  for (const g of MENU) {
    const hit = g.items.find((i) => i.name === route.name)
    if (hit) return hit.label
  }
  return '后台管理'
})

const initial = computed(() => {
  const name = admin.value?.nickname || admin.value?.username || 'A'
  return name.slice(0, 1).toUpperCase()
})

async function handleLogout() {
  try {
    await adminLogout()
  } catch {
    /* 后端不可达也照常本地登出 */
  }
  clearAdminAuth()
  router.replace('/admin/login')
}

onMounted(async () => {
  const auth = getAdminAuth()
  if (auth) admin.value = auth
  try {
    const fresh = await adminMe()
    admin.value = { ...(auth || {}), ...fresh }
  } catch {
    /* 守卫已做校验，这里失败不阻塞渲染 */
  }
})
</script>

<template>
  <div class="admin-shell" :class="{ collapse: collapsing }">
    <!-- ============ 侧边栏 ============ -->
    <aside class="sidebar">
      <div class="brand" @click="router.push('/')">
        <div class="logo">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
            <path d="M3 21h18M5 21V8l7-5 7 5v13" />
            <path d="M9 21v-6h6v6" />
          </svg>
        </div>
        <div v-show="!collapsing" class="brand-text">
          <b>桜次元</b>
          <small>admin console</small>
        </div>
      </div>

      <nav class="menu">
        <div v-for="g in MENU" :key="g.group" class="menu-group">
          <p v-show="!collapsing" class="group-title">{{ g.group }}</p>
          <router-link
            v-for="item in g.items"
            :key="item.name"
            :to="{ name: item.name }"
            class="menu-item"
            :class="{ active: route.name === item.name }"
            :title="collapsing ? item.label : ''"
          >
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round">
              <path :d="item.icon" />
            </svg>
            <span v-show="!collapsing">{{ item.label }}</span>
          </router-link>
        </div>
      </nav>

      <button class="collapse-btn" type="button" @click="collapsing = !collapsing">
        <svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
          <path v-if="!collapsing" d="M15 18l-6-6 6-6" />
          <path v-else d="M9 18l6-6-6-6" />
        </svg>
        <span v-show="!collapsing">收起菜单</span>
      </button>
    </aside>

    <!-- ============ 主区 ============ -->
    <div class="main">
      <header class="topbar">
        <div class="crumb">
          <h2>{{ currentTitle }}</h2>
          <span class="sep">/</span>
          <span class="path">桜次元 后台管理系统</span>
        </div>

        <div class="top-right">
          <button class="front-btn" type="button" @click="router.push('/')">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
              <path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z" />
              <path d="M9 22V12h6v10" />
            </svg>
            前台首页
          </button>

          <div class="admin-chip">
            <span class="a-avatar">{{ initial }}</span>
            <div class="a-meta">
              <span class="a-name">{{ admin?.nickname || admin?.username || '管理员' }}</span>
              <span class="a-role"><i></i>超级管理员</span>
            </div>
            <button class="pwd-btn" type="button" title="修改密码" @click="pwdModalShow = true">
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.1" stroke-linecap="round" stroke-linejoin="round">
                <rect x="4" y="11" width="16" height="10" rx="2.5" />
                <path d="M8 11V7a4 4 0 0 1 8 0v4" />
              </svg>
              <span>修改密码</span>
            </button>
            <button class="logout" type="button" title="退出登录" @click="handleLogout">
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.1" stroke-linecap="round" stroke-linejoin="round">
                <path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4" />
                <path d="m16 17 5-5-5-5M21 12H9" />
              </svg>
            </button>
          </div>
        </div>
      </header>

      <main class="content">
        <router-view v-slot="{ Component }">
          <transition name="slide-fade" mode="out-in">
            <component :is="Component" />
          </transition>
        </router-view>
      </main>
    </div>

    <!-- 修改密码弹窗：改密成功后令牌已失效，回到登录页 -->
    <AdminPasswordModal
      :show="pwdModalShow"
      @close="pwdModalShow = false"
      @done="router.replace('/admin/login')"
    />
  </div>
</template>

<style scoped>
.admin-shell {
  display: flex;
  height: 100vh;
  overflow: hidden;
  background: #f5f3fa;
}

/* ============ 侧边栏 ============ */
.sidebar {
  width: 226px;
  flex-shrink: 0;
  display: flex;
  flex-direction: column;
  padding: 18px 14px;
  background: linear-gradient(180deg, #2b2140 0%, #221c35 100%);
  box-shadow: 4px 0 24px -12px rgba(43, 33, 64, 0.6);
  transition: width 0.26s cubic-bezier(0.2, 0.8, 0.25, 1);
}
.admin-shell.collapse .sidebar {
  width: 70px;
}

.brand {
  display: flex;
  align-items: center;
  gap: 11px;
  padding: 4px 6px 20px;
  cursor: pointer;
}
.logo {
  width: 40px;
  height: 40px;
  border-radius: 13px;
  background: var(--grad);
  display: grid;
  place-items: center;
  flex-shrink: 0;
  box-shadow: 0 10px 22px -8px rgba(192, 132, 252, 0.7);
}
.brand-text b {
  display: block;
  font-size: 15px;
  color: #fff;
  letter-spacing: 0.06em;
}
.brand-text small {
  font-size: 9.5px;
  color: rgba(255, 255, 255, 0.4);
  letter-spacing: 0.2em;
  text-transform: uppercase;
}

.menu {
  flex: 1;
  overflow-y: auto;
  display: flex;
  flex-direction: column;
  gap: 16px;
}
.menu-group {
  display: flex;
  flex-direction: column;
  gap: 4px;
}
.group-title {
  font-size: 10.5px;
  letter-spacing: 0.16em;
  color: rgba(255, 255, 255, 0.32);
  padding: 0 10px 6px;
  text-transform: uppercase;
}
.menu-item {
  display: flex;
  align-items: center;
  gap: 11px;
  padding: 10px 12px;
  border-radius: 12px;
  font-size: 13.5px;
  font-weight: 600;
  color: rgba(255, 255, 255, 0.62);
  text-decoration: none;
  transition: 0.2s;
  white-space: nowrap;
}
.menu-item:hover {
  background: rgba(255, 255, 255, 0.07);
  color: #fff;
}
.menu-item.active {
  color: #fff;
  background: var(--grad);
  box-shadow: 0 10px 22px -10px rgba(192, 132, 252, 0.95);
}

.collapse-btn {
  display: flex;
  align-items: center;
  gap: 10px;
  height: 38px;
  padding: 0 12px;
  border-radius: 12px;
  border: 1px solid rgba(255, 255, 255, 0.1);
  background: rgba(255, 255, 255, 0.04);
  color: rgba(255, 255, 255, 0.5);
  font-size: 12.5px;
  cursor: pointer;
  transition: 0.2s;
}
.collapse-btn:hover {
  color: #fff;
  background: rgba(255, 255, 255, 0.1);
}

/* ============ 主区 ============ */
.main {
  flex: 1;
  min-width: 0;
  display: flex;
  flex-direction: column;
}

.topbar {
  flex-shrink: 0;
  height: 66px;
  padding: 0 26px;
  display: flex;
  align-items: center;
  justify-content: space-between;
  background: rgba(255, 255, 255, 0.85);
  border-bottom: 1px solid rgba(126, 104, 180, 0.12);
  backdrop-filter: blur(14px);
  -webkit-backdrop-filter: blur(14px);
}
.crumb {
  display: flex;
  align-items: baseline;
  gap: 10px;
}
.crumb h2 {
  font-size: 18px;
  font-weight: 800;
  letter-spacing: 0.02em;
  color: var(--ink);
}
.crumb .sep {
  color: var(--ink-soft);
  opacity: 0.5;
}
.crumb .path {
  font-size: 12px;
  color: var(--ink-soft);
}

.top-right {
  display: flex;
  align-items: center;
  gap: 16px;
}
.front-btn {
  display: inline-flex;
  align-items: center;
  gap: 7px;
  height: 36px;
  padding: 0 15px;
  border-radius: 999px;
  border: 1.5px solid var(--line);
  background: rgba(255, 255, 255, 0.8);
  color: var(--ink-soft);
  font-size: 12.5px;
  font-weight: 600;
  cursor: pointer;
  transition: 0.22s;
}
.front-btn:hover {
  color: var(--accent);
  border-color: #e3d4ff;
  transform: translateY(-1px);
}

.admin-chip {
  display: flex;
  align-items: center;
  gap: 10px;
}
.a-avatar {
  width: 38px;
  height: 38px;
  border-radius: 13px;
  background: var(--grad);
  display: grid;
  place-items: center;
  font-size: 16px;
  font-weight: 800;
  color: #fff;
  box-shadow: 0 10px 20px -8px rgba(192, 132, 252, 0.85);
}
.a-meta {
  display: flex;
  flex-direction: column;
  line-height: 1.3;
}
.a-name {
  font-size: 13px;
  font-weight: 700;
  color: var(--ink);
}
.a-role {
  font-size: 10.5px;
  color: #34d399;
  display: flex;
  align-items: center;
  gap: 5px;
}
.a-role i {
  width: 5px;
  height: 5px;
  border-radius: 50%;
  background: #34d399;
}

/* 修改密码入口 */
.pwd-btn {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  height: 36px;
  padding: 0 13px;
  border-radius: 12px;
  border: 1.5px solid var(--line);
  background: rgba(255, 255, 255, 0.7);
  color: var(--ink-soft);
  font-size: 12.5px;
  font-weight: 600;
  cursor: pointer;
  white-space: nowrap;
  transition: 0.22s;
}
.pwd-btn:hover {
  color: var(--accent);
  border-color: #e3d4ff;
  background: #fff;
  transform: translateY(-2px);
}

.logout {
  width: 36px;
  height: 36px;
  border: 1.5px solid var(--line);
  border-radius: 12px;
  background: rgba(255, 255, 255, 0.7);
  color: var(--ink-soft);
  cursor: pointer;
  display: grid;
  place-items: center;
  transition: 0.22s;
}
.logout:hover {
  color: #f43f5e;
  border-color: #ffc2d2;
  background: #fff;
  transform: translateY(-2px);
}

.content {
  flex: 1;
  min-height: 0;
  overflow-y: auto;
  overflow-x: hidden;
  padding: 24px 26px 40px;
}

.slide-fade-enter-active,
.slide-fade-leave-active {
  transition: opacity 0.2s ease, transform 0.2s ease;
}
.slide-fade-enter-from {
  opacity: 0;
  transform: translateY(10px);
}
.slide-fade-leave-to {
  opacity: 0;
}

@media (max-width: 860px) {
  .sidebar {
    width: 70px;
  }
  .sidebar .brand-text,
  .sidebar .group-title,
  .sidebar .menu-item span,
  .sidebar .collapse-btn span {
    display: none;
  }
  .crumb .path {
    display: none;
  }
  .pwd-btn span {
    display: none;
  }
  .pwd-btn {
    padding: 0 11px;
  }
  .a-meta {
    display: none;
  }
}
</style>
