<script setup>
/* =========================================================
   番剧管理 —— 对应首页「Hero 轮播 / 番剧新番 / 分类 Tab」
   - 列表分页 + 关键词搜索 + 分类筛选
   - 新增 / 编辑 / 删除
   - 分类字段直接决定前台分类 Tab 的分组
   ========================================================= */
import { ref, reactive, onMounted, computed } from 'vue'
import {
  fetchAdminBangumi,
  createAdminBangumi,
  updateAdminBangumi,
  deleteAdminBangumi
} from '../../api/admin'
import AdminToast from './AdminToast.vue'
import AdminConfirm from './AdminConfirm.vue'
import '../../styles/admin.css'

const CATS = ['全部', '日漫', '国漫', '剧场', '美漫']

const list = ref([])
const total = ref(0)
const page = ref(1)
const size = 10
const keyword = ref('')
const category = ref('全部')
const loading = ref(true)
const errorMsg = ref('')

const toast = reactive({ show: false, message: '', type: 'ok' })
let toastTimer = null
function notify(message, type = 'ok') {
  toast.message = message
  toast.type = type
  toast.show = true
  clearTimeout(toastTimer)
  toastTimer = setTimeout(() => (toast.show = false), 2400)
}

/* ---------- 编辑弹窗 ---------- */
const editing = ref(false)
const saving = ref(false)
const formError = ref('')
const isEdit = ref(false)
const blankForm = () => ({
  id: null,
  title: '',
  coverUrl: '',
  coverGradient: 'linear-gradient(135deg,#ff8fb1,#c084fc)',
  sourceType: 'native',
  vid: '',
  bvid: '',
  src: '',
  episodes: 12,
  status: '连载中',
  score: 8.0,
  studio: '',
  category: '日漫',
  tags: '',
  description: ''
})
const form = reactive(blankForm())

function openCreate() {
  Object.assign(form, blankForm())
  isEdit.value = false
  formError.value = ''
  editing.value = true
}

function openEdit(row) {
  Object.assign(form, {
    id: row.id,
    title: row.title || '',
    coverUrl: row.coverUrl || '',
    coverGradient: row.cover || 'linear-gradient(135deg,#ff8fb1,#c084fc)',
    sourceType: ['tencent', 'bilibili'].includes(row.sourceType) ? row.sourceType : 'native',
    vid: row.vid || '',
    bvid: row.bvid || '',
    src: row.src || '',
    episodes: row.episodes || 12,
    status: row.status || '连载中',
    score: row.score ?? 8.0,
    studio: row.studio || '',
    category: row.category || '日漫',
    tags: (row.tags || []).join('/'),
    description: row.desc || ''
  })
  isEdit.value = true
  formError.value = ''
  editing.value = true
}

function closeEdit() {
  editing.value = false
  formError.value = ''
}

async function submit() {
  if (!form.title.trim()) {
    formError.value = '请填写番剧标题'
    return
  }
  if (form.episodes == null || Number(form.episodes) <= 0) {
    formError.value = '请填写正确的总集数'
    return
  }
  if (form.score == null || form.score === '') {
    formError.value = '请填写评分'
    return
  }
  if (form.sourceType === 'tencent' && !form.vid.trim()) {
    formError.value = '腾讯视频源需要填写 VID（如 v3186hgiqhs）'
    return
  }
  if (form.sourceType === 'bilibili' && !form.bvid.trim()) {
    formError.value = '哔哩哔哩源需要填写 BV 号（如 BV145G1z9E71）'
    return
  }
  saving.value = true
  formError.value = ''
  try {
    const payload = {
      title: form.title,
      coverUrl: form.coverUrl || null,
      coverGradient: form.coverGradient,
      sourceType: form.sourceType,
      vid: form.vid,
      bvid: form.bvid,
      src: form.src,
      episodes: Number(form.episodes),
      status: form.status,
      score: Number(form.score),
      studio: form.studio,
      category: form.category,
      tags: form.tags,
      description: form.description
    }
    if (isEdit.value) {
      await updateAdminBangumi(form.id, payload)
      notify('番剧已更新')
    } else {
      await createAdminBangumi(payload)
      notify('番剧已新增')
    }
    editing.value = false
    await load()
  } catch (e) {
    formError.value = e.message || '保存失败'
  } finally {
    saving.value = false
  }
}

/* ---------- 删除 ---------- */
const removing = ref(false)
const pendingDelete = ref(null)
function askDelete(row) {
  pendingDelete.value = row
}
async function confirmDelete() {
  if (!pendingDelete.value) return
  removing.value = true
  try {
    await deleteAdminBangumi(pendingDelete.value.id)
    notify('番剧已删除')
    pendingDelete.value = null
    if (list.value.length === 1 && page.value > 1) page.value -= 1
    await load()
  } catch (e) {
    notify(e.message || '删除失败', 'err')
  } finally {
    removing.value = false
  }
}

/* ---------- 列表 ---------- */
async function load() {
  loading.value = true
  errorMsg.value = ''
  try {
    const res = await fetchAdminBangumi({
      page: page.value,
      size,
      keyword: keyword.value.trim(),
      category: category.value
    })
    list.value = res.records || []
    total.value = res.total || 0
  } catch (e) {
    errorMsg.value = e.message || '番剧列表加载失败'
    list.value = []
    total.value = 0
  } finally {
    loading.value = false
  }
}

function search() {
  page.value = 1
  load()
}

function pickCat(c) {
  category.value = c
  page.value = 1
  load()
}

const totalPages = computed(() => Math.max(1, Math.ceil(total.value / size)))
const pageNumbers = computed(() => {
  const n = totalPages.value
  const cur = page.value
  if (n <= 5) return Array.from({ length: n }, (_, i) => i + 1)
  const start = Math.max(1, Math.min(cur - 2, n - 4))
  return Array.from({ length: 5 }, (_, i) => start + i)
})

function goPage(p) {
  if (p < 1 || p > totalPages.value || p === page.value) return
  page.value = p
  load()
}

onMounted(load)
</script>

<template>
  <div class="admin-page">
    <AdminToast :show="toast.show" :message="toast.message" :type="toast.type" />
    <AdminConfirm
      :show="!!pendingDelete"
      title="删除番剧"
      :message="`确定要删除番剧 <b>${pendingDelete?.title || ''}</b> 吗？<br />该番剧的放送计划会一并清除，此操作不可撤销。`"
      :loading="removing"
      @cancel="pendingDelete = null"
      @confirm="confirmDelete"
    />

    <div class="panel">
      <div class="panel-head">
        <h3>番剧列表</h3>
        <div class="toolbar">
          <div class="search-box">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round">
              <circle cx="11" cy="11" r="7" />
              <path d="m21 21-4.3-4.3" />
            </svg>
            <input v-model="keyword" type="text" placeholder="搜索标题 / 制作公司 / 标签" @keyup.enter="search" />
          </div>
          <button class="btn ghost" type="button" @click="search">搜索</button>
          <button class="btn primary" type="button" @click="openCreate">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round">
              <path d="M12 5v14M5 12h14" />
            </svg>
            新增番剧
          </button>
        </div>
      </div>

      <div class="cat-bar">
        <span class="chips">
          <span
            v-for="c in CATS"
            :key="c"
            :class="{ on: category === c }"
            @click="pickCat(c)"
          >
            {{ c }}
          </span>
        </span>
      </div>

      <div v-if="errorMsg" class="alert error" style="margin: 0 20px 16px">
        <span>⚠ {{ errorMsg }}</span>
        <button class="btn ghost sm" type="button" @click="load">重新加载</button>
      </div>

      <div class="table-wrap">
        <table class="data">
          <thead>
            <tr>
              <th style="width: 66px">海报</th>
              <th>标题 / 简介</th>
              <th style="width: 100px">分类</th>
              <th style="width: 92px">集数</th>
              <th style="width: 88px">评分</th>
              <th style="width: 92px">状态</th>
              <th style="width: 130px">制作公司</th>
              <th style="width: 118px">播放源</th>
              <th style="width: 120px">操作</th>
            </tr>
          </thead>
          <tbody>
            <tr v-for="b in list" :key="b.id">
              <td>
                <img v-if="b.illust" class="thumb poster-thumb" :src="b.illust" :alt="b.title" />
                <div v-else class="thumb-fallback">无图</div>
              </td>
              <td>
                <p class="cell-main">{{ b.title }}</p>
                <p class="cell-sub">{{ b.desc || '暂无简介' }}</p>
              </td>
              <td><span class="tag sky">{{ b.category || '未分类' }}</span></td>
              <td class="num">{{ b.episodes }} 集</td>
              <td class="num"><b>{{ Number(b.score || 0).toFixed(1) }}</b> 分</td>
              <td>
                <span class="tag" :class="b.status === '连载中' ? 'rose' : 'grey'">{{ b.status || '—' }}</span>
              </td>
              <td>{{ b.studio || '—' }}</td>
              <td>
                <span v-if="b.sourceType === 'bilibili'" class="tag src-bili">哔哩哔哩</span>
                <span v-else-if="b.sourceType === 'tencent'" class="tag src-tencent">腾讯视频</span>
                <span v-else class="cell-sub">原生直链</span>
                <p v-if="b.bvid" class="cell-sub" style="margin: 4px 0 0">{{ b.bvid }}</p>
                <p v-else-if="b.vid" class="cell-sub" style="margin: 4px 0 0">{{ b.vid }}</p>
              </td>
              <td class="actions">
                <div class="row-actions">
                  <button class="btn ghost sm" type="button" @click="openEdit(b)">编辑</button>
                  <button class="btn danger sm" type="button" @click="askDelete(b)">删除</button>
                </div>
              </td>
            </tr>
          </tbody>
        </table>

        <div v-if="loading" class="state">
          <i class="loader-spin"></i>
          <p style="margin-top: 10px">加载中…</p>
        </div>
        <div v-else-if="!list.length" class="state">
          <svg width="38" height="38" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6">
            <path d="M4 5h16v14H4zM8 5v14M4 9h4" />
          </svg>
          <p>该分类下暂无番剧</p>
        </div>
      </div>

      <div v-if="total > 0" class="pager">
        <span class="info">共 {{ total }} 部番剧 · 第 {{ page }} / {{ totalPages }} 页</span>
        <div class="pages">
          <button type="button" :disabled="page === 1" @click="goPage(page - 1)">上一页</button>
          <button
            v-for="p in pageNumbers"
            :key="p"
            type="button"
            :class="{ on: p === page }"
            @click="goPage(p)"
          >
            {{ p }}
          </button>
          <button type="button" :disabled="page === totalPages" @click="goPage(page + 1)">下一页</button>
        </div>
      </div>
    </div>

    <!-- ============ 新增 / 编辑弹窗 ============ -->
    <div v-if="editing" class="modal-mask" @click.self="closeEdit">
      <div class="modal">
        <div class="modal-head">
          <h3>{{ isEdit ? '编辑番剧' : '新增番剧' }}</h3>
          <button class="close" type="button" @click="closeEdit">
            <svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round">
              <path d="M18 6L6 18M6 6l12 12" />
            </svg>
          </button>
        </div>

        <div class="modal-body">
          <p v-if="formError" class="alert error">⚠ {{ formError }}</p>

          <div class="form-grid">
            <div class="form-item full">
              <label>番剧标题<span class="req">*</span></label>
              <input v-model="form.title" type="text" placeholder="如：超时空辉夜姬" />
            </div>

            <div class="form-item">
              <label>分类</label>
              <select v-model="form.category">
                <option v-for="c in CATS.slice(1)" :key="c" :value="c">{{ c }}</option>
              </select>
              <span class="desc">决定首页分类 Tab 的分组</span>
            </div>

            <div class="form-item">
              <label>状态</label>
              <select v-model="form.status">
                <option value="连载中">连载中</option>
                <option value="已完结">已完结</option>
                <option value="预告">预告</option>
              </select>
            </div>

            <div class="form-item">
              <label>总集数<span class="req">*</span></label>
              <input v-model="form.episodes" type="number" min="1" />
            </div>

            <div class="form-item">
              <label>评分<span class="req">*</span></label>
              <input v-model="form.score" type="number" step="0.1" min="0" max="10" />
            </div>

            <div class="form-item">
              <label>制作公司</label>
              <input v-model="form.studio" type="text" placeholder="如：苍崎制作" />
            </div>

            <div class="form-item">
              <label>标签</label>
              <input v-model="form.tags" type="text" placeholder="热血/战斗/原创" />
              <span class="desc">斜杠分隔</span>
            </div>

            <div class="form-item full">
              <label>简介</label>
              <textarea v-model="form.description" placeholder="番剧简介"></textarea>
            </div>

            <div class="form-item full">
              <label>封面图 URL</label>
              <input v-model="form.coverUrl" type="text" placeholder="留空则沿用该番剧已有的内联插画" />
              <span class="desc">编辑时留空不会清空原有插画</span>
            </div>

            <div class="form-item full">
              <label>播放源类型</label>
              <select v-model="form.sourceType" class="form-select">
                <option value="native">原生直链（mp4 等直链文件）</option>
                <option value="tencent">腾讯视频（iframe 官方播放器）</option>
                <option value="bilibili">哔哩哔哩（iframe 官方播放器）</option>
              </select>
              <span class="desc">腾讯视频 / 哔哩哔哩由服务端依据 VID / BV 号自动拼装播放地址</span>
            </div>

            <div class="form-item full">
              <label>腾讯视频 VID</label>
              <input
                v-model="form.vid"
                type="text"
                placeholder="如：v3186hgiqhs"
                :disabled="form.sourceType !== 'tencent'"
              />
              <span class="desc">仅腾讯视频源需要填写</span>
            </div>

            <div class="form-item full">
              <label>哔哩哔哩 BV 号</label>
              <input
                v-model="form.bvid"
                type="text"
                placeholder="如：BV145G1z9E71 或 BV145G1z9E71?p=1"
                :disabled="form.sourceType !== 'bilibili'"
              />
              <span class="desc">仅哔哩哔哩源需要填写，可直接粘贴完整播放页地址</span>
            </div>

            <div class="form-item full">
              <label>原生播放地址</label>
              <input
                v-model="form.src"
                type="text"
                placeholder="https://.../video.mp4"
                :disabled="form.sourceType !== 'native'"
              />
              <span v-if="form.sourceType !== 'native'" class="desc">非原生源无需填写，保存时会自动生成 iframe 播放地址</span>
            </div>

            <div class="form-item full">
              <label>封面渐变 CSS</label>
              <input v-model="form.coverGradient" type="text" placeholder="linear-gradient(135deg,#ff8fb1,#c084fc)" />
            </div>
          </div>
        </div>

        <div class="modal-foot">
          <button class="btn ghost" type="button" :disabled="saving" @click="closeEdit">取消</button>
          <button class="btn primary" type="button" :disabled="saving" @click="submit">
            {{ saving ? '保存中…' : '保存' }}
          </button>
        </div>
      </div>
    </div>
  </div>
</template>

<style scoped>
.cat-bar {
  padding: 0 20px 16px;
}
.poster-thumb {
  height: 52px;
  width: 40px;
}
</style>
