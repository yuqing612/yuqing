<script setup>
/* 轻量吐司提示：后台各页共用，通过 props 控制显示与文案 */
defineProps({
  show: { type: Boolean, default: false },
  message: { type: String, default: '' },
  type: { type: String, default: 'ok' } // ok / err
})
</script>

<template>
  <div class="toast-wrap">
    <transition name="toast-pop">
      <div v-if="show" class="toast" :class="type">
        <svg v-if="type === 'ok'" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round">
          <path d="M20 6L9 17l-5-5" />
        </svg>
        <svg v-else width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round">
          <path d="M18 6L6 18M6 6l12 12" />
        </svg>
        <span>{{ message }}</span>
      </div>
    </transition>
  </div>
</template>

<style scoped>
.toast-pop-enter-active {
  transition: opacity 0.26s cubic-bezier(0.2, 0.8, 0.25, 1), transform 0.26s cubic-bezier(0.2, 0.8, 0.25, 1);
}
.toast-pop-leave-active {
  transition: opacity 0.2s;
}
.toast-pop-enter-from {
  opacity: 0;
  transform: translateY(-14px);
}
.toast-pop-leave-to {
  opacity: 0;
}
</style>
