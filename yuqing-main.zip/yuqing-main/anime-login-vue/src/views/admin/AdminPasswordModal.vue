<script setup>
/* =========================================================
   后台「修改密码」弹窗
   - 调用 POST /api/admin/auth/password（oldPassword / newPassword）
   - 后端在改密成功后会立即作废该账号此前签发的所有令牌，
     因此改密成功后前端主动清理令牌并回到登录页
   - 密码规则与前台一致：6-15 位，须含数字、大小写字母、特殊字符
   ========================================================= */
import { ref, reactive, computed, watch } from 'vue'
import { adminChangePassword, clearAdminAuth } from '../../api/admin'
import AdminToast from './AdminToast.vue'

const props = defineProps({
  show: { type: Boolean, default: false }
})
const emit = defineEmits(['close', 'done'])

const form = reactive({ oldPassword: '', newPassword: '', confirmPassword: '' })
const loading = ref(false)
const errorMessage = ref('')
const toast = reactive({ show: false, message: '', type: 'ok' })

/* 前端先行校验，规则与后端 Regexp.PASSWORD 保持一致 */
const PASSWORD_RE = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[\W_]).{6,15}$/

const newPasswordHint = computed(() => {
  const v = form.newPassword
  if (!v) return ''
  if (v.length < 6 || v.length > 15) return '密码需为 6-15 位'
  const checks = [
    { ok: /[a-z]/.test(v), text: '小写字母' },
    { ok: /[A-Z]/.test(v), text: '大写字母' },
    { ok: /\d/.test(v), text: '数字' },
    { ok: /[\W_]/.test(v), text: '特殊字符' }
  ]
  const missing = checks.filter((c) => !c.ok).map((c) => c.text)
  return missing.length ? `还需包含：${missing.join('、')}` : '密码强度符合要求'
})
const newPasswordOk = computed(() => PASSWORD_RE.test(form.newPassword))

/* 打开时重置表单与报错，避免上次残留 */
watch(
  () => props.show,
  (val) => {
    if (val) {
      form.oldPassword = ''
      form.newPassword = ''
      form.confirmPassword = ''
      errorMessage.value = ''
    }
  }
)

function showToast(message, type = 'ok') {
  toast.message = message
  toast.type = type
  toast.show = true
  setTimeout(() => (toast.show = false), 2600)
}

async function onSubmit() {
  if (loading.value) return
  errorMessage.value = ''

  if (!form.oldPassword) {
    errorMessage.value = '请输入原密码'
    return
  }
  if (!form.newPassword) {
    errorMessage.value = '请输入新密码'
    return
  }
  if (!newPasswordOk.value) {
    errorMessage.value = '新密码需为 6-15 位，且包含数字、大小写字母和特殊字符'
    return
  }
  if (form.newPassword !== form.confirmPassword) {
    errorMessage.value = '两次输入的新密码不一致'
    return
  }
  if (form.newPassword === form.oldPassword) {
    errorMessage.value = '新密码不能与原密码相同'
    return
  }

  loading.value = true
  try {
    await adminChangePassword({
      oldPassword: form.oldPassword,
      newPassword: form.newPassword
    })
    showToast('密码修改成功，请重新登录')
    // 后端已作废全部旧令牌，本地凭证必须一并清掉
    clearAdminAuth()
    setTimeout(() => emit('done'), 900)
  } catch (e) {
    errorMessage.value = e.message || '修改失败，请稍后再试'
  } finally {
    loading.value = false
  }
}
</script>

<template>
  <div v-if="show" class="modal-mask" @click.self="emit('close')">
    <div class="modal narrow pwd-modal">
      <div class="modal-head">
        <h3>修改密码</h3>
        <button class="close" type="button" @click="emit('close')">
          <svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round">
            <path d="M18 6L6 18M6 6l12 12" />
          </svg>
        </button>
      </div>

      <form novalidate @submit.prevent="onSubmit">
        <div class="modal-body">
          <p class="pwd-tip">
            密码规则：6-15 位，须同时包含数字、大小写字母和特殊字符。
            修改成功后需要重新登录。
          </p>

          <p v-if="errorMessage" class="err-bar">{{ errorMessage }}</p>

          <label class="fld">
            <span>原密码</span>
            <input v-model="form.oldPassword" type="password" placeholder="请输入原密码" autocomplete="current-password" />
          </label>

          <label class="fld">
            <span>新密码</span>
            <input v-model="form.newPassword" type="password" placeholder="请输入新密码" autocomplete="new-password" />
            <em v-if="newPasswordHint" :class="newPasswordOk ? 'ok' : 'warn'">{{ newPasswordHint }}</em>
          </label>

          <label class="fld">
            <span>确认新密码</span>
            <input v-model="form.confirmPassword" type="password" placeholder="请再次输入新密码" autocomplete="new-password" />
          </label>
        </div>

        <div class="modal-foot">
          <button class="btn ghost" type="button" :disabled="loading" @click="emit('close')">取消</button>
          <button class="btn primary" type="submit" :disabled="loading">
            {{ loading ? '提交中…' : '确认修改' }}
          </button>
        </div>
      </form>
    </div>
  </div>

  <AdminToast :show="toast.show" :message="toast.message" :type="toast.type" />
</template>

<style scoped>
.pwd-modal {
  max-width: 420px;
}

.pwd-tip {
  font-size: 12px;
  line-height: 1.75;
  color: var(--ink-soft);
  background: rgba(125, 211, 252, 0.09);
  border: 1px solid rgba(125, 211, 252, 0.28);
  border-radius: 12px;
  padding: 10px 13px;
  margin-bottom: 16px;
}

.err-bar {
  font-size: 12.5px;
  color: #b42318;
  background: rgba(244, 63, 94, 0.1);
  border: 1px solid rgba(244, 63, 94, 0.28);
  border-radius: 10px;
  padding: 9px 13px;
  margin-bottom: 14px;
}

.fld {
  display: block;
  margin-bottom: 15px;
}
.fld > span {
  display: block;
  font-size: 12.5px;
  font-weight: 600;
  color: var(--ink-soft);
  margin-bottom: 7px;
}
.fld input {
  width: 100%;
  height: 42px;
  padding: 0 14px;
  border-radius: 12px;
  border: 1.5px solid var(--line);
  background: #fff;
  font-size: 13.5px;
  color: var(--ink);
  font-family: inherit;
  outline: none;
  transition: 0.22s;
}
.fld input:focus {
  border-color: #c9a7ff;
  box-shadow: 0 0 0 4px rgba(192, 132, 252, 0.12);
}
.fld em {
  display: block;
  font-style: normal;
  font-size: 11.5px;
  margin-top: 6px;
}
.fld em.ok {
  color: #10b981;
}
.fld em.warn {
  color: #d97706;
}
</style>
