<script setup>
/* 删除确认弹窗：后台各页共用 */
defineProps({
  show: { type: Boolean, default: false },
  title: { type: String, default: '确认删除' },
  message: { type: String, default: '' },
  loading: { type: Boolean, default: false }
})
const emit = defineEmits(['confirm', 'cancel'])
</script>

<template>
  <div v-if="show" class="modal-mask" @click.self="emit('cancel')">
    <div class="modal narrow">
      <div class="modal-head">
        <h3>{{ title }}</h3>
        <button class="close" type="button" @click="emit('cancel')">
          <svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round">
            <path d="M18 6L6 18M6 6l12 12" />
          </svg>
        </button>
      </div>
      <div class="modal-body">
        <p class="confirm-text" v-html="message"></p>
      </div>
      <div class="modal-foot">
        <button class="btn ghost" type="button" :disabled="loading" @click="emit('cancel')">取消</button>
        <button class="btn danger" type="button" :disabled="loading" @click="emit('confirm')">
          {{ loading ? '删除中…' : '确认删除' }}
        </button>
      </div>
    </div>
  </div>
</template>
