/* =========================================================
   mock 数据层（仅前端演示用，后端就绪后可整体移除）
   所有函数返回 Promise，模拟网络延迟，数据结构与真实
   /api 返回保持一致，页面通过 api/index.js 门面调用，
   不感知数据来自 mock 还是后端。
   ========================================================= */

import { BANGUMI_ILLUST } from '../assets/bangumi'

const delay = (ms = 160) => new Promise((r) => setTimeout(r, ms))

/* ---------- 视频（首页推荐 / 收藏 / 排行共用） ---------- */
export const VIDEOS = [
  {
    id: 1,
    title: '《总之就是非常可爱》',
    uploader: '动漫共和国',
    views: '2.2亿',
    play: 220000000,
    danmaku: '306.4万',
    duration: '23:41',
    tags: ['恋爱', '日常', '漫画改', '甜', '校园'],
    desc: '由崎星空对神秘美少女——司一见钟情。面对星空决死的告白，她的回答是「如果你愿意和我结婚，那我就跟你交往」？！充满了星空与司的爱，可爱&高贵的新婚生活开始了！全 12 话正片。',
    fav: true,
    grad: 'linear-gradient(135deg,#7dd3fc,#ff8fb1)',
    coverUrl: '/tonikawa.webp',
    /* 动漫共和国源：sourceType = omofun，m3u8 由 hls.js 直连播放 */
    sourceType: 'omofun',
    omofunId: '43835',
    src: 'https://www.omofun23.com/index.php/vod/play/id/43835/sid/1/nid/1.html'
  },
  {
    id: 2,
    title: '纸片人女友的一天 · 原创短篇动画',
    uploader: '星屑工坊',
    views: '56.1万',
    play: 561000,
    danmaku: '8742',
    duration: '08:47',
    tags: ['原创', '日常', '甜'],
    desc: '从清晨的第一缕光到深夜的台灯，她把平凡的日子过成了童话。',
    fav: false,
    grad: 'linear-gradient(135deg,#7dd3fc,#a78bfa)'
  },
  {
    id: 3,
    title: '雨夜便利店 · 慢节奏 ASMR 白噪音',
    uploader: '夜猫电台',
    views: '23.9万',
    play: 239000,
    danmaku: '1920',
    duration: '30:00',
    tags: ['ASMR', '助眠', '雨声'],
    desc: '关东煮的热气、窗外的雨、以及永远为你亮着的那盏灯。',
    fav: true,
    grad: 'linear-gradient(135deg,#c084fc,#7dd3fc)'
  },
  {
    id: 4,
    title: '超时空辉夜姬',
    uploader: '多叻嘿嘿',
    views: '1.9万',
    play: 19548,
    danmaku: '13',
    duration: '02:21:23',
    tags: ['同人', '战斗', '燃'],
    desc: '为了夺回被夺走的星光，少女拔出了沉睡千年的剑。',
    fav: false,
    grad: 'linear-gradient(135deg,#ff6f9c,#c084fc)',
    coverUrl: '/kaguya.webp',
    /* 哔哩哔哩源：sourceType = bilibili 时前端用 iframe 嵌入官方播放器 */
    sourceType: 'bilibili',
    bvid: 'BV1Lk8C6bE3z?p=3',
    src: 'https://player.bilibili.com/player.html?bvid=BV1Lk8C6bE3z&p=3&autoplay=0&high_quality=1&danmaku=0'
  },
  {
    id: 5,
    title: '猫咪咖啡馆营业中 · 治愈 vlog',
    uploader: '软糖日记',
    views: '78.4万',
    play: 784000,
    danmaku: '4531',
    duration: '12:33',
    tags: ['vlog', '猫', '治愈'],
    desc: '三只店长猫，一杯手冲，和刚好路过的你。',
    fav: false,
    grad: 'linear-gradient(135deg,#ffd98a,#ff8fb1)'
  },
  {
    id: 6,
    title: '赛马娘芦毛灰姑娘',
    uploader: '哔哩哔哩番剧',
    views: '466.7万',
    play: 4667408,
    danmaku: '1.1万',
    duration: '23:47',
    tags: ['赛马娘', '热血', '运动', '原创动画'],
    desc: '《周刊YOUNG JUMP》销量破 800 万的漫画终于动画化。地方出身的怪物小栗帽，迎战人称「最强」的玉藻十字。灰扑扑的少女，踏入全新的领域——驰骋火热梦想的灰姑娘故事，继续奔跑。',
    fav: true,
    grad: 'linear-gradient(135deg,#a78bfa,#7dd3fc)',
    coverUrl: '/umamusume.webp',
    /* 哔哩哔哩源：sourceType = bilibili 时前端用 iframe 嵌入官方播放器 */
    sourceType: 'bilibili',
    bvid: 'BV145G1z9E71',
    src: 'https://player.bilibili.com/player.html?bvid=BV145G1z9E71&p=1&autoplay=0&high_quality=1&danmaku=0'
  },
  {
    id: 7,
    title: '深夜画室 · 厚涂立绘绘制过程',
    uploader: '小满Official',
    views: '45.2万',
    play: 452000,
    danmaku: '3201',
    duration: '21:08',
    tags: ['绘画', '教程', '厚涂'],
    desc: '从线稿到高光，一笔一画把纸片人养成会呼吸的少女。',
    fav: false,
    grad: 'linear-gradient(135deg,#ff8fb1,#a78bfa)'
  },
  {
    id: 8,
    title: '赛马娘第二季',
    uploader: '哔哩哔哩番剧',
    views: '7075.4万',
    play: 70754000,
    danmaku: '47.1万',
    duration: '23:56',
    tags: ['赛马娘', '热血', '运动', '偶像', '催泪'],
    desc: '憧憬着皇帝，向不败的三连冠冲刺的马娘东海帝皇，以及背负着名家的荣耀，向天皇赏连霸发起挑战的目白麦昆。二人既是对手，也是伙伴，一同向着梦想——「闪光系列赛」的优胜，全力奔跑！',
    fav: true,
    grad: 'linear-gradient(135deg,#a78bfa,#7dd3fc)',
    coverUrl: '/umamusume-s2.webp',
    /* 哔哩哔哩源：sourceType = bilibili 时前端用 iframe 嵌入官方播放器 */
    sourceType: 'bilibili',
    bvid: 'BV1Yv411x7n5',
    src: 'https://player.bilibili.com/player.html?bvid=BV1Yv411x7n5&p=1&autoplay=0&high_quality=1&danmaku=0'
  }
]

/* 公开示例视频，仅作播放占位，后端就绪后替换为真实地址 */
export const VIDEO_SRC = {
  1: 'https://www.omofun23.com/index.php/vod/play/id/43835/sid/1/nid/1.html',
  2: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4',
  3: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4',
  /* 超时空辉夜姬走哔哩哔哩 iframe 播放器，见 VIDEOS[3].src */
  4: 'https://player.bilibili.com/player.html?bvid=BV1Lk8C6bE3z&p=3&autoplay=0&high_quality=1&danmaku=0',
  5: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4',
  /* 赛马娘芦毛灰姑娘走哔哩哔哩 iframe 播放器，见 VIDEOS[5].src */
  6: 'https://player.bilibili.com/player.html?bvid=BV145G1z9E71&p=1&autoplay=0&high_quality=1&danmaku=0',
  7: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4',
  /* 赛马娘第二季走哔哩哔哩 iframe 播放器，见 VIDEOS[7].src */
  8: 'https://player.bilibili.com/player.html?bvid=BV1Yv411x7n5&p=1&autoplay=0&high_quality=1&danmaku=0'
}

/* =========================================================
   视频分集播放源（mock）
   真实数据来自 video_episode 表，由后端随视频列表一并下发；
   这里给 mock 模式准备一份等价结构，便于脱离后端也能看选集面板。
   ========================================================= */
const VIDEO_EPISODES = {
  1: [
    { epNo: 1, title: '结婚', m3u8Url: 'https://vodcnd09.ajupf.com/20251008/Y8RoHmhl/index.m3u8', duration: 1421000, vip: false },
    { epNo: 2, title: '初夜', m3u8Url: 'https://vodcnd09.ajupf.com/20251008/Q5F5NSWo/index.m3u8', duration: 1421000, vip: true },
    { epNo: 3, title: '姐妹', m3u8Url: 'https://vodcnd09.ajupf.com/20251008/69Y49RGm/index.m3u8', duration: 1421000, vip: true },
    { epNo: 4, title: '约定', m3u8Url: 'https://vodcnd09.ajupf.com/20251008/AvXIWivo/index.m3u8', duration: 1421000, vip: true },
    { epNo: 5, title: '戒指', m3u8Url: 'https://vodcnd09.ajupf.com/20251008/skGJyyTH/index.m3u8', duration: 1421000, vip: true },
    { epNo: 6, title: '报告', m3u8Url: 'https://vodcnd09.ajupf.com/20251008/AqJMS4Qq/index.m3u8', duration: 1421000, vip: true },
    { epNo: 7, title: '旅行', m3u8Url: 'https://vodcnd09.ajupf.com/20251008/OsbF19iK/index.m3u8', duration: 1421000, vip: true },
    { epNo: 8, title: '亲子', m3u8Url: 'https://vodcnd09.ajupf.com/20251008/xvAVkKLR/index.m3u8', duration: 1421000, vip: true },
    { epNo: 9, title: '日常', m3u8Url: 'https://vodcnd09.ajupf.com/20251008/38DN167T/index.m3u8', duration: 1421000, vip: true },
    { epNo: 10, title: '归路', m3u8Url: 'https://vodcnd09.ajupf.com/20251008/ZGGhxdn3/index.m3u8', duration: 1421000, vip: true },
    { epNo: 11, title: '友人', m3u8Url: 'https://vodcnd09.ajupf.com/20251008/pnpLnceA/index.m3u8', duration: 1421000, vip: true },
    { epNo: 12, title: '夫妻', m3u8Url: 'https://vodcnd09.ajupf.com/20251008/DhtxnlRc/index.m3u8', duration: 1421000, vip: true }
  ],
  8: [
    { epNo: 1, title: '东海帝王', bvid: 'BV1Yv411x7n5', duration: 1436000, vip: false },
    { epNo: 2, title: '绝不让步', bvid: 'BV1ev411x7Ao', duration: 1436000, vip: true },
    { epNo: 3, title: '邂逅', bvid: 'BV1PU4y147g8', duration: 1436000, vip: true },
    { epNo: 4, title: 'TM对决', bvid: 'BV1Mh41117Nz', duration: 1436000, vip: true },
    { epNo: 5, title: '不败和连霸', bvid: 'BV1AU4y1x74L', duration: 1436000, vip: true },
    { epNo: 6, title: '为了什么', bvid: 'BV1L54y1W7Ar', duration: 1436000, vip: true },
    { epNo: 7, title: '祝福之名', bvid: 'BV1xA411M7QS', duration: 1436000, vip: true },
    { epNo: 8, title: '小小的祈愿', bvid: 'BV1aA411M7Fo', duration: 1436000, vip: true },
    { epNo: 9, title: '秒表', bvid: 'BV1Ur4y1A7h5', duration: 1436000, vip: true },
    { epNo: 10, title: '一定 必定', bvid: 'BV1Jy4y187je', duration: 1436000, vip: true },
    { epNo: 11, title: '这个心情是', bvid: 'BV1Bh411Q79Z', duration: 1436000, vip: true },
    { epNo: 12, title: '两人', bvid: 'BV1zh411Q7B5', duration: 1436000, vip: true },
    { epNo: 13, title: '驰骋于梦想中', bvid: 'BV1Nf4y1x7rf', duration: 1436000, vip: true }
  ]
}

/* 由 bvid 拼装 B 站官方 iframe 播放器地址，与后端 buildBilibiliSrc 保持一致 */
function buildBiliSrc(bvid) {
  return `https://player.bilibili.com/player.html?bvid=${bvid}&p=1&autoplay=0&high_quality=1&danmaku=0`
}

/* 给视频挂上分集播放源（结构与后端 video_episode 出参一致） */
function withEpisodes(v) {
  const eps = VIDEO_EPISODES[v.id]
  return {
    ...v,
    episodeList: eps
      ? eps.map((e) => ({
          ...e,
          // m3u8 源直连播放，B 站源走官方 iframe 播放器
          src: e.m3u8Url || buildBiliSrc(e.bvid)
        }))
      : []
  }
}

/* =========================================================
   番剧分集播放源（mock）
   真实数据来自 bangumi_episode 表，由后端下发；
   这里给 mock 模式准备一份等价结构，便于脱离后端也能看选集面板。
   ========================================================= */
const BANGUMI_EPISODES = {
  102: [
    { epNo: 1, title: '横空出世', bvid: 'BV145G1z9E71', duration: 1427000, vip: false },
    { epNo: 2, title: '让我出赛吧', bvid: 'BV1TVG1zsEhh', duration: 1427000, vip: true },
    { epNo: 3, title: '顶峰的景色', bvid: 'BV1zkV2z7Egk', duration: 1425966, vip: true },
    { epNo: 4, title: '初级皇冠赛', bvid: 'BV1fkV2z7ECr', duration: 1427000, vip: true },
    { epNo: 5, title: '最好的选择', bvid: 'BV1y4jJzWEzB', duration: 1421000, vip: true },
    { epNo: 6, title: '怪物', bvid: 'BV1To7GzyEdR', duration: 1427000, vip: true },
    { epNo: 7, title: '特雷森学园', bvid: 'BV1tpTTzKEPr', duration: 1425966, vip: true },
    { epNo: 8, title: '正确的资质', bvid: 'BV1CWMuzTE5f', duration: 1426000, vip: true },
    { epNo: 9, title: '日本德比', bvid: 'BV1qPKczcEr1', duration: 1425924, vip: true },
    { epNo: 10, title: '最强', bvid: 'BV1rKKEzXEdJ', duration: 1427000, vip: true },
    { epNo: 11, title: '笠松的明星', bvid: 'BV1nv3uz6ELE', duration: 1426000, vip: true },
    { epNo: 12, title: '天皇赏（秋）', bvid: 'BV1du31zPEMD', duration: 1427000, vip: true },
    { epNo: 13, title: '日本第一', bvid: 'BV1ztuizGEmR', duration: 1366000, vip: true },
    { epNo: 14, title: '新的山峰', bvid: 'BV1Gt2MBFERH', duration: 1427000, vip: true },
    { epNo: 15, title: '我们的故事', bvid: 'BV1qJ2MBvEw4', duration: 1426000, vip: true },
    { epNo: 16, title: '世界级', bvid: 'BV1GTCeBZE1r', duration: 1427000, vip: true },
    { epNo: 17, title: '日本杯', bvid: 'BV12nUgBbE4d', duration: 1427000, vip: true },
    { epNo: 18, title: '狂野滑稽表演者', bvid: 'BV1wqSCBDEzM', duration: 1427000, vip: true },
    { epNo: 19, title: '未知的「领域」', bvid: 'BV1Ct2aBjEDm', duration: 1427000, vip: true },
    { epNo: 20, title: '答案', bvid: 'BV11dmCBDEgX', duration: 1426000, vip: true },
    { epNo: 21, title: '有马纪念', bvid: 'BV1T2BSBUE9R', duration: 1427000, vip: true },
    { epNo: 22, title: '灰发怪物', bvid: 'BV14XvHBFEi8', duration: 1426000, vip: true },
    { epNo: 23, title: '新时代', bvid: 'BV1arvHBqEW2', duration: 1412000, vip: true }
  ]
}

/* ---------- 番剧时间表（每周更新表，mock） ---------- */
export const WEEKDAYS = ['周一', '周二', '周三', '周四', '周五', '周六', '周日']
export const SCHEDULE = {
  周一: [
    { title: '星屑列车开往黎明', ep: 8, time: '20:00' },
    { title: '便利屋猫咪日记', ep: 6, time: '22:30' }
  ],
  周二: [
    { title: '魔法少女小满的午后', ep: 19, time: '19:30' },
    { title: '深空抒情诗', ep: 5, time: '21:00' }
  ],
  周三: [
    { title: '晚晴剑歌', ep: 7, time: '20:30' },
    { title: '机甲学徒守则', ep: 4, time: '23:00' }
  ],
  周四: [
    { title: '樱色咖啡店物语', ep: 14, time: '20:00' },
    { title: '妖怪百物语·春', ep: 9, time: '22:00' }
  ],
  周五: [
    { title: '星屑列车开往黎明', ep: 9, time: '20:00' },
    { title: '深空抒情诗', ep: 6, time: '21:00' }
  ],
  周六: [
    { title: '魔法少女小满的午后', ep: 20, time: '18:00' },
    { title: '晚晴剑歌', ep: 8, time: '20:30' },
    { title: '机甲学徒守则', ep: 5, time: '23:00' }
  ],
  周日: [
    { title: '樱色咖啡店物语', ep: 15, time: '19:00' },
    { title: '妖怪百物语·春', ep: 10, time: '21:30' }
  ]
}
/* ---------- 番剧 ---------- */
export const BANGUMI = [
  { id: 101, title: '星屑列车开往黎明', cover: 'linear-gradient(135deg,#ff8fb1,#c084fc)', episodes: 12, status: '连载中', score: 9.2, studio: '桜动画', category: '日漫', tags: ['原创', '科幻', '治愈'], desc: '末日后的轨道上，少女与一台会说话的旧列车驶向传说的黎明站。' },
  { id: 102, title: '赛马娘芦毛灰姑娘', cover: 'linear-gradient(135deg,#ff6f9c,#c084fc)', episodes: 23, status: '已完结', score: 9.9, studio: 'CygamesPictures', category: '日漫', tags: ['漫画改', '热血', '运动', '励志'], desc: '《周刊YOUNG JUMP》销量破 800 万的漫画终于动画化。地方出身的怪物小栗帽，迎战人称「最强」的玉藻十字。灰扑扑的少女，即将踏入全新的领域——驰骋火热梦想的灰姑娘故事，继续奔跑！', coverUrl: '/umamusume-poster.webp', sourceType: 'bilibili', bvid: 'BV145G1z9E71', src: 'https://player.bilibili.com/player.html?bvid=BV145G1z9E71&p=1&autoplay=0&high_quality=1&danmaku=0' },
  { id: 103, title: '晚晴剑歌', cover: 'linear-gradient(135deg,#ff6f9c,#c084fc)', episodes: 13, status: '连载中', score: 9.0, studio: '苍崎制作', category: '国漫', tags: ['武侠', '古风', '燃'], desc: '一把断剑，一座空城，她在雨里等一个再也不会回来的人。' },
  { id: 104, title: '便利屋猫咪日记', cover: 'linear-gradient(135deg,#ffd98a,#ff8fb1)', episodes: 10, status: '已完结', score: 8.4, studio: '软糖动画', category: '日漫', tags: ['治愈', '猫', '日常'], desc: '帮邻居送牛奶、替老人修水管，顺手拯救一下世界也不错。' },
  { id: 105, title: '深空抒情诗', cover: 'linear-gradient(135deg,#a78bfa,#7dd3fc)', episodes: 12, status: '连载中', score: 8.9, studio: '棱镜动画', category: '日漫', tags: ['太空', '音乐', '群像'], desc: '一艘载满歌声的飞船，在星云间寻找失落的故乡频率。' },
  { id: 106, title: '樱色咖啡店物语', cover: 'linear-gradient(135deg,#ff8fb1,#a78bfa)', episodes: 24, status: '已完结', score: 8.6, studio: '桜动画', category: '日漫', tags: ['美食', '治愈', '群像'], desc: '转角那家咖啡店，每位客人都带着一段想被温柔接住的故事。' },
  { id: 107, title: '机甲学徒守则', cover: 'linear-gradient(135deg,#c084fc,#7dd3fc)', episodes: 13, status: '连载中', score: 8.8, studio: '青空制作', category: '国漫', tags: ['机甲', '校园', '热血'], desc: '入学第一天，她把全校最强的机甲拆成了零件标本。' },
  { id: 108, title: '妖怪百物语·春', cover: 'linear-gradient(135deg,#ff6f9c,#a78bfa)', episodes: 11, status: '已完结', score: 9.1, studio: '苍崎制作', category: '日漫', tags: ['妖怪', '单元剧', '和风'], desc: '春夜里，妖怪们排队来借一样人类弄丢的东西。' },
  { id: 109, title: '星海航路·剧场版', cover: 'linear-gradient(135deg,#7dd3fc,#ff8fb1)', episodes: 1, status: '已完结', score: 9.3, studio: '棱镜动画', category: '剧场', tags: ['剧场版', '科幻', '冒险'], desc: '一封信，一片海，和一场跨越十二年的告别。' },
  { id: 110, title: '樱之纪念日·剧场版', cover: 'linear-gradient(135deg,#ff8fb1,#c084fc)', episodes: 1, status: '已完结', score: 9.0, studio: '桜动画', category: '剧场', tags: ['剧场版', '恋爱', '催泪'], desc: '樱花落下的速度，刚好是我想起你的速度。' },
  { id: 111, title: '赛博小吃街', cover: 'linear-gradient(135deg,#c084fc,#ff8fb1)', episodes: 16, status: '连载中', score: 8.5, studio: '青空制作', category: '国漫', tags: ['美食', '科幻', '单元剧'], desc: '霓虹灯下的深夜食堂，每碗面都藏着一段心事。' },
  { id: 112, title: '星际巡逻队', cover: 'linear-gradient(135deg,#a78bfa,#7dd3fc)', episodes: 20, status: '连载中', score: 8.3, studio: '棱镜动画', category: '美漫', tags: ['科幻', '搞笑', '冒险'], desc: '宇宙边界的巡逻小队，今天的任务依然是——摸鱼失败。' }
]

/* ---------- 直播 ---------- */
export const LIVES = [
  { id: 201, title: '深夜绘画直播·厚涂立绘教学', streamer: '小满Official', category: '绘画', viewers: '1.2万', grad: 'linear-gradient(135deg,#ff8fb1,#c084fc)' },
  { id: 202, title: '歌回！点歌随便唱到天亮', streamer: '晚晴Official', category: '音乐', viewers: '8643', grad: 'linear-gradient(135deg,#a78bfa,#7dd3fc)' },
  { id: 203, title: '新番速看吐槽大会', streamer: '桜TV情报局', category: '杂谈', viewers: '5321', grad: 'linear-gradient(135deg,#7dd3fc,#a78bfa)' },
  { id: 204, title: '手作娘的黏土教室', streamer: '软糖日记', category: '手工', viewers: '3098', grad: 'linear-gradient(135deg,#ffd98a,#ff8fb1)' },
  { id: 205, title: '钢琴即兴· requests 开放', streamer: '棱镜现场', category: '音乐', viewers: '7120', grad: 'linear-gradient(135deg,#c084fc,#7dd3fc)' },
  { id: 206, title: '通宵通关老 RPG', streamer: '夜猫电台', category: '游戏', viewers: '4502', grad: 'linear-gradient(135deg,#ff6f9c,#c084fc)' },
  { id: 207, title: 'Vlog：逛了一整天的同人展', streamer: '星屑工坊', category: '生活', viewers: '2760', grad: 'linear-gradient(135deg,#a78bfa,#ff8fb1)' },
  { id: 208, title: '读书会·一起读轻小说', streamer: '青空书库', category: '阅读', viewers: '1984', grad: 'linear-gradient(135deg,#7dd3fc,#c084fc)' }
]

/* ===================== mock 异步接口 ===================== */
export async function mockFetchVideos() {
  await delay()
  return VIDEOS.map((v) => withEpisodes({ ...v, src: VIDEO_SRC[v.id] }))
}

export async function mockFetchVideo(id) {
  await delay()
  const v = VIDEOS.find((x) => x.id === id)
  return v ? withEpisodes({ ...v, src: VIDEO_SRC[v.id] }) : null
}

export async function mockSearchVideos(q) {
  await delay()
  const s = (q || '').trim().toLowerCase()
  if (!s) return VIDEOS.map((v) => withEpisodes({ ...v, src: VIDEO_SRC[v.id] }))
  return VIDEOS.filter(
    (v) =>
      v.title.toLowerCase().includes(s) ||
      v.uploader.toLowerCase().includes(s) ||
      v.tags.some((t) => t.toLowerCase().includes(s))
  ).map((v) => withEpisodes({ ...v, src: VIDEO_SRC[v.id] }))
}

export async function mockFetchBangumi() {
  await delay()
  /* 挂上插画：优先用 coverUrl（外部/站内图），否则回落为内置 SVG 插画
     同时按需附上分集播放源（episodeList），与后端返回结构保持一致 */
  return BANGUMI.map((b) => {
    const eps = BANGUMI_EPISODES[b.id]
    return {
      ...b,
      illust: b.coverUrl || BANGUMI_ILLUST[b.id] || null,
      episodeList: eps
        ? eps.map((e) => ({ ...e, src: buildBiliSrc(e.bvid) }))
        : []
    }
  })
}

export async function mockFetchLives() {
  await delay()
  return LIVES
}

export async function mockFetchFavorites() {
  await delay()
  return VIDEOS.filter((v) => v.fav).map((v) => withEpisodes({ ...v, src: VIDEO_SRC[v.id] }))
}

export async function mockFetchRanks() {
  await delay()
  return [...VIDEOS]
    .sort((a, b) => b.play - a.play)
    .map((v, i) => withEpisodes({ ...v, src: VIDEO_SRC[v.id], rank: i + 1 }))
}

export async function mockFetchSchedule() {
  await delay()
  return { weekdays: WEEKDAYS, today: WEEKDAYS[new Date().getDay() === 0 ? 6 : new Date().getDay() - 1], items: SCHEDULE }
}
