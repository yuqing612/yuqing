/* ---------- 后台管理 API 封装 ----------
   与前台 api/index.js 完全独立的一套请求层：

   1. 独立 token：后台令牌存在 ADMIN_AUTH_KEY，与前台的 sakura_auth 分开。
      后端 AdminTokenService 用不同的签名密钥派生后台密钥，
      前台 token 访问 /api/admin/** 会直接 401，两套会话互不串味。
   2. 独立 request：只读后台 token，不会误把前台 token 发给后台接口。
   3. 全部走真实后端：后台管理没有 mock 版本，必须连真实数据库。 */

const BASE = '/api'
const ADMIN_AUTH_KEY = 'sakura_admin_auth'

/* ---------- 凭证持久化 ---------- */

export function saveAdminAuth(auth, remember) {
  clearAdminAuth()
  const store = remember ? localStorage : sessionStorage
  store.setItem(ADMIN_AUTH_KEY, JSON.stringify(auth))
}

export function getAdminAuth() {
  const raw = sessionStorage.getItem(ADMIN_AUTH_KEY) || localStorage.getItem(ADMIN_AUTH_KEY)
  if (!raw) return null
  try {
    return JSON.parse(raw)
  } catch {
    clearAdminAuth()
    return null
  }
}

export function clearAdminAuth() {
  sessionStorage.removeItem(ADMIN_AUTH_KEY)
  localStorage.removeItem(ADMIN_AUTH_KEY)
}

/* ---------- 请求层 ---------- */

async function request(path, { method = 'GET', body } = {}) {
  const headers = {}
  if (body) headers['Content-Type'] = 'application/json'
  const auth = getAdminAuth()
  if (auth && auth.token) headers['Authorization'] = `Bearer ${auth.token}`

  let res
  try {
    res = await fetch(BASE + path, {
      method,
      headers: Object.keys(headers).length ? headers : undefined,
      body: body ? JSON.stringify(body) : undefined
    })
  } catch {
    throw new Error('无法连接服务器，请确认后端已启动 (¬_¬")')
  }

  let json = null
  let parsed = false
  try {
    json = await res.json()
    parsed = true
  } catch {
    /* 非 JSON 响应 */
  }
  if (!res.ok || !json) {
    // Vite 代理在后端未启动时返回纯文本 500（ECONNREFUSED），不是业务错误。
    if (!parsed && (res.status === 500 || res.status === 502 || res.status === 503)) {
      throw new Error('后端服务未启动（8081 无响应），请先运行 启动项目.bat 或启动 springBootTest')
    }
    throw new Error((json && json.message) || `请求失败（${res.status}）`)
  }
  if (json.code === 401) {
    clearAdminAuth()
    throw Object.assign(new Error(json.message || '后台登录状态已失效，请重新登录'), { code: 401 })
  }
  if (json.code !== 200) {
    throw new Error(json.message || '操作失败，请稍后再试')
  }
  return json.data
}

/* =========================================================
   后台认证：只有登录，没有注册
   ========================================================= */
export const adminLogin = (data) => request('/admin/auth/login', { method: 'POST', body: data })
export const adminMe = () => request('/admin/auth/me')
export const adminLogout = () => request('/admin/auth/logout', { method: 'POST' })
export const adminChangePassword = (data) => request('/admin/auth/password', { method: 'POST', body: data })

/* =========================================================
   概览统计
   ========================================================= */
export const fetchAdminStats = () => request('/admin/stats')

/* =========================================================
   视频管理：首页热门推荐 / 播放器 / 热播排行
   ========================================================= */
export const fetchAdminVideos = (params = {}) => {
  const { page = 1, size = 10, keyword } = params
  const q = new URLSearchParams({ page: String(page), size: String(size) })
  if (keyword) q.set('keyword', keyword)
  return request(`/admin/videos?${q.toString()}`)
}
export const fetchAllAdminVideos = () => request('/admin/videos/list-all')
export const createAdminVideo = (data) => request('/admin/videos', { method: 'POST', body: data })
export const updateAdminVideo = (id, data) => request(`/admin/videos/${id}`, { method: 'PUT', body: data })
export const deleteAdminVideo = (id) => request(`/admin/videos/${id}`, { method: 'DELETE' })
export const toggleAdminDailyPick = (id) => request(`/admin/videos/${id}/daily-pick`, { method: 'PUT' })
export const toggleAdminFav = (id) => request(`/admin/videos/${id}/fav`, { method: 'PUT' })

/* =========================================================
   番剧管理：Hero 轮播 / 番剧新番 / 分类 Tab
   ========================================================= */
export const fetchAdminBangumi = (params = {}) => {
  const { page = 1, size = 10, keyword, category } = params
  const q = new URLSearchParams({ page: String(page), size: String(size) })
  if (keyword) q.set('keyword', keyword)
  if (category && category !== '全部') q.set('category', category)
  return request(`/admin/bangumi?${q.toString()}`)
}
export const fetchAllAdminBangumi = () => request('/admin/bangumi/list-all')
export const createAdminBangumi = (data) => request('/admin/bangumi', { method: 'POST', body: data })
export const updateAdminBangumi = (id, data) => request(`/admin/bangumi/${id}`, { method: 'PUT', body: data })
export const deleteAdminBangumi = (id) => request(`/admin/bangumi/${id}`, { method: 'DELETE' })

/* =========================================================
   番剧时间表：首页侧栏
   ========================================================= */
export const fetchAdminSchedules = () => request('/admin/schedules')
export const createAdminSchedule = (data) => request('/admin/schedules', { method: 'POST', body: data })
export const updateAdminSchedule = (id, data) => request(`/admin/schedules/${id}`, { method: 'PUT', body: data })
export const deleteAdminSchedule = (id) => request(`/admin/schedules/${id}`, { method: 'DELETE' })

/* =========================================================
   用户管理：前台注册用户
   ========================================================= */
export const fetchAdminUsers = (params = {}) => {
  const { page = 1, size = 10, keyword } = params
  const q = new URLSearchParams({ page: String(page), size: String(size) })
  if (keyword) q.set('keyword', keyword)
  return request(`/admin/users?${q.toString()}`)
}
export const toggleAdminUserStatus = (id) => request(`/admin/users/${id}/status`, { method: 'PUT' })
/* 授予 / 回收管理员权限（0 管理员 ↔ 1 默认权限） */
export const toggleAdminUserPermission = (id) => request(`/admin/users/${id}/permission`, { method: 'PUT' })
