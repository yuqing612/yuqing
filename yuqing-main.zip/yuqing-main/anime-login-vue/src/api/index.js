/* ---------- 后端 API 封装 ----------
   开发环境通过 vite 代理将 /api 转发到 http://localhost:8081
   登录凭证（token + 用户信息）持久化：
   - 勾选"记住我" → localStorage（7 天，与后端 token 有效期一致）
   - 不勾选 → sessionStorage（12 小时，关闭标签页即失效） */

const BASE = '/api'
const AUTH_KEY = 'sakura_auth'

export function saveAuth(auth, remember) {
  clearAuth()
  const store = remember ? localStorage : sessionStorage
  store.setItem(AUTH_KEY, JSON.stringify(auth))
}

export function getAuth() {
  const raw = sessionStorage.getItem(AUTH_KEY) || localStorage.getItem(AUTH_KEY)
  if (!raw) return null
  try {
    return JSON.parse(raw)
  } catch {
    clearAuth()
    return null
  }
}

export function clearAuth() {
  sessionStorage.removeItem(AUTH_KEY)
  localStorage.removeItem(AUTH_KEY)
}

async function request(path, { method = 'GET', body } = {}) {
  const headers = {}
  if (body) headers['Content-Type'] = 'application/json'
  const auth = getAuth()
  if (auth && auth.token) headers['Authorization'] = `Bearer ${auth.token}`

  let res
  try {
    res = await fetch(BASE + path, {
      method,
      headers: Object.keys(headers).length ? headers : undefined,
      body: body ? JSON.stringify(body) : undefined
    })
  } catch {
    throw new Error('无法连接服务器，请确认后端已启动 (¬_¬")')
  }

  let json = null
  try {
    json = await res.json()
  } catch {
    /* 非 JSON 响应 */
  }
  if (!res.ok || !json) {
    throw new Error((json && json.message) || `请求失败（${res.status}）`)
  }
  if (json.code === 401) {
    clearAuth()
    throw Object.assign(new Error(json.message || '登录状态已失效'), { code: 401 })
  }
  if (json.code !== 200) {
    throw new Error(json.message || '操作失败，请稍后再试')
  }
  return json.data
}

export const login = (data) => request('/auth/login', { method: 'POST', body: data })
export const register = (data) => request('/auth/register', { method: 'POST', body: data })
export const me = () => request('/auth/me')
export const logout = () => request('/auth/logout', { method: 'POST' })
