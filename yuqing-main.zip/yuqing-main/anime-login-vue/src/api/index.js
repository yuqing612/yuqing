/* ---------- 后端 API 封装 ----------
   开发环境通过 vite 代理将 /api 转发到 http://localhost:8081
   登录凭证（token + 用户信息）持久化：
   - 勾选"记住我" → localStorage（7 天，与后端 token 有效期一致）
   - 不勾选 → sessionStorage（12 小时，关闭标签页即失效） */

const BASE = '/api'
const AUTH_KEY = 'sakura_auth'

export function saveAuth(auth, remember) {
  clearAuth()
  const store = remember ? localStorage : sessionStorage
  store.setItem(AUTH_KEY, JSON.stringify(auth))
}

export function getAuth() {
  const raw = sessionStorage.getItem(AUTH_KEY) || localStorage.getItem(AUTH_KEY)
  if (!raw) return null
  try {
    return JSON.parse(raw)
  } catch {
    clearAuth()
    return null
  }
}

export function clearAuth() {
  sessionStorage.removeItem(AUTH_KEY)
  localStorage.removeItem(AUTH_KEY)
}

async function request(path, { method = 'GET', body } = {}) {
  const headers = {}
  if (body) headers['Content-Type'] = 'application/json'
  const auth = getAuth()
  if (auth && auth.token) headers['Authorization'] = `Bearer ${auth.token}`

  let res
  try {
    res = await fetch(BASE + path, {
      method,
      headers: Object.keys(headers).length ? headers : undefined,
      body: body ? JSON.stringify(body) : undefined
    })
  } catch {
    throw new Error('无法连接服务器，请确认后端已启动 (¬_¬")')
  }

  let json = null
  try {
    json = await res.json()
  } catch {
    /* 非 JSON 响应 */
  }
  if (!res.ok || !json) {
    throw new Error((json && json.message) || `请求失败（${res.status}）`)
  }
  if (json.code === 401) {
    clearAuth()
    throw Object.assign(new Error(json.message || '登录状态已失效'), { code: 401 })
  }
  if (json.code !== 200) {
    throw new Error(json.message || '操作失败，请稍后再试')
  }
  return json.data
}

export const login = (data) => request('/auth/login', { method: 'POST', body: data })
export const register = (data) => request('/auth/register', { method: 'POST', body: data })
export const me = () => request('/auth/me')
export const logout = () => request('/auth/logout', { method: 'POST' })

/* =========================================================
   首页 / 视频 / 番剧 / 直播 相关接口
   - 页面统一调用下方方法，不感知数据来自 mock 还是真实后端
   - 默认走 src/api/mockData.js（仅前端演示）
   - 后端就绪后，将 vite 环境变量 VITE_API_REAL 设为 'true'，
     即可无缝切换到真实 /api 接口，页面代码无需任何改动
   ========================================================= */
import * as mock from './mockData'

// 是否使用真实后端（默认 false → mock）
const USE_REAL = import.meta.env.VITE_API_REAL === 'true'
// 番剧模块单独开关：后端已实现番剧接口，可先于其它模块切到真实数据。
// 视频模块单独开关：后端已实现首页每日推荐 / 排行 / 搜索 / 详情接口。
// 想整体切换时把 VITE_API_REAL 设为 'true' 即可，下面各模块开关会自动跟随。
const BANGUMI_REAL = USE_REAL || import.meta.env.VITE_API_BANGUMI === 'true'
const VIDEOS_REAL = USE_REAL || import.meta.env.VITE_API_VIDEOS === 'true'

export const fetchVideos = () =>
  VIDEOS_REAL ? request('/videos') : mock.mockFetchVideos()              // GET  /api/videos
export const fetchVideo = (id) =>
  VIDEOS_REAL ? request(`/videos/${id}`) : mock.mockFetchVideo(id)       // GET  /api/videos/:id
export const searchVideos = (q) =>
  VIDEOS_REAL
    ? request(`/videos/search?q=${encodeURIComponent(q)}`)
    : mock.mockSearchVideos(q)                                          // GET  /api/videos/search?q=
export const fetchBangumi = (category) =>
  BANGUMI_REAL
    ? request(category && category !== '全部'
        ? `/bangumi?category=${encodeURIComponent(category)}`
        : '/bangumi')
    : mock.mockFetchBangumi()                                           // GET  /api/bangumi
export const fetchLives = () =>
  USE_REAL ? request('/lives') : mock.mockFetchLives()                   // GET  /api/lives
export const fetchFavorites = () =>
  USE_REAL ? request('/favorites') : mock.mockFetchFavorites()          // GET  /api/favorites
export const fetchRanks = () =>
  VIDEOS_REAL ? request('/videos/rank') : mock.mockFetchRanks()         // GET  /api/videos/rank
export const fetchSchedule = () =>
  BANGUMI_REAL ? request('/schedule') : mock.mockFetchSchedule()        // GET  /api/schedule

/* =========================================================
   首页聚合 / 分级分类搜索（后端新接口）
   - /api/home/overview：一次拿全首页数据（轮播/推荐/排行/分类/新番/时间表/热搜）
   - /api/categories：分类树（顶级分区 + 子分类），用于分级分类筛选
   - /api/search：组合搜索（关键词 + 分类 + 分级 + 排序 + 分页）
   ========================================================= */

/** 首页聚合数据 */
export const fetchHomeOverview = () =>
  request('/home/overview')                                            // GET  /api/home/overview

/** 分类树：module 取 video / bangumi / all */
export const fetchCategories = (module = 'video') =>
  request(`/categories?module=${encodeURIComponent(module)}`)           // GET  /api/categories

/**
 * 组合搜索。
 * @param {Object} opts keyword / categoryId / scope / rating / region / sort / page / size
 */
export function searchAll(opts = {}) {
  const p = new URLSearchParams()
  if (opts.keyword) p.set('keyword', opts.keyword)
  if (opts.categoryId) p.set('categoryId', opts.categoryId)
  if (opts.scope) p.set('scope', opts.scope)
  if (opts.rating) p.set('rating', opts.rating)
  if (opts.region) p.set('region', opts.region)
  if (opts.sort) p.set('sort', opts.sort)
  if (opts.page) p.set('page', opts.page)
  if (opts.size) p.set('size', opts.size)
  return request(`/search?${p.toString()}`)                            // GET  /api/search
}

/** 热门搜索词 */
export const fetchHotKeywords = (limit = 10) =>
  request(`/search/hot?limit=${limit}`)                                // GET  /api/search/hot

/** 搜索建议（输入联想） */
export const fetchSuggestions = (q, limit = 8) =>
  request(`/search/suggest?q=${encodeURIComponent(q)}&limit=${limit}`) // GET  /api/search/suggest

/* 番剧分类 Tab 数据来源（后端按表中实际分类去重返回） */
const CATS_FALLBACK = ['日漫', '国漫', '剧场', '美漫']
export const fetchBangumiCategories = () =>
  BANGUMI_REAL
    ? request('/bangumi/categories')
    : Promise.resolve(CATS_FALLBACK)                                    // GET  /api/bangumi/categories

/* =========================================================
   后台管理系统：独立会话 + 管理员 CRUD
   - 复用 /api/auth/login 登录，但仅允许 role = ADMIN 的账号进入
   - 后台会话单独存储（sakura_admin_auth），不与普通用户会话混淆
   - CRUD 全部走真实后端 /api/admin/**
   ========================================================= */
const ADMIN_AUTH_KEY = 'sakura_admin_auth'

export function saveAdminAuth(auth, remember) {
  clearAdminAuth()
  const store = remember ? localStorage : sessionStorage
  store.setItem(ADMIN_AUTH_KEY, JSON.stringify(auth))
}
export function getAdminAuth() {
  const raw = sessionStorage.getItem(ADMIN_AUTH_KEY) || localStorage.getItem(ADMIN_AUTH_KEY)
  if (!raw) return null
  try {
    return JSON.parse(raw)
  } catch {
    clearAdminAuth()
    return null
  }
}
export function clearAdminAuth() {
  sessionStorage.removeItem(ADMIN_AUTH_KEY)
  localStorage.removeItem(ADMIN_AUTH_KEY)
}

async function requestAdmin(path, { method = 'GET', body } = {}) {
  const headers = {}
  if (body) headers['Content-Type'] = 'application/json'
  const auth = getAdminAuth()
  if (auth && auth.token) headers['Authorization'] = `Bearer ${auth.token}`

  let res
  try {
    res = await fetch(BASE + path, {
      method,
      headers: Object.keys(headers).length ? headers : undefined,
      body: body ? JSON.stringify(body) : undefined
    })
  } catch {
    throw new Error('无法连接服务器，请确认后端已启动 (¬_¬")')
  }

  let json = null
  try {
    json = await res.json()
  } catch {
    /* 非 JSON 响应 */
  }
  if (!res.ok || !json) {
    throw new Error((json && json.message) || `请求失败（${res.status}）`)
  }
  if (json.code === 401) {
    clearAdminAuth()
    throw Object.assign(new Error(json.message || '登录状态已失效'), { code: 401 })
  }
  if (json.code === 403) {
    throw new Error(json.message || '无后台管理权限')
  }
  if (json.code !== 200) {
    throw new Error(json.message || '操作失败，请稍后再试')
  }
  return json.data
}

/** 后台登录：复用普通登录接口，但校验必须为管理员角色 */
export async function adminLogin(data) {
  const auth = await login(data)
  if (auth.role !== 'ADMIN') {
    // 注意：这里不要清理普通用户会话，否则用非管理员账号试登会把门户登录踢掉
    throw new Error('该账号没有后台管理权限')
  }
  return auth
}

/* ---------- 视频管理 CRUD ---------- */
export const adminListVideos = (keyword = '', page = 1, size = 10) =>
  requestAdmin(`/admin/videos?keyword=${encodeURIComponent(keyword)}&page=${page}&size=${size}`)
export const adminGetVideo = (id) => requestAdmin(`/admin/videos/${id}`)
export const adminCreateVideo = (data) =>
  requestAdmin('/admin/videos', { method: 'POST', body: data })
export const adminUpdateVideo = (id, data) =>
  requestAdmin(`/admin/videos/${id}`, { method: 'PUT', body: data })
export const adminDeleteVideo = (id) =>
  requestAdmin(`/admin/videos/${id}`, { method: 'DELETE' })

/* ---------- 番剧管理 CRUD ---------- */
export const adminListBangumi = (keyword = '', page = 1, size = 10) =>
  requestAdmin(`/admin/bangumi?keyword=${encodeURIComponent(keyword)}&page=${page}&size=${size}`)
export const adminGetBangumi = (id) => requestAdmin(`/admin/bangumi/${id}`)
export const adminCreateBangumi = (data) =>
  requestAdmin('/admin/bangumi', { method: 'POST', body: data })
export const adminUpdateBangumi = (id, data) =>
  requestAdmin(`/admin/bangumi/${id}`, { method: 'PUT', body: data })
export const adminDeleteBangumi = (id) =>
  requestAdmin(`/admin/bangumi/${id}`, { method: 'DELETE' })

