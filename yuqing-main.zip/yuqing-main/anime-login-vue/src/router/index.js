/* ---------- 路由表 ----------
   /            前台门户（登录 / 注册 / 首页 / 番剧 / 排行 / 收藏）
   /admin/login 后台管理系统登录页（只有登录，无注册）
   /admin/*     后台管理系统主体，需要后台令牌才能进入

   后台守卫：进入后台前先校验后台令牌，
   令牌失效或未登录一律重定向到登录页。

   权限守卫：后台管理系统只对管理员权限（permission=0）的账号开放，
   默认权限（permission=1）的账号即使手动输入 /admin 也会被挡回前台。 */
import { createRouter, createWebHistory } from 'vue-router'
import { getAdminAuth, adminMe } from '../api/admin'
import { getAuth, me } from '../api'

import FrontApp from '../views/FrontApp.vue'
import AdminLogin from '../views/admin/AdminLogin.vue'
import AdminLayout from '../views/admin/AdminLayout.vue'
import AdminDashboard from '../views/admin/AdminDashboard.vue'
import AdminVideos from '../views/admin/AdminVideos.vue'
import AdminBangumi from '../views/admin/AdminBangumi.vue'
import AdminSchedules from '../views/admin/AdminSchedules.vue'
import AdminUsers from '../views/admin/AdminUsers.vue'

const routes = [
  { path: '/', name: 'front', component: FrontApp },
  {
    path: '/admin/login',
    name: 'admin-login',
    component: AdminLogin,
    meta: { title: '后台登录' }
  },
  {
    path: '/admin',
    component: AdminLayout,
    meta: { requiresAdmin: true },
    children: [
      { path: '', redirect: { name: 'admin-dashboard' } },
      { path: 'dashboard', name: 'admin-dashboard', component: AdminDashboard, meta: { title: '概览' } },
      { path: 'videos', name: 'admin-videos', component: AdminVideos, meta: { title: '视频管理' } },
      { path: 'bangumi', name: 'admin-bangumi', component: AdminBangumi, meta: { title: '番剧管理' } },
      { path: 'schedules', name: 'admin-schedules', component: AdminSchedules, meta: { title: '放送计划' } },
      { path: 'users', name: 'admin-users', component: AdminUsers, meta: { title: '用户管理' } }
    ]
  },
  { path: '/:pathMatch(.*)*', redirect: '/' }
]

const router = createRouter({
  history: createWebHistory(),
  routes,
  scrollBehavior: () => ({ top: 0 })
})

router.beforeEach(async (to) => {
  // 后台相关路由（/admin/login 与 /admin/*）统一做管理员权限校验
  const isAdminRoute = to.path.startsWith('/admin')
  if (!isAdminRoute) return true

  // 1) 前台会话里已登录的账号必须是管理员权限，否则挡回前台首页
  const frontAuth = getAuth()
  if (frontAuth && frontAuth.token) {
    let frontUser = null
    try {
      frontUser = await me()
    } catch {
      /* 前台令牌失效，交给后台自身的校验处理 */
    }
    if (frontUser && frontUser.permission !== 0) {
      return { name: 'front' }
    }
  }

  // 2) 后台登录页本身只需通过上面的权限校验
  if (to.name === 'admin-login') return true

  // 3) 后台主体：必须有后台令牌，且服务端确认仍然有效
  const auth = getAdminAuth()
  if (!auth || !auth.token) {
    return { name: 'admin-login', query: { redirect: to.fullPath } }
  }
  // 已有令牌：向端确认一次是否仍然有效，避免拿过期令牌进后台再报错
  try {
    await adminMe()
    return true
  } catch {
    return { name: 'admin-login', query: { redirect: to.fullPath } }
  }
})

export default router
