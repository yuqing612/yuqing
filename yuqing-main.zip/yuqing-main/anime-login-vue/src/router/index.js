/* ---------- 路由表 ----------
   /            前台门户（登录 / 注册 / 首页 / 番剧 / 排行 / 收藏）
   /admin/login 后台管理系统登录页（只有登录，无注册）
   /admin/*     后台管理系统主体，需要后台令牌才能进入

   后台守卫：进入后台前先校验后台令牌，
   令牌失效或未登录一律重定向到登录页。 */
import { createRouter, createWebHistory } from 'vue-router'
import { getAdminAuth, adminMe } from '../api/admin'

import FrontApp from '../views/FrontApp.vue'
import AdminLogin from '../views/admin/AdminLogin.vue'
import AdminLayout from '../views/admin/AdminLayout.vue'
import AdminDashboard from '../views/admin/AdminDashboard.vue'
import AdminVideos from '../views/admin/AdminVideos.vue'
import AdminBangumi from '../views/admin/AdminBangumi.vue'
import AdminSchedules from '../views/admin/AdminSchedules.vue'
import AdminUsers from '../views/admin/AdminUsers.vue'

const routes = [
  { path: '/', name: 'front', component: FrontApp },
  {
    path: '/admin/login',
    name: 'admin-login',
    component: AdminLogin,
    meta: { title: '后台登录' }
  },
  {
    path: '/admin',
    component: AdminLayout,
    meta: { requiresAdmin: true },
    children: [
      { path: '', redirect: { name: 'admin-dashboard' } },
      { path: 'dashboard', name: 'admin-dashboard', component: AdminDashboard, meta: { title: '概览' } },
      { path: 'videos', name: 'admin-videos', component: AdminVideos, meta: { title: '视频管理' } },
      { path: 'bangumi', name: 'admin-bangumi', component: AdminBangumi, meta: { title: '番剧管理' } },
      { path: 'schedules', name: 'admin-schedules', component: AdminSchedules, meta: { title: '放送计划' } },
      { path: 'users', name: 'admin-users', component: AdminUsers, meta: { title: '用户管理' } }
    ]
  },
  { path: '/:pathMatch(.*)*', redirect: '/' }
]

const router = createRouter({
  history: createWebHistory(),
  routes,
  scrollBehavior: () => ({ top: 0 })
})

router.beforeEach(async (to) => {
  if (!to.matched.some((r) => r.meta.requiresAdmin)) return true

  const auth = getAdminAuth()
  if (!auth || !auth.token) {
    return { name: 'admin-login', query: { redirect: to.fullPath } }
  }
  // 已有令牌：向端确认一次是否仍然有效，避免拿过期令牌进后台再报错
  try {
    await adminMe()
    return true
  } catch {
    return { name: 'admin-login', query: { redirect: to.fullPath } }
  }
})

export default router
