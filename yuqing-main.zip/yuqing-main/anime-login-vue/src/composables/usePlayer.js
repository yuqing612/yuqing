/* =========================================================
   播放逻辑共享层（usePlayer）
   —— 首页 / 番剧 / 排行 / 收藏 四个板块的播放界面共用。

   职责：
   1. 归一化播放源类型（native 直链 / tencent 腾讯 / bilibili B站）；
   2. 维护「当前播放的条目」与「当前选中的分集」；
   3. 切换分集时重建播放器地址，实现按集数分级播放；
   4. 对外暴露 playEpisode / playPrev / playNext / playCurrent。

   说明：B 站与腾讯视频均为跨域 iframe，无法从外部调用内部 play()，
   因此切换分集的做法是重挂 iframe（换 src）来触发重新加载；
   原生直链则直接调用 video.play()。
   ========================================================= */
import { ref, computed, watch } from 'vue'

export function usePlayer() {
  /* 当前播放的条目：视频 / 番剧统一结构 */
  const current = ref(null)
  /* 当前选中的分集 */
  const currentEp = ref(null)
  /* iframe 播放地址 */
  const tencentSrc = ref('')
  const bilibiliSrc = ref('')
  /* 原生 <video> 引用（由 PlayerPanel 通过 setVideoEl 回调注册） */
  const videoEl = ref(null)
  function setVideoEl(el) {
    videoEl.value = el
  }

  const isTencent = computed(() => current.value?.sourceType === 'tencent')
  const isBilibili = computed(() => current.value?.sourceType === 'bilibili')
  const isOmofun = computed(() => current.value?.sourceType === 'omofun')
  const isNative = computed(() => !isTencent.value && !isBilibili.value && !isOmofun.value)
  /* 分集列表（当前条目带分集时非空） */
  const episodes = computed(() => current.value?.episodeList || [])

  /* ---------- 播放地址拼装 ---------- */

  /* 拼装腾讯视频 iframe 地址：src 已由后端生成，这里补上自适应尺寸与自动播放参数 */
  function buildTencentUrl(src, auto = false) {
    if (!src) return ''
    const sep = src.includes('?') ? '&' : '?'
    return `${src}${sep}height=540&width=960&auto=${auto ? 1 : 0}`
  }

  /* 拼装哔哩哔哩 iframe 地址：src 已由后端生成（player.bilibili.com），
     这里只补上自适应尺寸参数，自动播放通过替换 autoplay 实现 */
  function buildBilibiliUrl(src, auto = false) {
    if (!src) return ''
    const sep = src.includes('?') ? '&' : '?'
    const params = `height=540&width=960&autoplay=${auto ? 1 : 0}`
    // 后端拼装的地址里已带 autoplay=0，播放时替换掉以触发自动起播
    if (auto) {
      return src.replace(/[?&]autoplay=\d+/, `${sep}autoplay=1`) + sep + params
    }
    return src + sep + params
  }

  /* ---------- 播放 ---------- */

  /* 切换到指定分集：更新 iframe 地址以触发重新加载 */
  function playEpisode(ep) {
    if (!ep) return
    currentEp.value = ep
    if (isBilibili.value) {
      bilibiliSrc.value = buildBilibiliUrl(ep.src)
    } else if (isTencent.value) {
      tencentSrc.value = buildTencentUrl(ep.src)
    } else if (isOmofun.value) {
      // HLS 源：PlayerPanel 内部监听 currentEp.m3u8Url 变化重建播放器，无需在此处理
    } else if (videoEl.value) {
      // 原生源：换 src 并从头播放
      videoEl.value.src = ep.src
      videoEl.value.load()
      videoEl.value.play?.()
    }
  }

  /* 播放指定条目：带分集时默认选中第一集 */
  function playItem(item) {
    if (!item) {
      current.value = null
      currentEp.value = null
      tencentSrc.value = ''
      bilibiliSrc.value = ''
      return
    }
    current.value = item
    const eps = item.episodeList || []
    currentEp.value = eps.length ? eps[0] : null
    const src = currentEp.value?.src || item.src
    tencentSrc.value = item.sourceType === 'tencent' ? buildTencentUrl(src) : ''
    bilibiliSrc.value = item.sourceType === 'bilibili' ? buildBilibiliUrl(src) : ''
    // 原生源交给 <video> 的 :src 绑定，这里只需等 DOM 更新后重载
    if (item.sourceType !== 'tencent' && item.sourceType !== 'bilibili' && item.sourceType !== 'omofun') {
      // 用 nextTick 等 <video> 渲染出新 src 后再 load
      Promise.resolve().then(() => {
        if (videoEl.value) {
          videoEl.value.load()
          videoEl.value.play?.()
        }
      })
    }
  }

  /* 立即播放：
     - 原生源：直接调用 video.play()
     - 腾讯源 / B站源：跨域 iframe 无法调用内部 play()，改为重挂 iframe 并带上自动播放参数
     - HLS 源：由 PlayerPanel 内的 HlsPlayer 处理
     有分集时以当前选中分集的源为准，否则回落到条目自身的 src */
  function playCurrent() {
    const src = currentEp.value?.src || current.value?.src
    if (isTencent.value) {
      tencentSrc.value = buildTencentUrl(src, true)
      return
    }
    if (isBilibili.value) {
      bilibiliSrc.value = buildBilibiliUrl(src, true)
      return
    }
    if (isOmofun.value) {
      // HLS 源的播放由 HlsPlayer 内部接管，这里无需额外动作
      return
    }
    videoEl.value?.play()
  }

  /* 上一集 / 下一集 */
  function step(delta) {
    const eps = episodes.value
    if (!eps.length) return
    const idx = eps.findIndex((e) => e.epNo === currentEp.value?.epNo)
    const nextIdx = idx < 0 ? 0 : idx + delta
    if (nextIdx < 0 || nextIdx >= eps.length) return
    playEpisode(eps[nextIdx])
  }
  function playPrev() {
    step(-1)
  }
  function playNext() {
    step(1)
  }

  /* 切换条目时清空 iframe 地址，避免残留上一个源的播放器 */
  watch(current, () => {
    if (!isBilibili.value) bilibiliSrc.value = ''
    if (!isTencent.value) tencentSrc.value = ''
  })

  return {
    current,
    currentEp,
    tencentSrc,
    bilibiliSrc,
    videoEl,
    setVideoEl,
    isTencent,
    isBilibili,
    isNative,
    episodes,
    playEpisode,
    playItem,
    playCurrent,
    playPrev,
    playNext
  }
}
