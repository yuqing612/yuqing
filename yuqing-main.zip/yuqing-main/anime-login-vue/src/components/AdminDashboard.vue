<script setup>
/* 后台管理系统框架：左侧炭灰色侧边栏 + 右侧内容区，含退出后台 */
import { ref, computed } from 'vue'
import AdminHome from './AdminHome.vue'
import AdminVideoManage from './AdminVideoManage.vue'
import AdminBangumiManage from './AdminBangumiManage.vue'

const props = defineProps({
  adminUser: { type: Object, default: null }
})
const emit = defineEmits(['logout'])

const menus = [
  { key: 'home', label: '概览', icon: 'M3 13h8V3H3v10zm0 8h8v-6H3v6zm10 0h8V11h-8v10zm0-18v6h8V3h-8z' },
  { key: 'video', label: '视频管理', icon: 'M4 4h16a2 2 0 0 1 2 2v9a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2zm6 3v8l6-4-6-4z' },
  { key: 'bangumi', label: '番剧管理', icon: 'M3 5h18v14H3zM3 5l9 7 9-7' }
]
const active = ref('home')

const views = {
  home: AdminHome,
  video: AdminVideoManage,
  bangumi: AdminBangumiManage
}
const currentView = computed(() => views[active.value] || AdminHome)
const currentLabel = computed(() => (menus.find((m) => m.key === active.value) || {}).label || '')

const displayName = computed(() => {
  const u = props.adminUser
  return u ? u.nickname || u.username : '管理员'
})

function selectMenu(key) {
  active.value = key
}
</script>

<template>
  <div class="admin-shell">
    <!-- 侧边栏（炭灰色，呼应项目主色） -->
    <aside class="sidebar">
      <div class="side-brand">
        <div class="logo">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="#fff">
            <path d="M12 2.6l1.7 3.2 3.6.5-2.6 2.5.6 3.6L12 10.8 8.7 12.4l.6-3.6L6.7 6.3l3.6-.5z" />
            <circle cx="5.5" cy="17" r="2.6" />
            <circle cx="18.5" cy="17" r="2.6" />
            <circle cx="12" cy="21" r="2.6" />
          </svg>
        </div>
        <div class="side-brand-text">
          <b>桜次元</b>
          <small>管理后台</small>
        </div>
      </div>

      <nav class="side-nav">
        <button
          v-for="m in menus"
          :key="m.key"
          class="side-item"
          :class="{ on: active === m.key }"
          type="button"
          @click="selectMenu(m.key)"
        >
          <svg width="19" height="19" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round">
            <path :d="m.icon" />
          </svg>
          <span>{{ m.label }}</span>
        </button>
      </nav>

      <div class="side-foot">
        <div class="admin-chip">
          <span class="a-avatar">{{ displayName.slice(0, 1).toUpperCase() }}</span>
          <div class="a-meta">
            <span class="a-name">{{ displayName }}</span>
            <span class="a-role">管理员</span>
          </div>
        </div>
        <button class="logout-btn" type="button" @click="emit('logout')">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.1" stroke-linecap="round" stroke-linejoin="round">
            <path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4" />
            <path d="m16 17 5-5-5-5M21 12H9" />
          </svg>
          退出后台
        </button>
      </div>
    </aside>

    <!-- 内容区 -->
    <section class="content">
      <header class="topbar">
        <div class="crumb">
          <span class="c-root">后台管理</span>
          <span class="c-sep">/</span>
          <span class="c-cur">{{ currentLabel }}</span>
        </div>
        <div class="topbar-right">
          <span class="badge">ADMIN</span>
          <span class="who">{{ displayName }}</span>
        </div>
      </header>

      <main class="content-scroll">
        <component :is="currentView" />
      </main>
    </section>
  </div>
</template>

<style scoped>
.admin-shell {
  position: relative;
  z-index: 1;
  width: 100%;
  height: 100vh;
  display: flex;
}

/* ============ 侧边栏 ============ */
.sidebar {
  width: 248px;
  flex-shrink: 0;
  display: flex;
  flex-direction: column;
  background: linear-gradient(180deg, #2b2342 0%, #211a34 100%);
  color: #e9e4f5;
  padding: 22px 16px;
  box-shadow: 8px 0 30px -22px rgba(0, 0, 0, 0.6);
}
.side-brand {
  display: flex;
  align-items: center;
  gap: 11px;
  padding: 6px 8px 22px;
}
.logo {
  width: 40px;
  height: 40px;
  border-radius: 12px;
  background: var(--grad);
  display: grid;
  place-items: center;
  box-shadow: 0 10px 22px -8px rgba(192, 132, 252, 0.7);
}
.side-brand-text b {
  font-size: 16px;
  letter-spacing: 0.04em;
  display: block;
  color: #fff;
}
.side-brand-text small {
  font-size: 10.5px;
  color: #b6aad6;
  letter-spacing: 0.22em;
  text-transform: uppercase;
}

.side-nav {
  display: flex;
  flex-direction: column;
  gap: 6px;
  margin-top: 4px;
}
.side-item {
  display: flex;
  align-items: center;
  gap: 12px;
  padding: 12px 14px;
  border-radius: 12px;
  border: 0;
  background: transparent;
  color: #c4bce0;
  font-size: 14px;
  font-weight: 600;
  cursor: pointer;
  transition: 0.2s;
  text-align: left;
}
.side-item svg {
  flex-shrink: 0;
  opacity: 0.85;
}
.side-item:hover {
  background: rgba(255, 255, 255, 0.07);
  color: #fff;
}
.side-item.on {
  background: var(--grad);
  color: #fff;
  box-shadow: 0 10px 20px -10px rgba(192, 132, 252, 0.9);
}

.side-foot {
  margin-top: auto;
  display: flex;
  flex-direction: column;
  gap: 12px;
}
.admin-chip {
  display: flex;
  align-items: center;
  gap: 10px;
  padding: 10px;
  border-radius: 12px;
  background: rgba(255, 255, 255, 0.06);
}
.a-avatar {
  width: 36px;
  height: 36px;
  border-radius: 11px;
  background: var(--grad);
  display: grid;
  place-items: center;
  font-size: 15px;
  font-weight: 800;
  color: #fff;
  flex-shrink: 0;
}
.a-meta {
  display: flex;
  flex-direction: column;
  line-height: 1.3;
  min-width: 0;
}
.a-name {
  font-size: 13.5px;
  font-weight: 700;
  color: #fff;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}
.a-role {
  font-size: 11px;
  color: #9be8c9;
}
.logout-btn {
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 8px;
  height: 40px;
  border-radius: 12px;
  border: 1.5px solid rgba(255, 255, 255, 0.14);
  background: transparent;
  color: #d7cdef;
  font-size: 13px;
  font-weight: 600;
  cursor: pointer;
  transition: 0.2s;
}
.logout-btn:hover {
  border-color: #ff9bb0;
  color: #ffd0db;
  background: rgba(244, 63, 94, 0.12);
}

/* ============ 内容区 ============ */
.content {
  flex: 1;
  min-width: 0;
  display: flex;
  flex-direction: column;
  background: #f7f2ff;
}
.topbar {
  flex-shrink: 0;
  height: 66px;
  padding: 0 30px;
  display: flex;
  align-items: center;
  justify-content: space-between;
  background: rgba(255, 255, 255, 0.7);
  backdrop-filter: blur(14px);
  border-bottom: 1px solid rgba(255, 255, 255, 0.7);
  box-shadow: 0 10px 26px -22px rgba(90, 60, 140, 0.6);
}
.crumb {
  display: flex;
  align-items: center;
  gap: 9px;
  font-size: 14px;
}
.c-root {
  color: var(--ink-soft);
}
.c-sep {
  color: #cbbde8;
}
.c-cur {
  font-weight: 800;
  color: var(--ink);
}
.topbar-right {
  display: flex;
  align-items: center;
  gap: 12px;
}
.badge {
  font-size: 11px;
  font-weight: 800;
  letter-spacing: 0.1em;
  color: #fff;
  background: var(--grad);
  padding: 4px 10px;
  border-radius: 999px;
}
.who {
  font-size: 13.5px;
  font-weight: 700;
  color: var(--ink);
}
.content-scroll {
  flex: 1;
  min-height: 0;
  overflow-y: auto;
  overflow-x: hidden;
  padding: 28px 30px 60px;
}

@media (max-width: 760px) {
  .sidebar {
    width: 72px;
    padding: 18px 10px;
  }
  .side-brand-text,
  .side-item span,
  .admin-chip .a-meta,
  .logout-btn span {
    display: none;
  }
  .side-item {
    justify-content: center;
  }
  .topbar,
  .content-scroll {
    padding-left: 18px;
    padding-right: 18px;
  }
}
</style>
