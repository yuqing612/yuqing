<script setup>
/* 后台 · 番剧管理：列表（搜索/分页）+ 新增/编辑/删除 */
import { ref, reactive, onMounted } from 'vue'
import {
  adminListBangumi,
  adminCreateBangumi,
  adminUpdateBangumi,
  adminDeleteBangumi
} from '../api'

const CATEGORIES = ['日漫', '国漫', '剧场', '美漫']
const STATUSES = ['连载中', '已完结']

const list = ref([])
const total = ref(0)
const page = ref(1)
const size = ref(10)
const keyword = ref('')
const loading = ref(false)
const error = ref('')

const showModal = ref(false)
const editing = ref(null)
const saving = ref(false)
const formError = ref('')

const form = reactive({
  title: '',
  studio: '',
  category: '日漫',
  episodes: 12,
  status: '连载中',
  score: 8.0,
  tags: '',
  description: '',
  coverGradient: '',
  coverUrl: ''
})

const confirmTarget = ref(null)
const deleting = ref(false)

async function load() {
  loading.value = true
  error.value = ''
  try {
    const res = await adminListBangumi(keyword.value.trim(), page.value, size.value)
    list.value = res.list || []
    total.value = res.total || 0
  } catch (e) {
    error.value = e.message || '加载失败'
    list.value = []
    total.value = 0
  } finally {
    loading.value = false
  }
}

function onSearch() {
  page.value = 1
  load()
}

function prevPage() {
  if (page.value > 1) {
    page.value--
    load()
  }
}
function nextPage() {
  if (page.value * size.value < total.value) {
    page.value++
    load()
  }
}

function resetForm() {
  Object.assign(form, {
    title: '',
    studio: '',
    category: '日漫',
    episodes: 12,
    status: '连载中',
    score: 8.0,
    tags: '',
    description: '',
    coverGradient: '',
    coverUrl: ''
  })
  formError.value = ''
}

function openCreate() {
  editing.value = null
  resetForm()
  showModal.value = true
}

function openEdit(row) {
  editing.value = row
  Object.assign(form, {
    title: row.title || '',
    studio: row.studio || '',
    category: row.category || '日漫',
    episodes: row.episodes || 12,
    status: row.status || '连载中',
    score: row.score != null ? Number(row.score) : 8.0,
    tags: row.tags || '',
    description: row.description || '',
    coverGradient: row.coverGradient || '',
    coverUrl: row.coverUrl || ''
  })
  formError.value = ''
  showModal.value = true
}

async function submit() {
  if (!form.title.trim()) {
    formError.value = '请填写番剧标题'
    return
  }
  saving.value = true
  formError.value = ''
  const payload = {
    title: form.title.trim(),
    studio: form.studio.trim(),
    category: form.category,
    episodes: Number(form.episodes) || 0,
    status: form.status,
    score: Number(form.score) || 0,
    tags: form.tags.trim(),
    description: form.description.trim(),
    coverGradient: form.coverGradient.trim(),
    // 传空串而非 null：MyBatis-Plus 更新时会跳过 null 字段，传 null 就无法清空封面
    coverUrl: form.coverUrl.trim()
  }
  try {
    if (editing.value) {
      await adminUpdateBangumi(editing.value.id, payload)
    } else {
      await adminCreateBangumi(payload)
    }
    showModal.value = false
    load()
  } catch (e) {
    formError.value = e.message || '保存失败'
  } finally {
    saving.value = false
  }
}

function askDelete(row) {
  confirmTarget.value = row
}
async function confirmDelete() {
  if (!confirmTarget.value) return
  deleting.value = true
  try {
    await adminDeleteBangumi(confirmTarget.value.id)
    confirmTarget.value = null
    if (list.value.length === 1 && page.value > 1) page.value--
    load()
  } catch (e) {
    error.value = e.message || '删除失败'
  } finally {
    deleting.value = false
  }
}
function cancelDelete() {
  confirmTarget.value = null
}

onMounted(load)
</script>

<template>
  <div class="manage">
    <div class="toolbar">
      <div class="search">
        <svg class="s-ico" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round">
          <circle cx="11" cy="11" r="7" />
          <path d="m21 21-4.3-4.3" />
        </svg>
        <input v-model="keyword" type="text" placeholder="搜索标题 / 制作公司 / 标签 / 分类" @keyup.enter="onSearch" />
        <button class="s-btn" type="button" @click="onSearch">搜索</button>
        <button class="s-reset" type="button" @click="keyword=''; onSearch()">重置</button>
      </div>
      <button class="add-btn" type="button" @click="openCreate">
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round">
          <path d="M12 5v14M5 12h14" />
        </svg>
        新增番剧
      </button>
    </div>

    <p v-if="error" class="err-bar">⚠ {{ error }}</p>

    <div class="table-wrap">
      <table class="grid-table">
        <thead>
          <tr>
            <th class="c-id">ID</th>
            <th>标题</th>
            <th>制作公司</th>
            <th>分类</th>
            <th class="c-num">集数</th>
            <th>状态</th>
            <th class="c-num">评分</th>
            <th>标签</th>
            <th class="c-act">操作</th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="row in list" :key="row.id">
            <td class="c-id">{{ row.id }}</td>
            <td class="c-title" :title="row.title">{{ row.title }}</td>
            <td>{{ row.studio || '—' }}</td>
            <td>{{ row.category || '—' }}</td>
            <td class="c-num">{{ row.episodes != null ? row.episodes : '—' }}</td>
            <td>
              <span class="pill" :class="{ on: row.status === '连载中', done: row.status === '已完结' }">
                {{ row.status || '—' }}
              </span>
            </td>
            <td class="c-num">{{ row.score != null ? row.score : '—' }}</td>
            <td class="c-tags">{{ row.tags || '—' }}</td>
            <td class="c-act">
              <button class="t-edit" type="button" @click="openEdit(row)">编辑</button>
              <button class="t-del" type="button" @click="askDelete(row)">删除</button>
            </td>
          </tr>
          <tr v-if="!loading && !list.length">
            <td colspan="9" class="empty">暂无番剧数据，点击右上角「新增番剧」试试～</td>
          </tr>
        </tbody>
      </table>

      <div v-if="loading" class="loading-wrap">
        <i class="loader-spin"></i><span>加载中…</span>
      </div>
    </div>

    <div class="pager">
      <span class="p-info">共 {{ total }} 部 · 第 {{ page }} 页</span>
      <div class="p-btns">
        <button class="p-btn" type="button" :disabled="page <= 1" @click="prevPage">上一页</button>
        <button class="p-btn" type="button" :disabled="page * size >= total" @click="nextPage">下一页</button>
      </div>
    </div>

    <!-- 新增 / 编辑弹窗 -->
    <div v-if="showModal" class="modal-mask" @click.self="showModal = false">
      <div class="modal">
        <header class="m-head">
          <h3>{{ editing ? '编辑番剧' : '新增番剧' }}</h3>
          <button class="m-close" type="button" @click="showModal = false">✕</button>
        </header>
        <p v-if="formError" class="m-err">{{ formError }}</p>
        <div class="m-body">
          <label class="f-row">
            <span class="f-label">标题 <i>*</i></span>
            <input v-model="form.title" type="text" placeholder="番剧标题" />
          </label>
          <div class="f-grid">
            <label class="f-row">
              <span class="f-label">制作公司</span>
              <input v-model="form.studio" type="text" placeholder="如 苍崎制作" />
            </label>
            <label class="f-row">
              <span class="f-label">分类</span>
              <select v-model="form.category">
                <option v-for="c in CATEGORIES" :key="c" :value="c">{{ c }}</option>
              </select>
            </label>
            <label class="f-row">
              <span class="f-label">总集数</span>
              <input v-model.number="form.episodes" type="number" min="0" />
            </label>
            <label class="f-row">
              <span class="f-label">状态</span>
              <select v-model="form.status">
                <option v-for="s in STATUSES" :key="s" :value="s">{{ s }}</option>
              </select>
            </label>
            <label class="f-row">
              <span class="f-label">评分</span>
              <input v-model.number="form.score" type="number" step="0.1" min="0" max="10" placeholder="如 8.5" />
            </label>
            <label class="f-row">
              <span class="f-label">标签</span>
              <input v-model="form.tags" type="text" placeholder="斜杠分隔，如 原创/科幻/治愈" />
            </label>
          </div>
          <label class="f-row">
            <span class="f-label">简介</span>
            <textarea v-model="form.description" rows="2" placeholder="番剧简介"></textarea>
          </label>
          <div class="f-grid">
            <label class="f-row">
              <span class="f-label">封面渐变 CSS</span>
              <input v-model="form.coverGradient" type="text" placeholder="linear-gradient(...)" />
            </label>
            <label class="f-row">
              <span class="f-label">封面图 URL</span>
              <input v-model="form.coverUrl" type="text" placeholder="外部封面地址（可空）" />
            </label>
          </div>
        </div>
        <footer class="m-foot">
          <button class="m-cancel" type="button" @click="showModal = false">取消</button>
          <button class="m-save" type="button" :class="{ loading: saving }" :disabled="saving" @click="submit">
            {{ saving ? '保存中…' : '保存' }}
          </button>
        </footer>
      </div>
    </div>

    <!-- 删除确认 -->
    <div v-if="confirmTarget" class="modal-mask" @click.self="cancelDelete">
      <div class="confirm">
        <h3>确认删除？</h3>
        <p>将删除番剧「{{ confirmTarget.title }}」，此操作不可恢复。</p>
        <footer class="c-foot">
          <button class="m-cancel" type="button" @click="cancelDelete">取消</button>
          <button class="m-del" type="button" :disabled="deleting" @click="confirmDelete">
            {{ deleting ? '删除中…' : '确认删除' }}
          </button>
        </footer>
      </div>
    </div>
  </div>
</template>

<style scoped>
.manage {
  animation: rise 0.5s cubic-bezier(0.2, 0.8, 0.25, 1) both;
}
.toolbar {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 14px;
  margin-bottom: 18px;
  flex-wrap: wrap;
}
.search {
  display: flex;
  align-items: center;
  gap: 8px;
  height: 42px;
  padding: 0 6px 0 14px;
  border-radius: 999px;
  background: rgba(255, 255, 255, 0.78);
  border: 1.5px solid var(--line);
  transition: 0.25s;
}
.search:focus-within {
  border-color: #c9a7ff;
  box-shadow: 0 0 0 5px rgba(192, 132, 252, 0.14);
  background: #fff;
}
.s-ico {
  color: #b9aedd;
  flex-shrink: 0;
}
.search input {
  width: 250px;
  border: 0;
  outline: none;
  background: transparent;
  font-size: 13.5px;
  color: var(--ink);
  font-family: inherit;
}
.s-btn {
  border: 0;
  cursor: pointer;
  height: 30px;
  padding: 0 16px;
  border-radius: 999px;
  background: var(--grad);
  color: #fff;
  font-size: 12.5px;
  font-weight: 700;
  transition: 0.22s;
}
.s-btn:hover {
  transform: translateY(-1px);
}
.s-reset {
  border: 0;
  background: none;
  cursor: pointer;
  color: var(--ink-soft);
  font-size: 12.5px;
  padding: 0 8px;
}
.s-reset:hover {
  color: var(--accent);
}
.add-btn {
  display: inline-flex;
  align-items: center;
  gap: 7px;
  height: 42px;
  padding: 0 18px;
  border-radius: 14px;
  border: 0;
  cursor: pointer;
  background: var(--grad);
  color: #fff;
  font-size: 13.5px;
  font-weight: 700;
  box-shadow: 0 12px 26px -12px rgba(192, 132, 252, 0.95);
  transition: 0.22s;
}
.add-btn:hover {
  transform: translateY(-2px);
}

.err-bar {
  display: flex;
  align-items: center;
  gap: 14px;
  margin-bottom: 16px;
  padding: 12px 16px;
  border-radius: 14px;
  font-size: 13px;
  color: #b42318;
  background: rgba(255, 228, 230, 0.9);
  border: 1px solid rgba(244, 63, 94, 0.35);
}

.table-wrap {
  position: relative;
  border-radius: 18px;
  overflow: hidden;
  background: rgba(255, 255, 255, 0.66);
  border: 1px solid rgba(255, 255, 255, 0.7);
  box-shadow: 0 18px 40px -30px rgba(90, 60, 140, 0.5);
  backdrop-filter: blur(14px);
  -webkit-backdrop-filter: blur(14px);
}
.grid-table {
  width: 100%;
  border-collapse: collapse;
  font-size: 13px;
}
.grid-table thead th {
  text-align: left;
  padding: 14px 14px;
  font-size: 12px;
  font-weight: 700;
  color: var(--ink-soft);
  background: rgba(255, 255, 255, 0.5);
  border-bottom: 1px solid var(--line);
  white-space: nowrap;
  letter-spacing: 0.03em;
}
.grid-table tbody td {
  padding: 13px 14px;
  border-bottom: 1px dashed var(--line);
  color: var(--ink);
  vertical-align: middle;
}
.grid-table tbody tr:hover {
  background: rgba(255, 255, 255, 0.5);
}
.c-id {
  color: var(--ink-soft);
  font-variant-numeric: tabular-nums;
  width: 64px;
}
.c-num {
  text-align: right;
  font-variant-numeric: tabular-nums;
  white-space: nowrap;
}
.c-title {
  max-width: 280px;
  font-weight: 600;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
.c-tags {
  max-width: 180px;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  color: var(--ink-soft);
}
.c-act {
  width: 130px;
  white-space: nowrap;
}
.pill {
  display: inline-block;
  padding: 3px 10px;
  border-radius: 999px;
  font-size: 11.5px;
  font-weight: 700;
  color: var(--ink-soft);
  background: rgba(126, 104, 180, 0.1);
}
.pill.on {
  color: #fff;
  background: linear-gradient(105deg, #ff8fb1, #c084fc);
}
.pill.done {
  color: #fff;
  background: #7a6f96;
}
.t-edit,
.t-del {
  border: 0;
  cursor: pointer;
  font-size: 12.5px;
  font-weight: 700;
  padding: 6px 12px;
  border-radius: 9px;
  transition: 0.2s;
}
.t-edit {
  color: var(--accent);
  background: rgba(255, 255, 255, 0.8);
  border: 1.5px solid var(--line);
  margin-right: 6px;
}
.t-edit:hover {
  border-color: #e3d4ff;
  background: #fff;
}
.t-del {
  color: #f43f5e;
  background: rgba(255, 255, 255, 0.8);
  border: 1.5px solid rgba(244, 63, 94, 0.3);
}
.t-del:hover {
  background: #fff0f3;
}
.empty {
  text-align: center;
  padding: 50px 0;
  color: var(--ink-soft);
}

.loading-wrap {
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 12px;
  padding: 40px 0;
  color: var(--ink-soft);
  font-size: 13px;
}

.pager {
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin-top: 16px;
}
.p-info {
  font-size: 12.5px;
  color: var(--ink-soft);
}
.p-btns {
  display: flex;
  gap: 8px;
}
.p-btn {
  height: 36px;
  padding: 0 16px;
  border-radius: 11px;
  border: 1.5px solid var(--line);
  background: rgba(255, 255, 255, 0.8);
  color: var(--ink);
  font-size: 12.5px;
  font-weight: 600;
  cursor: pointer;
  transition: 0.2s;
}
.p-btn:hover:not(:disabled) {
  border-color: #e3d4ff;
  background: #fff;
}
.p-btn:disabled {
  opacity: 0.45;
  cursor: not-allowed;
}

/* ============ 弹窗 ============ */
.modal-mask {
  position: fixed;
  inset: 0;
  z-index: 50;
  background: rgba(31, 21, 48, 0.45);
  backdrop-filter: blur(4px);
  display: grid;
  place-items: center;
  padding: 24px;
  animation: fade 0.2s ease;
}
@keyframes fade {
  from { opacity: 0; }
  to { opacity: 1; }
}
.modal {
  width: min(640px, 96vw);
  max-height: 90vh;
  overflow: hidden;
  display: flex;
  flex-direction: column;
  border-radius: 20px;
  background: #fff;
  box-shadow: 0 40px 90px -30px rgba(31, 21, 48, 0.6);
  animation: pop 0.25s cubic-bezier(0.2, 0.9, 0.3, 1.2) both;
}
.m-head {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 20px 22px;
  border-bottom: 1px solid var(--line);
}
.m-head h3 {
  font-size: 17px;
  font-weight: 800;
}
.m-close {
  border: 0;
  background: none;
  cursor: pointer;
  font-size: 16px;
  color: var(--ink-soft);
  width: 32px;
  height: 32px;
  border-radius: 9px;
  transition: 0.2s;
}
.m-close:hover {
  background: rgba(126, 104, 180, 0.1);
  color: var(--ink);
}
.m-err {
  margin: 14px 22px 0;
  padding: 10px 14px;
  border-radius: 12px;
  font-size: 12.5px;
  color: #b42318;
  background: rgba(255, 228, 230, 0.9);
  border: 1px solid rgba(244, 63, 94, 0.3);
}
.m-body {
  padding: 20px 22px;
  overflow-y: auto;
  display: flex;
  flex-direction: column;
  gap: 14px;
}
.f-row {
  display: flex;
  flex-direction: column;
  gap: 7px;
}
.f-grid {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 14px;
}
.f-label {
  font-size: 12.5px;
  font-weight: 700;
  color: var(--ink);
}
.f-label i {
  color: #f43f5e;
  font-style: normal;
}
.f-row input,
.f-row textarea,
.f-row select {
  width: 100%;
  padding: 11px 13px;
  border-radius: 12px;
  border: 1.5px solid var(--line);
  background: #fbf9ff;
  font-size: 13.5px;
  color: var(--ink);
  font-family: inherit;
  outline: none;
  transition: 0.2s;
  resize: vertical;
}
.f-row select {
  cursor: pointer;
}
.f-row input:focus,
.f-row textarea:focus,
.f-row select:focus {
  border-color: #c9a7ff;
  background: #fff;
  box-shadow: 0 0 0 4px rgba(192, 132, 252, 0.12);
}
.m-foot {
  display: flex;
  justify-content: flex-end;
  gap: 10px;
  padding: 16px 22px;
  border-top: 1px solid var(--line);
}
.m-cancel,
.m-save,
.m-del {
  height: 42px;
  padding: 0 22px;
  border-radius: 12px;
  font-size: 13.5px;
  font-weight: 700;
  cursor: pointer;
  transition: 0.2s;
}
.m-cancel {
  border: 1.5px solid var(--line);
  background: #fff;
  color: var(--ink-soft);
}
.m-cancel:hover {
  border-color: #e3d4ff;
}
.m-save {
  border: 0;
  background: var(--grad);
  color: #fff;
  box-shadow: 0 12px 26px -12px rgba(192, 132, 252, 0.95);
}
.m-save:hover:not(:disabled) {
  transform: translateY(-1px);
}
.m-save:disabled {
  opacity: 0.6;
  cursor: not-allowed;
}

.confirm {
  width: min(400px, 92vw);
  border-radius: 18px;
  background: #fff;
  padding: 24px;
  box-shadow: 0 40px 90px -30px rgba(31, 21, 48, 0.6);
  animation: pop 0.25s cubic-bezier(0.2, 0.9, 0.3, 1.2) both;
}
.confirm h3 {
  font-size: 17px;
  font-weight: 800;
  margin-bottom: 10px;
}
.confirm p {
  font-size:13px;
  color: var(--ink-soft);
  line-height: 1.7;
  margin-bottom: 20px;
}
.c-foot {
  display: flex;
  justify-content: flex-end;
  gap: 10px;
}
.m-del {
  border: 0;
  background: #f43f5e;
  color: #fff;
}
.m-del:hover:not(:disabled) {
  background: #e11d48;
}
.m-del:disabled {
  opacity: 0.6;
}

@media (max-width: 720px) {
  .f-grid {
    grid-template-columns: 1fr;
  }
  .search input {
    width: 150px;
  }
}
</style>
