<script setup>
/* 番剧页：调用 mock API fetchBangumi，网格展示新番
   带播放源的番剧（如接入 B 站正片的条目）可点击卡片直接内嵌播放 */
import { ref, computed, onMounted } from 'vue'
import { fetchBangumi } from '../api'

defineProps({ user: Object, q: String })
const list = ref([])
const loading = ref(true)
const err = ref('')

/* 当前正在播放的番剧（有播放源时才非 null） */
const playing = ref(null)

async function load() {
  loading.value = true
  err.value = ''
  try {
    list.value = (await fetchBangumi()) || []
  } catch (e) {
    err.value = e.message || '番剧加载失败'
  } finally {
    loading.value = false
  }
}

/* 拼装哔哩哔哩 iframe 地址：src 已由后端生成，这里只补自适应尺寸参数 */
function buildBilibiliUrl(src) {
  if (!src) return ''
  const sep = src.includes('?') ? '&' : '?'
  return `${src}${sep}height=540&width=960&autoplay=1`
}
/* 拼装腾讯视频 iframe 地址 */
function buildTencentUrl(src) {
  if (!src) return ''
  const sep = src.includes('?') ? '&' : '?'
  return `${src}${sep}height=540&width=960&auto=1`
}

const isBilibili = computed(() => playing.value?.sourceType === 'bilibili')
const isTencent = computed(() => playing.value?.sourceType === 'tencent')

/* 当前播放的分集（从 playing.episodeList 里取），为空则用番剧自身的 src */
const currentEp = ref(null)

/* 播放器地址：优先用选中分集的 src，否则用番剧自身的 src */
const playerSrc = computed(() => {
  const src = currentEp.value?.src || playing.value?.src
  if (!src) return ''
  return isBilibili.value
    ? buildBilibiliUrl(src)
    : isTencent.value
      ? buildTencentUrl(src)
      : ''
})

function play(b) {
  if (!b || !b.src) return
  playing.value = b
  // 默认选中第一集
  currentEp.value = b.episodeList && b.episodeList.length ? b.episodeList[0] : null
  // 滚动到播放器
  requestAnimationFrame(() => {
    document.getElementById('bangumi-player')?.scrollIntoView({ behavior: 'smooth', block: 'center' })
  })
}

/* 切换到指定分集：重挂 iframe 以触发重新加载 */
function playEpisode(ep) {
  if (!ep) return
  currentEp.value = ep
}

function closePlayer() {
  playing.value = null
  currentEp.value = null
}

/* 毫秒 → mm:ss */
function fmtDuration(ms) {
  if (!ms) return ''
  const total = Math.round(ms / 1000)
  return `${String(Math.floor(total / 60)).padStart(2, '0')}:${String(total % 60).padStart(2, '0')}`
}

onMounted(load)
</script>

<template>
  <div class="page">
    <div class="sec-head">
      <h2>番剧新番</h2>
      <span class="sec-sub">{{ loading ? '加载中…' : `${list.length} 部作品` }}</span>
    </div>

    <div v-if="loading" class="loading-wrap">
      <i class="loader-spin"></i><span>正在连接次元…</span>
    </div>

    <!-- ============ 番剧播放器（有播放源时出现） ============ -->
    <section v-else-if="playing" id="bangumi-player" class="b-player">
      <div class="b-player-card">
        <button class="b-close" type="button" aria-label="关闭播放器" @click="closePlayer">×</button>
        <div class="b-player-wrap">
          <iframe
            v-if="isBilibili || isTencent"
            class="b-player-media"
            :src="playerSrc"
            allowfullscreen
            frameborder="0"
            scrolling="no"
            referrerpolicy="no-referrer"
          ></iframe>
          <video
            v-else
            class="b-player-media"
            :src="playing.src"
            :poster="playing.illust"
            controls
            preload="metadata"
            playsinline
          ></video>
        </div>
        <div class="b-player-info">
          <div class="tags">
            <span v-for="t in playing.tags" :key="t" class="tag">{{ t }}</span>
            <span v-if="isBilibili" class="tag src-tag src-tag-bili">哔哩哔哩</span>
            <span v-else-if="isTencent" class="tag src-tag">腾讯视频</span>
          </div>
          <h3 class="b-player-title">{{ playing.title }}</h3>
          <p class="b-player-desc">{{ playing.desc }}</p>

          <!-- ============ 选集面板 ============ -->
          <div v-if="playing.episodeList && playing.episodeList.length" class="ep-panel">
            <div class="ep-head">
              <span class="ep-title">选集</span>
              <span class="ep-count">共 {{ playing.episodeList.length }} 集</span>
              <span v-if="currentEp" class="ep-current">
                当前：第 {{ currentEp.epNo }} 集 · {{ currentEp.title }}
                <template v-if="currentEp.vip">（大会员）</template>
              </span>
            </div>
            <div class="ep-list">
              <button
                v-for="ep in playing.episodeList"
                :key="ep.id"
                type="button"
                class="ep-item"
                :class="{ on: currentEp && currentEp.epNo === ep.epNo }"
                :title="ep.vip ? '大会员专享，需登录 B 站大会员观看' : ep.title"
                @click="playEpisode(ep)"
              >
                <span class="ep-no">{{ ep.epNo }}</span>
                <span class="ep-name">{{ ep.title }}</span>
                <span v-if="ep.vip" class="ep-vip">VIP</span>
                <span class="ep-dur">{{ fmtDuration(ep.duration) }}</span>
              </button>
            </div>
          </div>
        </div>
      </div>
    </section>

    <div v-else-if="list.length" class="grid">
      <article
        v-for="b in list"
        :key="b.id"
        class="b-card"
        :class="{ playable: !!b.src }"
        @click="play(b)"
      >
        <div class="cover" :style="{ background: b.cover }">
          <img v-if="b.illust" class="b-img" :src="b.illust" :alt="b.title" loading="lazy" />
          <i class="b-shade"></i>
          <span class="status" :class="b.status === '连载中' ? 'on' : 'done'">{{ b.status }}</span>
          <span v-if="b.sourceType === 'bilibili'" class="b-src">哔哩哔哩</span>
          <span class="eps">{{ b.episodes }} 话</span>
          <span class="score">★ {{ b.score.toFixed(1) }}</span>
          <span v-if="b.src" class="b-play">
            <svg width="20" height="20" viewBox="0 0 24 24" fill="#fff"><path d="M8 5v14l11-7z"/></svg>
          </span>
        </div>
        <div class="b-body">
          <h4 class="b-name">{{ b.title }}</h4>
          <p class="b-studio">{{ b.studio }} · {{ b.tags.join(' / ') }}</p>
          <p class="b-desc">{{ b.desc }}</p>
        </div>
      </article>
    </div>

    <div v-else-if="err" class="empty">
      <p>番剧加载失败：{{ err }}</p>
      <p class="tip">确认后端已启动并已执行 yuqing_db.sql 导入番剧数据</p>
    </div>

    <div v-else class="empty">
      <svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="4" width="18" height="16" rx="2"/><path d="M3 9h18M8 4v5M16 4v5"/></svg>
      <p>暂无番剧数据</p>
    </div>

    <footer class="foot">桜次元 · Sakura — 番剧数据来自后端 /api/bangumi</footer>
  </div>
</template>

<style scoped>
/* ============ 番剧播放器 ============ */
.b-player {
  margin-bottom: 22px;
}
.b-player-card {
  position: relative;
  border-radius: 18px;
  overflow: hidden;
  background: var(--glass);
  border: 1px solid rgba(255, 255, 255, 0.7);
  box-shadow: 0 18px 40px -28px rgba(90, 60, 140, 0.55);
  backdrop-filter: blur(14px);
  -webkit-backdrop-filter: blur(14px);
}
.b-close {
  position: absolute;
  top: 12px;
  right: 12px;
  z-index: 2;
  width: 32px;
  height: 32px;
  border-radius: 50%;
  border: 1px solid rgba(255, 255, 255, 0.5);
  background: rgba(28, 21, 48, 0.55);
  color: #fff;
  font-size: 20px;
  line-height: 1;
  cursor: pointer;
  backdrop-filter: blur(4px);
  transition: background 0.2s;
}
.b-close:hover {
  background: rgba(244, 63, 94, 0.8);
}
.b-player-wrap {
  position: relative;
  aspect-ratio: 16 / 9;
  background: #14101f;
}
.b-player-media {
  position: absolute;
  inset: 0;
  width: 100%;
  height: 100%;
  border: 0;
  display: block;
}
.b-player-info {
  padding: 14px 18px 18px;
}
.b-player-info .tags {
  display: flex;
  flex-wrap: wrap;
  gap: 6px;
  margin-bottom: 9px;
}
.b-player-title {
  font-size: 17px;
  font-weight: 800;
  color: var(--ink);
  line-height: 1.45;
}
.b-player-desc {
  margin-top: 8px;
  font-size: 12.5px;
  line-height: 1.75;
  color: var(--ink-soft);
}
/* ============ 选集面板 ============ */
.ep-panel {
  margin-top: 14px;
  padding-top: 13px;
  border-top: 1px solid rgba(140, 120, 190, 0.18);
}
.ep-head {
  display: flex;
  align-items: center;
  flex-wrap: wrap;
  gap: 10px;
  margin-bottom: 10px;
}
.ep-title {
  font-size: 13px;
  font-weight: 800;
  color: var(--ink);
}
.ep-count {
  font-size: 11.5px;
  color: var(--ink-soft);
}
.ep-current {
  font-size: 11.5px;
  font-weight: 600;
  color: var(--accent);
}
.ep-list {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(148px, 1fr));
  gap: 8px;
}
.ep-item {
  display: flex;
  align-items: center;
  gap: 7px;
  padding: 7px 10px;
  border-radius: 10px;
  border: 1px solid rgba(140, 120, 190, 0.2);
  background: rgba(255, 255, 255, 0.6);
  color: var(--ink);
  font-size: 12px;
  cursor: pointer;
  text-align: left;
  transition: border-color 0.2s, background 0.2s, transform 0.2s;
}
.ep-item:hover {
  border-color: rgba(192, 132, 252, 0.6);
  background: rgba(255, 255, 255, 0.85);
  transform: translateY(-1px);
}
.ep-item.on {
  border-color: transparent;
  background: var(--grad);
  color: #fff;
  box-shadow: 0 6px 14px -8px rgba(192, 132, 252, 0.9);
}
.ep-no {
  flex: none;
  min-width: 20px;
  font-weight: 800;
  font-size: 11.5px;
  opacity: 0.75;
}
.ep-name {
  flex: 1;
  min-width: 0;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
.ep-vip {
  flex: none;
  padding: 1px 5px;
  border-radius: 5px;
  font-size: 9.5px;
  font-weight: 800;
  color: #fff;
  background: rgba(244, 63, 94, 0.85);
}
.ep-dur {
  flex: none;
  font-size: 10.5px;
  opacity: 0.7;
  font-variant-numeric: tabular-nums;
}
/* 播放源角标 */
.cover .b-src {
  position: absolute;
  top: 12px;
  right: 12px;
  padding: 4px 11px;
  border-radius: 999px;
  font-size: 11px;
  font-weight: 700;
  color: #fff;
  background: rgba(251, 114, 153, 0.88);
  backdrop-filter: blur(3px);
}
/* 悬停时居中的播放按钮 */
.cover .b-play {
  position: absolute;
  top: 50%;
  left: 50%;
  width: 46px;
  height: 46px;
  margin: -23px 0 0 -23px;
  border-radius: 50%;
  display: grid;
  place-items: center;
  color: #fff;
  background: rgba(28, 21, 48, 0.55);
  border: 1px solid rgba(255, 255, 255, 0.45);
  backdrop-filter: blur(4px);
  opacity: 0;
  transform: scale(0.8);
  transition: opacity 0.24s, transform 0.24s;
  pointer-events: none;
}
.b-card.playable:hover .cover .b-play {
  opacity: 1;
  transform: scale(1);
}
.b-card {
  border-radius: 18px;
  overflow: hidden;
  background: var(--glass);
  border: 1px solid rgba(255, 255, 255, 0.7);
  box-shadow: 0 18px 40px -28px rgba(90, 60, 140, 0.5);
  backdrop-filter: blur(14px);
  -webkit-backdrop-filter: blur(14px);
  transition: transform 0.26s cubic-bezier(0.2, 0.8, 0.25, 1), box-shadow 0.26s, border-color 0.26s;
  cursor: pointer;
}
.b-card:hover {
  transform: translateY(-6px);
  box-shadow: 0 26px 50px -26px rgba(90, 60, 140, 0.6);
  border-color: #e3d4ff;
}
.cover {
  position: relative;
  aspect-ratio: 3 / 4;
  overflow: hidden;
}
/* 番剧插画 */
.cover .b-img {
  position: absolute;
  inset: 0;
  width: 100%;
  height: 100%;
  object-fit: cover;
  display: block;
  transition: transform 0.5s cubic-bezier(0.2, 0.8, 0.25, 1);
}
.b-card:hover .cover .b-img {
  transform: scale(1.06);
}
.cover .b-shade {
  position: absolute;
  left: 0;
  right: 0;
  bottom: 0;
  height: 34%;
  pointer-events: none;
  background: linear-gradient(0deg, rgba(28, 21, 48, 0.45), transparent);
}
.cover .status {
  position: absolute;
  top: 12px;
  left: 12px;
  padding: 4px 11px;
  border-radius: 999px;
  font-size: 11px;
  font-weight: 700;
  color: #fff;
  backdrop-filter: blur(3px);
}
.cover .status.on {
  background: rgba(244, 63, 94, 0.85);
}
.cover .status.done {
  background: rgba(47, 36, 69, 0.55);
}
.cover .eps {
  position: absolute;
  top: 12px;
  right: 12px;
  padding: 4px 11px;
  border-radius: 999px;
  font-size: 11px;
  font-weight: 700;
  color: var(--ink);
  background: rgba(255, 255, 255, 0.85);
}
.cover .score {
  position: absolute;
  left: 12px;
  bottom: 12px;
  padding: 4px 11px;
  border-radius: 999px;
  font-size: 12px;
  font-weight: 800;
  color: #fff;
  background: rgba(28, 21, 48, 0.55);
  backdrop-filter: blur(3px);
}
.b-body {
  padding: 14px 16px 18px;
}
.b-name {
  font-size: 15px;
  font-weight: 800;
  line-height: 1.45;
  color: var(--ink);
}
.b-studio {
  font-size: 12px;
  color: var(--accent);
  margin-top: 7px;
  font-weight: 600;
}
.b-desc {
  font-size: 12px;
  color: var(--ink-soft);
  margin-top: 8px;
  line-height: 1.7;
  display: -webkit-box;
  -webkit-line-clamp: 2;
  -webkit-box-orient: vertical;
  overflow: hidden;
}
.tip {
  margin-top: 8px;
  font-size: 12px;
  color: var(--ink-soft);
  opacity: 0.85;
}
</style>
