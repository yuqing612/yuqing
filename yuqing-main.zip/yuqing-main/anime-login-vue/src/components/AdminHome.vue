<script setup>
/* 后台概览：展示视频 / 番剧数量等统计，引导进入各管理模块 */
import { ref, onMounted } from 'vue'
import { adminListVideos, adminListBangumi } from '../api'

const videoTotal = ref(null)
const bangumiTotal = ref(null)
const loading = ref(true)
const error = ref('')

const cards = ref([])

onMounted(async () => {
  loading.value = true
  error.value = ''
  try {
    const [v, b] = await Promise.allSettled([
      adminListVideos('', 1, 1),
      adminListBangumi('', 1, 1)
    ])
    if (v.status === 'fulfilled') videoTotal.value = v.value.total
    if (b.status === 'fulfilled') bangumiTotal.value = b.value.total
    const failed = [v, b].find((x) => x.status === 'rejected')
    error.value = failed ? failed.reason?.message || '数据加载失败' : ''

    cards.value = [
      { label: '首页视频', value: videoTotal.value, unit: '条', desc: '热门推荐 / 播放器数据源', color: '#ff8fb1' },
      { label: '番剧作品', value: bangumiTotal.value, unit: '部', desc: 'Hero 轮播 / 新番墙数据源', color: '#c084fc' },
      { label: '每日推荐', value: '—', unit: '', desc: '勾选 daily_pick 的视频', color: '#7dd3fc' },
      { label: '系统状态', value: '运行中', unit: '', desc: '后台服务连接正常', color: '#34d399' }
    ]
  } catch (e) {
    error.value = e.message || '加载失败'
  } finally {
    loading.value = false
  }
})
</script>

<template>
  <div class="home">
    <div class="welcome">
      <h2>欢迎来到后台管理系统 👋</h2>
      <p>这里可以对首页展示的 <b>视频</b> 与 <b>番剧</b> 数据进行增删改查，所有改动会实时影响门户前端展示。</p>
    </div>

    <p v-if="error" class="err-bar">⚠ {{ error }}</p>

    <div v-if="loading" class="loading-wrap">
      <i class="loader-spin"></i><span>正在统计…</span>
    </div>

    <div v-else class="stats">
      <article v-for="c in cards" :key="c.label" class="stat-card" :style="{ '--c': c.color }">
        <span class="dot"></span>
        <div class="s-value">{{ c.value }}</div>
        <div class="s-label">{{ c.label }}<small v-if="c.unit"> {{ c.unit }}</small></div>
        <div class="s-desc">{{ c.desc }}</div>
      </article>
    </div>

    <div v-if="!loading" class="tips">
      <h3>快速开始</h3>
      <ol>
        <li>点击左侧「视频管理」可新增 / 编辑 / 删除首页热门推荐中的视频。</li>
        <li>点击左侧「番剧管理」可维护首页轮播与新番墙的番剧数据。</li>
        <li>所有操作需管理员权限；普通账号无法进入本系统。</li>
      </ol>
    </div>
  </div>
</template>

<style scoped>
.home {
  max-width: 1000px;
  margin: 0 auto;
  animation: rise 0.5s cubic-bezier(0.2, 0.8, 0.25, 1) both;
}
.welcome {
  margin-bottom: 26px;
}
.welcome h2 {
  font-size: 22px;
  font-weight: 800;
  letter-spacing: 0.02em;
}
.welcome p {
  margin-top: 8px;
  font-size: 13.5px;
  color: var(--ink-soft);
  line-height: 1.8;
}

.err-bar {
  display: flex;
  align-items: center;
  gap: 14px;
  margin-bottom: 22px;
  padding: 14px 18px;
  border-radius: 16px;
  font-size: 13px;
  color: #b42318;
  background: rgba(255, 228, 230, 0.9);
  border: 1px solid rgba(244, 63, 94, 0.35);
}

.loading-wrap {
  display: flex;
  align-items: center;
  gap: 12px;
  padding: 60px 0;
  color: var(--ink-soft);
  font-size: 14px;
}

.stats {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(220px, 1fr));
  gap: 18px;
}
.stat-card {
  position: relative;
  padding: 22px 22px 20px;
  border-radius: 20px;
  background: rgba(255, 255, 255, 0.66);
  border: 1px solid rgba(255, 255, 255, 0.7);
  box-shadow: 0 18px 40px -30px rgba(90, 60, 140, 0.5);
  backdrop-filter: blur(14px);
  -webkit-backdrop-filter: blur(14px);
  overflow: hidden;
}
.stat-card .dot {
  position: absolute;
  top: 18px;
  right: 18px;
  width: 12px;
  height: 12px;
  border-radius: 50%;
  background: var(--c);
  box-shadow: 0 0 0 4px color-mix(in srgb, var(--c) 22%, transparent);
}
.s-value {
  font-size: 34px;
  font-weight: 900;
  color: var(--ink);
  line-height: 1.1;
  letter-spacing: 0.01em;
}
.s-label {
  font-size: 14px;
  font-weight: 700;
  color: var(--ink);
  margin-top: 6px;
}
.s-label small {
  font-size: 12px;
  color: var(--ink-soft);
  font-weight: 600;
}
.s-desc {
  font-size: 12px;
  color: var(--ink-soft);
  margin-top: 8px;
  line-height: 1.6;
}

.tips {
  margin-top: 30px;
  padding: 22px 24px;
  border-radius: 20px;
  background: rgba(255, 255, 255, 0.55);
  border: 1px solid rgba(255, 255, 255, 0.7);
}
.tips h3 {
  font-size: 15px;
  font-weight: 800;
  margin-bottom: 12px;
}
.tips ol {
  margin: 0;
  padding-left: 20px;
  display: flex;
  flex-direction: column;
  gap: 8px;
}
.tips li {
  font-size: 13px;
  color: var(--ink-soft);
  line-height: 1.7;
}
</style>
