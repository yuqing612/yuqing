<script setup>
/* 后台登录页：仅提供登录（无注册），校验账号角色必须为 ADMIN */
import { ref, computed, nextTick } from 'vue'
import { adminLogin, saveAdminAuth } from '../api'

const emit = defineEmits(['success', 'back'])

const username = ref('')
const password = ref('')
const errorMessage = ref('')
const loading = ref(false)
const showPassword = ref(false)
const shakeUser = ref(false)
const shakePass = ref(false)
let shakeTimers = []

function triggerShake(target) {
  const key = target === 'user' ? shakeUser : shakePass
  target === 'user' ? (shakePass.value = false) : (shakeUser.value = false)
  key.value = false
  nextTick(() => {
    key.value = true
    const t = setTimeout(() => {
      key.value = false
    }, 460)
    shakeTimers.push(t)
  })
}

const passwordType = computed(() => (showPassword.value ? 'text' : 'password'))

function validate() {
  const name = username.value.trim()
  const pwd = password.value
  if (!name) {
    errorMessage.value = '请输入管理员用户名'
    triggerShake('user')
    return null
  }
  if (!pwd) {
    errorMessage.value = '请输入密码'
    triggerShake('pass')
    return null
  }
  return { name, pwd }
}

async function onSubmit() {
  if (loading.value) return
  const payload = validate()
  if (!payload) return
  errorMessage.value = ''
  loading.value = true
  try {
    const auth = await adminLogin({ account: payload.name, password: payload.pwd, remember: true })
    saveAdminAuth(auth, true)
    emit('success', auth)
  } catch (e) {
    errorMessage.value = e.message || '登录失败，请稍后再试'
    triggerShake(/权限/.test(errorMessage.value) ? 'user' : 'pass')
  } finally {
    loading.value = false
  }
}
</script>

<template>
  <main class="admin-stage">
    <div class="admin-card">
      <div class="brand">
        <div class="logo">
          <svg width="24" height="24" viewBox="0 0 24 24" fill="#fff">
            <path d="M12 2.6l1.7 3.2 3.6.5-2.6 2.5.6 3.6L12 10.8 8.7 12.4l.6-3.6L6.7 6.3l3.6-.5z" />
            <circle cx="5.5" cy="17" r="2.6" />
            <circle cx="18.5" cy="17" r="2.6" />
            <circle cx="12" cy="21" r="2.6" />
          </svg>
        </div>
        <div class="brand-text">
          <b>桜次元 · Sakura</b>
          <small>后台管理系统</small>
        </div>
      </div>

      <h1>管理员登录</h1>
      <p class="sub">仅限管理员账号访问，登录后可对首页数据进行增删改查</p>

      <p class="err" role="alert">{{ errorMessage }}</p>

      <form class="panel" novalidate @submit.prevent="onSubmit">
        <div class="field" :class="{ shake: shakeUser }">
          <input id="a-user" v-model="username" type="text" placeholder=" " autocomplete="username" />
          <label for="a-user">管理员账号</label>
          <span class="ico">
            <svg width="19" height="19" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
              <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2" />
              <circle cx="12" cy="7" r="4" />
            </svg>
          </span>
        </div>

        <div class="field" :class="{ shake: shakePass }">
          <input id="a-pass" v-model="password" :type="passwordType" placeholder=" " autocomplete="current-password" />
          <label for="a-pass">密码</label>
          <span class="ico">
            <svg width="19" height="19" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
              <rect x="4" y="11" width="16" height="10" rx="2.5" />
              <path d="M8 11V7a4 4 0 0 1 8 0v4" />
            </svg>
          </span>
          <button class="toggle" type="button" aria-label="显示密码" @click="showPassword = !showPassword">
            <svg v-if="showPassword" width="19" height="19" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
              <path d="M2 2l20 20" />
              <path d="M6.7 6.8C4 8.6 1.5 12 1.5 12s3.5 6.5 10.5 6.5c1.6 0 3-.4 4.2-1" />
              <path d="M9.9 5.5A9.6 9.6 0 0 1 12 5.5c7 0 10.5 6.5 10.5 6.5a19 19 0 0 1-2.7 3.6" />
            </svg>
            <svg v-else width="19" height="19" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
              <path d="M1.5 12S5 5.5 12 5.5 22.5 12 22.5 12 19 18.5 12 18.5 1.5 12 1.5 12z" />
              <circle cx="12" cy="12" r="3.2" />
            </svg>
          </button>
        </div>

        <button class="btn" type="submit" :class="{ loading }">
          <span>
            登 录 后 台
            <svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round">
              <path d="M5 12h14M13 6l6 6-6 6" />
            </svg>
          </span>
          <i class="spin"></i>
        </button>
      </form>

      <a class="back" href="#" @click.prevent="emit('back')">← 返回门户首页</a>
    </div>
  </main>
</template>

<style scoped>
.admin-stage {
  position: relative;
  z-index: 1;
  width: 100%;
  min-height: 100vh;
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 30px;
}

.admin-card {
  position: relative;
  width: min(440px, 94vw);
  padding: 44px 44px 34px;
  border-radius: var(--radius);
  background: var(--glass);
  border: 1px solid rgba(255, 255, 255, 0.65);
  box-shadow: 0 34px 80px -34px rgba(90, 60, 140, 0.45);
  backdrop-filter: blur(20px);
  -webkit-backdrop-filter: blur(20px);
  animation: rise 0.7s cubic-bezier(0.2, 0.8, 0.25, 1) both;
}

.brand {
  display: flex;
  align-items: center;
  gap: 12px;
  margin-bottom: 30px;
}
.logo {
  width: 44px;
  height: 44px;
  border-radius: 14px;
  background: var(--grad);
  display: grid;
  place-items: center;
  box-shadow: 0 10px 22px -8px rgba(192, 132, 252, 0.7);
  animation: logoFloat 4s ease-in-out infinite;
}
.brand-text b {
  font-size: 17px;
  letter-spacing: 0.04em;
  display: block;
}
.brand-text small {
  font-size: 11.5px;
  color: var(--ink-soft);
  letter-spacing: 0.24em;
  text-transform: uppercase;
}

h1 {
  font-size: 25px;
  letter-spacing: 0.02em;
  margin-bottom: 8px;
  font-weight: 800;
}
.sub {
  font-size: 13px;
  color: var(--ink-soft);
  margin-bottom: 26px;
  line-height: 1.6;
}

.err {
  color: #f43f5e;
  font-size: 12px;
  margin: -6px 0 12px;
  min-height: 16px;
  letter-spacing: 0.02em;
}

.field {
  position: relative;
  margin-bottom: 18px;
}
.field input {
  width: 100%;
  height: 54px;
  padding: 22px 46px 8px 44px;
  border-radius: 16px;
  border: 1.5px solid var(--line);
  background: rgba(255, 255, 255, 0.78);
  font-size: 14.5px;
  color: var(--ink);
  outline: none;
  font-family: inherit;
  transition: border-color 0.25s, box-shadow 0.25s, background 0.25s;
}
.field input::placeholder {
  color: transparent;
}
.field label {
  position: absolute;
  left: 44px;
  top: 17px;
  font-size: 14px;
  color: var(--ink-soft);
  pointer-events: none;
  transition: 0.24s cubic-bezier(0.2, 0.8, 0.25, 1);
  letter-spacing: 0.02em;
}
.field input:focus + label,
.field input:not(:placeholder-shown) + label {
  top: 8px;
  font-size: 11px;
  color: var(--accent);
  letter-spacing: 0.1em;
  font-weight: 600;
}
.field input:focus {
  border-color: #c9a7ff;
  background: #fff;
  box-shadow: 0 0 0 5px rgba(192, 132, 252, 0.14);
}
.field .ico {
  position: absolute;
  left: 15px;
  top: 17px;
  color: #b9aedd;
  transition: color 0.25s, transform 0.25s;
}
.field input:focus ~ .ico {
  color: var(--accent);
  transform: scale(1.1);
}
.toggle {
  position: absolute;
  right: 14px;
  top: 17px;
  width: 30px;
  height: 30px;
  border: 0;
  background: none;
  cursor: pointer;
  color: #b9aedd;
  border-radius: 8px;
  display: grid;
  place-items: center;
  transition: 0.2s;
}
.toggle:hover {
  color: var(--accent);
  background: rgba(192, 132, 252, 0.1);
}

.btn {
  position: relative;
  width: 100%;
  height: 52px;
  border: 0;
  border-radius: 16px;
  cursor: pointer;
  overflow: hidden;
  background: var(--grad);
  background-size: 220% 100%;
  color: #fff;
  font-size: 15.5px;
  font-weight: 700;
  letter-spacing: 0.16em;
  box-shadow: 0 16px 34px -14px rgba(192, 132, 252, 0.95);
  transition: transform 0.22s cubic-bezier(0.2, 0.8, 0.25, 1), box-shadow 0.22s, background-position 0.6s;
  margin-top: 6px;
}
.btn:hover {
  transform: translateY(-2.5px);
  box-shadow: 0 22px 42px -14px rgba(192, 132, 252, 1);
  background-position: 100% 0;
}
.btn:active {
  transform: translateY(0) scale(0.985);
}
.btn::before {
  content: "";
  position: absolute;
  top: 0;
  left: -120%;
  width: 60%;
  height: 100%;
  background: linear-gradient(100deg, transparent, rgba(255, 255, 255, 0.55), transparent);
  transition: left 0.65s;
}
.btn:hover::before {
  left: 130%;
}
.btn span {
  position: relative;
  z-index: 2;
  display: inline-flex;
  align-items: center;
  gap: 9px;
}
.btn.loading {
  pointer-events: none;
  color: transparent;
}
.spin {
  position: absolute;
  inset: 0;
  margin: auto;
  width: 22px;
  height: 22px;
  border: 2.5px solid rgba(255, 255, 255, 0.35);
  border-top-color: #fff;
  border-radius: 50%;
  opacity: 0;
  animation: spin360 0.7s linear infinite;
}
.btn.loading .spin {
  opacity: 1;
}

.back {
  display: block;
  text-align: center;
  margin-top: 22px;
  font-size: 13px;
  color: var(--ink-soft);
  text-decoration: none;
}
.back:hover {
  color: var(--accent);
}

.shake {
  animation: shake 0.42s;
}

@media (max-width: 520px) {
  .admin-card {
    padding: 34px 26px 28px;
  }
}
</style>
