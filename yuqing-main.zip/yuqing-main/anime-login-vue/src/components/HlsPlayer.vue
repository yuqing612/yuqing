<script setup>
/* =========================================================
   HLS 播放器（HlsPlayer）
   —— 用于动漫共和国等 HLS（.m3u8）源。

   相比直接嵌第三方播放页，这样做的好处：
   1. 播放体验与站内一致，播放器外观统一；
   2. 可以自己实现「分级播放」：解析主清单里的多条码率，
      按档位（清晰度）切换，切换后保持当前播放进度。

   props:
     src       m3u8 地址
     poster    封面图
     startAt   起播位置（秒），分集切换时传入以续播
   emits:
     levels    解析出可用清晰度档位 [{ label, height, index }]
     playing   开始播放
   ========================================================= */
import { ref, watch, onBeforeUnmount, onMounted, nextTick } from 'vue'
import Hls from 'hls.js'

const props = defineProps({
  src: { type: String, default: '' },
  poster: { type: String, default: '' },
  startAt: { type: Number, default: 0 }
})

const emit = defineEmits(['levels', 'playing', 'error'])

const videoEl = ref(null)
/** 当前选中的清晰度档位索引，-1 表示自动 */
const levelIndex = ref(-1)
/** 可用清晰度档位 */
const levels = ref([])
const isLive = ref(false)

let hls = null

/* ---------- 清晰度档位解析 ---------- */

/**
 * 拉取主清单，解析出各条码率（BANDWIDTH / RESOLUTION）。
 * 只含单条码率时不展示档位选择器。
 */
async function fetchLevels(url) {
  try {
    const res = await fetch(url, { method: 'GET' })
    const text = await res.text()
    if (!text.includes('#EXTM3U')) return []
    const lines = text.split('\n').map((l) => l.trim())
    const out = []
    for (let i = 0; i < lines.length; i++) {
      if (!lines[i].startsWith('#EXT-X-STREAM-INF')) continue
      const bw = /BANDWIDTH=(\d+)/.exec(lines[i])
      const res_ = /RESOLUTION=(\d+x\d+)/.exec(lines[i])
      if (!res_ && !bw) continue
      const [w, h] = res_ ? res_[1].split('x').map(Number) : [0, 0]
      out.push({
        index: out.length,
        width: w,
        height: h,
        bandwidth: bw ? Number(bw[1]) : 0,
        label: h ? `${h}P` : bw ? `${Math.round(bw[1] / 1000)}K` : '自动'
      })
    }
    // 按分辨率从高到低排序
    out.sort((a, b) => b.height - a.height)
    out.forEach((l, i) => {
      l.index = i
    })
    return out
  } catch {
    return []
  }
}

/* ---------- 播放器初始化 ---------- */

function destroy() {
  if (hls) {
    hls.destroy()
    hls = null
  }
}

async function setup(url, resumeAt = 0) {
  const video = videoEl.value
  if (!video || !url) return
  destroy()

  // 原生支持 HLS 的浏览器（Safari / iOS）直接交给系统播放器
  if (video.canPlayType('application/vnd.apple.mpegurl')) {
    video.src = url
    if (resumeAt > 0) {
      video.currentTime = resumeAt
      video.play().catch(() => {})
    }
    return
  }

  if (!Hls.isSupported()) {
    emit('error', '当前浏览器不支持 HLS 播放')
    return
  }

  hls = new Hls({
    enableWorker: true,
    lowLatencyMode: true,
    backBufferLength: 90
  })
  hls.loadSource(url)
  hls.attachMedia(video)

  hls.on(Hls.Events.MANIFEST_PARSED, () => {
    // 解析出清晰度档位后，若有当前选中档位则切过去
    const lv = hls.levels || []
    const mapped = lv.map((l, i) => ({
      index: i,
      width: l.width || 0,
      height: l.height || 0,
      bandwidth: l.bitrate || 0,
      label: l.height ? `${l.height}P` : `${Math.round((l.bitrate || 0) / 1000)}K`
    }))
    levels.value = mapped
    emit('levels', mapped)
    if (levelIndex.value >= 0 && levelIndex.value < mapped.length) {
      hls.currentLevel = levelIndex.value
    }
    if (resumeAt > 0) {
      video.currentTime = resumeAt
    }
    video.play().catch(() => {})
    emit('playing')
  })

  hls.on(Hls.Events.LEVEL_SWITCHED, (_e, data) => {
    // 实际生效的档位可能与选中项一致，这里只同步展示
    levelIndex.value = data.level
  })

  hls.on(Hls.Events.ERROR, (_e, data) => {
    if (!data.fatal) return
    if (data.type === Hls.ErrorTypes.NETWORK_ERROR) {
      hls.startLoad()
    } else if (data.type === Hls.ErrorTypes.MEDIA_ERROR) {
      hls.recoverMediaError()
    } else {
      emit('error', '视频加载失败，请稍后重试')
      destroy()
    }
  })
}

/* ---------- 清晰度切换 ---------- */

/**
 * 切换清晰度档位。
 * hls.js 的 currentLevel = -1 表示自动；指定数字则锁定该档位。
 */
function setLevel(idx) {
  levelIndex.value = idx
  if (!hls) return
  const levels_ = hls.levels || []
  if (idx < 0 || idx >= levels_.length) {
    hls.currentLevel = -1
    return
  }
  hls.currentLevel = idx
}

/* ---------- 生命周期 ---------- */

onMounted(async () => {
  await nextTick()
  if (!props.src) return
  const lv = await fetchLevels(props.src)
  levels.value = lv
  emit('levels', lv)
  setup(props.src, props.startAt)
})

/* src 变化（切换分集）：重建播放器并从上次进度续播 */
watch(
  () => props.src,
  async (url, old) => {
    if (!url || url === old) return
    const video = videoEl.value
    const resume = video && !video.paused ? video.currentTime : 0
    await nextTick()
    setup(url, resume)
  }
)

onBeforeUnmount(destroy)

defineExpose({ setLevel, levels, videoEl })
</script>

<template>
  <div class="hls-player">
    <video
      ref="videoEl"
      class="hls-video"
      :poster="poster"
      controls
      playsinline
      preload="metadata"
    ></video>
    <!-- ============ 分级播放：清晰度档位 ============ -->
    <div v-if="levels.length > 1" class="hls-levels">
      <span class="hl-label">画质</span>
      <button
        type="button"
        class="hl-btn"
        :class="{ on: levelIndex === -1 }"
        @click="setLevel(-1)"
      >
        自动
      </button>
      <button
        v-for="l in levels"
        :key="l.index"
        type="button"
        class="hl-btn"
        :class="{ on: levelIndex === l.index }"
        @click="setLevel(l.index)"
      >
        {{ l.label }}
      </button>
    </div>
  </div>
</template>

<style scoped>
.hls-player {
  position: relative;
  width: 100%;
  height: 100%;
}
.hls-video {
  width: 100%;
  height: 100%;
  display: block;
  object-fit: contain;
  background: #14101f;
}
/* ============ 画质档位 ============ */
.hls-levels {
  position: absolute;
  right: 12px;
  top: 12px;
  z-index: 3;
  display: flex;
  align-items: center;
  flex-wrap: wrap;
  gap: 5px;
  padding: 6px 10px;
  border-radius: 12px;
  background: rgba(20, 16, 31, 0.72);
  backdrop-filter: blur(8px);
  border: 1px solid rgba(255, 255, 255, 0.16);
}
.hl-label {
  font-size: 11px;
  font-weight: 700;
  color: rgba(255, 255, 255, 0.7);
  margin-right: 2px;
}
.hl-btn {
  padding: 3px 9px;
  border-radius: 8px;
  border: 1px solid rgba(255, 255, 255, 0.18);
  background: rgba(255, 255, 255, 0.1);
  color: rgba(255, 255, 255, 0.82);
  font-size: 11px;
  font-weight: 700;
  cursor: pointer;
  transition: 0.2s;
}
.hl-btn:hover {
  background: rgba(255, 255, 255, 0.22);
  color: #fff;
}
.hl-btn.on {
  background: linear-gradient(135deg, #ff8fb1, #c084fc);
  border-color: transparent;
  color: #fff;
  box-shadow: 0 4px 12px -4px rgba(192, 132, 252, 0.9);
}
</style>
