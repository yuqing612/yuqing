<script setup>
/* =========================================================
   HLS 播放器（HlsPlayer）
   —— 所有番剧 / 视频的 HLS（.m3u8）源共用这一个组件。

   相比直接嵌第三方播放页，这样做的好处：
   1. 播放体验与站内一致，播放器外观统一；
   2. 可以自己实现「分级播放」：解析主清单里的多条码率，
      按档位（清晰度）切换，切换后保持当前播放进度；
   3. 多线路容灾：首选线路拉流失败时自动降级到备用线路。

   说明：页面加载后直接尝试起播，不显示任何起播提示或遮罩；
   未能自动起播时用原生 controls 或「立即播放」按钮即可，不额外打扰用户。
   只有「所有线路都加载失败」这种真故障才显示错误层。

   props:
     src         m3u8 地址
     sources     备用线路列表（数组，按优先级排列）；首选线路失效时自动降级
     poster      封面图
     startAt     起播位置（秒）
     playToken   外部「立即播放」信号，每变化一次触发一次显式 play()
   emits:
     levels      解析出可用清晰度档位 [{ label, height, index }]
     playing     开始播放
     error       所有线路均失败
   expose:
     play()      供父组件在用户手势里直接调用
     retry()     清空线路队列重新起播
   ========================================================= */
import { ref, watch, onBeforeUnmount, onMounted, nextTick } from 'vue'
import Hls from 'hls.js'

const props = defineProps({
  src: { type: String, default: '' },
  sources: { type: Array, default: () => [] },
  poster: { type: String, default: '' },
  startAt: { type: Number, default: 0 },
  playToken: { type: Number, default: 0 }
})

const emit = defineEmits(['levels', 'playing', 'error'])

const videoEl = ref(null)
/** 当前选中的清晰度档位索引，-1 表示自动 */
const levelIndex = ref(-1)
/** 可用清晰度档位 */
const levels = ref([])
/** 所有线路都失败时的错误文案（唯一的加载失败提示层） */
const loadError = ref('')
/** 当前线路提示，便于排查是哪条 CDN 在工作 */
const lineInfo = ref('')
/** 只有配置了多条线路时才展示线路提示 */
const candidatesHint = ref(false)

let hls = null

/* ---------- 多线路容灾 ----------
   外部 CDN 域名随时可能失效（DNS 停解析、证书过期、临时 502 等）。
   这里把可用线路排成队列，首选线路拉流失败时自动切到下一条，
   避免整部番因单个域名挂掉而全部无法播放。 */

/* 当前正在尝试的线路列表（按优先级） */
let candidates = []
/* 当前正在尝试的线路下标 */
let candIndex = 0
/* 本轮播放已尝试过的线路，用于避免重复试同一条 */
const tried = new Set()
/* 当前线路连续网络失败次数：达到阈值才降级，避免偶发抖动误切 */
let networkFails = 0
const MAX_NETWORK_FAILS = 2
/* 用户是否已主动请求播放：切集 / 降级后据此自动续播 */
let wantPlay = false

/**
 * 组装本轮可尝试的线路队列。
 * sources 由后端按优先级下发（含首选线路）；props.src 为最终兜底。
 */
function buildCandidates() {
  const list = []
  const push = (u) => {
    if (u && typeof u === 'string' && u.trim() && !list.includes(u.trim())) {
      list.push(u.trim())
    }
  }
  ;(props.sources || []).forEach(push)
  push(props.src)
  return list
}

/* ---------- 清晰度档位解析 ---------- */

/**
 * 拉取主清单，解析出各条码率（BANDWIDTH / RESOLUTION）。
 * 只含单条码率时不展示档位选择器。
 */
async function fetchLevels(url) {
  try {
    const res = await fetch(url, { method: 'GET' })
    const text = await res.text()
    if (!text.includes('#EXTM3U')) return []
    const lines = text.split('\n').map((l) => l.trim())
    const out = []
    for (let i = 0; i < lines.length; i++) {
      if (!lines[i].startsWith('#EXT-X-STREAM-INF')) continue
      const bw = /BANDWIDTH=(\d+)/.exec(lines[i])
      const res_ = /RESOLUTION=(\d+x\d+)/.exec(lines[i])
      if (!res_ && !bw) continue
      const [w, h] = res_ ? res_[1].split('x').map(Number) : [0, 0]
      out.push({
        index: out.length,
        width: w,
        height: h,
        bandwidth: bw ? Number(bw[1]) : 0,
        label: h ? `${h}P` : bw ? `${Math.round(bw[1] / 1000)}K` : '自动'
      })
    }
    // 按分辨率从高到低排序
    out.sort((a, b) => b.height - a.height)
    out.forEach((l, i) => {
      l.index = i
    })
    return out
  } catch {
    return []
  }
}

/* ---------- 起播 ----------
   统一收敛到 tryPlay()：尝试 play()，成功就抛 playing；
   未自动起播时不弹任何提示，交给原生 controls 或「立即播放」按钮。 */
function tryPlay() {
  const video = videoEl.value
  if (!video) return
  const p = video.play()
  if (p && typeof p.then === 'function') {
    p.then(() => emit('playing')).catch(() => {})
  } else {
    emit('playing')
  }
}

/** 外部「立即播放」调用入口：记录播放意图并立刻尝试 */
function play() {
  wantPlay = true
  tryPlay()
}

/** 用户点「重新加载」：清空本轮线路记录，从首选线路重试 */
function retry() {
  const video = videoEl.value
  const resume = video && Number.isFinite(video.currentTime) ? video.currentTime : 0
  wantPlay = true
  startWithQueue(props.src, resume)
}

/* ---------- 播放器初始化 ---------- */

function destroy() {
  if (hls) {
    hls.destroy()
    hls = null
  }
}

function currentResume() {
  const video = videoEl.value
  return video && Number.isFinite(video.currentTime) && video.currentTime > 0
    ? video.currentTime
    : 0
}

async function setup(url, resumeAt = 0) {
  const video = videoEl.value
  if (!video || !url) return
  destroy()
  video.removeEventListener('loadedmetadata', onNativeReady)
  networkFails = 0
  lineInfo.value = `线路 ${Math.min(candIndex, candidates.length) || 1}/${candidates.length || 1}`

  // 原生支持 HLS 的浏览器（Safari / iOS）直接交给系统播放器
  if (video.canPlayType('application/vnd.apple.mpegurl')) {
    video.src = url
    video.addEventListener('loadedmetadata', onNativeReady, { once: true })
    try {
      if (resumeAt > 0) video.currentTime = resumeAt
      else if (video.currentTime > 0.1) video.currentTime = 0
    } catch { /* 时长未知时忽略 */ }
    return
  }

  if (!Hls.isSupported()) {
    loadError.value = '当前浏览器不支持 HLS 播放'
    emit('error', loadError.value)
    return
  }

  hls = new Hls({
    enableWorker: true,
    lowLatencyMode: true,
    backBufferLength: 90
  })
  hls.loadSource(url)
  hls.attachMedia(video)

  hls.on(Hls.Events.MANIFEST_PARSED, () => {
    networkFails = 0
    loadError.value = ''
    // 解析出清晰度档位后，若有当前选中档位则切过去
    const lv = hls.levels || []
    const mapped = lv.map((l, i) => ({
      index: i,
      width: l.width || 0,
      height: l.height || 0,
      bandwidth: l.bitrate || 0,
      label: l.height ? `${l.height}P` : `${Math.round((l.bitrate || 0) / 1000)}K`
    }))
    levels.value = mapped
    emit('levels', mapped)
    if (levelIndex.value >= 0 && levelIndex.value < mapped.length) {
      hls.currentLevel = levelIndex.value
    }
    // 切集时 hls.js 复用同一个 <video>，不会自动把播放位置归零，
    // 会沿用上一集的 currentTime 导致漏掉片头；这里显式归位。
    // 线路降级（resumeAt > 0）则保留进度，做到无缝续播。
    try {
      if (resumeAt > 0) video.currentTime = resumeAt
      else if (video.currentTime > 0.1) video.currentTime = 0
    } catch { /* 时长未知时忽略 */ }
    tryPlay()
  })

  hls.on(Hls.Events.LEVEL_SWITCHED, (_e, data) => {
    // 实际生效的档位可能与选中项一致，这里只同步展示
    levelIndex.value = data.level
  })

  hls.on(Hls.Events.ERROR, (_e, data) => {
    if (!data.fatal) return
    if (data.type === Hls.ErrorTypes.NETWORK_ERROR) {
      // 网络类错误：先原地恢复一次；连续失败才降级到下一条线路。
      // 旧实现只 startLoad() 无限原地重试，首选 CDN 一挂就整部番卡死。
      networkFails++
      if (networkFails >= MAX_NETWORK_FAILS) {
        tryNextCandidate()
      } else if (hls) {
        hls.startLoad()
      }
    } else if (data.type === Hls.ErrorTypes.MEDIA_ERROR) {
      if (hls) hls.recoverMediaError()
    } else {
      tryNextCandidate()
    }
  })
}

/** Safari 原生 HLS：加载完成后按用户意图起播 */
function onNativeReady() {
  if (wantPlay) tryPlay()
}

/** 原生 <video> 报错（Safari 分支，或 hls.js 未接管时）→ 降级到下一线路 */
function onVideoError() {
  if (hls) return // hls.js 的错误走上面自己的 ERROR 事件，避免重复切换
  tryNextCandidate()
}

/**
 * 降级到下一条线路。
 * 所有线路都试过仍失败时，才向外抛出错误并给出可重试的提示。
 */
function tryNextCandidate() {
  const resume = currentResume()
  destroy()

  // 跳过本轮已试过的线路
  while (candIndex < candidates.length && tried.has(candidates[candIndex])) {
    candIndex++
  }
  if (candIndex >= candidates.length) {
    loadError.value = '所有播放线路均加载失败，请稍后重试'
    emit('error', loadError.value)
    return
  }
  const next = candidates[candIndex]
  tried.add(next)
  candIndex++
  setup(next, resume)
}

/* ---------- 清晰度切换 ---------- */

/**
 * 切换清晰度档位。
 * hls.js 的 currentLevel = -1 表示自动；指定数字则锁定该档位。
 */
function setLevel(idx) {
  levelIndex.value = idx
  if (!hls) return
  const levels_ = hls.levels || []
  if (idx < 0 || idx >= levels_.length) {
    hls.currentLevel = -1
    return
  }
  hls.currentLevel = idx
}

/* ---------- 生命周期 ---------- */

/* 重置线路队列并开始播放（切集 / 首次挂载共用） */
function startWithQueue(url, resumeAt = 0) {
  candidates = buildCandidates()
  candIndex = 0
  tried.clear()
  networkFails = 0
  loadError.value = ''
  candidatesHint.value = candidates.length > 1
  if (candidates.length) {
    tried.add(candidates[0])
    candIndex = 1
  }
  setup(candidates[0] || url, resumeAt)
}

onMounted(async () => {
  await nextTick()
  if (!props.src) return
  const lv = await fetchLevels(props.src)
  levels.value = lv
  emit('levels', lv)
  startWithQueue(props.src, props.startAt)
})

/* src 或备用线路变化（切换分集 / 分集数据异步补齐）：重建播放器并从头播放。
   合并成一个 watch 很关键：切集时 src 与 sources 会同时变，
   拆成两个 watch 会重复初始化，且其中一个带着上一集进度把片头跳过。 */
watch(
  () => `${props.src}|${(props.sources || []).join('|')}`,
  async (key, oldKey) => {
    if (!props.src || key === oldKey) return
    await nextTick()
    startWithQueue(props.src, 0)
  }
)

/* 外部「立即播放」：这是用户手势，显式调 play() 即可起播 */
watch(
  () => props.playToken,
  (n, old) => {
    if (n > 0 && n !== old) play()
  }
)

onBeforeUnmount(destroy)

defineExpose({ setLevel, levels, videoEl, play, retry })
</script>

<template>
  <div class="hls-player">
    <video
      ref="videoEl"
      class="hls-video"
      :poster="poster"
      controls
      autoplay
      playsinline
      preload="metadata"
      @error="onVideoError"
    ></video>

    <!-- 只有「所有线路都加载失败」才提示 -->
    <div v-if="loadError" class="hls-overlay fail">
      <p class="hls-err-title">视频加载失败</p>
      <p class="hls-err-sub">{{ loadError }}</p>
      <button type="button" class="hls-retry" @click="retry">重新加载</button>
    </div>

    <!-- 当前线路提示（多线路容灾时便于判断走到了哪一条） -->
    <span v-if="lineInfo && candidatesHint" class="hls-line">{{ lineInfo }}</span>

    <!-- ============ 分级播放：清晰度档位 ============ -->
    <div v-if="levels.length > 1" class="hls-levels">
      <span class="hl-label">画质</span>
      <button
        type="button"
        class="hl-btn"
        :class="{ on: levelIndex === -1 }"
        @click="setLevel(-1)"
      >
        自动
      </button>
      <button
        v-for="l in levels"
        :key="l.index"
        type="button"
        class="hl-btn"
        :class="{ on: levelIndex === l.index }"
        @click="setLevel(l.index)"
      >
        {{ l.label }}
      </button>
    </div>
  </div>
</template>

<style scoped>
.hls-player {
  position: relative;
  width: 100%;
  height: 100%;
}
.hls-video {
  width: 100%;
  height: 100%;
  display: block;
  object-fit: contain;
  background: #14101f;
}
/* 遮罩：仅在所有线路加载失败时出现 */
.hls-overlay {
  position: absolute;
  inset: 0;
  z-index: 4;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  gap: 14px;
  padding: 20px;
  text-align: center;
  color: #fff;
  background: rgba(20, 16, 31, 0.78);
  backdrop-filter: blur(6px);
}
.hls-overlay p {
  font-size: 12.5px;
  color: rgba(255, 255, 255, 0.82);
  margin: 0;
}
.hls-err-title {
  font-size: 16px !important;
  font-weight: 800;
  color: #fff !important;
}
.hls-retry {
  margin-top: 2px;
  padding: 8px 20px;
  border-radius: 999px;
  border: 0;
  cursor: pointer;
  font-size: 12.5px;
  font-weight: 700;
  color: #fff;
  background: linear-gradient(135deg, #ff8fb1, #c084fc);
}
.hls-line {
  position: absolute;
  left: 12px;
  bottom: 12px;
  z-index: 3;
  padding: 3px 10px;
  border-radius: 8px;
  font-size: 11px;
  font-weight: 700;
  color: rgba(255, 255, 255, 0.9);
  background: rgba(20, 16, 31, 0.65);
  pointer-events: none;
}
/* ============ 画质档位 ============ */
.hls-levels {
  position: absolute;
  right: 12px;
  top: 12px;
  z-index: 3;
  display: flex;
  align-items: center;
  flex-wrap: wrap;
  gap: 5px;
  padding: 6px 10px;
  border-radius: 12px;
  background: rgba(20, 16, 31, 0.72);
  backdrop-filter: blur(8px);
  border: 1px solid rgba(255, 255, 255, 0.16);
}
.hl-label {
  font-size: 11px;
  font-weight: 700;
  color: rgba(255, 255, 255, 0.7);
  margin-right: 2px;
}
.hl-btn {
  padding: 3px 9px;
  border-radius: 8px;
  border: 1px solid rgba(255, 255, 255, 0.18);
  background: rgba(255, 255, 255, 0.1);
  color: rgba(255, 255, 255, 0.82);
  font-size: 11px;
  font-weight: 700;
  cursor: pointer;
  transition: 0.2s;
}
.hl-btn:hover {
  background: rgba(255, 255, 255, 0.22);
  color: #fff;
}
.hl-btn.on {
  background: linear-gradient(135deg, #ff8fb1, #c084fc);
  border-color: transparent;
  color: #fff;
  box-shadow: 0 4px 12px -4px rgba(192, 132, 252, 0.9);
}
</style>
