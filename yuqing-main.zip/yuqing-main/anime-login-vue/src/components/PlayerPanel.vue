<script setup>
/* =========================================================
   统一播放界面（PlayerPanel）
   —— 首页 / 番剧 / 排行 / 收藏 四个板块共用。

   结构：
     [ 播放器 ]  [ 标题 / 标签 / 简介 ]
                 [ 集数快选（分级播放入口）]
                 [ 完整分集列表 ]
                 [ 操作按钮 ]

   播放源分四种：
     native   → 原生 <video> 直链
     tencent  → 腾讯视频官方 iframe
     bilibili → 哔哩哔哩官方 iframe
     omofun   → 动漫共和国 HLS（m3u8），用 hls.js 直连播放

   props:
     item    播放条目 { title, src, sourceType, tags, views, danmaku, duration, desc, coverUrl, episodeList }
     compact 紧凑模式（用于番剧页 / 排行页 / 收藏页的卡片内播放）
   emits:
     close   关闭播放器（可选，父组件决定是否需要）
   ========================================================= */
import { computed } from 'vue'
import EpisodePanel from './EpisodePanel.vue'
import HlsPlayer from './HlsPlayer.vue'

const props = defineProps({
  item: { type: Object, required: true },
  compact: { type: Boolean, default: false }
})

const emit = defineEmits(['close'])

const eps = computed(() => props.item?.episodeList || [])
const hasEps = computed(() => eps.value.length > 0)
const isTencent = computed(() => props.item?.sourceType === 'tencent')
const isBilibili = computed(() => props.item?.sourceType === 'bilibili')
const isOmofun = computed(() => props.item?.sourceType === 'omofun')
/* HLS 直链：优先取当前分集的 m3u8，其次取条目自身的 m3u8Url */
const hlsSrc = computed(() => {
  if (!isOmofun.value) return ''
  return props.item?.currentEp?.m3u8Url || props.item?.m3u8Url || ''
})
</script>

<template>
  <div class="pp" :class="{ compact }">
    <!-- ============ 播放器 ============ -->
    <div class="pp-wrap">
      <slot name="media">
        <!-- 动漫共和国 HLS 源：用 hls.js 直连 m3u8，支持清晰度分级切换 -->
        <HlsPlayer
          v-if="isOmofun && hlsSrc"
          class="pp-media-wrap"
          :src="hlsSrc"
          :poster="item.coverUrl || item.img || item.fallbackPoster"
        />
        <iframe
          v-else-if="isBilibili && item.bilibiliSrc"
          class="pp-media"
          :src="item.bilibiliSrc"
          allowfullscreen
          frameborder="0"
          scrolling="no"
          referrerpolicy="no-referrer"
        ></iframe>
        <iframe
          v-else-if="isTencent && item.tencentSrc"
          class="pp-media"
          :src="item.tencentSrc"
          allowfullscreen
          frameborder="0"
          scrolling="no"
          referrerpolicy="no-referrer"
        ></iframe>
        <video
          v-else
          class="pp-media"
          :ref="item.setVideoEl"
          :src="item.currentEp?.src || item.src"
          :poster="item.coverUrl || item.img || item.fallbackPoster"
          controls
          preload="metadata"
          playsinline
        ></video>
      </slot>
      <button v-if="compact" class="pp-close" type="button" aria-label="关闭播放器" @click="emit('close')">×</button>
      <span class="pp-badge">NOW PLAYING</span>
    </div>

    <!-- ============ 信息 + 分集 ============ -->
    <div class="pp-info">
      <div class="pp-tags">
        <span v-for="t in item.tags" :key="t" class="pp-tag">{{ t }}</span>
        <span v-if="isTencent" class="pp-tag src-tag">腾讯视频</span>
        <span v-if="isBilibili" class="pp-tag src-tag src-tag-bili">哔哩哔哩</span>
        <span v-if="isOmofun" class="pp-tag src-tag src-tag-omo">动漫共和国</span>
        <span v-if="hasEps" class="pp-tag src-tag src-tag-ep">全 {{ eps.length }} 集</span>
      </div>

      <h3 class="pp-title">{{ item.title }}</h3>

      <div class="pp-stats">
        <span v-if="item.uploader">
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>{{ item.uploader }}
        </span>
        <span v-if="item.views">
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7-10-7-10-7z"/><circle cx="12" cy="12" r="3"/></svg>{{ item.views }} 播放
        </span>
        <span v-if="item.danmaku">
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 11.5a8.38 8.38 0 0 1-9 8.3A8.5 8.5 0 1 1 12 3a8.38 8.38 0 0 1 9 5.8"/></svg>{{ item.danmaku }} 弹幕
        </span>
        <span v-if="item.duration">
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/></svg>{{ item.duration }}
        </span>
      </div>

      <p v-if="item.desc" class="pp-desc">{{ item.desc }}</p>

      <!-- ============ 分级播放：按集数选择 ============ -->
      <EpisodePanel
        v-if="hasEps"
        :episodes="eps"
        :current="item.currentEp"
        label="选集"
        @select="(ep) => item.onPlayEpisode && item.onPlayEpisode(ep)"
        @prev="() => item.onPlayPrev && item.onPlayPrev()"
        @next="() => item.onPlayNext && item.onPlayNext()"
      />

      <div class="pp-actions">
        <button class="pp-btn primary" type="button" @click="item.onPlayCurrent && item.onPlayCurrent()">
          <svg width="15" height="15" viewBox="0 0 24 24" fill="currentColor"><path d="M8 5v14l11-7z"/></svg>
          立即播放
        </button>
        <button class="pp-btn ghost" type="button">
          <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M19 21l-7-5-7 5V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2z"/></svg>
          收藏
        </button>
        <button class="pp-btn ghost" type="button">
          <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="18" cy="5" r="3"/><circle cx="6" cy="12" r="3"/><circle cx="18" cy="19" r="3"/><path d="m8.6 13.5 6.8 4M15.4 6.5l-6.8 4"/></svg>
          分享
        </button>
      </div>
    </div>
  </div>
</template>

<style scoped>
.pp {
  display: grid;
  grid-template-columns: 1.55fr 1fr;
  border-radius: var(--radius);
  overflow: hidden;
  background: var(--glass);
  border: 1px solid rgba(255, 255, 255, 0.7);
  box-shadow: 0 30px 70px -34px rgba(90, 60, 140, 0.45);
  backdrop-filter: blur(20px);
  -webkit-backdrop-filter: blur(20px);
}
/* 紧凑模式：播放器在上，信息在下（番剧页 / 排行页 / 收藏页用） */
.pp.compact {
  grid-template-columns: 1fr;
}

/* ============ 播放器 ============ */
.pp-wrap {
  position: relative;
  background: #1c1530;
  min-height: 300px;
}
.pp.compact .pp-wrap {
  aspect-ratio: 16 / 9;
  min-height: 0;
}
.pp-media {
  width: 100%;
  height: 100%;
  display: block;
  object-fit: cover;
  background: #1c1530;
}
/* iframe 铺满播放区，保持 16:9 观感 */
.pp-wrap iframe.pp-media {
  object-fit: initial;
  border: 0;
  position: absolute;
  inset: 0;
}
.pp-badge {
  position: absolute;
  top: 14px;
  left: 14px;
  padding: 5px 12px;
  border-radius: 999px;
  font-size: 10.5px;
  font-weight: 700;
  letter-spacing: 0.12em;
  color: #fff;
  background: rgba(244, 63, 94, 0.85);
  backdrop-filter: blur(4px);
  pointer-events: none;
}
.pp-close {
  position: absolute;
  top: 12px;
  right: 12px;
  z-index: 2;
  width: 32px;
  height: 32px;
  border-radius: 50%;
  border: 1px solid rgba(255, 255, 255, 0.5);
  background: rgba(28, 21, 48, 0.55);
  color: #fff;
  font-size: 20px;
  line-height: 1;
  cursor: pointer;
  backdrop-filter: blur(4px);
  transition: background 0.2s;
}
.pp-close:hover {
  background: rgba(244, 63, 94, 0.8);
}

/* ============ 信息区 ============ */
.pp-info {
  padding: 22px 24px;
  display: flex;
  flex-direction: column;
  min-width: 0;
}
.pp.compact .pp-info {
  padding: 16px 18px 18px;
}
.pp-tags {
  display: flex;
  flex-wrap: wrap;
  gap: 7px;
  margin-bottom: 10px;
}
.pp-tag {
  padding: 4px 11px;
  border-radius: 999px;
  font-size: 11.5px;
  font-weight: 600;
  color: #8b5cf6;
  background: rgba(255, 255, 255, 0.8);
  border: 1px solid rgba(192, 132, 252, 0.3);
}
.src-tag {
  color: #0ea5e9;
  background: rgba(255, 255, 255, 0.9);
  border-color: rgba(14, 165, 233, 0.35);
}
.src-tag-bili {
  color: #fb7299;
  border-color: rgba(251, 114, 153, 0.35);
}
.src-tag-ep {
  color: #10b981;
  border-color: rgba(16, 185, 129, 0.35);
}
/* 动漫共和国源标签 */
.src-tag-omo {
  color: #f97316;
  border-color: rgba(249, 115, 22, 0.35);
}
/* HLS 播放器容器：铺满播放区 */
.pp-media-wrap {
  position: absolute;
  inset: 0;
  width: 100%;
  height: 100%;
}
.pp-title {
  font-size: 18px;
  font-weight: 800;
  line-height: 1.45;
  margin-bottom: 10px;
  color: var(--ink);
}
.pp.compact .pp-title {
  font-size: 17px;
}
.pp-stats {
  display: flex;
  flex-wrap: wrap;
  gap: 15px;
  margin-bottom: 12px;
  color: var(--ink-soft);
  font-size: 12.5px;
}
.pp-stats span {
  display: inline-flex;
  align-items: center;
  gap: 6px;
}
.pp-desc {
  font-size: 13px;
  line-height: 1.8;
  color: var(--ink-soft);
  margin-bottom: 16px;
  display: -webkit-box;
  -webkit-line-clamp: 3;
  -webkit-box-orient: vertical;
  overflow: hidden;
}
.pp-actions {
  display: flex;
  flex-wrap: wrap;
  gap: 10px;
  margin-top: auto;
}
.pp-btn {
  display: inline-flex;
  align-items: center;
  gap: 8px;
  height: 42px;
  padding: 0 20px;
  border-radius: 14px;
  border: 0;
  cursor: pointer;
  font-size: 13px;
  font-weight: 700;
  letter-spacing: 0.04em;
  transition: transform 0.22s, box-shadow 0.22s, background 0.22s;
}
.pp-btn.primary {
  color: #fff;
  background: var(--grad);
  background-size: 220% 100%;
  box-shadow: 0 14px 28px -12px rgba(192, 132, 252, 0.95);
}
.pp-btn.primary:hover {
  transform: translateY(-2px);
  background-position: 100% 0;
}
.pp-btn.ghost {
  color: var(--accent);
  background: rgba(255, 255, 255, 0.8);
  border: 1.5px solid var(--line);
}
.pp-btn.ghost:hover {
  transform: translateY(-2px);
  background: #fff;
  border-color: #e3d4ff;
}

@media (max-width: 980px) {
  .pp {
    grid-template-columns: 1fr;
  }
  .pp-wrap {
    min-height: 220px;
  }
}
</style>
