<script setup>
/* 收藏页：展示 video 表中 fav=1 的视频，
   与后台「视频管理 → 标记为收藏」共用同一份数据。
   带多集的视频可在播放界面里按集数分级播放。 */
import { ref, computed, onMounted } from 'vue'
import { fetchFavorites } from '../api'
import PlayerPanel from './PlayerPanel.vue'
import { usePlayer } from '../composables/usePlayer'

defineProps({ user: Object, q: String })
const list = ref([])
const loading = ref(true)
const errorMsg = ref('')

/* 播放逻辑与首页共用 */
const player = usePlayer()
const { current } = player

/* 传给 PlayerPanel 的播放条目（含当前分集与回调） */
const playItem = computed(() => {
  if (!current.value) return null
  return {
    ...current.value,
    currentEp: player.currentEp.value,
    bilibiliSrc: player.bilibiliSrc.value,
    tencentSrc: player.tencentSrc.value,
    m3u8Url: current.value.m3u8Url || player.currentEp.value?.m3u8Url || '',
    setVideoEl: player.setVideoEl,
    onPlayEpisode: player.playEpisode,
    onPlayPrev: player.playPrev,
    onPlayNext: player.playNext,
    onPlayCurrent: player.playCurrent
  }
})

async function load() {
  loading.value = true
  errorMsg.value = ''
  try {
    list.value = await fetchFavorites()
  } catch (e) {
    errorMsg.value = e.message || '收藏列表加载失败'
  } finally {
    loading.value = false
  }
}

/* 点击收藏卡片：播放该条目（有分集时默认第 1 集） */
function play(v) {
  player.playItem(v)
  requestAnimationFrame(() => {
    document.getElementById('fav-player')?.scrollIntoView({ behavior: 'smooth', block: 'center' })
  })
}

function closePlayer() {
  player.playItem(null)
}

onMounted(load)
</script>

<template>
  <div class="page">
    <div class="sec-head">
      <h2>我的收藏</h2>
      <span class="sec-sub">{{ loading ? '加载中…' : `${list.length} 个视频` }}</span>
    </div>

    <div v-if="loading" class="loading-wrap">
      <i class="loader-spin"></i><span>正在连接次元…</span>
    </div>

    <div v-else-if="errorMsg" class="err-bar">
      <span>⚠ {{ errorMsg }}</span>
      <button class="btn ghost" type="button" @click="load">重新加载</button>
    </div>

    <!-- ============ 收藏播放界面（支持按集数分级播放） ============ -->
    <section v-else-if="current" id="fav-player" class="f-player">
      <PlayerPanel :item="playItem" compact @close="closePlayer" />
    </section>

    <div v-else-if="list.length" class="grid">
      <article
        v-for="v in list"
        :key="v.id"
        class="f-card"
        :class="{ on: current && current.id === v.id }"
        @click="play(v)"
      >
        <div class="thumb" :style="{ background: v.grad }">
          <img v-if="v.coverUrl || v.img" class="t-img" :src="v.coverUrl || v.img" :alt="v.title" loading="lazy" />
          <span class="play">
            <svg width="22" height="22" viewBox="0 0 24 24" fill="#fff"><path d="M8 5v14l11-7z"/></svg>
          </span>
          <span class="dur">{{ v.duration }}</span>
          <span v-if="v.episodeList && v.episodeList.length" class="ep-count">共 {{ v.episodeList.length }} 集</span>
          <span class="heart">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="#fff"><path d="M19 21l-7-5-7 5V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2z"/></svg>
          </span>
        </div>
        <div class="v-body">
          <h4 class="v-name">{{ v.title }}</h4>
          <p class="v-up">{{ v.uploader }}</p>
          <p class="v-count">{{ v.views }} 播放 · {{ v.danmaku }} 弹幕</p>
        </div>
      </article>
    </div>

    <div v-else class="empty">
      <svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><path d="M19 21l-7-5-7 5V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2z"/></svg>
      <p>还没有收藏，去首页挑一部喜欢的吧～</p>
    </div>

    <footer class="foot">桜次元 · Sakura — 收藏数据由后台管理系统统一维护</footer>
  </div>
</template>

<style scoped>
/* 加载失败提示条（与首页 err-bar 视觉一致，scoped 独立定义避免影响其它页） */
.err-bar {
  display: flex;
  align-items: center;
  justify-content: space-between;
  flex-wrap: wrap;
  gap: 14px;
  margin: 0 0 22px;
  padding: 14px 18px;
  border-radius: 16px;
  font-size: 13px;
  color: #b42318;
  background: rgba(255, 228, 230, 0.9);
  border: 1px solid rgba(244, 63, 94, 0.35);
}
.err-bar .btn {
  height: 36px;
  padding: 0 16px;
  font-size: 12.5px;
  flex-shrink: 0;
}
.err-bar .btn.ghost {
  color: var(--accent);
  background: rgba(255, 255, 255, 0.8);
  border: 1.5px solid var(--line);
  border-radius: 14px;
  font-weight: 700;
  cursor: pointer;
  transition: 0.22s;
}
.err-bar .btn.ghost:hover {
  background: #fff;
  border-color: #e3d4ff;
}

/* ============ 收藏播放界面 ============ */
.f-player {
  margin-bottom: 22px;
}

.f-card {
  border-radius: 18px;
  overflow: hidden;
  background: var(--glass);
  border: 1px solid rgba(255, 255, 255, 0.7);
  box-shadow: 0 18px 40px -28px rgba(90, 60, 140, 0.5);
  backdrop-filter: blur(14px);
  -webkit-backdrop-filter: blur(14px);
  cursor: pointer;
  transition: transform 0.26s cubic-bezier(0.2, 0.8, 0.25, 1), box-shadow 0.26s, border-color 0.26s;
}
.f-card:hover {
  transform: translateY(-6px);
  box-shadow: 0 26px 50px -26px rgba(90, 60, 140, 0.6);
  border-color: #e3d4ff;
}
/* 正在播放的条目 */
.f-card.on {
  border-color: transparent;
  box-shadow: 0 0 0 2px #c084fc, 0 22px 46px -22px rgba(192, 132, 252, 0.8);
}
.thumb {
  position: relative;
  aspect-ratio: 16 / 9;
  display: grid;
  place-items: center;
  overflow: hidden;
}
.thumb .t-img {
  position: absolute;
  inset: 0;
  width: 100%;
  height: 100%;
  object-fit: cover;
  display: block;
}
.thumb .play {
  position: relative;
  z-index: 1;
  width: 52px;
  height: 52px;
  border-radius: 50%;
  background: rgba(255, 255, 255, 0.92);
  display: grid;
  place-items: center;
  box-shadow: 0 10px 24px -8px rgba(47, 36, 69, 0.5);
  transition: transform 0.26s, background 0.26s;
}
.f-card:hover .play {
  transform: scale(1.12);
  background: #fff;
}
.thumb .dur {
  position: absolute;
  right: 10px;
  bottom: 10px;
  padding: 3px 9px;
  border-radius: 8px;
  font-size: 11px;
  font-weight: 700;
  color: #fff;
  background: rgba(28, 21, 48, 0.7);
  backdrop-filter: blur(3px);
}
/* 可分集播放的条目标记 */
.thumb .ep-count {
  position: absolute;
  left: 10px;
  bottom: 10px;
  padding: 3px 9px;
  border-radius: 8px;
  font-size: 11px;
  font-weight: 700;
  color: #fff;
  background: rgba(192, 132, 252, 0.85);
  backdrop-filter: blur(3px);
}
.thumb .heart {
  position: absolute;
  top: 10px;
  right: 10px;
  width: 26px;
  height: 26px;
  border-radius: 50%;
  display: grid;
  place-items: center;
  background: rgba(244, 63, 94, 0.9);
}
.v-body {
  padding: 14px 16px 16px;
}
.v-name {
  font-size: 14px;
  font-weight: 700;
  line-height: 1.5;
  color: var(--ink);
  display: -webkit-box;
  -webkit-line-clamp: 2;
  -webkit-box-orient: vertical;
  overflow: hidden;
}
.v-up {
  font-size: 12px;
  color: var(--accent);
  margin-top: 8px;
  font-weight: 600;
}
.v-count {
  font-size: 11.5px;
  color: var(--ink-soft);
  margin-top: 4px;
}
</style>
