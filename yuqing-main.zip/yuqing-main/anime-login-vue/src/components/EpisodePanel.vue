<script setup>
/* =========================================================
   分集播放面板（EpisodePanel）
   —— 供首页 / 番剧 / 排行 / 收藏 四个板块的播放界面共用。

   功能：
   1. 集数快选：把「选第几集」直接摆成一行数字按钮，
      点一下就切到对应集播放（这就是分级播放的核心交互）。
   2. 完整选集列表：带标题、时长、大会员标记。
   3. 上一集 / 下一集快捷跳转。
   4. 支持只读模式（只展示，不允许切换）。

   事件：
   - select(ep)  用户选择某一集
   - prev()      上一集
   - next()      下一集
   ========================================================= */
import { computed } from 'vue'

const props = defineProps({
  /* 分集列表，元素结构：{ id, epNo, title, src, duration, vip } */
  episodes: { type: Array, default: () => [] },
  /* 当前选中的分集 */
  current: { type: Object, default: null },
  /* 标题文案，默认「选集」 */
  label: { type: String, default: '选集' },
  /* 只读模式：仅展示不可点击 */
  readonly: { type: Boolean, default: false }
})

const emit = defineEmits(['select', 'prev', 'next'])

const total = computed(() => props.episodes.length)

/* 当前集序号（找不到时按 0 处理，避免第一页显示「第 0 集」） */
const currentNo = computed(() => {
  if (props.current) {
    const found = props.episodes.find((e) => e.epNo === props.current.epNo)
    if (found) return found.epNo
  }
  return 0
})

/* 上一集 / 下一集是否存在 */
const hasPrev = computed(() => {
  const i = props.episodes.findIndex((e) => e.epNo === currentNo.value)
  return i > 0
})
const hasNext = computed(() => {
  const i = props.episodes.findIndex((e) => e.epNo === currentNo.value)
  return i >= 0 && i < props.episodes.length - 1
})

/* 毫秒 → mm:ss */
function fmtDuration(ms) {
  if (!ms) return ''
  const total = Math.round(ms / 1000)
  return `${String(Math.floor(total / 60)).padStart(2, '0')}:${String(total % 60).padStart(2, '0')}`
}

function pick(ep) {
  if (props.readonly) return
  emit('select', ep)
}
</script>

<template>
  <div v-if="total" class="ep-panel">
    <!-- ============ 头部：标题 / 集数 / 上下集 ============ -->
    <div class="ep-head">
      <span class="ep-title">{{ label }}</span>
      <span class="ep-count">共 {{ total }} 集</span>
      <span v-if="current" class="ep-current">
        当前：第 {{ current.epNo }} 集 · {{ current.title }}
        <template v-if="current.vip">（大会员）</template>
      </span>
      <div v-if="!readonly && total > 1" class="ep-nav">
        <button
          type="button"
          class="ep-step"
          :disabled="!hasPrev"
          title="上一集"
          @click="emit('prev')"
        >
          <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><path d="m15 18-6-6 6-6"/></svg>
        </button>
        <button
          type="button"
          class="ep-step"
          :disabled="!hasNext"
          title="下一集"
          @click="emit('next')"
        >
          <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><path d="m9 18 6-6-6-6"/></svg>
        </button>
      </div>
    </div>

    <!-- ============ 集数快选：直接点数字切集 ============ -->
    <div class="ep-nums">
      <button
        v-for="ep in episodes"
        :key="ep.id || ep.epNo"
        type="button"
        class="ep-num"
        :class="{ on: current && current.epNo === ep.epNo, vip: ep.vip }"
        :title="`第 ${ep.epNo} 集 ${ep.title}${ep.vip ? '（大会员）' : ''}`"
        :disabled="readonly"
        @click="pick(ep)"
      >
        {{ ep.epNo }}
      </button>
    </div>

    <!-- ============ 完整选集列表：标题 + 时长 + VIP ============ -->
    <div class="ep-list">
      <button
        v-for="ep in episodes"
        :key="'d' + (ep.id || ep.epNo)"
        type="button"
        class="ep-item"
        :class="{ on: current && current.epNo === ep.epNo }"
        :title="ep.vip ? '大会员专享，需登录 B 站大会员观看' : ep.title"
        :disabled="readonly"
        @click="pick(ep)"
      >
        <span class="ep-no">{{ ep.epNo }}</span>
        <span class="ep-name">{{ ep.title }}</span>
        <span v-if="ep.vip" class="ep-vip">VIP</span>
        <span class="ep-dur">{{ fmtDuration(ep.duration) }}</span>
      </button>
    </div>
  </div>
</template>

<style scoped>
.ep-panel {
  margin-top: 16px;
  padding-top: 14px;
  border-top: 1px solid rgba(140, 120, 190, 0.18);
}
.ep-head {
  display: flex;
  align-items: center;
  flex-wrap: wrap;
  gap: 10px;
  margin-bottom: 10px;
}
.ep-title {
  font-size: 13px;
  font-weight: 800;
  color: var(--ink);
}
.ep-count {
  font-size: 11.5px;
  color: var(--ink-soft);
}
.ep-current {
  font-size: 11.5px;
  font-weight: 600;
  color: var(--accent);
}
/* 上一集 / 下一集 */
.ep-nav {
  display: flex;
  gap: 6px;
  margin-left: auto;
}
.ep-step {
  width: 28px;
  height: 28px;
  display: grid;
  place-items: center;
  border-radius: 9px;
  border: 1px solid var(--line);
  background: rgba(255, 255, 255, 0.7);
  color: var(--accent);
  cursor: pointer;
  transition: 0.2s;
}
.ep-step:hover:not(:disabled) {
  border-color: #e3d4ff;
  background: #fff;
  transform: translateY(-1px);
}
.ep-step:disabled {
  opacity: 0.35;
  cursor: not-allowed;
}

/* ============ 集数快选 ============ */
.ep-nums {
  display: flex;
  flex-wrap: wrap;
  gap: 6px;
  margin-bottom: 10px;
}
.ep-num {
  width: 34px;
  height: 34px;
  border-radius: 10px;
  border: 1px solid rgba(140, 120, 190, 0.22);
  background: rgba(255, 255, 255, 0.62);
  color: var(--ink);
  font-size: 13px;
  font-weight: 800;
  font-variant-numeric: tabular-nums;
  cursor: pointer;
  transition: border-color 0.2s, background 0.2s, transform 0.2s, color 0.2s;
}
.ep-num:hover:not(:disabled) {
  border-color: rgba(192, 132, 252, 0.6);
  background: #fff;
  transform: translateY(-1px);
}
.ep-num.on {
  border-color: transparent;
  background: var(--grad);
  color: #fff;
  box-shadow: 0 6px 14px -8px rgba(192, 132, 252, 0.9);
}
/* 大会员集：右上角小标记 */
.ep-num.vip {
  position: relative;
}
.ep-num.vip::after {
  content: '';
  position: absolute;
  top: 3px;
  right: 3px;
  width: 5px;
  height: 5px;
  border-radius: 50%;
  background: rgba(244, 63, 94, 0.85);
}
.ep-num.on.vip::after {
  background: rgba(255, 255, 255, 0.9);
}

/* ============ 完整选集列表 ============ */
.ep-list {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(148px, 1fr));
  gap: 8px;
}
.ep-item {
  display: flex;
  align-items: center;
  gap: 7px;
  padding: 7px 10px;
  border-radius: 10px;
  border: 1px solid rgba(140, 120, 190, 0.2);
  background: rgba(255, 255, 255, 0.6);
  color: var(--ink);
  font-size: 12px;
  cursor: pointer;
  text-align: left;
  transition: border-color 0.2s, background 0.2s, transform 0.2s;
}
.ep-item:hover:not(:disabled) {
  border-color: rgba(192, 132, 252, 0.6);
  background: rgba(255, 255, 255, 0.85);
  transform: translateY(-1px);
}
.ep-item.on {
  border-color: transparent;
  background: var(--grad);
  color: #fff;
  box-shadow: 0 6px 14px -8px rgba(192, 132, 252, 0.9);
}
.ep-no {
  flex: none;
  min-width: 20px;
  font-weight: 800;
  font-size: 11.5px;
  opacity: 0.75;
}
.ep-name {
  flex: 1;
  min-width: 0;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
.ep-vip {
  flex: none;
  padding: 1px 5px;
  border-radius: 5px;
  font-size: 9.5px;
  font-weight: 800;
  color: #fff;
  background: rgba(244, 63, 94, 0.85);
}
.ep-dur {
  flex: none;
  font-size: 10.5px;
  opacity: 0.7;
  font-variant-numeric: tabular-nums;
}
</style>
