<script setup>
/* 用户中心面板：修改资料 + 修改密码
   - 由 NavBar 头像点击唤出
   - 改密成功后，后端会立即使该账号此前签发的所有 token 失效，
     所以这里改密成功后直接触发父级的 onRelogin（回到登录页） */
import { ref, computed, watch } from 'vue'
import { updateProfile, changePassword } from '../api'

const props = defineProps({
  show: { type: Boolean, default: false },
  user: { type: Object, required: true }
})
const emit = defineEmits(['close', 'updated', 'relogin'])

/* ---------- 资料修改 ---------- */
const nickname = ref('')
const email = ref('')
const profileMsg = ref('')
const profileErr = ref('')
const savingProfile = ref(false)

/* ---------- 修改密码 ---------- */
const oldPwd = ref('')
const newPwd = ref('')
const confirmPwd = ref('')
const pwdMsg = ref('')
const pwdErr = ref('')
const savingPwd = ref(false)

const PWD_RULE = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[\W_]).{6,15}$/
const EMAIL_RULE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/

const pwdChecks = computed(() => [
  { label: '6-15 位', met: newPwd.value.length >= 6 && newPwd.value.length <= 15 },
  { label: '小写字母', met: /[a-z]/.test(newPwd.value) },
  { label: '大写字母', met: /[A-Z]/.test(newPwd.value) },
  { label: '数字', met: /\d/.test(newPwd.value) },
  { label: '特殊字符', met: /[\W_]/.test(newPwd.value) }
])

watch(
  () => props.show,
  (v) => {
    if (v) {
      nickname.value = props.user.nickname || ''
      email.value = props.user.email || ''
      profileMsg.value = ''
      profileErr.value = ''
      pwdMsg.value = ''
      pwdErr.value = ''
      oldPwd.value = ''
      newPwd.value = ''
      confirmPwd.value = ''
    }
  }
)

async function saveProfile() {
  if (savingProfile.value) return
  profileMsg.value = ''
  profileErr.value = ''

  const nick = nickname.value.trim()
  const mail = email.value.trim()
  if (!nick) {
    profileErr.value = '昵称不能为空'
    return
  }
  if (mail && !EMAIL_RULE.test(mail)) {
    profileErr.value = '邮箱格式不太对哦～'
    return
  }

  savingProfile.value = true
  try {
    const updated = await updateProfile({ nickname: nick, email: mail || null })
    profileMsg.value = '资料已更新'
    emit('updated', updated)
  } catch (e) {
    profileErr.value = e.message || '保存失败，请稍后再试'
  } finally {
    savingProfile.value = false
  }
}

async function savePassword() {
  if (savingPwd.value) return
  pwdMsg.value = ''
  pwdErr.value = ''

  if (!oldPwd.value) {
    pwdErr.value = '请输入原密码'
    return
  }
  if (!PWD_RULE.test(newPwd.value)) {
    pwdErr.value = '新密码需为 6-15 位，且包含数字、大小写字母和特殊字符'
    return
  }
  if (newPwd.value !== confirmPwd.value) {
    pwdErr.value = '两次输入的新密码不一致'
    return
  }

  savingPwd.value = true
  try {
    await changePassword({ oldPassword: oldPwd.value, newPassword: newPwd.value })
    pwdMsg.value = '密码已修改，请重新登录'
    // 后端已让旧 token 失效，稍作提示后回到登录页
    setTimeout(() => emit('relogin'), 900)
  } catch (e) {
    pwdErr.value = e.message || '修改失败，请稍后再试'
  } finally {
    savingPwd.value = false
  }
}
</script>

<template>
  <div v-if="show" class="up-mask" @click.self="emit('close')">
    <div class="up-panel">
      <header class="up-head">
        <div class="up-title">
          <span class="up-avatar">{{ (user.nickname || user.username || '?').slice(0, 1).toUpperCase() }}</span>
          <div>
            <strong>{{ user.nickname || user.username }}</strong>
            <small>{{ user.username }}</small>
          </div>
        </div>
        <button class="up-close" type="button" title="关闭" @click="emit('close')">×</button>
      </header>

      <section class="up-sec">
        <h4>个人资料</h4>
        <label class="up-field">
          <span>昵称</span>
          <input v-model="nickname" type="text" maxlength="32" placeholder="给自己起个名字" />
        </label>
        <label class="up-field">
          <span>邮箱<i class="up-opt">选填</i></span>
          <input v-model="email" type="text" placeholder="用于找回密码" />
        </label>
        <p v-if="profileErr" class="up-err">{{ profileErr }}</p>
        <p v-if="profileMsg" class="up-ok">{{ profileMsg }}</p>
        <button class="up-btn" type="button" :disabled="savingProfile" @click="saveProfile">
          {{ savingProfile ? '保存中…' : '保存资料' }}
        </button>
      </section>

      <section class="up-sec">
        <h4>修改密码</h4>
        <label class="up-field">
          <span>原密码</span>
          <input v-model="oldPwd" type="password" autocomplete="current-password" placeholder="输入当前密码" />
        </label>
        <label class="up-field">
          <span>新密码</span>
          <input v-model="newPwd" type="password" autocomplete="new-password" placeholder="6-15 位，含数字/大小写/特殊字符" />
        </label>
        <div class="up-checks">
          <span v-for="c in pwdChecks" :key="c.label" :class="{ met: c.met }">
            <i>{{ c.met ? '✓' : '·' }}</i>{{ c.label }}
          </span>
        </div>
        <label class="up-field">
          <span>确认新密码</span>
          <input v-model="confirmPwd" type="password" autocomplete="new-password" placeholder="再输入一次新密码" />
        </label>
        <p v-if="pwdErr" class="up-err">{{ pwdErr }}</p>
        <p v-if="pwdMsg" class="up-ok">{{ pwdMsg }}</p>
        <button class="up-btn up-btn-warn" type="button" :disabled="savingPwd" @click="savePassword">
          {{ savingPwd ? '提交中…' : '修改密码' }}
        </button>
        <p class="up-tip">修改密码后当前登录状态会失效，需要用新密码重新登录。</p>
      </section>
    </div>
  </div>
</template>

<style scoped>
.up-mask {
  position: fixed;
  inset: 0;
  z-index: 60;
  display: flex;
  align-items: center;
  justify-content: center;
  background: rgba(24, 28, 38, 0.45);
  backdrop-filter: blur(4px);
  padding: 20px;
}
.up-panel {
  width: min(430px, 100%);
  max-height: 88vh;
  overflow-y: auto;
  background: #fffdfd;
  border-radius: 20px;
  box-shadow: 0 24px 60px rgba(24, 28, 38, 0.28);
  padding: 22px 24px 26px;
  color: #33323c;
}
.up-head {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 12px;
  padding-bottom: 14px;
  border-bottom: 1px dashed rgba(160, 140, 170, 0.28);
}
.up-title {
  display: flex;
  align-items: center;
  gap: 12px;
}
.up-title strong {
  display: block;
  font-size: 16px;
}
.up-title small {
  color: #8d8899;
  font-size: 12px;
}
.up-avatar {
  width: 42px;
  height: 42px;
  border-radius: 50%;
  display: grid;
  place-items: center;
  background: linear-gradient(135deg, #7dd3fc, #ff8fb1);
  color: #fff;
  font-weight: 700;
  font-size: 17px;
}
.up-close {
  border: none;
  background: transparent;
  font-size: 24px;
  line-height: 1;
  color: #9b95a6;
  cursor: pointer;
  padding: 2px 6px;
  border-radius: 8px;
}
.up-close:hover {
  background: rgba(160, 140, 170, 0.12);
}
.up-sec {
  padding-top: 18px;
}
.up-sec h4 {
  margin: 0 0 12px;
  font-size: 14px;
  color: #6c6678;
  letter-spacing: 0.04em;
}
.up-field {
  display: block;
  margin-bottom: 12px;
}
.up-field > span {
  display: block;
  font-size: 12px;
  color: #857f92;
  margin-bottom: 5px;
}
.up-opt {
  font-style: normal;
  color: #b9b2c4;
  margin-left: 4px;
}
.up-field input {
  width: 100%;
  box-sizing: border-box;
  padding: 10px 12px;
  border: 1px solid rgba(160, 140, 170, 0.3);
  border-radius: 10px;
  font-size: 14px;
  background: #fff;
  outline: none;
  transition: border-color 0.18s, box-shadow 0.18s;
}
.up-field input:focus {
  border-color: #7dd3fc;
  box-shadow: 0 0 0 3px rgba(125, 211, 252, 0.22);
}
.up-checks {
  display: flex;
  flex-wrap: wrap;
  gap: 6px 12px;
  margin: -4px 0 12px;
  font-size: 11.5px;
  color: #b3adbd;
}
.up-checks span.met {
  color: #3fa88a;
}
.up-checks i {
  font-style: normal;
  margin-right: 3px;
}
.up-err {
  margin: 0 0 10px;
  color: #e05a72;
  font-size: 12.5px;
}
.up-ok {
  margin: 0 0 10px;
  color: #3fa88a;
  font-size: 12.5px;
}
.up-btn {
  width: 100%;
  padding: 11px 0;
  border: none;
  border-radius: 12px;
  font-size: 14px;
  font-weight: 600;
  color: #fff;
  background: linear-gradient(135deg, #67c8ea, #a78bfa);
  cursor: pointer;
  transition: opacity 0.18s, transform 0.12s;
}
.up-btn:hover:not(:disabled) {
  transform: translateY(-1px);
}
.up-btn:disabled {
  opacity: 0.55;
  cursor: not-allowed;
}
.up-btn-warn {
  background: linear-gradient(135deg, #f7a072, #ef7d9c);
}
.up-tip {
  margin: 10px 0 0;
  font-size: 11.5px;
  color: #a49dae;
  line-height: 1.6;
}
</style>
