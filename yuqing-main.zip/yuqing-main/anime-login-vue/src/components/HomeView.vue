<script setup>
import { computed } from 'vue'

const props = defineProps({
  user: { type: Object, required: true }
})

const emit = defineEmits(['logout'])

const initial = computed(() => {
  const name = props.user.nickname || props.user.username || '?'
  return name.slice(0, 1).toUpperCase()
})
</script>

<template>
  <div class="home">
    <div class="card">
      <div class="avatar">{{ initial }}</div>

      <div class="vtag">
        <span class="dot"></span>
        ONLINE · 次元链接已建立
      </div>

      <h1>欢迎回来，{{ user.nickname || user.username }}</h1>
      <p class="sub">夢幻の次元へようこそ —— 冒险仍在继续 ✦</p>

      <div class="info">
        <div class="row">
          <span class="k">用户名</span>
          <span class="v">{{ user.username }}</span>
        </div>
        <div class="row" v-if="user.email">
          <span class="k">邮箱</span>
          <span class="v">{{ user.email }}</span>
        </div>
        <div class="row">
          <span class="k"> UID </span>
          <span class="v">#{{ String(user.id).padStart(6, '0') }}</span>
        </div>
      </div>

      <button class="logout" type="button" @click="emit('logout')">
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round">
          <path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4" />
          <path d="m16 17 5-5-5-5M21 12H9" />
        </svg>
        退出登录
      </button>
    </div>
  </div>
</template>

<style scoped>
.home {
  position: relative;
  z-index: 1;
  width: 100%;
  min-height: 100vh;
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 30px;
}

.card {
  width: min(460px, 94vw);
  padding: 46px 44px 40px;
  border-radius: var(--radius);
  background: var(--glass);
  border: 1px solid rgba(255, 255, 255, 0.65);
  box-shadow: 0 34px 80px -34px rgba(90, 60, 140, 0.45);
  backdrop-filter: blur(20px);
  -webkit-backdrop-filter: blur(20px);
  text-align: center;
  animation: rise 0.7s cubic-bezier(0.2, 0.8, 0.25, 1) both;
}

.avatar {
  width: 92px;
  height: 92px;
  margin: 0 auto 18px;
  border-radius: 32px;
  background: var(--grad);
  display: grid;
  place-items: center;
  font-size: 38px;
  font-weight: 800;
  color: #fff;
  box-shadow: 0 20px 44px -16px rgba(192, 132, 252, 0.95);
  animation: logoFloat 4s ease-in-out infinite;
  user-select: none;
}

.vtag {
  display: inline-flex;
  align-items: center;
  gap: 8px;
  padding: 7px 14px;
  border-radius: 999px;
  font-size: 11.5px;
  letter-spacing: 0.06em;
  font-weight: 600;
  color: #8b5cf6;
  background: rgba(255, 255, 255, 0.75);
  border: 1px solid rgba(255, 255, 255, 0.9);
  margin-bottom: 20px;
}
.dot {
  width: 7px;
  height: 7px;
  border-radius: 50%;
  background: #34d399;
  box-shadow: 0 0 0 4px rgba(52, 211, 153, 0.22);
  animation: pulse 2s infinite;
}

h1 {
  font-size: 24px;
  font-weight: 800;
  letter-spacing: 0.02em;
  margin-bottom: 8px;
}
.sub {
  font-size: 13px;
  color: var(--ink-soft);
  margin-bottom: 28px;
  line-height: 1.7;
}

.info {
  border: 1.5px solid var(--line);
  border-radius: 16px;
  background: rgba(255, 255, 255, 0.55);
  padding: 6px 18px;
  margin-bottom: 26px;
}
.row {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 12px 0;
  font-size: 13.5px;
}
.row + .row {
  border-top: 1px dashed var(--line);
}
.k {
  color: var(--ink-soft);
  letter-spacing: 0.08em;
}
.v {
  font-weight: 700;
  color: var(--ink);
}

.logout {
  display: inline-flex;
  align-items: center;
  gap: 8px;
  padding: 13px 34px;
  border: 0;
  border-radius: 14px;
  cursor: pointer;
  background: var(--ink);
  color: #fff;
  font-size: 13.5px;
  font-weight: 700;
  letter-spacing: 0.1em;
  transition: transform 0.22s, box-shadow 0.22s;
}
.logout:hover {
  transform: translateY(-2px);
  box-shadow: 0 14px 28px -12px rgba(47, 36, 69, 0.7);
}
</style>
