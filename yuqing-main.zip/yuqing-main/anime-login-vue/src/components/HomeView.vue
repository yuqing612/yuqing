<script setup>
/* =========================================================
   首页（门户版 · 风格对齐动漫共和国，视觉沿用登录页）
   - 导航栏由 App 壳统一渲染（含搜索栏）
   - 结构：Hero 轮播 → 视频播放器 → 热门推荐 + 番剧新番 →
           侧边栏（热播排行 + 番剧时间表）
   - 数据全部来自后端：
       /api/home/overview 首页聚合（轮播/推荐/排行/分类/新番/时间表/热搜）
       /api/search 分级分类组合搜索
   ========================================================= */
import { ref, computed, watch, nextTick, onMounted, onBeforeUnmount } from 'vue'
import characterImg from '../assets/character.jpg'
import { fetchHomeOverview, searchAll } from '../api'
import FeatherField from './FeatherField.vue'

const props = defineProps({
  user: { type: Object, required: true },
  q: { type: String, default: '' }
})

/* ---------- 后端返回的首页聚合数据 ---------- */
const banners = ref([])
const videos = ref([])
const bangumi = ref([])
const ranks = ref([])
const categories = ref([])
const schedule = ref({ weekdays: [], today: '', items: {} })
const hotKeywords = ref([])
const stat = ref({})

const current = ref(null)
const loading = ref(true)
const loadError = ref('')
const query = ref(props.q || '')
const videoEl = ref(null)

/* ---------- 搜索状态 ---------- */
const searchResult = ref(null)
const searching = ref(false)
const searchPage = ref(1)
const searchSize = 12
const searchTotal = ref(0)
/* 分级分类筛选条件 */
const scope = ref('all')
const activeCategory = ref(null)
const rating = ref('')
const sortBy = ref('relevance')

/* Hero 轮播：优先用后端 banner，其次回落到番剧 */
const heroItems = computed(() => {
  if (banners.value.length) return banners.value
  return bangumi.value.slice(0, 5).map((b) => ({
    ...b,
    title: b.title,
    subtitle: b.desc,
    cover: b.cover,
    illust: b.illust,
    tag: b.status,
    score: b.score,
    episodes: b.episodes,
    studio: b.studio
  }))
})
const heroIndex = ref(0)
let heroTimer = null
function goHero(i) {
  heroIndex.value = (i + heroItems.value.length) % heroItems.value.length
}
function nextHero() {
  goHero(heroIndex.value + 1)
}
function prevHero() {
  goHero(heroIndex.value - 1)
}
function startHero() {
  stopHero()
  heroTimer = setInterval(nextHero, 5000)
}
function stopHero() {
  clearInterval(heroTimer)
}

/* ---------- 热门推荐：无搜索词时展示后端每日推荐 ---------- */
const filtered = computed(() => {
  if (searchResult.value) {
    // 搜索态：结果已在后端完成分级分类过滤与排序
    return searchResult.value.list.map(toCard)
  }
  return videos.value
})

/** 后端搜索条目 -> 前端卡片结构 */
function toCard(item) {
  if (item.type === 'bangumi') {
    return {
      id: item.id,
      isBangumi: true,
      title: item.title,
      uploader: item.subtitle,
      views: item.score != null ? `★ ${item.score.toFixed(1)}` : '',
      danmaku: item.rating || '',
      duration: item.categoryPath || '',
      tags: item.tags || [],
      grad: item.cover,
      coverUrl: item.illust,
      desc: item.desc
    }
  }
  return {
    id: item.id,
    isBangumi: false,
    title: item.title,
    uploader: item.subtitle,
    views: item.views || '',
    danmaku: item.danmaku || item.rating || '',
    duration: item.categoryPath || '',
    tags: item.tags || [],
    grad: item.cover,
    coverUrl: item.illust,
    src: item.src,
    desc: item.desc
  }
}

/* ---------- 分类筛选 ---------- */
/* 顶级分区 Tab + 二级子分类（分级分类） */
const topCats = computed(() => categories.value)
const activeChild = ref(null)
const flatChildCats = computed(() =>
  categories.value.flatMap((c) => c.children || []).filter((c) => c.totalCount > 0)
)
function pickCategory(cat) {
  activeCategory.value = cat ? cat.id : null
  activeChild.value = null
  searchPage.value = 1
  runSearch()
}
function pickChild(child) {
  activeChild.value = activeChild.value === child.id ? null : child.id
  activeCategory.value = activeChild.value
  searchPage.value = 1
  runSearch()
}
function clearFilters() {
  activeCategory.value = null
  activeChild.value = null
  rating.value = ''
  scope.value = 'all'
  sortBy.value = 'relevance'
  searchPage.value = 1
  runSearch()
}
function changeSort(v) {
  sortBy.value = v
  searchPage.value = 1
  runSearch()
}
function changeScope(v) {
  scope.value = v
  searchPage.value = 1
  runSearch()
}
function changeRating(v) {
  rating.value = v
  searchPage.value = 1
  runSearch()
}

/* 搜索触发条件：有关键词或任一筛选条件生效时走后端搜索 */
const hasFilter = computed(
  () =>
    !!query.value.trim() ||
    !!activeCategory.value ||
    !!rating.value ||
    scope.value !== 'all'
)

/* ---------- 番剧板块：分类 Tab + 海报墙（本地按 category 过滤） ---------- */
const CATS = ref(['全部', '日漫', '国漫', '剧场', '美漫'])
const cat = ref('全部')
const bangumiFiltered = computed(() =>
  cat.value === '全部' ? bangumi.value : bangumi.value.filter((b) => b.category === cat.value)
)

function playVideo(v) {
  current.value = v
  nextTick(() => videoEl.value && videoEl.value.load())
  document.getElementById('player')?.scrollIntoView({ behavior: 'smooth', block: 'start' })
}
function watchHero() {
  if (videos.value[0]) playVideo(videos.value[0])
}

/* ---------- 搜索：走后端 /api/search ---------- */
async function runSearch() {
  if (!hasFilter.value) {
    searchResult.value = null
    searchTotal.value = 0
    return
  }
  searching.value = true
  try {
    const data = await searchAll({
      keyword: query.value.trim(),
      categoryId: activeCategory.value || undefined,
      scope: scope.value,
      rating: rating.value || undefined,
      sort: sortBy.value,
      page: searchPage.value,
      size: searchSize
    })
    searchResult.value = data
    searchTotal.value = data.total || 0
    // 搜索结果里的视频可直接播放
    const firstVideo = (data.list || []).find((x) => x.type === 'video')
    if (firstVideo) current.value = toCard(firstVideo)
  } catch (e) {
    loadError.value = e.message || '搜索失败'
  } finally {
    searching.value = false
  }
}

function gotoPage(p) {
  searchPage.value = p
  runSearch()
}

watch(
  () => props.q,
  (val) => {
    query.value = val || ''
    searchPage.value = 1
    runSearch()
    nextTick(() =>
      document.getElementById('video-grid')?.scrollIntoView({ behavior: 'smooth', block: 'start' })
    )
  }
)

const initial = computed(() => {
  const name = props.user.nickname || props.user.username || '?'
  return name.slice(0, 1).toUpperCase()
})

/* 首页聚合数据：一次请求拿全所有板块 */
async function loadAll() {
  loading.value = true
  loadError.value = ''
  try {
    const data = await fetchHomeOverview()
    banners.value = data.banners || []
    videos.value = data.dailyVideos || []
    ranks.value = data.rankVideos || []
    categories.value = data.categories || []
    bangumi.value = data.bangumis || []
    schedule.value = data.schedule || { weekdays: [], today: '', items: {} }
    hotKeywords.value = data.hotKeywords || []
    stat.value = data.stat || {}
    current.value = videos.value[0] || null

    // 番剧分类 Tab 取实际分类
    const cats = [...new Set(bangumi.value.map((b) => b.category).filter(Boolean))]
    if (cats.length) CATS.value = ['全部', ...cats]

    // 导航栏带来的关键词：直接走后端搜索
    if (query.value.trim()) {
      await runSearch()
    }
  } catch (e) {
    loadError.value = e.message || '数据加载失败'
  } finally {
    startHero()
    loading.value = false
  }
}

onMounted(loadAll)
onBeforeUnmount(stopHero)
</script>

<template>
  <div class="page home">
    <FeatherField />
    <!-- 欢迎条（轻量） -->
    <div class="greet">
      <span class="g-avatar">{{ initial }}</span>
      <div>
        <p class="g-hi">欢迎回来，{{ user.nickname || user.username }} ✦</p>
        <p class="g-sub">今天也想看点和什么呢？挑一部，把烦恼留在现实的车站就好。</p>
      </div>
    </div>

    <div v-if="loading" class="loading-wrap">
      <i class="loader-spin"></i><span>正在连接次元…</span>
    </div>

    <div v-else-if="loadError && !bangumi.length && !videos.length" class="err-bar">
      <span>⚠ 数据加载失败：{{ loadError }}</span>
      <button class="btn ghost" type="button" @click="loadAll">重新加载</button>
    </div>
    <div v-else-if="loadError" class="err-bar warn">
      <span>⚠ 部分板块没加载出来：{{ loadError }}</span>
      <button class="btn ghost" type="button" @click="loadAll">重试</button>
    </div>

    <template v-if="!loading">
      <!-- ============ Hero 轮播 ============ -->
      <section class="hero">
        <div class="slides">
          <div
            v-for="(h, i) in heroItems"
            :key="h.id"
            class="slide"
            :class="{ active: i === heroIndex }"
            :style="{ background: h.cover }"
          >
            <img v-if="h.illust" class="slide-art" :src="h.illust" :alt="h.title" />
            <div class="slide-mask"></div>
            <div class="slide-content">
              <span class="h-tag">
                <i class="h-dot"></i>{{ h.tag || h.status }} · {{ h.studio }}
              </span>
              <h2 class="h-title">{{ h.title }}</h2>
              <p class="h-desc">{{ h.subtitle || h.desc }}</p>
              <div class="h-meta">
                <span v-if="h.score != null"><b>★</b> {{ h.score.toFixed(1) }}</span>
                <span v-if="h.episodes">全 {{ h.episodes }} 话</span>
              </div>
              <button class="btn primary" type="button" @click="watchHero">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor"><path d="M8 5v14l11-7z"/></svg>
                立即观看
              </button>
            </div>
          </div>
        </div>
        <button class="h-nav prev" type="button" aria-label="上一个" @click="prevHero">‹</button>
        <button class="h-nav next" type="button" aria-label="下一个" @click="nextHero">›</button>
        <div class="h-dots">
          <span
            v-for="(h, i) in heroItems"
            :key="h.id"
            :class="{ on: i === heroIndex }"
            @click="goHero(i)"
          ></span>
        </div>
      </section>

      <!-- ============ 视频播放器 ============ -->
      <section class="player-section" id="player" v-if="current">
        <div class="player-card">
          <div class="player-wrap">
            <video
              ref="videoEl"
              class="player"
              :src="current.src"
              :poster="current.coverUrl || current.img || characterImg"
              controls
              preload="metadata"
              playsinline
            ></video>
            <span class="live-badge">NOW PLAYING</span>
          </div>
          <div class="player-info">
            <div class="tags">
              <span v-for="t in current.tags" :key="t" class="tag">{{ t }}</span>
            </div>
            <h3 class="v-title">{{ current.title }}</h3>
            <div class="stats">
              <span><svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7-10-7-10-7z"/><circle cx="12" cy="12" r="3"/></svg>{{ current.views }} 播放</span>
              <span><svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 11.5a8.38 8.38 0 0 1-9 8.3A8.5 8.5 0 1 1 12 3a8.38 8.38 0 0 1 9 5.8"/></svg>{{ current.danmaku }} 弹幕</span>
              <span><svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/></svg>{{ current.duration }}</span>
            </div>
            <p class="v-desc">{{ current.desc }}</p>
            <div class="actions">
              <button class="btn primary" type="button" @click="videoEl && videoEl.play()">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor"><path d="M8 5v14l11-7z"/></svg>
                立即播放
              </button>
              <button class="btn ghost" type="button">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M19 21l-7-5-7 5V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2z"/></svg>
                收藏
              </button>
              <button class="btn ghost" type="button">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="18" cy="5" r="3"/><circle cx="6" cy="12" r="3"/><circle cx="18" cy="19" r="3"/><path d="m8.6 13.5 6.8 4M15.4 6.5l-6.8 4"/></svg>
                分享
              </button>
            </div>
          </div>
        </div>
      </section>

      <!-- ============ 主区 + 侧栏 ============ -->
      <div class="layout">
        <div class="main-col">
          <section class="block" id="video-grid">
            <div class="sec-head">
              <h3>{{ query.trim() ? `“${query.trim()}” 的搜索结果` : '热门推荐' }}</h3>
              <span class="sec-sub">{{ searchTotal || filtered.length }} 个视频</span>
            </div>

            <!-- 分级分类筛选：范围 / 一级分区 / 二级子分类 / 内容分级 / 排序 -->
            <div class="filter-bar">
              <div class="f-row">
                <span class="f-label">范围</span>
                <div class="f-group">
                  <span
                    v-for="s in [
                      { v: 'all', t: '全部' },
                      { v: 'video', t: '视频' },
                      { v: 'bangumi', t: '番剧' }
                    ]"
                    :key="s.v"
                    class="f-chip"
                    :class="{ on: scope === s.v }"
                    @click="changeScope(s.v)"
                  >{{ s.t }}</span>
                </div>
              </div>

              <div class="f-row">
                <span class="f-label">分区</span>
                <div class="f-group">
                  <span
                    class="f-chip"
                    :class="{ on: !activeCategory }"
                    @click="pickCategory(null)"
                  >全部</span>
                  <span
                    v-for="c in topCats"
                    :key="c.id"
                    class="f-chip"
                    :class="{ on: activeCategory === c.id }"
                    @click="pickCategory(c)"
                  >{{ c.name }} <i class="f-num">{{ c.totalCount }}</i></span>
                </div>
              </div>

              <div v-if="activeCategory && flatChildCats.length" class="f-row">
                <span class="f-label">子分类</span>
                <div class="f-group">
                  <span
                    v-for="c in flatChildCats"
                    :key="c.id"
                    class="f-chip sub"
                    :class="{ on: activeChild === c.id }"
                    @click="pickChild(c)"
                  >{{ c.name }}</span>
                </div>
              </div>

              <div class="f-row">
                <span class="f-label">分级</span>
                <div class="f-group">
                  <span
                    v-for="r in ['', '全年龄', '12+', '16+', '18+']"
                    :key="r || 'all'"
                    class="f-chip"
                    :class="{ on: rating === r }"
                    @click="changeRating(r)"
                  >{{ r || '不限' }}</span>
                </div>

                <span class="f-label ml">排序</span>
                <div class="f-group">
                  <span
                    v-for="o in [
                      { v: 'relevance', t: '相关度' },
                      { v: 'play', t: '播放量' },
                      { v: 'latest', t: '最新' },
                      { v: 'score', t: '评分' }
                    ]"
                    :key="o.v"
                    class="f-chip"
                    :class="{ on: sortBy === o.v }"
                    @click="changeSort(o.v)"
                  >{{ o.t }}</span>
                </div>

                <button v-if="hasFilter" class="f-clear" type="button" @click="clearFilters">
                  清除筛选
                </button>
              </div>

              <!-- 热门搜索词 -->
              <div v-if="hotKeywords.length && !query.trim()" class="f-row">
                <span class="f-label">热搜</span>
                <div class="f-group">
                  <span
                    v-for="h in hotKeywords"
                    :key="h.keyword"
                    class="f-chip hot"
                    @click="query = h.keyword; runSearch()"
                  >{{ h.keyword }} <i class="f-num">{{ h.count }}</i></span>
                </div>
              </div>
            </div>

            <div v-if="searching" class="loading-wrap">
              <i class="loader-spin"></i><span>正在检索…</span>
            </div>

            <div v-else-if="filtered.length" class="grid">
              <article
                v-for="v in filtered"
                :key="`${v.isBangumi ? 'b' : 'v'}-${v.id}`"
                class="v-card"
                :class="{ on: current && current.id === v.id && !v.isBangumi }"
                @click="!v.isBangumi && playVideo(v)"
              >
                <div class="thumb" :style="{ background: v.grad }">
                  <img v-if="v.coverUrl || v.img" class="t-img" :src="v.coverUrl || v.img" :alt="v.title" loading="lazy" />
                  <span class="play"><svg width="22" height="22" viewBox="0 0 24 24" fill="#fff"><path d="M8 5v14l11-7z"/></svg></span>
                  <span class="dur">{{ v.duration }}</span>
                </div>
                <div class="v-body">
                  <h4 class="v-name">{{ v.title }}</h4>
                  <p class="v-up">{{ v.uploader }}</p>
                  <p class="v-count">{{ v.views }} {{ v.danmaku }}</p>
                </div>
              </article>
            </div>
            <div v-else class="empty">
              <p>没有找到相关视频，换个关键词或分类试试吧～</p>
            </div>

            <!-- 分页 -->
            <div v-if="searchResult && searchTotal > searchSize" class="pager">
              <button
                class="pg-btn"
                type="button"
                :disabled="searchPage <= 1"
                @click="gotoPage(searchPage - 1)"
              >上一页</button>
              <span class="pg-info">{{ searchPage }} / {{ searchResult.pages }}</span>
              <button
                class="pg-btn"
                type="button"
                :disabled="searchPage >= searchResult.pages"
                @click="gotoPage(searchPage + 1)"
              >下一页</button>
            </div>
          </section>

          <section class="block">
            <div class="sec-head">
              <h3>番剧新番</h3>
              <div class="cat-tabs">
                <span
                  v-for="c in CATS"
                  :key="c"
                  :class="{ on: cat === c }"
                  @click="cat = c"
                >{{ c }}</span>
              </div>
            </div>
            <div class="poster-grid">
              <article v-for="b in bangumiFiltered" :key="b.id" class="p-card">
                <div class="poster" :style="{ background: b.cover }">
                  <img v-if="b.illust" class="p-img" :src="b.illust" :alt="b.title" loading="lazy" />
                  <i class="p-shade"></i>
                  <span v-if="b.status === '连载中'" class="p-status">连载中</span>
                  <span class="p-score">{{ b.score.toFixed(1) }}分</span>
                </div>
                <p class="p-name">{{ b.title }}</p>
                <p class="p-sub">更新至第 {{ b.episodes }} 集 · {{ b.category }}</p>
              </article>
            </div>
            <div v-if="!bangumiFiltered.length" class="empty">
              <p>该分类下暂无番剧</p>
            </div>
          </section>
        </div>

        <aside class="side-col">
          <section class="block">
            <div class="sec-head"><h3>热播排行</h3></div>
            <div class="side-rank">
              <div
                v-for="v in ranks.slice(0, 6)"
                :key="v.id"
                class="sr-row"
                :class="`top${v.rank <= 3 ? v.rank : ''}`"
                @click="playVideo(v)"
              >
                <span class="sr-no">{{ v.rank }}</span>
                <div class="sr-info">
                  <p class="sr-name">{{ v.title }}</p>
                  <p class="sr-views">{{ v.views }} 播放</p>
                </div>
              </div>
            </div>
          </section>

          <section class="block">
            <div class="sec-head">
              <h3>番剧时间表</h3>
              <span class="sec-sub">今天 · {{ schedule.today }}</span>
            </div>
            <div class="week-tabs">
              <span
                v-for="d in schedule.weekdays"
                :key="d"
                class="wt"
                :class="{ on: d === schedule.today }"
              >{{ d.replace('周', '') }}</span>
            </div>
            <ul class="sched-list">
              <li v-for="(it, i) in (schedule.items[schedule.today] || [])" :key="i">
                <span class="sc-time">{{ it.time }}</span>
                <span class="sc-title">{{ it.title }}</span>
                <span class="sc-ep">第 {{ it.ep }} 话</span>
              </li>
              <li v-if="!(schedule.items[schedule.today] || []).length" class="sc-none">
                今天没有更新哦～
              </li>
            </ul>
          </section>

          <!-- 站点统计 -->
          <section v-if="stat.videoCount" class="block">
            <div class="sec-head"><h3>次元统计</h3></div>
            <div class="stat-grid">
              <div class="st-item">
                <span class="st-num">{{ stat.videoCount }}</span>
                <span class="st-label">视频</span>
              </div>
              <div class="st-item">
                <span class="st-num">{{ stat.bangumiCount }}</span>
                <span class="st-label">番剧</span>
              </div>
              <div class="st-item">
                <span class="st-num">{{ stat.categoryCount }}</span>
                <span class="st-label">分类</span>
              </div>
              <div class="st-item">
                <span class="st-num">{{ ((stat.totalPlay || 0) / 10000).toFixed(1) }}万</span>
                <span class="st-label">播放</span>
              </div>
            </div>
          </section>
        </aside>
      </div>
    </template>

    <footer class="foot">桜次元 · Sakura — 数据来自后端 /api/home/overview 与 /api/search</footer>
  </div>
</template>

<style scoped>
.page {
  max-width: 1200px;
  margin: 0 auto;
  padding: 26px 22px 60px;
  animation: rise 0.6s cubic-bezier(0.2, 0.8, 0.25, 1) both;
}

/* 欢迎条 */
.greet {
  display: flex;
  align-items: center;
  gap: 14px;
  margin-bottom: 22px;
}
.g-avatar {
  width: 46px;
  height: 46px;
  border-radius: 15px;
  background: var(--grad);
  display: grid;
  place-items: center;
  font-size: 19px;
  font-weight: 800;
  color: #fff;
  box-shadow: 0 10px 22px -10px rgba(192, 132, 252, 0.9);
  flex-shrink: 0;
}
.g-hi {
  font-size: 18px;
  font-weight: 800;
  letter-spacing: 0.02em;
}
.g-sub {
  font-size: 12.5px;
  color: var(--ink-soft);
  margin-top: 3px;
}

/* ============ Hero 轮播 ============ */
.hero {
  position: relative;
  border-radius: var(--radius);
  overflow: hidden;
  height: 420px;
  margin-bottom: 30px;
  box-shadow: 0 30px 70px -34px rgba(90, 60, 140, 0.5);
  background: #1c1530;
}
.slides {
  position: absolute;
  inset: 0;
}
.slide {
  position: absolute;
  inset: 0;
  opacity: 0;
  transform: scale(1.06);
  transition: opacity 0.8s ease, transform 6s ease;
  display: flex;
  align-items: flex-end;
}
.slide.active {
  opacity: 1;
  transform: scale(1);
  z-index: 1;
}
/* 番剧插画：裁切贴右侧，与左侧文案形成留白 */
.slide-art {
  position: absolute;
  z-index: 1;
  top: 0;
  right: 0;
  width: 40%;
  height: 100%;
  object-fit: cover;
  object-position: center 28%;
  -webkit-mask-image: linear-gradient(90deg, transparent 0%, #000 30%, #000 100%);
  mask-image: linear-gradient(90deg, transparent 0%, #000 30%, #000 100%);
}
.slide-mask {
  position: absolute;
  z-index: 2;
  inset: 0;
  background: linear-gradient(90deg, rgba(28, 21, 48, 0.82) 0%, rgba(28, 21, 48, 0.35) 48%, transparent 78%),
    linear-gradient(0deg, rgba(28, 21, 48, 0.7), transparent 40%);
}
.slide-content {
  position: relative;
  z-index: 2;
  max-width: 620px;
  padding: 0 0 46px 44px;
  color: #fff;
}
.h-tag {
  display: inline-flex;
  align-items: center;
  gap: 7px;
  padding: 6px 13px;
  border-radius: 999px;
  font-size: 12px;
  font-weight: 600;
  background: rgba(255, 255, 255, 0.18);
  backdrop-filter: blur(6px);
  margin-bottom: 14px;
}
.h-dot {
  width: 7px;
  height: 7px;
  border-radius: 50%;
  background: #34d399;
  box-shadow: 0 0 0 3px rgba(52, 211, 153, 0.25);
}
.h-title {
  font-size: 32px;
  font-weight: 900;
  line-height: 1.25;
  text-shadow: 0 3px 18px rgba(0, 0, 0, 0.4);
}
.h-desc {
  font-size: 13.5px;
  line-height: 1.7;
  margin: 12px 0 14px;
  color: rgba(255, 255, 255, 0.9);
  max-width: 540px;
}
.h-meta {
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  gap: 12px;
  margin-bottom: 20px;
  font-size: 13px;
  color: rgba(255, 255, 255, 0.95);
}
.h-meta b {
  color: #ffd98a;
}
.h-chip {
  padding: 3px 10px;
  border-radius: 999px;
  font-size: 11.5px;
  background: rgba(255, 255, 255, 0.16);
}
.h-nav {
  position: absolute;
  top: 50%;
  transform: translateY(-50%);
  z-index: 3;
  width: 44px;
  height: 44px;
  border: 0;
  border-radius: 50%;
  cursor: pointer;
  font-size: 26px;
  line-height: 1;
  color: #fff;
  background: rgba(28, 21, 48, 0.4);
  backdrop-filter: blur(4px);
  transition: 0.22s;
}
.h-nav:hover {
  background: rgba(28, 21, 48, 0.7);
}
.h-nav.prev {
  left: 16px;
}
.h-nav.next {
  right: 16px;
}
.h-dots {
  position: absolute;
  z-index: 3;
  right: 30px;
  bottom: 26px;
  display: flex;
  gap: 8px;
}
.h-dots span {
  width: 9px;
  height: 9px;
  border-radius: 50%;
  background: rgba(255, 255, 255, 0.45);
  cursor: pointer;
  transition: 0.25s;
}
.h-dots span.on {
  width: 26px;
  border-radius: 999px;
  background: #fff;
}

/* ============ 视频播放器 ============ */
.player-section {
  margin-bottom: 34px;
}
.player-card {
  display: grid;
  grid-template-columns: 1.55fr 1fr;
  border-radius: var(--radius);
  overflow: hidden;
  background: var(--glass);
  border: 1px solid rgba(255, 255, 255, 0.7);
  box-shadow: 0 30px 70px -34px rgba(90, 60, 140, 0.45);
  backdrop-filter: blur(20px);
  -webkit-backdrop-filter: blur(20px);
}
.player-wrap {
  position: relative;
  background: #1c1530;
  min-height: 300px;
}
.player {
  width: 100%;
  height: 100%;
  display: block;
  object-fit: cover;
  background: #1c1530;
}
.live-badge {
  position: absolute;
  top: 14px;
  left: 14px;
  padding: 5px 12px;
  border-radius: 999px;
  font-size: 10.5px;
  font-weight: 700;
  letter-spacing: 0.12em;
  color: #fff;
  background: rgba(244, 63, 94, 0.85);
  backdrop-filter: blur(4px);
}
.player-info {
  padding: 24px 26px;
  display: flex;
  flex-direction: column;
}
.tags {
  display: flex;
  flex-wrap: wrap;
  gap: 8px;
  margin-bottom: 12px;
}
.tag {
  padding: 5px 12px;
  border-radius: 999px;
  font-size: 11.5px;
  font-weight: 600;
  color: #8b5cf6;
  background: rgba(255, 255, 255, 0.8);
  border: 1px solid rgba(192, 132, 252, 0.3);
}
.v-title {
  font-size: 18px;
  font-weight: 800;
  line-height: 1.45;
  margin-bottom: 12px;
}
.stats {
  display: flex;
  flex-wrap: wrap;
  gap: 16px;
  margin-bottom: 14px;
  color: var(--ink-soft);
  font-size: 12.5px;
}
.stats span {
  display: inline-flex;
  align-items: center;
  gap: 6px;
}
.v-desc {
  font-size: 13px;
  line-height: 1.8;
  color: var(--ink-soft);
  margin-bottom: 20px;
}
.actions {
  display: flex;
  flex-wrap: wrap;
  gap: 10px;
  margin-top: auto;
}
.btn {
  display: inline-flex;
  align-items: center;
  gap: 8px;
  height: 44px;
  padding: 0 22px;
  border-radius: 14px;
  border: 0;
  cursor: pointer;
  font-size: 13.5px;
  font-weight: 700;
  letter-spacing: 0.04em;
  transition: transform 0.22s, box-shadow 0.22s, background 0.22s;
}
.btn.primary {
  color: #fff;
  background: var(--grad);
  background-size: 220% 100%;
  box-shadow: 0 14px 28px -12px rgba(192, 132, 252, 0.95);
}
.btn.primary:hover {
  transform: translateY(-2px);
  background-position: 100% 0;
}
.btn.ghost {
  color: var(--accent);
  background: rgba(255, 255, 255, 0.8);
  border: 1.5px solid var(--line);
}
.btn.ghost:hover {
  transform: translateY(-2px);
  background: #fff;
  border-color: #e3d4ff;
}

/* ============ 主区 + 侧栏 ============ */
.layout {
  display: grid;
  grid-template-columns: 1fr 320px;
  gap: 26px;
  align-items: start;
}
.block {
  margin-bottom: 30px;
}
.main-col .grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(220px, 1fr));
  gap: 18px;
}

/* 视频卡 */
.v-card {
  border-radius: 18px;
  overflow: hidden;
  background: var(--glass);
  border: 1px solid rgba(255, 255, 255, 0.7);
  box-shadow: 0 18px 40px -28px rgba(90, 60, 140, 0.5);
  backdrop-filter: blur(14px);
  -webkit-backdrop-filter: blur(14px);
  cursor: pointer;
  transition: transform 0.26s cubic-bezier(0.2, 0.8, 0.25, 1), box-shadow 0.26s, border-color 0.26s;
}
.v-card:hover {
  transform: translateY(-6px);
  box-shadow: 0 26px 50px -26px rgba(90, 60, 140, 0.6);
  border-color: #e3d4ff;
}
.v-card.on {
  border-color: transparent;
  box-shadow: 0 0 0 2px #c084fc, 0 22px 46px -22px rgba(192, 132, 252, 0.8);
}
.thumb {
  position: relative;
  aspect-ratio: 16 / 9;
  display: grid;
  place-items: center;
  overflow: hidden;
}
.thumb .t-img {
  position: absolute;
  inset: 0;
  width: 100%;
  height: 100%;
  object-fit: cover;
  display: block;
  transition: transform 0.5s cubic-bezier(0.2, 0.8, 0.25, 1);
}
.v-card:hover .thumb .t-img {
  transform: scale(1.06);
}
.thumb .play {
  position: relative;
  z-index: 1;
  width: 50px;
  height: 50px;
  border-radius: 50%;
  background: rgba(255, 255, 255, 0.92);
  display: grid;
  place-items: center;
  box-shadow: 0 10px 24px -8px rgba(47, 36, 69, 0.5);
  transition: transform 0.26s, background 0.26s;
}
.v-card:hover .play {
  transform: scale(1.12);
  background: #fff;
}
.thumb .dur {
  position: absolute;
  right: 10px;
  bottom: 10px;
  padding: 3px 9px;
  border-radius: 8px;
  font-size: 11px;
  font-weight: 700;
  color: #fff;
  background: rgba(28, 21, 48, 0.7);
  backdrop-filter: blur(3px);
}
.v-body {
  padding: 13px 15px 15px;
}
.v-name {
  font-size: 13.5px;
  font-weight: 700;
  line-height: 1.5;
  color: var(--ink);
  display: -webkit-box;
  -webkit-line-clamp: 2;
  -webkit-box-orient: vertical;
  overflow: hidden;
}
.v-up {
  font-size: 12px;
  color: var(--accent);
  margin-top: 7px;
  font-weight: 600;
}
.v-count {
  font-size: 11.5px;
  color: var(--ink-soft);
  margin-top: 4px;
}

/* 番剧分类 Tab */
.cat-tabs {
  display: flex;
  gap: 6px;
  margin-left: auto;
}
.cat-tabs span {
  padding: 6px 14px;
  border-radius: 999px;
  font-size: 12.5px;
  font-weight: 600;
  color: var(--ink-soft);
  background: rgba(255, 255, 255, 0.6);
  border: 1px solid var(--line);
  cursor: pointer;
  user-select: none;
  transition: 0.2s;
}
.cat-tabs span:hover {
  color: var(--accent);
  border-color: #e3d4ff;
}
.cat-tabs span.on {
  color: #fff;
  background: var(--grad);
  border-color: transparent;
  box-shadow: 0 8px 18px -8px rgba(192, 132, 252, 0.9);
}

/* 番剧海报墙（竖版海报 + 下方标题） */
.poster-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(148px, 1fr));
  gap: 16px;
}
.p-card {
  cursor: pointer;
  transition: transform 0.26s cubic-bezier(0.2, 0.8, 0.25, 1);
}
.p-card:hover {
  transform: translateY(-5px);
}
.poster {
  position: relative;
  aspect-ratio: 3 / 4;
  border-radius: 14px;
  overflow: hidden;
  box-shadow: 0 14px 30px -18px rgba(90, 60, 140, 0.6);
  transition: box-shadow 0.26s;
}
.p-card:hover .poster {
  box-shadow: 0 20px 38px -16px rgba(90, 60, 140, 0.75);
}
/* 番剧插画 */
.poster .p-img {
  position: absolute;
  inset: 0;
  width: 100%;
  height: 100%;
  object-fit: cover;
  display: block;
  transition: transform 0.5s cubic-bezier(0.2, 0.8, 0.25, 1);
}
.p-card:hover .poster .p-img {
  transform: scale(1.06);
}
/* 底部压暗，保证分数可读 */
.poster .p-shade {
  position: absolute;
  left: 0;
  right: 0;
  bottom: 0;
  height: 42%;
  pointer-events: none;
  background: linear-gradient(0deg, rgba(28, 21, 48, 0.5), transparent);
}
.p-status {
  position: absolute;
  top: 9px;
  left: 9px;
  padding: 3px 9px;
  border-radius: 999px;
  font-size: 10px;
  font-weight: 700;
  color: #fff;
  background: rgba(244, 63, 94, 0.88);
  backdrop-filter: blur(3px);
}
.p-score {
  position: absolute;
  left: 9px;
  bottom: 9px;
  padding: 3px 9px;
  border-radius: 999px;
  font-size: 10.5px;
  font-weight: 800;
  color: #fff;
  background: rgba(28, 21, 48, 0.6);
  backdrop-filter: blur(3px);
}
.p-name {
  font-size: 13px;
  font-weight: 700;
  color: var(--ink);
  margin-top: 9px;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}
.p-sub {
  font-size: 11px;
  color: var(--ink-soft);
  margin-top: 3px;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}

/* ============ 分级分类筛选栏 ============ */
.filter-bar {
  display: flex;
  flex-direction: column;
  gap: 10px;
  margin-bottom: 20px;
  padding: 14px 16px;
  border-radius: 16px;
  background: var(--glass);
  border: 1px solid rgba(255, 255, 255, 0.7);
  box-shadow: 0 16px 36px -30px rgba(90, 60, 140, 0.5);
  backdrop-filter: blur(14px);
  -webkit-backdrop-filter: blur(14px);
}
.f-row {
  display: flex;
  align-items: center;
  flex-wrap: wrap;
  gap: 8px;
}
.f-label {
  font-size: 11.5px;
  font-weight: 700;
  color: var(--ink-soft);
  letter-spacing: 0.08em;
  flex-shrink: 0;
  min-width: 32px;
}
.f-label.ml {
  margin-left: 10px;
}
.f-group {
  display: flex;
  flex-wrap: wrap;
  gap: 6px;
}
.f-chip {
  display: inline-flex;
  align-items: center;
  gap: 4px;
  padding: 5px 12px;
  border-radius: 999px;
  font-size: 12px;
  font-weight: 600;
  color: var(--ink-soft);
  background: rgba(255, 255, 255, 0.62);
  border: 1px solid var(--line);
  cursor: pointer;
  user-select: none;
  transition: 0.2s;
}
.f-chip:hover {
  color: var(--accent);
  border-color: #e3d4ff;
}
.f-chip.on {
  color: #fff;
  background: var(--grad);
  border-color: transparent;
  box-shadow: 0 6px 14px -7px rgba(192, 132, 252, 0.9);
}
.f-chip.sub {
  padding: 4px 11px;
  font-size: 11.5px;
}
.f-chip.hot {
  color: #b42318;
  background: rgba(255, 228, 230, 0.85);
  border-color: rgba(244, 63, 94, 0.28);
}
.f-chip.hot:hover {
  color: #fff;
  background: rgba(244, 63, 94, 0.85);
}
.f-num {
  font-style: normal;
  font-size: 10px;
  opacity: 0.7;
}
.f-clear {
  margin-left: auto;
  border: 0;
  cursor: pointer;
  padding: 5px 12px;
  border-radius: 999px;
  font-size: 11.5px;
  font-weight: 600;
  color: var(--ink-soft);
  background: rgba(255, 255, 255, 0.6);
  border: 1px solid var(--line);
  transition: 0.2s;
}
.f-clear:hover {
  color: #f43f5e;
  border-color: #ffc2d2;
  background: #fff;
}

/* ============ 分页 ============ */
.pager {
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 16px;
  margin-top: 22px;
}
.pg-btn {
  height: 34px;
  padding: 0 18px;
  border-radius: 999px;
  border: 1.5px solid var(--line);
  background: rgba(255, 255, 255, 0.75);
  color: var(--accent);
  font-size: 12.5px;
  font-weight: 700;
  cursor: pointer;
  transition: 0.2s;
}
.pg-btn:hover:not(:disabled) {
  color: #fff;
  background: var(--grad);
  border-color: transparent;
  box-shadow: 0 8px 16px -8px rgba(192, 132, 252, 0.9);
}
.pg-btn:disabled {
  opacity: 0.4;
  cursor: not-allowed;
}
.pg-info {
  font-size: 12.5px;
  font-weight: 700;
  color: var(--ink-soft);
}

/* ============ 站点统计 ============ */
.stat-grid {
  display: grid;
  grid-template-columns: repeat(4, 1fr);
  gap: 8px;
}
.st-item {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 3px;
  padding: 10px 4px;
  border-radius: 12px;
  background: rgba(255, 255, 255, 0.5);
}
.st-num {
  font-size: 15px;
  font-weight: 900;
  color: var(--accent);
  line-height: 1.2;
}
.st-label {
  font-size: 10.5px;
  color: var(--ink-soft);
}

/* 侧栏 */
.side-col .block {
  background: var(--glass);
  border: 1px solid rgba(255, 255, 255, 0.7);
  border-radius: 18px;
  padding: 16px 16px 18px;
  box-shadow: 0 18px 40px -30px rgba(90, 60, 140, 0.5);
  backdrop-filter: blur(14px);
  -webkit-backdrop-filter: blur(14px);
}
.side-rank {
  display: flex;
  flex-direction: column;
  gap: 4px;
}
.sr-row {
  display: flex;
  align-items: center;
  gap: 12px;
  padding: 8px 8px;
  border-radius: 12px;
  cursor: pointer;
  transition: 0.2s;
}
.sr-row:hover {
  background: rgba(255, 255, 255, 0.55);
}
.sr-no {
  width: 22px;
  text-align: center;
  font-size: 16px;
  font-weight: 900;
  font-style: italic;
  color: var(--ink-soft);
  flex-shrink: 0;
}
.sr-row.top1 .sr-no {
  color: #ffb020;
}
.sr-row.top2 .sr-no {
  color: #9ca3ff;
}
.sr-row.top3 .sr-no {
  color: #ff9a76;
}
.sr-name {
  font-size: 13px;
  font-weight: 700;
  color: var(--ink);
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}
.sr-views {
  font-size: 11px;
  color: var(--ink-soft);
  margin-top: 2px;
}

.week-tabs {
  display: flex;
  gap: 4px;
  margin-bottom: 12px;
}
.wt {
  flex: 1;
  text-align: center;
  padding: 6px 0;
  border-radius: 9px;
  font-size: 12px;
  font-weight: 600;
  color: var(--ink-soft);
  background: rgba(255, 255, 255, 0.5);
  cursor: default;
}
.wt.on {
  color: #fff;
  background: var(--grad);
}
.sched-list {
  list-style: none;
  display: flex;
  flex-direction: column;
  gap: 2px;
}
.sched-list li {
  display: flex;
  align-items: center;
  gap: 10px;
  padding: 9px 6px;
  border-bottom: 1px dashed var(--line);
  font-size: 12.5px;
}
.sched-list li:last-child {
  border-bottom: 0;
}
.sc-time {
  font-weight: 800;
  color: var(--accent);
  width: 44px;
  flex-shrink: 0;
}
.sc-title {
  flex: 1;
  color: var(--ink);
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}
.sc-ep {
  font-size: 11px;
  color: var(--ink-soft);
  flex-shrink: 0;
}
.sc-none {
  color: var(--ink-soft);
  justify-content: center;
}

/* 加载失败提示条 */
.err-bar {
  display: flex;
  align-items: center;
  justify-content: space-between;
  flex-wrap: wrap;
  gap: 14px;
  margin: 0 0 22px;
  padding: 14px 18px;
  border-radius: 16px;
  font-size: 13px;
  color: #b42318;
  background: rgba(255, 228, 230, 0.9);
  border: 1px solid rgba(244, 63, 94, 0.35);
}
.err-bar.warn {
  color: #92400e;
  background: rgba(254, 243, 199, 0.9);
  border-color: rgba(245, 158, 11, 0.4);
}
.err-bar .btn {
  height: 36px;
  padding: 0 16px;
  font-size: 12.5px;
  flex-shrink: 0;
}

.empty {
  text-align: center;
  padding: 50px 0;
  color: var(--ink-soft);
}
.empty p {
  font-size: 14px;
}
.foot {
  text-align: center;
  font-size: 11.5px;
  color: var(--ink-soft);
  margin-top: 20px;
  letter-spacing: 0.04em;
}

/* ============ 响应式 ============ */
@media (max-width: 980px) {
  .layout {
    grid-template-columns: 1fr;
  }
  .player-card {
    grid-template-columns: 1fr;
  }
  .player-wrap {
    min-height: 220px;
  }
  .sec-head {
    flex-wrap: wrap;
  }
  .cat-tabs {
    margin-left: 0;
    width: 100%;
  }
}
@media (max-width: 720px) {
  .hero {
    height: 320px;
  }
  .slide-content {
    padding: 0 0 30px 22px;
  }
  .h-title {
    font-size: 24px;
  }
  .h-nav {
    display: none;
  }
  .slide-art {
    width: 72%;
    opacity: 0.7;
  }
}
@media (prefers-reduced-motion: reduce) {
  .page,
  .slide {
    animation: none !important;
    transition: opacity 0.3s !important;
  }
}
</style>
