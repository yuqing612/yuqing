import { defineConfig } from 'vite'
import vue from '@vitejs/plugin-vue'

// 本机局域网 IP（以太网适配器 以太网 的 IPv4）。
// 改成 0.0.0.0 可同时兼容本机与局域网；写死具体 IP 则仅该地址可访问。
const HOST = '192.168.68.15'
const API_TARGET = 'http://192.168.68.15:8081'

export default defineConfig({
  plugins: [vue()],
  server: {
    /* 绑定局域网 IPv4：默认 localhost 在 Node 17+ 会优先解析到 ::1，
       导致浏览器访问 127.0.0.1 时连不上（本机代理返回 502）；
       写成本机 IP 后，同网段手机 / 模拟器也能直接打开调试页。 */
    host: HOST,
    port: 5173,
    open: true,
    proxy: {
      '/api': {
        target: API_TARGET,
        changeOrigin: true
      }
    }
  },
  build: {
    outDir: 'dist',
    assetsInlineLimit: 4096
  }
})
