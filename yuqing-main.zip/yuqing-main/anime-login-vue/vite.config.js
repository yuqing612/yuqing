import { defineConfig } from 'vite'
import vue from '@vitejs/plugin-vue'
import os from 'node:os'

// 探测本机局域网 IPv4（以太网适配器 的 IPv4），供手机 / 模拟器访问调试页。
// 探测失败时退回 127.0.0.1，保证前端至少本机可用。
function detectLanIp() {
  const nets = os.networkInterfaces()
  for (const name of Object.keys(nets)) {
    for (const net of nets[name] || []) {
      if (net.family === 'IPv4' && !net.internal) return net.address
    }
  }
  return '127.0.0.1'
}

const LAN_IP = detectLanIp()

// 后端代理目标：走本机回环地址，不依赖局域网 IP 是否变动。
// 后端已监听 0.0.0.0:8081，127.0.0.1 一定能连上。
const API_TARGET = 'http://127.0.0.1:8081'

export default defineConfig({
  plugins: [vue()],
  server: {
    /* 绑定 0.0.0.0：本机与同网段手机 / 模拟器都能访问。
       默认 localhost 在 Node 17+ 会优先解析到 ::1，导致浏览器访问
       127.0.0.1 时连不上（本机代理返回 502）。 */
    host: '0.0.0.0',
    port: 5173,
    open: true,
    proxy: {
      '/api': {
        target: API_TARGET,
        changeOrigin: true
      }
    }
  },
  build: {
    outDir: 'dist',
    assetsInlineLimit: 4096
  }
})
