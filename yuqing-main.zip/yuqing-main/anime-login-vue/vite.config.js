import { defineConfig } from 'vite'
import vue from '@vitejs/plugin-vue'

// 本机对外访问 IP（以太网适配器 以太网 的 IPv4）。
// 用途：手机 / 模拟器与本机同网段时，通过这个地址访问前端页面与后端接口。
// 换网络导致 IP 变动时，只需改这一处；也可用环境变量 LOCAL_IP 临时覆盖。
const LOCAL_IP = process.env.LOCAL_IP || '192.168.68.15'

// 后端代理目标：指向本机 IP。
// 后端 server.address 绑的是 0.0.0.0（全网卡），走 192.168.68.15 或
// 127.0.0.1 都能连上；这里用局域网 IP，避免 localhost 在 Node 17+ 优先
// 解析到 ::1 导致代理返回 502。
const API_TARGET = `http://${LOCAL_IP}:8081`

export default defineConfig({
  plugins: [vue()],
  server: {
    /* 绑定 0.0.0.0：本机与同网段手机 / 模拟器都能访问。
       默认 localhost 在 Node 17+ 会优先解析到 ::1，导致浏览器访问
       127.0.0.1 时连不上（本机代理返回 502）。 */
    host: '0.0.0.0',
    port: 5173,
    open: true,
    proxy: {
      '/api': {
        target: API_TARGET,
        changeOrigin: true
      }
    }
  },
  build: {
    outDir: 'dist',
    assetsInlineLimit: 4096
  }
})
