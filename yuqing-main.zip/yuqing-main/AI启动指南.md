# AI 启动指南（给 AI 助手看的，不是给人看的）

> 目的：每次开机后让 AI 在 1 分钟内把项目跑起来，不要重新探索环境。
> 最后验证时间：2026-10-10，全部实测通过。

## 项目是什么
- 日漫风格登录/注册系统：`anime-login-vue`（Vue3 + Vite 前端）+ `springBootTest`（Spring Boot 3 + MyBatis-Plus + JWT 后端）+ MySQL。
- 前端端口 **5173**，后端端口 **8081**（profile=dev），vite 已配置 `/api` → `http://localhost:8081` 代理。
- 测试账号：`sakura / Test@123456`（后端启动时自动初始化，无需手工插数据）。
- 密码规则：6-15 位，须含数字、大小写字母、特殊字符。

## 这台电脑的事实（已验证，不要重新检查）
- Windows，用户 Administrator，Node v22 + npm 10 在 PATH，直接可用。
- Java 21（Zulu）在 PATH，`JAVA_HOME` 已配置。pom 写的 java 17，用 21 跑没问题。
- **`mvn` 不在 PATH**，必须用 `springBootTest\mvnw.cmd`。wrapper 发行版和全部依赖已缓存在 `~/.m2`，离线可编译。
- MySQL 8.0 已安装并作为服务常驻（3306）。mysql CLI 不在 PATH，完整路径：`C:\Program Files\MySQL\MySQL Server 8.0\bin\mysql.exe`
- 数据库 `yuqing_db`、`sys_user` 表、应用账号 `yuqing/123456` 全部已就绪。**不要重跑 yuqing_db.sql。**
- **每次开机会删除 `node_modules` 和 `target`，其他都保留**（含 ~/.m2、npm 缓存），所以脚本里必须先判断再装依赖。

## 每次开机要做的事（按顺序，别多做）
1. 运行项目根目录的 `启动项目.bat`（双击或命令行均可）。它做的事：
   - 检查 MySQL 3306 是否在听；
   - 后端新窗口：`cd springBootTest && mvnw.cmd spring-boot:run`；
   - 前端：若 `node_modules` 不存在先 `npm install`，再新窗口 `npm run dev`。
2. 验证：`netstat -ano | findstr "LISTENING"` 里 8081 和 5173 都在即成功；浏览器开 http://localhost:5173 。后端首次编译约 30 秒属正常。
3. 停止：运行 `停止项目.bat`（按端口杀 8081/5173 进程，不动 MySQL）。

## 不要做
- 不要重装 maven / mysql / jdk，全都有。
- 不要重跑 `yuqing_db.sql`（表已存在，跑了无害但没必要）。
- 不要在沙盒里调 `sc.exe`（被安全策略阻止）；查 MySQL 用 netstat 看 3306。
- bat 脚本必须保持 **GBK 编码**，改完若用 UTF-8 保存中文会乱码。

## 已知小毛病（不影响运行，别顺手修，用户说要修再修）
- `README.md` 基本是空的。
- `application-prob.properties` 是 `prod` 的拼写错误，但没人用它。
- `application.properties` 里 `logging.pattern.file` 那行把 key 写进了 value，日志文件格式不生效。
